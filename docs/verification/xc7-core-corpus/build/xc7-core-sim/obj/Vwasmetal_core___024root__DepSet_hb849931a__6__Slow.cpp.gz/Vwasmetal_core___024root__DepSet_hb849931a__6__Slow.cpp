#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__5(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__5\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___019356_;
    wasmetal_core__DOT___019356_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049641_;
    wasmetal_core__DOT___049641_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051292_;
    wasmetal_core__DOT___051292_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051636_;
    wasmetal_core__DOT___051636_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052602_;
    wasmetal_core__DOT___052602_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053655_;
    wasmetal_core__DOT___053655_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069655_;
    wasmetal_core__DOT___069655_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127827___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127827___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127835___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127835___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128148___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128148___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128164___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128164___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128197___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128197___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128214___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128214___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128427___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128427___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128672___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128672___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128711___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128711___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135451___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___135451___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135467___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___135467___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h8e6178a2__0;
    __VdfgTmp_h8e6178a2__0 = 0;
    CData/*1:0*/ __VdfgTmp_h40aa5d33__0;
    __VdfgTmp_h40aa5d33__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___031356_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 3U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031355_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031352_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031330_ = (1U & (0xf40bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051564_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071847_))))));
    vlSelf->wasmetal_core__DOT___053436_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053091_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5c8f7b91__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052834_)))));
    vlSelf->wasmetal_core__DOT___053572_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052834_))));
    vlSelf->wasmetal_core__DOT___052650_ = (1U & (0x1f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052649_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048516_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052643_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048433_))))));
    vlSelf->wasmetal_core__DOT___053619_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053613_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h56fc5986__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052987_)))));
    vlSelf->wasmetal_core__DOT___063445_ = (1U & (IData)(
                                                         (0xa03fafc0a000a00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->mem_fault) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0faaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h56fc5986__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052953_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0ff1168c__0))))))))))))))));
    wasmetal_core__DOT___019356_ = (1U & (0xca00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h56fc5986__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052953_))))));
    vlSelf->wasmetal_core__DOT___053479_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h56fc5986__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128594___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033933_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b7__05d) {
        vlSelf->wasmetal_core__DOT___033937_ = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
        vlSelf->wasmetal_core__DOT___032959_ = vlSelf->wasmetal_core__DOT__sp__05b7__05d;
    } else {
        vlSelf->wasmetal_core__DOT___033937_ = vlSelf->wasmetal_core__DOT___128594___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___032959_ = vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128491___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128491___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032955_)))));
    vlSelf->wasmetal_core__DOT___054639_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_wide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052805_))));
    vlSelf->wasmetal_core__DOT___053347_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053334_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha85820a5__0))));
    vlSelf->wasmetal_core__DOT___039819_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128222___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039798_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128222___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039797_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128222___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039780_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128222___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___048210_ = (1U & (0xa008aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->insn_op) 
                                                         | (IData)(vlSelf->__VdfgTmp_h50379cea__0))))));
    vlSelf->wasmetal_core__DOT___048430_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045703_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044168_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___045715_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___044180_))))));
    vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_z >> 8U) & (IData)(vlSelf->wasmetal_core__DOT___027958_));
    vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x100U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 8U) : (IData)(vlSelf->wasmetal_core__DOT___030493_)));
    vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b8__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027733_));
    vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___028023_));
    vlSelf->wasmetal_core__DOT___128157___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029314_));
    vlSelf->wasmetal_core__DOT___128190___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b8__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029676_));
    vlSelf->wasmetal_core__DOT___128207___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b8__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029845_));
    vlSelf->wasmetal_core__DOT___128372___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031615_));
    vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032096_));
    vlSelf->wasmetal_core__DOT___039831_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128275___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039822_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128275___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039823_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128275___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 4U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039830_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128275___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 5U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___128276___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030588_));
    vlSelf->wasmetal_core__DOT___039411_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128223___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039775_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128223___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039794_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128223___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039793_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128223___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___128224___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b8__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___030014_));
    wasmetal_core__DOT___128214___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029942_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128214___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b6__05d));
    vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032894_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d));
    vlSelf->wasmetal_core__DOT___127996___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128944___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___027668_));
    wasmetal_core__DOT___128197___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029773_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128197___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b6__05d));
    wasmetal_core__DOT___128164___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029410_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128164___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b6__05d));
    vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027829_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b6__05d));
    vlSelf->wasmetal_core__DOT___062673_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128256___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062684_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128256___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062695_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128256___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062706_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128256___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___128257___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030374_));
    vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_x >> 8U) & (IData)(vlSelf->wasmetal_core__DOT___028184_));
    wasmetal_core__DOT___128148___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029249_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128148___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d));
    vlSelf->wasmetal_core__DOT___128020___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027894_));
    vlSelf->wasmetal_core__DOT___044760_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & vlSelf->function_locals) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                                        >> 1U)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 6U)))))))));
    vlSelf->wasmetal_core__DOT___044772_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_locals 
                                                                  >> 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 4U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 5U))))))))));
    vlSelf->wasmetal_core__DOT___044759_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_locals 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 3U)))))))));
    vlSelf->wasmetal_core__DOT___044771_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & vlSelf->function_locals) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__0__KET__ 
        = ((~ (vlSelf->function_params >> 8U)) & (IData)(vlSelf->wasmetal_core__DOT___030975_));
    vlSelf->wasmetal_core__DOT___071595_ = (1U & (0x1f000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071578_) 
                                                    << 4U) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                      << 3U))));
    vlSelf->wasmetal_core__DOT___071593_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x7000U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                           << 3U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___071578_) 
                                                             << 2U)))))));
    vlSelf->wasmetal_core__DOT___071601_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071578_))));
    vlSelf->wasmetal_core__DOT___071678_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b36__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071677_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___071711_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b100__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071677_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___071653_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b20__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb8bcf48d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___071691_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b52__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb8bcf48d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___071708_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b84__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb8bcf48d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___071714_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b116__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb8bcf48d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019434_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071588_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071587_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h891b440b__0))))))));
    vlSelf->__VdfgTmp_hce6e76ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___071587_) 
                                       << 1U) | (1U 
                                                 & (0x4fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                      << 4U) 
                                                     | ((8U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                            << 3U)) 
                                                        | ((4U 
                                                            & ((0x8fU 
                                                                >> 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                                 << 2U)) 
                                                               << 2U)) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                              << 1U)))))));
    vlSelf->wasmetal_core__DOT___071607_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b5__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                                    << 1U)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((0x8fU 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___071578_) 
                                                                       << 2U)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071606_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h891b440b__0))))))));
    vlSelf->__VdfgTmp_h9972469d__0 = (((IData)(vlSelf->wasmetal_core__DOT___071606_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x700000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                 << 3U) 
                                                                | (4U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                      << 2U))))))));
    vlSelf->wasmetal_core__DOT___071618_ = (1U & (IData)(
                                                         (0x7f007f7f7f7f7f7fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___071578_) 
                                                                 << 1U)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___071582_) 
                                                                    << 1U)) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071616_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (8U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                              >> 2U)))))))))));
    vlSelf->__VdfgTmp_hb635a29b__0 = (((IData)(vlSelf->wasmetal_core__DOT___071616_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x100000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                 << 3U) 
                                                                | (4U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                      << 2U))))))));
    vlSelf->__VdfgTmp_hc7c7e46f__0 = (((IData)(vlSelf->wasmetal_core__DOT___071642_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)));
    vlSelf->__VdfgTmp_h35a843b1__0 = (((IData)(vlSelf->wasmetal_core__DOT___071602_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)));
    vlSelf->__VdfgTmp_hfffbe48f__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                      | (1U & (IData)(
                                                      (0xff7f80ffffffffffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_he7466e08__0)))));
    vlSelf->__VdfgTmp_hd1e6ff3c__0 = (((IData)(vlSelf->wasmetal_core__DOT___071594_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x1f00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_he7466e08__0)))));
    vlSelf->wasmetal_core__DOT___071673_ = (1U & (0xfffa3fffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hce5a5a6e__0))))));
    vlSelf->__VdfgTmp_hd54e1937__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hce5a5a6e__0));
    vlSelf->__VdfgTmp_h5b134ff6__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071610_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x10U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___071583_) 
                                                             << 2U))))))));
    vlSelf->wasmetal_core__DOT___071611_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071610_))));
    vlSelf->__VdfgTmp_h017bc299__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 1U)) 
                                      | (1U & (0x807fffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h3a1fe2e7__0))));
    vlSelf->__VdfgTmp_hce90a299__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 1U)) 
                                      | (1U & (0xf807ffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h3a1fe2e7__0))));
    vlSelf->__VdfgTmp_h79503a99__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 1U)) 
                                      | (1U & (0xfe01ffffU 
                                               >> (IData)(vlSelf->__VdfgTmp_h3a1fe2e7__0))));
    wasmetal_core__DOT___128427___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032222_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128427___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d));
    vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032702_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d));
    vlSelf->wasmetal_core__DOT___066179_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___066997_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 0xfU))))));
    vlSelf->wasmetal_core__DOT___067555_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066369_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065565_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064973_)))));
    vlSelf->wasmetal_core__DOT___065266_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064249_))));
    vlSelf->wasmetal_core__DOT___065570_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065568_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065566_))))));
    vlSelf->wasmetal_core__DOT___066371_ = (1U & (0x7f000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065558_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h92a0f8b0__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)))))))));
    vlSelf->wasmetal_core__DOT___069285_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065647_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___069342_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065842_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___069392_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066020_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 5U))))));
    vlSelf->wasmetal_core__DOT___069418_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066176_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 6U))))));
    vlSelf->wasmetal_core__DOT___069315_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065755_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___069474_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065572_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 8U)))))));
    vlSelf->wasmetal_core__DOT___070100_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066176_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 4U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76d711b0__0))))))));
    vlSelf->wasmetal_core__DOT___070070_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065975_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 1U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76d711b0__0))))))));
    vlSelf->wasmetal_core__DOT___070086_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066020_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 2U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 3U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76d711b0__0))))))));
    vlSelf->wasmetal_core__DOT___070263_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066457_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068537_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 0x11U))))))));
    vlSelf->wasmetal_core__DOT___069808_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066943_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069653_))));
    vlSelf->wasmetal_core__DOT___070337_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066943_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067563_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0x15U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x16U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___070249_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066375_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xdU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xeU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))))));
    wasmetal_core__DOT___069655_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___066375_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___069653_))));
    vlSelf->wasmetal_core__DOT___069721_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066556_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069653_))));
    vlSelf->wasmetal_core__DOT___070287_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066556_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067563_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0x11U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x12U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___069764_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066724_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069653_))));
    vlSelf->wasmetal_core__DOT___070313_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066724_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x12U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x13U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))))));
    vlSelf->wasmetal_core__DOT___069831_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066996_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x15U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x16U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))));
    vlSelf->wasmetal_core__DOT___070325_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066809_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068773_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 0x16U))))))));
    vlSelf->wasmetal_core__DOT___070402_ = (1U & (0x700U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067264_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069059_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[1U] 
                                                               >> 0x1cU)))))));
    vlSelf->wasmetal_core__DOT___069748_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066670_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069743_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069742_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069653_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0xcU))))))))));
    vlSelf->wasmetal_core__DOT___070299_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066670_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068675_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 0x14U))))))));
    vlSelf->wasmetal_core__DOT___070275_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066480_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068576_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 0x12U))))))));
    vlSelf->wasmetal_core__DOT___070056_ = (1U & (0x77070000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070053_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___070115_ = (1U & (0x77070000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070112_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 5U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 6U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___067626_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067623_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067622_)))));
    vlSelf->wasmetal_core__DOT___067775_ = (1U & (0xd000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067772_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___069061_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067833_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069059_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067262_)))));
    vlSelf->wasmetal_core__DOT___067989_ = (1U & (0xd000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067986_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 7U)))))));
    vlSelf->wasmetal_core__DOT___067867_ = (1U & (0xd000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067864_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 5U)))))));
    vlSelf->wasmetal_core__DOT___068539_ = (1U & (IData)(
                                                         (0xd000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067623_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068537_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066456_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x19U))))))))));
    vlSelf->wasmetal_core__DOT___068777_ = (1U & (IData)(
                                                         (0xd000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067935_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068773_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066808_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x1eU))))))))));
    vlSelf->wasmetal_core__DOT___068495_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067569_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xeU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1936621__0))))))));
    vlSelf->wasmetal_core__DOT___068580_ = (1U & (IData)(
                                                         (0xd000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067704_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068576_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066479_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x1aU))))))))));
    vlSelf->wasmetal_core__DOT___068680_ = (1U & (IData)(
                                                         (0xd000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067833_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068675_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066669_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x1cU))))))))));
    vlSelf->wasmetal_core__DOT___068619_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067772_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & vlSelf->mem_rdata[0U]) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x11U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1936621__0))))))));
    vlSelf->wasmetal_core__DOT___068716_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067864_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 2U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x13U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1936621__0))))))));
    vlSelf->wasmetal_core__DOT___068816_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067986_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 4U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x15U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1936621__0))))))));
    vlSelf->wasmetal_core__DOT___068870_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[0U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___019393_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065586_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065585_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065584_)))));
    vlSelf->wasmetal_core__DOT___070132_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070130_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 5U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x16U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068124_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067623_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 6U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x17U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068447_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067986_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xcU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1dU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068378_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067935_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xbU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1cU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068182_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067704_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 7U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x18U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068209_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067772_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 8U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x19U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068316_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067864_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xaU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1bU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___070147_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070014_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070144_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 6U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x17U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___070174_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070053_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070171_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 8U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x19U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___070161_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070036_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070158_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 7U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x18U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___070235_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070112_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070232_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xcU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x1dU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068055_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067569_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 5U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x16U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068269_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067833_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 9U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1aU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___067774_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070055_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070114_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070099_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070069_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___067866_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___070085_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___067625_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->wasmetal_core__DOT___067574_ = (1U & (0xd000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067569_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067567_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067566_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0x10U))))))));
    vlSelf->wasmetal_core__DOT___067708_ = (1U & (0xd000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067704_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067703_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067566_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0x12U))))))));
    vlSelf->wasmetal_core__DOT___067988_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067566_))));
    vlSelf->__VdfgTmp_hf22e2068__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___067566_));
    vlSelf->__VdfgTmp_h84a22723__0 = (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___067566_));
    vlSelf->wasmetal_core__DOT___069473_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067558_))));
    vlSelf->__VdfgTmp_h753cf8b1__0 = (((IData)(vlSelf->wasmetal_core__DOT___067558_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___069260_));
    vlSelf->wasmetal_core__DOT___067560_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065567_))));
    vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037212_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h0d1b5516__0))));
    wasmetal_core__DOT___128672___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034658_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128711___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035144_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128711___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b5__05d));
    vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b5__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127835___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026289_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127835___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b6__05d));
    wasmetal_core__DOT___127827___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026193_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127827___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d));
    vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026385_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b6__05d));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b0__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054482_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b1__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054484_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128474___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032827_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032824_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032813_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032802_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032795_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032827_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128474___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT___032831_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032830_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b6__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032829_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b5__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032828_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O)))));
    vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032992_));
    wasmetal_core__DOT___135451___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___046798_) 
           & (IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128330___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031170_) 
           | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b0__05d));
    vlSelf->wasmetal_core__DOT___128354___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031458_) 
           | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b0__05d));
    vlSelf->wasmetal_core__DOT___128442___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032481_) 
           | (IData)(vlSelf->wasmetal_core__DOT___032353_));
    wasmetal_core__DOT___135467___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___046931_) 
           & (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___065162_ = (1U & (IData)(
                                                         (0x7fff00007fff7fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065161_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (1U 
                                                                              & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___048562_)))))))))))));
    vlSelf->wasmetal_core__DOT___050483_ = (1U & (0x440f0f0fU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h558c6a5e__0))));
    vlSelf->wasmetal_core__DOT___049334_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8e945c96__0))));
    vlSelf->wasmetal_core__DOT___051609_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h41349efa__0))));
    vlSelf->wasmetal_core__DOT___051999_ = (1U & (IData)(
                                                         (0x11ff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051998_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haa60ee2a__0))))))));
    vlSelf->wasmetal_core__DOT___054849_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b14__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xbb000f00ff00ffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054847_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                            << 2U) 
                                                                           | (2U 
                                                                              & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))))))))))));
    vlSelf->wasmetal_core__DOT___049481_ = (1U & (0xd7U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h808d3d88__0))));
    vlSelf->wasmetal_core__DOT___053715_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6af6bfd0__0))));
    vlSelf->wasmetal_core__DOT___049792_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9b387498__0))));
    vlSelf->wasmetal_core__DOT___051109_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h72fb59a4__0))));
    vlSelf->wasmetal_core__DOT___053808_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf722c8bb__0))));
    vlSelf->__VdfgTmp_h4b125034__0 = (((IData)(vlSelf->wasmetal_core__DOT___051051_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xf7f00000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h84873f61__0)))));
    vlSelf->__VdfgTmp_h0ebff551__0 = (((IData)(vlSelf->wasmetal_core__DOT___051407_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xf8ff00ff00ff00ffULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h06d4437a__0)))));
    vlSelf->wasmetal_core__DOT___051985_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfff01110fff0fffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051982_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_haa60ee2a__0))))))))));
    vlSelf->wasmetal_core__DOT___052628_ = (1U & (IData)(
                                                         (0x773f3f3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052626_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          (2U 
                                                                           & ((4U 
                                                                               >> 
                                                                               (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                              << 1U)))))))))));
    vlSelf->wasmetal_core__DOT___009512_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h937c72cf__0))));
    vlSelf->wasmetal_core__DOT___051516_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h27becb7d__0))));
    vlSelf->wasmetal_core__DOT___050841_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb744a8fa__0))));
    vlSelf->wasmetal_core__DOT___053722_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h53aec20d__0))));
    vlSelf->wasmetal_core__DOT___049881_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h73a0c82f__0))));
    vlSelf->__VdfgTmp_hfb07bbea__0 = (((IData)(vlSelf->wasmetal_core__DOT___050812_) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | ((2U 
                                                         & ((0xeU 
                                                             >> 
                                                             (3U 
                                                              & (- (IData)(
                                                                           (1U 
                                                                            & (4U 
                                                                               >> 
                                                                               ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 1U))))))) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___048562_))))));
    vlSelf->wasmetal_core__DOT___067175_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b26__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xef00efefefefefefULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                      << 4U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051361_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                            << 2U) 
                                                                           | (1U 
                                                                              & (1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U))))))))))))))))));
    vlSelf->__VdfgTmp_h228e0a62__0 = (((IData)(vlSelf->wasmetal_core__DOT___051361_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((0xeU 
                                                          >> 
                                                          (3U 
                                                           & (- (IData)(
                                                                        (1U 
                                                                         & (4U 
                                                                            >> 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                             << 1U))))))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->__VdfgTmp_h03f43c88__0 = (((IData)(vlSelf->wasmetal_core__DOT___051576_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x700000000ULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h84873f61__0)))));
    vlSelf->wasmetal_core__DOT___055066_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b15__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xbb000f00ff00ffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055064_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                            << 2U) 
                                                                           | (2U 
                                                                              & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U))))))))))));
    vlSelf->wasmetal_core__DOT___053706_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha2558491__0))));
    vlSelf->wasmetal_core__DOT___049674_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h073e4ce8__0))));
    vlSelf->wasmetal_core__DOT___051626_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_habfc584e__0))));
    vlSelf->wasmetal_core__DOT___049744_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h37fa163f__0))));
    vlSelf->wasmetal_core__DOT___051342_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2290cda0__0))));
    vlSelf->wasmetal_core__DOT___057736_ = (1U & (0x11f00000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051066_)))))));
    vlSelf->wasmetal_core__DOT___051423_ = (1U & (0x5ccc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((0xcU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051066_))))));
    vlSelf->wasmetal_core__DOT___068034_ = (1U & (0xcf5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b39__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050793_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))));
    vlSelf->wasmetal_core__DOT___052623_ = (1U & (0x5ccc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((0xcU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050793_))))));
    vlSelf->wasmetal_core__DOT___049820_ = (1U & (IData)(
                                                         (0xf0c0f050f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                            << 5U) 
                                                           | ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b50__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha09ba029__0)))))));
    vlSelf->wasmetal_core__DOT___051352_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x30aU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha09ba029__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___050847_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x30aU 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha09ba029__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048676_)))));
    vlSelf->wasmetal_core__DOT___053418_ = (1U & (IData)(
                                                         (0x5cc0ccc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0xcU 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5eca347b__0))))));
    vlSelf->wasmetal_core__DOT___049766_ = (1U & (0x5cccU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5eca347b__0))));
    vlSelf->wasmetal_core__DOT___050974_ = (1U & (0xa333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5eca347b__0))));
    vlSelf->wasmetal_core__DOT___049899_ = (1U & (0x30aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049599_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048676_)))));
    vlSelf->wasmetal_core__DOT___051524_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049599_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___050040_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049599_))));
    vlSelf->wasmetal_core__DOT___049606_ = (1U & (0xa333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049599_)))));
    vlSelf->wasmetal_core__DOT___067953_ = (1U & (0x3b00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b38__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049599_))))));
    vlSelf->wasmetal_core__DOT___055140_ = (1U & (0x1f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b40__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___053628_ = (1U & (0xfcaa0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049537_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))));
    vlSelf->wasmetal_core__DOT___050867_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (1U 
                                                          & (0x8fU 
                                                             >> 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                              << 2U))))))));
    vlSelf->wasmetal_core__DOT___050642_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050561_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049607_)))));
    vlSelf->wasmetal_core__DOT___053194_ = (1U & (0xff100000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x10U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                               << 2U)) 
                                                             << 2U)) 
                                                         | (2U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 1U)))))));
    vlSelf->wasmetal_core__DOT___049833_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049607_))));
    vlSelf->wasmetal_core__DOT___053385_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x11ff0fffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___053383_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 3U)) 
                                                                       | ((8U 
                                                                           & ((1U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048679_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b12__05d)))));
    vlSelf->wasmetal_core__DOT___049539_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049525_))));
    wasmetal_core__DOT___052602_ = (1U & (0x70U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b28__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___052601_) 
                                               << 1U) 
                                              | (1U 
                                                 & (8U 
                                                    >> 
                                                    (3U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                        >> 2U))))))));
    vlSelf->__VdfgTmp_hb7578f7f__0 = ((0x20U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h4795829e__0));
    vlSelf->wasmetal_core__DOT___051774_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051773_))));
    vlSelf->wasmetal_core__DOT___053879_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b118__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff00ff00ff1fffULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h7a8eb480__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053553_))))));
    vlSelf->wasmetal_core__DOT___053641_ = (1U & (0x3000aU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9e2bcde2__0))));
    vlSelf->wasmetal_core__DOT___052720_ = (1U & (0x30aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9e2bcde2__0))));
    vlSelf->wasmetal_core__DOT___051789_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051659_))));
    vlSelf->wasmetal_core__DOT___053654_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051523_))));
    vlSelf->wasmetal_core__DOT___051837_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050825_))));
    vlSelf->wasmetal_core__DOT___050795_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050794_))));
    vlSelf->wasmetal_core__DOT___052634_ = (1U & (0x5cccU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h25173009__0))));
    vlSelf->__VdfgTmp_heaed7142__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                             << 3U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h25173009__0));
    vlSelf->wasmetal_core__DOT___053519_ = (1U & (0x30aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051735_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009534_)))));
    vlSelf->wasmetal_core__DOT___051736_ = (1U & (0xa333U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051735_)))));
    wasmetal_core__DOT___053655_ = (1U & (4U >> ((2U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___051735_)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___050707_ = (1U & (0xaafc0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->wasmetal_core__DOT___009534_)))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___049720_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009534_)))))));
    vlSelf->wasmetal_core__DOT___066714_ = (1U & (IData)(
                                                         (0x1fff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066711_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___049720_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (1U 
                                                                              & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___009534_)))))))))))));
    vlSelf->wasmetal_core__DOT___050640_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049720_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___009534_))))));
    vlSelf->wasmetal_core__DOT___009496_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfffe000000000000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h0467adbf__0)))))));
    vlSelf->wasmetal_core__DOT___053389_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1ffffffffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h0467adbf__0)))))));
    vlSelf->wasmetal_core__DOT___050860_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049215_))));
    vlSelf->wasmetal_core__DOT___051065_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049215_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009534_)))));
    vlSelf->wasmetal_core__DOT___051421_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049215_))))));
    __VdfgTmp_h8e6178a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___049215_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009534_));
    __VdfgTmp_h40aa5d33__0 = (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049215_));
    vlSelf->wasmetal_core__DOT___049724_ = (1U & (IData)(
                                                         (0x1515153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049720_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))))));
    vlSelf->wasmetal_core__DOT___050832_ = (1U & (0x3700U 
                                                  >> 
                                                  ((8U 
                                                    & ((0x3700U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b43__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___049599_))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  >> 2U))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050825_))))));
    vlSelf->wasmetal_core__DOT___053811_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051773_))));
    vlSelf->wasmetal_core__DOT___053711_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050904_))));
    vlSelf->wasmetal_core__DOT___053719_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049595_))));
    vlSelf->wasmetal_core__DOT___049767_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049764_))));
    vlSelf->wasmetal_core__DOT___049900_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049897_))));
    vlSelf->wasmetal_core__DOT___051353_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051351_))));
    vlSelf->wasmetal_core__DOT___051525_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051523_))));
    vlSelf->wasmetal_core__DOT___053815_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051659_))));
    vlSelf->wasmetal_core__DOT___053703_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051700_))));
    wasmetal_core__DOT___051292_ = (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___050794_))));
    wasmetal_core__DOT___049641_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfffe000000000000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h0467adbf__0)))))));
    wasmetal_core__DOT___051636_ = (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x1ffffffffULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h0467adbf__0)))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128586___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b8__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b7__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b6__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b5__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128578___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128569___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128535___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128586___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128587___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b8__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128578___DOT____VdfgTmp_h9d2c3928__0));
    if (vlSelf->wasmetal_core__DOT__sp__05b8__05d) {
        vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b8__05d;
        vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b8__05d;
        vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b8__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031902_;
        vlSelf->wasmetal_core__DOT___128595___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___033937_;
        vlSelf->wasmetal_core__DOT___128492___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032959_;
    }
    vlSelf->wasmetal_core__DOT___007197_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053773_))));
    vlSelf->wasmetal_core__DOT___019780_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053563_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053562_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052857_)))));
    vlSelf->wasmetal_core__DOT___019782_ = (1U & (0xbf000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053438_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053563_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053562_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->busy) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052857_)))))));
    vlSelf->__VdfgTmp_hdc23a011__0 = (((IData)(vlSelf->wasmetal_core__DOT___070621_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___042683_));
    vlSelf->wasmetal_core__DOT___042595_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042590_))));
    vlSelf->wasmetal_core__DOT___062494_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053087_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062493_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052897_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052733_)))))));
    vlSelf->wasmetal_core__DOT___053354_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053353_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052853_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053087_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052905_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052733_)))))))));
    vlSelf->wasmetal_core__DOT___052908_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052907_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052733_))));
    vlSelf->wasmetal_core__DOT___053054_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 7U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 8U))))));
    vlSelf->wasmetal_core__DOT___053055_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 8U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 9U))))));
    vlSelf->wasmetal_core__DOT___053056_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0xbU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xcU))))));
    vlSelf->wasmetal_core__DOT___053057_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0xcU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xdU))))));
    vlSelf->wasmetal_core__DOT___053052_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 9U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xaU))))));
    vlSelf->wasmetal_core__DOT___053053_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0xaU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xbU))))));
    vlSelf->wasmetal_core__DOT___053050_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0xdU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xeU))))));
    vlSelf->wasmetal_core__DOT___053051_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0xeU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xfU))))));
    vlSelf->wasmetal_core__DOT___053049_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___053048_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___053046_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          << 1U)) 
                                                      | (1U 
                                                         & vlSelf->insn_x)))));
    vlSelf->wasmetal_core__DOT___053047_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & vlSelf->insn_z) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___053021_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 4U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 5U))))));
    vlSelf->wasmetal_core__DOT___053023_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 3U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 4U))))));
    vlSelf->wasmetal_core__DOT___052734_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 5U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 6U))))));
    vlSelf->wasmetal_core__DOT___052735_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 6U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 7U))))));
    vlSelf->wasmetal_core__DOT___053024_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x14U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x15U))))));
    vlSelf->wasmetal_core__DOT___053025_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x18U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___053026_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x13U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x14U))))));
    vlSelf->wasmetal_core__DOT___053028_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x1aU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x1bU))))));
    vlSelf->wasmetal_core__DOT___053029_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x15U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x16U))))));
    vlSelf->wasmetal_core__DOT___053030_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x10U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x11U))))));
    vlSelf->wasmetal_core__DOT___053031_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x1bU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x1cU))))));
    vlSelf->wasmetal_core__DOT___053032_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x1cU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x1dU))))));
    vlSelf->wasmetal_core__DOT___053033_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0xfU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x10U))))));
    vlSelf->wasmetal_core__DOT___053034_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x11U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x12U))))));
    vlSelf->wasmetal_core__DOT___053035_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x12U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x13U))))));
    vlSelf->wasmetal_core__DOT___053036_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x17U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x18U))))));
    vlSelf->wasmetal_core__DOT___053037_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x1dU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x1eU))))));
    vlSelf->wasmetal_core__DOT___053027_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x1eU)) 
                                                      | (vlSelf->insn_x 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___048395_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048389_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x1000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___048374_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048373_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048372_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048371_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048370_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048369_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x1ff00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048380_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048379_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048378_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048377_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048376_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((0x1fU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048382_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048381_)))) 
                                                                  & (IData)(
                                                                            (1ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007036_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007035_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007032_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007031_))))))))))))))));
    vlSelf->wasmetal_core__DOT___048394_ = (1U & (IData)(
                                                         (0x7000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048355_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048354_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048353_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048352_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048351_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000354_)))))))));
    vlSelf->wasmetal_core__DOT___007203_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048422_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007055_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3900e5db__0))))))));
    vlSelf->wasmetal_core__DOT___007205_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048422_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007055_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3900e5db__0))))));
    vlSelf->wasmetal_core__DOT___063367_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053263_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052883_)))));
    vlSelf->wasmetal_core__DOT___070024_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->insn_imm[3U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053485_))));
    vlSelf->wasmetal_core__DOT___069273_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & vlSelf->insn_y)))))))));
    vlSelf->wasmetal_core__DOT___069331_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___069430_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 1U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 6U))))))))));
    vlSelf->wasmetal_core__DOT___069464_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 7U))))))))));
    vlSelf->wasmetal_core__DOT___069484_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 5U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 8U))))))))));
    vlSelf->wasmetal_core__DOT___069575_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 7U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 9U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0xcU))))))))));
    vlSelf->wasmetal_core__DOT___069620_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 9U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0xbU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0xeU))))))))));
    vlSelf->wasmetal_core__DOT___069666_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0xbU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x10U))))))))));
    vlSelf->wasmetal_core__DOT___069688_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0xcU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0xeU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x11U))))))))));
    vlSelf->wasmetal_core__DOT___069840_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0x13U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x15U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x18U))))))))));
    vlSelf->wasmetal_core__DOT___069861_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0x14U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x19U))))))))));
    vlSelf->wasmetal_core__DOT___069881_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0x15U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x17U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x1aU))))))))));
    vlSelf->wasmetal_core__DOT___069902_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0x16U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x18U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x1bU))))))))));
    vlSelf->wasmetal_core__DOT___069922_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0x17U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x19U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x1cU))))))))));
    vlSelf->wasmetal_core__DOT___069943_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0x18U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x1dU))))))))));
    vlSelf->wasmetal_core__DOT___069304_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___069355_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & vlSelf->insn_x) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___069380_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               << 1U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 4U))))))))));
    vlSelf->wasmetal_core__DOT___053488_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052899_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053485_))));
    vlSelf->__VdfgTmp_hc55be417__0 = (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h652beeee__0));
    vlSelf->wasmetal_core__DOT___050941_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b20__05d))));
    vlSelf->wasmetal_core__DOT___048486_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & ((~ (IData)(
                                                          (0x8000000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___048476_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048474_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048473_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048472_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048471_))))))))) 
                                               | (IData)(
                                                         (0x7fffffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007043_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007042_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048452_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048451_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x100U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048446_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048305_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048270_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048324_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019280_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007190_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x80U 
                                                                            >> 
                                                                            ((4U 
                                                                              & (((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                                                | (IData)(
                                                                                (0x55557f7fffffc0ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & (vlSelf->insn_op 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_op 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & vlSelf->insn_op) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___000375_)))))))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048458_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048456_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048455_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048454_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048469_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048468_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048467_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048466_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048465_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048464_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___066983_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061519_))));
    vlSelf->__VdfgTmp_hb4cc7c9a__0 = (((IData)(vlSelf->wasmetal_core__DOT___060719_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___060718_));
    vlSelf->wasmetal_core__DOT___055315_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052732_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055312_))));
    if (vlSelf->wasmetal_core__DOT__sp__05b9__05d) {
        vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
        vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b9__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128460___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___032637_;
        vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128396___DOT__CO__BRA__0__KET__;
    }
    vlSelf->__VdfgTmp_h648a31a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010378_));
    vlSelf->wasmetal_core__DOT___056601_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009691_))));
    vlSelf->wasmetal_core__DOT___009693_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053780_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053767_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053766_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054671_))))));
    vlSelf->wasmetal_core__DOT___010092_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007193_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007192_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054671_)))));
    vlSelf->__VdfgTmp_ha091cfd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063859_));
    vlSelf->wasmetal_core__DOT___066407_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066282_))));
    vlSelf->wasmetal_core__DOT___056541_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011740_))));
    vlSelf->wasmetal_core__DOT___008974_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___033033_))));
    vlSelf->wasmetal_core__DOT___008810_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___033033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009653_))));
    vlSelf->wasmetal_core__DOT___000666_ = (1U & (0xb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044819_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048286_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048285_)))))));
    vlSelf->wasmetal_core__DOT___048431_ = (1U & (0x40ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044819_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048286_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048429_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048285_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf8000000U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048426_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048425_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h9fdaf630__0))))))))))));
    vlSelf->wasmetal_core__DOT___053018_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053015_))));
    vlSelf->wasmetal_core__DOT___063448_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063446_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062498_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052902_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050366_))))));
    vlSelf->wasmetal_core__DOT___053272_ = (1U & (IData)(
                                                         (0x1010000101000ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053271_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0x80000000U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___047790_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___047792_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0x1fff0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___047964_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x4000U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___047786_)))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x1f00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053264_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003010_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047954_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x4000U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048328_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1fff000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___002978_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053266_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x4000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___047783_)))))))))))))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                                        >> 2U)) 
                                                                    | (1U 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O)))))))));
    vlSelf->wasmetal_core__DOT___030687_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048391_))));
    vlSelf->wasmetal_core__DOT___048392_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048391_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003147_)))));
    if (vlSelf->wasmetal_core__DOT___003030_) {
        vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003030_)));
        vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)));
        vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003030_)));
    } else {
        vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)));
        vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003030_)));
        vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)));
    }
    vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003030_)) 
                 | (~ (IData)(vlSelf->wasmetal_core__DOT___003034_))));
    vlSelf->wasmetal_core__DOT___005723_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003030_)))));
    vlSelf->__VdfgTmp_hefabe8e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003034_));
    vlSelf->__VdfgTmp_hc058618d__0 = (((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003030_));
    vlSelf->__VdfgTmp_h360595f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003028_));
    vlSelf->wasmetal_core__DOT____Vcellinp___128723___S 
        = (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
            << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003028_));
    vlSelf->wasmetal_core__DOT____Vcellinp___128725___S 
        = (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
            << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003028_))));
    vlSelf->__VdfgTmp_hb9f44c2b__0 = (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003028_)));
    vlSelf->wasmetal_core__DOT___042570_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003032_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003029_)))))));
    vlSelf->wasmetal_core__DOT___070601_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070600_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003029_))));
    vlSelf->__VdfgTmp_h2de6a63c__0 = (((IData)(vlSelf->wasmetal_core__DOT___003032_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003029_));
    vlSelf->wasmetal_core__DOT___053428_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051571_))));
    vlSelf->wasmetal_core__DOT___053922_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051571_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053427_))));
    vlSelf->wasmetal_core__DOT___036749_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036781_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134151___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h83e5aafb__0))));
    vlSelf->wasmetal_core__DOT___053092_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053091_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053090_))));
    vlSelf->wasmetal_core__DOT___052651_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052645_))));
    vlSelf->wasmetal_core__DOT___063463_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063471_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063479_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063449_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063447_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___062602_))));
    vlSelf->wasmetal_core__DOT___071912_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_z 
                                                               >> 2U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (0xfU 
                                                                    & vlSelf->insn_z)) 
                                                                  << 4U)) 
                                                              | ((0xcU 
                                                                  & (vlSelf->insn_z 
                                                                     >> 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he0cbb0dc__0)))))));
    vlSelf->wasmetal_core__DOT___071911_ = (1U & (IData)(
                                                         (0x1010000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (0xfU 
                                                                 & vlSelf->insn_z)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_z 
                                                                  >> 1U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_z 
                                                                     >> 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_z 
                                                                        >> 5U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_heaa2bcd7__0))))))));
    vlSelf->wasmetal_core__DOT___071910_ = (1U & (IData)(
                                                         (0x1010000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (0xfU 
                                                                 & vlSelf->insn_z)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & vlSelf->insn_z) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_z 
                                                                     >> 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_z 
                                                                        >> 5U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hed859ce1__0))))))));
    vlSelf->wasmetal_core__DOT___051184_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051176_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h295e0579__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h36e63769__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbcd45513__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051148_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051144_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h964144cd__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc4635290__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h73f4a931__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051168_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051152_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h738a13de__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc7f628da__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he2a57136__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050995_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050987_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8b69f170__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h947ab6b4__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h71547b26__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051094_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051086_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6286ac7f__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h29fa0da7__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc66bf11b__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050894_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050886_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1dd2dede__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcb35a5f1__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3885fdb9__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050248_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050232_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b83__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b82__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b81__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b80__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b91__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b90__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b89__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b88__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b95__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b94__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b93__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b92__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___050208_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050200_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b175__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b174__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b173__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b172__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b167__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b166__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b165__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b164__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b163__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b162__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b161__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b160__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___050228_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050224_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b211__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b210__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b209__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b208__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b219__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b218__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b217__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b216__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b223__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b222__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b221__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b220__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___049988_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049972_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b83__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b82__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b81__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b80__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b91__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b90__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b89__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b88__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b95__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b94__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b93__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b92__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___050008_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049992_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b175__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b174__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b173__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b172__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b167__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b166__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b165__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b164__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b163__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b162__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b161__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b160__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___050028_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050012_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b211__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b210__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b209__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b208__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b219__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b218__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b217__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b216__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b223__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b222__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b221__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b220__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___050322_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050314_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h980fd1a4__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h12f13bc4__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3ca396d5__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051082_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051074_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb13e555e__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4fc63e3e__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5b3781b6__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050192_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050174_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b6__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b4__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b11__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b9__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b8__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b15__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b14__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b13__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b12__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___049968_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049934_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b6__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b4__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b11__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b9__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b8__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b15__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b14__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b13__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b12__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___049411_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h295e0579__0))))));
    vlSelf->wasmetal_core__DOT___049407_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2b062dd4__0))))));
    vlSelf->wasmetal_core__DOT___049415_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8dc4790b__0))))));
    vlSelf->wasmetal_core__DOT___048531_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4f25bbf3__0))))));
    vlSelf->wasmetal_core__DOT___049908_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc4635290__0))))));
    vlSelf->wasmetal_core__DOT___051599_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb256bb9f__0))))));
    vlSelf->wasmetal_core__DOT___051666_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h738a13de__0))))));
    vlSelf->wasmetal_core__DOT___051670_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc793c4ac__0))))));
    vlSelf->wasmetal_core__DOT___051674_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hff3ab0b7__0))))));
    vlSelf->wasmetal_core__DOT___050682_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8b69f170__0))))));
    vlSelf->wasmetal_core__DOT___050673_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7982dd07__0))))));
    vlSelf->wasmetal_core__DOT___050669_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1157f8a3__0))))));
    vlSelf->wasmetal_core__DOT___050646_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h51560923__0))))));
    vlSelf->wasmetal_core__DOT___050618_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h29fa0da7__0))))));
    vlSelf->wasmetal_core__DOT___050614_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc0d4cc40__0))))));
    vlSelf->wasmetal_core__DOT___050597_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1dd2dede__0))))));
    vlSelf->wasmetal_core__DOT___050589_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7d1b01d9__0))))));
    vlSelf->wasmetal_core__DOT___050560_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h38f4df47__0))))));
    vlSelf->wasmetal_core__DOT___050575_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b83__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b82__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b81__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b80__05d)))))))));
    vlSelf->wasmetal_core__DOT___050571_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b103__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b102__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b101__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b100__05d)))))))));
    vlSelf->wasmetal_core__DOT___050491_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b115__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b114__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b113__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b112__05d)))))))));
    vlSelf->wasmetal_core__DOT___051447_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b139__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b138__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b137__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b136__05d)))))))));
    vlSelf->wasmetal_core__DOT___051455_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b167__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b166__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b165__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b164__05d)))))))));
    vlSelf->wasmetal_core__DOT___051451_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b179__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b178__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b177__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b176__05d)))))))));
    vlSelf->wasmetal_core__DOT___053464_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b211__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b210__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b209__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b208__05d)))))))));
    vlSelf->wasmetal_core__DOT___053460_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b231__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b230__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b229__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b228__05d)))))))));
    vlSelf->wasmetal_core__DOT___053456_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b243__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b242__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b241__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b240__05d)))))))));
    vlSelf->wasmetal_core__DOT___051482_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b83__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b82__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b81__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b80__05d)))))))));
    vlSelf->wasmetal_core__DOT___051478_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b103__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b102__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b101__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b100__05d)))))))));
    vlSelf->wasmetal_core__DOT___051472_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b115__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b114__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b113__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b112__05d)))))))));
    vlSelf->wasmetal_core__DOT___051400_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b139__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b138__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b137__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b136__05d)))))))));
    vlSelf->wasmetal_core__DOT___051465_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b167__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b166__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b165__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b164__05d)))))))));
    vlSelf->wasmetal_core__DOT___050567_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b179__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b178__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b177__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b176__05d)))))))));
    vlSelf->wasmetal_core__DOT___050593_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b211__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b210__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b209__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b208__05d)))))))));
    vlSelf->wasmetal_core__DOT___051392_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b231__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b230__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b229__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b228__05d)))))))));
    vlSelf->wasmetal_core__DOT___051388_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b243__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b242__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b241__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b240__05d)))))))));
    vlSelf->wasmetal_core__DOT___049399_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5760b542__0))))));
    vlSelf->wasmetal_core__DOT___050918_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7a6ef80c__0))))));
    vlSelf->wasmetal_core__DOT___051678_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he052d4e7__0))))));
    vlSelf->wasmetal_core__DOT___050759_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0a9f8029__0))))));
    vlSelf->wasmetal_core__DOT___050650_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5864b2ba__0))))));
    vlSelf->wasmetal_core__DOT___050606_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1968304e__0))))));
    vlSelf->wasmetal_core__DOT___051031_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8546e85d__0))))));
    vlSelf->wasmetal_core__DOT___051035_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h02a1ae9a__0))))));
    vlSelf->wasmetal_core__DOT___051039_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf05a0261__0))))));
    vlSelf->wasmetal_core__DOT___050738_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6727edf3__0))))));
    vlSelf->wasmetal_core__DOT___050728_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hefac84ff__0))))));
    vlSelf->wasmetal_core__DOT___050751_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_haf724a20__0))))));
    vlSelf->wasmetal_core__DOT___050579_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b75__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b74__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b73__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b72__05d)))))))));
    vlSelf->wasmetal_core__DOT___051023_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b151__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b150__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b149__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b148__05d)))))))));
    vlSelf->wasmetal_core__DOT___051847_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b203__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b202__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b201__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b200__05d)))))))));
    vlSelf->wasmetal_core__DOT___072231_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b75__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b74__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b73__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b72__05d)))))))));
    vlSelf->wasmetal_core__DOT___072223_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b151__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b150__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b149__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b148__05d)))))))));
    vlSelf->wasmetal_core__DOT___051384_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b203__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b202__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b201__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b200__05d)))))))));
    vlSelf->wasmetal_core__DOT___051027_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8c9e90c9__0))))));
    vlSelf->wasmetal_core__DOT___050742_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf782be94__0))))));
    vlSelf->wasmetal_core__DOT___053448_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___051878_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___049430_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___051442_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___072243_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___072239_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___053444_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___072247_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__memory_bounds__02ewords__02e0__02e0__ADDRARDADDR 
        = (0x803fU | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b7__05d) 
                       << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                    << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                 << 0xbU) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                    << 0xaU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                       << 9U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                          << 8U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                             << 7U) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                               << 6U)))))))));
    vlSelf->__VdfgTmp_h8d479abc__0 = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b8__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___044479_));
    vlSelf->wasmetal_core__DOT___050942_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b30__05d))));
    vlSelf->wasmetal_core__DOT___044467_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070592_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x18U)) 
                                                                 | (3U 
                                                                    & (vlSelf->insn_x 
                                                                       >> 0x1aU))))))));
    vlSelf->wasmetal_core__DOT___044466_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070591_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x12U)) 
                                                                 | (3U 
                                                                    & (vlSelf->insn_x 
                                                                       >> 0x14U))))))));
    vlSelf->wasmetal_core__DOT___050961_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b23__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b19__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b18__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b17__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___044465_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070590_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xcU)) 
                                                                 | (3U 
                                                                    & (vlSelf->insn_x 
                                                                       >> 0xeU))))))));
    vlSelf->wasmetal_core__DOT___053985_ = (1U & (IData)(
                                                         (0xe0e0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053979_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050935_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x18U 
                                                                         >> 
                                                                         ((4U 
                                                                           & (vlSelf->insn_x 
                                                                              >> 0xcU)) 
                                                                          | ((2U 
                                                                              & (vlSelf->insn_y 
                                                                                >> 0xdU)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048519_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b12__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050933_)))))))));
    vlSelf->wasmetal_core__DOT___050940_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b27__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___044459_ = (1U & (IData)(
                                                         (0xcaffffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050957_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070589_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050935_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 9U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_x 
                                                                             >> 0xaU))))))))));
    vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031330_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___063054_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5c8f7b91__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053572_))));
    vlSelf->wasmetal_core__DOT___053955_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052650_))));
    vlSelf->wasmetal_core__DOT___062966_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062964_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052650_))));
    vlSelf->wasmetal_core__DOT___052694_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050381_)))));
    vlSelf->wasmetal_core__DOT___062603_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052837_))));
    vlSelf->wasmetal_core__DOT___053991_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
    vlSelf->wasmetal_core__DOT___063425_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063422_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___019356_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048111_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___038870_)))))));
    vlSelf->wasmetal_core__DOT___063395_ = (1U & ((~ (IData)(
                                                             (0xf00000dd00000000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053308_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053343_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill))))))))) 
                                                  & (IData)(
                                                            (0x3300ff3033f0fbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___019356_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->mem_fault) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d))))))))));
    vlSelf->wasmetal_core__DOT___062652_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O))))))))));
    vlSelf->wasmetal_core__DOT___062663_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062674_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062685_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                             >> 3U))))))))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O))) {
        vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O));
        vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O));
        vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O));
    } else {
        vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128516___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128524___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128601___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT___009544_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048430_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045693_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044230_)))));
    vlSelf->wasmetal_core__DOT__access_size__05b4__05d 
        = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___048430_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054465_))));
    vlSelf->wasmetal_core__DOT___054459_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048430_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (1ULL 
                                                                           >> 
                                                                           (vlSelf->insn_op 
                                                                            >> 0x1aU))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> 
                                                                      (3U 
                                                                       & (vlSelf->insn_op 
                                                                          >> 6U))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___044061_)))))))));
    vlSelf->wasmetal_core__DOT___053483_ = (1U & (IData)(
                                                         (0xffff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048430_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053482_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052647_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___044190_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___045725_)))))))));
    vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 9U) & (IData)(vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x200U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 9U) : (IData)(vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128004___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128036___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128157___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128157___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128190___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128190___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128207___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128207___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128372___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128372___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128420___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128276___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128276___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128224___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128224___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128214___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029943_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029942_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029941_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029940_)))) 
           ^ (((IData)(wasmetal_core__DOT___128214___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128214___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128214___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029907_)))));
    vlSelf->wasmetal_core__DOT___029911_ = ((IData)(vlSelf->wasmetal_core__DOT___029943_)
                                             ? (IData)(wasmetal_core__DOT___128214___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128483___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032895_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032894_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032893_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032892_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032859_)))));
    vlSelf->wasmetal_core__DOT___032863_ = ((IData)(vlSelf->wasmetal_core__DOT___032895_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d));
    vlSelf->wasmetal_core__DOT___127996___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128945___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127996___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128197___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029774_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029773_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029772_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029771_)))) 
           ^ (((IData)(wasmetal_core__DOT___128197___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128197___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128197___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029738_)))));
    vlSelf->wasmetal_core__DOT___029742_ = ((IData)(vlSelf->wasmetal_core__DOT___029774_)
                                             ? (IData)(wasmetal_core__DOT___128197___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128164___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029411_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029410_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029409_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029408_)))) 
           ^ (((IData)(wasmetal_core__DOT___128164___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128164___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128164___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029375_)))));
    vlSelf->wasmetal_core__DOT___029379_ = ((IData)(vlSelf->wasmetal_core__DOT___029411_)
                                             ? (IData)(wasmetal_core__DOT___128164___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128011___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027830_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027829_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027828_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027827_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027794_)))));
    vlSelf->wasmetal_core__DOT___027798_ = ((IData)(vlSelf->wasmetal_core__DOT___027830_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b7__05d));
    vlSelf->wasmetal_core__DOT___128257___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128257___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 9U) & (IData)(vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128148___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029250_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029249_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029248_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029247_)))) 
           ^ (((IData)(wasmetal_core__DOT___128148___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128148___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128148___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029214_)))));
    vlSelf->wasmetal_core__DOT___029218_ = ((IData)(vlSelf->wasmetal_core__DOT___029250_)
                                             ? (IData)(wasmetal_core__DOT___128148___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d));
    vlSelf->wasmetal_core__DOT___128020___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128020___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__1__KET__ 
        = ((~ (vlSelf->function_params >> 9U)) & (IData)(vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___071599_ = (1U & (0x7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071595_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071594_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___019451_ = (1U & (IData)(
                                                         (0x7fffffff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (1U 
                                                                              & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___071583_)))))))))))));
    vlSelf->wasmetal_core__DOT___071695_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b65__05d) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hce6e76ca__0))))));
    vlSelf->wasmetal_core__DOT___071672_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hce6e76ca__0))));
    vlSelf->wasmetal_core__DOT___071702_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b69__05d) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9972469d__0))))));
    vlSelf->wasmetal_core__DOT___071706_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b71__05d) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb635a29b__0))))));
    vlSelf->wasmetal_core__DOT___019496_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b17__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfffbe48f__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019561_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b49__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfffbe48f__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019604_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b81__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfffbe48f__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___019653_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b113__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfffbe48f__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___071676_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd1e6ff3c__0))));
    vlSelf->wasmetal_core__DOT___071646_ = (1U & (0xfa3fU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd54e1937__0))));
    vlSelf->__VdfgTmp_h460a0345__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (IData)(vlSelf->__VdfgTmp_hd54e1937__0))));
    vlSelf->wasmetal_core__DOT___071657_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071611_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071656_)))));
    vlSelf->wasmetal_core__DOT___071612_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071611_))));
    vlSelf->wasmetal_core__DOT___019576_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b57__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h017bc299__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019577_)))));
    vlSelf->wasmetal_core__DOT___071625_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h017bc299__0))))));
    vlSelf->wasmetal_core__DOT___071663_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h017bc299__0))))));
    vlSelf->wasmetal_core__DOT___071687_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h017bc299__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128632___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128427___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032223_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032222_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032221_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032220_)))) 
           ^ (((IData)(wasmetal_core__DOT___128427___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128427___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128427___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032187_)))));
    vlSelf->wasmetal_core__DOT___032191_ = ((IData)(vlSelf->wasmetal_core__DOT___032223_)
                                             ? (IData)(wasmetal_core__DOT___128427___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128467___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032703_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032702_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032701_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032700_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032667_)))));
    vlSelf->wasmetal_core__DOT___032671_ = ((IData)(vlSelf->wasmetal_core__DOT___032703_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d));
    vlSelf->wasmetal_core__DOT___067559_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067556_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067555_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065566_)))));
    vlSelf->wasmetal_core__DOT___066373_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066371_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066370_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066369_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___066368_))))));
    vlSelf->wasmetal_core__DOT___069262_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067558_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067555_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___066371_))))));
    vlSelf->wasmetal_core__DOT___069657_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___069655_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069654_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 5U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xeU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hede308eb__0))))))));
    vlSelf->wasmetal_core__DOT___068874_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067569_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068869_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7eff58ec__0))))));
    vlSelf->wasmetal_core__DOT___069215_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067986_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069211_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7e1b7882__0))))));
    vlSelf->wasmetal_core__DOT___067588_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019393_))));
    vlSelf->wasmetal_core__DOT___067836_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067833_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x11U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf22e2068__0))))))));
    vlSelf->wasmetal_core__DOT___067939_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067935_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x13U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 4U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf22e2068__0))))))));
    vlSelf->wasmetal_core__DOT___070018_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070014_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067622_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0xeU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84a22723__0))))))));
    vlSelf->wasmetal_core__DOT___070040_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070036_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067703_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0xfU)) 
                                                                 | ((4U 
                                                                     & vlSelf->mem_rdata[1U]) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84a22723__0))))))));
    vlSelf->wasmetal_core__DOT___070001_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067567_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0xdU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84a22723__0))))))));
    vlSelf->wasmetal_core__DOT___069497_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065647_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 6U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 7U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069517_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065755_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 7U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 8U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069543_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065842_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 8U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 9U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069569_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065975_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 9U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xaU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069634_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066218_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xcU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xdU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069284_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->mem_rdata[1U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067560_))));
    vlSelf->wasmetal_core__DOT___069341_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067560_))));
    vlSelf->wasmetal_core__DOT___069391_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067560_))));
    vlSelf->wasmetal_core__DOT___069417_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067560_))));
    vlSelf->wasmetal_core__DOT___069449_ = (1U & (0xbb0bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066218_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067560_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 5U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 6U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069260_)))))));
    vlSelf->wasmetal_core__DOT___069264_ = (1U & (0xbb0bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065572_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067560_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069260_)))))));
    vlSelf->wasmetal_core__DOT____Vcellout___134209___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037213_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037212_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037211_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037210_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037178_)))));
    vlSelf->wasmetal_core__DOT___037182_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037213_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0e12a4a2__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128672___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034669_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034658_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034647_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__0__KET__)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128672___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___034733_ = ((IData)(vlSelf->wasmetal_core__DOT___034669_) 
                                            & (IData)(wasmetal_core__DOT___128672___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128711___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035145_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035144_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035139_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035128_)))) 
           ^ (((IData)(wasmetal_core__DOT___128711___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128711___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128711___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035053_)))));
    vlSelf->wasmetal_core__DOT___035081_ = ((IData)(vlSelf->wasmetal_core__DOT___035145_)
                                             ? (IData)(wasmetal_core__DOT___128711___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b6__05d));
    vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b6__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128695___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127835___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026290_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026289_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026288_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026287_)))) 
           ^ (((IData)(wasmetal_core__DOT___127835___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127835___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127835___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026254_)))));
    vlSelf->wasmetal_core__DOT___026258_ = ((IData)(vlSelf->wasmetal_core__DOT___026290_)
                                             ? (IData)(wasmetal_core__DOT___127835___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127827___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026194_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026193_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026192_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026191_)))) 
           ^ (((IData)(wasmetal_core__DOT___127827___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127827___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127827___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026158_)))));
    vlSelf->wasmetal_core__DOT___026162_ = ((IData)(vlSelf->wasmetal_core__DOT___026194_)
                                             ? (IData)(wasmetal_core__DOT___127827___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127843___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026386_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026385_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026384_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026383_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026350_)))));
    vlSelf->wasmetal_core__DOT___026354_ = ((IData)(vlSelf->wasmetal_core__DOT___026386_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b7__05d));
    vlSelf->wasmetal_core__DOT___128475___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032828_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032795_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O)));
    vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128500___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___135451___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___046799_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___046798_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___046797_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__0__KET__)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___135451___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___135451___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___046834_ = ((IData)(vlSelf->wasmetal_core__DOT___046799_) 
                                            & (IData)(wasmetal_core__DOT___135451___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128330___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031181_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128330___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b1__05d));
    vlSelf->wasmetal_core__DOT___128354___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031469_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128354___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b1__05d));
    vlSelf->wasmetal_core__DOT___128442___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032492_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128442___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___032364_));
    vlSelf->wasmetal_core__DOT____Vcellout___135467___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___046932_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___046931_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___046930_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___135467___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___135467___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___046967_ = ((IData)(vlSelf->wasmetal_core__DOT___046932_) 
                                            & (IData)(wasmetal_core__DOT___135467___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___051901_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050483_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050482_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc489de0__0))))))));
    vlSelf->wasmetal_core__DOT___053526_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0ebff551__0))));
    vlSelf->wasmetal_core__DOT___050818_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfb07bbea__0))));
    vlSelf->wasmetal_core__DOT___051362_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h228e0a62__0))));
    vlSelf->wasmetal_core__DOT___051577_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h03f43c88__0))));
    vlSelf->wasmetal_core__DOT___051803_ = (1U & (IData)(
                                                         (0xbbbbb00ffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051352_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051351_)))))))));
    vlSelf->wasmetal_core__DOT___065725_ = (1U & (IData)(
                                                         (0x3f003f3f5555ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050847_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050846_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))))));
    vlSelf->wasmetal_core__DOT___050978_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xc5U 
                                                         >> 
                                                         ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050974_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___048676_))))))));
    vlSelf->wasmetal_core__DOT___050068_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b22__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xc1d3f3fU 
                                                         >> 
                                                         ((0x10U 
                                                           & ((1U 
                                                               >> 
                                                               (3U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                   >> 2U))) 
                                                              << 4U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050041_) 
                                                                 << 2U) 
                                                                | ((2U 
                                                                    & ((8U 
                                                                        >> 
                                                                        (3U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            >> 2U))) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___050040_))))))))));
    vlSelf->wasmetal_core__DOT___050501_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (2U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___049606_)))))));
    vlSelf->wasmetal_core__DOT___053120_ = (1U & (IData)(
                                                         (0x7f00007f7f7f7fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049833_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                       << 1U)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050798_)))))))));
    vlSelf->wasmetal_core__DOT___052605_ = (1U & (IData)(
                                                         (0xbb000f00ff00ff00ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(wasmetal_core__DOT___052602_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (2U 
                                                                             & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))))))));
    vlSelf->wasmetal_core__DOT___051990_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051774_))));
    vlSelf->wasmetal_core__DOT___053863_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b114__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xf0f0f77U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc1e7aa45__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052720_))))));
    vlSelf->wasmetal_core__DOT___053154_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051837_))));
    vlSelf->wasmetal_core__DOT___050796_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b23__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050795_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___053828_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b105__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x5dc0000U 
                                                         >> 
                                                         ((0x1cU 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050846_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xfa33f333U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_heaed7142__0))))))))));
    vlSelf->wasmetal_core__DOT___053658_ = (1U & (0xfe540000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(wasmetal_core__DOT___053655_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053654_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))));
    vlSelf->wasmetal_core__DOT___051331_ = (1U & (0x222dfffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050561_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050640_)))))));
    vlSelf->wasmetal_core__DOT___053391_ = (1U & (IData)(
                                                         (0x1515153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053390_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053389_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))))));
    vlSelf->wasmetal_core__DOT___065823_ = (1U & (IData)(
                                                         (0x3f003f3f5555ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050867_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050860_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))))));
    vlSelf->wasmetal_core__DOT___050868_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050860_))));
    vlSelf->wasmetal_core__DOT___051067_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051065_))));
    vlSelf->wasmetal_core__DOT___053524_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051421_))));
    vlSelf->wasmetal_core__DOT___053647_ = (1U & (0xa300U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_h8e6178a2__0))));
    vlSelf->wasmetal_core__DOT___049216_ = (1U & (0xa300U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (IData)(__VdfgTmp_h8e6178a2__0))));
    vlSelf->wasmetal_core__DOT___051371_ = (1U & (0x333aU 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_h40aa5d33__0))));
    vlSelf->wasmetal_core__DOT___051584_ = (1U & (0x333aU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (IData)(__VdfgTmp_h40aa5d33__0))));
    vlSelf->wasmetal_core__DOT___053714_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b98__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053711_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xa333U 
                                                               >> (IData)(vlSelf->__VdfgTmp_heaed7142__0))))))));
    vlSelf->wasmetal_core__DOT___053721_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b99__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053719_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051736_))))));
    vlSelf->wasmetal_core__DOT___053859_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b113__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049767_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052634_))))));
    vlSelf->wasmetal_core__DOT___053867_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b115__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049900_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053519_))))));
    vlSelf->wasmetal_core__DOT___053891_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b121__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051353_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053641_))))));
    vlSelf->wasmetal_core__DOT___053898_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b123__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051525_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___053655_))))));
    vlSelf->wasmetal_core__DOT___053817_ = (1U & (0xe600ff00U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b103__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051790_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053815_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___053705_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b97__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053703_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051701_))))));
    vlSelf->wasmetal_core__DOT___053883_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b119__05d) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___051292_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053582_))))));
    vlSelf->wasmetal_core__DOT___051294_ = (1U & (IData)(
                                                         (0xef00efef00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b55__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(wasmetal_core__DOT___051292_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050793_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))))))));
    vlSelf->wasmetal_core__DOT___053852_ = (1U & (0xb0c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b111__05d) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___049641_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051884_))))));
    vlSelf->wasmetal_core__DOT___049650_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___049641_))));
    vlSelf->wasmetal_core__DOT___051637_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___051636_))));
    vlSelf->wasmetal_core__DOT___053914_ = (1U & (0x70c0f0f0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b127__05d) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___051636_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053695_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128535___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b9__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b8__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b7__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b6__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128587___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128578___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128569___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128535___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___128536___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b9__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128587___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___053782_ = ((IData)(vlSelf->wasmetal_core__DOT___007197_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___007196_)) 
                                               | (IData)(
                                                         (0xbfffffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007195_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007193_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007192_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007191_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007190_))))))))));
    vlSelf->wasmetal_core__DOT___042587_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042539_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___042539_)
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___042595_)
                                                    ? 
                                                   (5U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hdc23a011__0))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___042590_))));
    vlSelf->wasmetal_core__DOT___062501_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048429_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052912_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x4000000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___062498_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___062497_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___062496_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052880_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052906_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053350_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052894_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x1000000000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___062494_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053090_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052882_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053013_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052905_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052845_))))))))))))));
    vlSelf->wasmetal_core__DOT___070485_ = (1U & (0xf088U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052864_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052908_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052885_))))));
    vlSelf->wasmetal_core__DOT___052914_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052912_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052911_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052910_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050397_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052890_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052889_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052888_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052886_)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052908_)))))))));
    vlSelf->wasmetal_core__DOT___053569_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052908_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053567_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052880_)))));
    vlSelf->wasmetal_core__DOT___053058_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053053_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053052_))));
    vlSelf->wasmetal_core__DOT___053059_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053051_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053050_))));
    vlSelf->wasmetal_core__DOT___053061_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053049_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053048_))));
    vlSelf->wasmetal_core__DOT___053064_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053047_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053046_))));
    vlSelf->wasmetal_core__DOT___053022_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052735_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052734_))));
    vlSelf->wasmetal_core__DOT___053042_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053032_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053031_))));
    vlSelf->wasmetal_core__DOT___053043_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053034_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053033_))));
}
