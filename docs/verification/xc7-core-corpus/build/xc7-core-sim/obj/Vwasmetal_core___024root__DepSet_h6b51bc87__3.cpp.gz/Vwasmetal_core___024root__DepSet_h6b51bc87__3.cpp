#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__6(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__6\n"); );
    // Body
    vlSelf->__VdfgTmp_h7d4fca25__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004728_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___004727_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h887e5924__0)))))));
    vlSelf->__VdfgTmp_hd1b03413__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004758_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000724_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h33ea4c85__0)))))));
    vlSelf->wasmetal_core__DOT___048196_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003746_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003745_)));
    vlSelf->wasmetal_core__DOT___048193_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003780_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001370_)));
    vlSelf->wasmetal_core__DOT___005467_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003902_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003901_)));
    vlSelf->wasmetal_core__DOT___005465_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003948_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000926_)));
    vlSelf->wasmetal_core__DOT___048071_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005148_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005147_)));
    vlSelf->wasmetal_core__DOT___048068_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005164_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000499_)));
    vlSelf->__VdfgTmp_h82d77f97__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004506_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003097_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hf8739cbc__0)))))));
    vlSelf->__VdfgTmp_h6e7f092f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004536_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000723_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hc61dfdcc__0)))))));
    vlSelf->wasmetal_core__DOT___005477_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003382_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003381_)));
    vlSelf->wasmetal_core__DOT___005475_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003428_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000981_)));
    vlSelf->wasmetal_core__DOT___005487_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003314_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003313_)));
    vlSelf->wasmetal_core__DOT___005485_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003360_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000993_)));
    vlSelf->wasmetal_core__DOT___048176_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005080_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005079_)));
    vlSelf->wasmetal_core__DOT___048173_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005096_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000521_)));
    vlSelf->wasmetal_core__DOT___048245_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005352_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005351_)));
    vlSelf->wasmetal_core__DOT___048242_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005368_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000543_)));
    vlSelf->__VdfgTmp_hf0176237__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004358_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003099_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h220272bf__0)))))));
    vlSelf->__VdfgTmp_ha7dc0a46__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004388_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000748_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h2bc911a1__0)))))));
    vlSelf->wasmetal_core__DOT___048230_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003598_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003597_)));
    vlSelf->wasmetal_core__DOT___048232_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003632_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001382_)));
    vlSelf->wasmetal_core__DOT___048178_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004944_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004943_)));
    vlSelf->wasmetal_core__DOT___048179_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004960_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000565_)));
    vlSelf->wasmetal_core__DOT___048259_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005012_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005011_)));
    vlSelf->wasmetal_core__DOT___048256_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005028_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000592_)));
    vlSelf->__VdfgTmp_hbacded4f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004432_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003101_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h193e1c6c__0)))))));
    vlSelf->__VdfgTmp_h2937d10d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004462_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000747_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h01ca3900__0)))))));
    vlSelf->wasmetal_core__DOT___048184_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004876_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004875_)));
    vlSelf->wasmetal_core__DOT___048181_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004892_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000614_)));
    vlSelf->wasmetal_core__DOT___048197_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003450_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003449_)));
    vlSelf->wasmetal_core__DOT___048199_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003484_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001414_)));
    vlSelf->__VdfgTmp_hb7a72eea__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004580_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003103_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h7b80a3df__0)))))));
    vlSelf->__VdfgTmp_h158a449d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004610_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000771_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h97352ffe__0)))))));
    vlSelf->wasmetal_core__DOT___048239_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005284_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005283_)));
    vlSelf->wasmetal_core__DOT___048240_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005300_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000636_)));
    vlSelf->wasmetal_core__DOT___048004_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005600_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005599_)));
    vlSelf->wasmetal_core__DOT___048006_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005618_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005617_)));
    vlSelf->wasmetal_core__DOT___048172_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005216_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005215_)));
    vlSelf->wasmetal_core__DOT___048169_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005232_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000658_)));
    vlSelf->wasmetal_core__DOT___048263_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003524_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003523_)));
    vlSelf->wasmetal_core__DOT___048260_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003558_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001426_)));
    vlSelf->__VdfgTmp_h601dd350__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003764_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003109_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h8103cb90__0)))))));
    vlSelf->__VdfgTmp_h2f983ac6__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003794_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000772_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_ha7c76017__0)))))));
    vlSelf->wasmetal_core__DOT___048185_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004118_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004117_)));
    vlSelf->wasmetal_core__DOT___048187_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004152_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001525_)));
    vlSelf->__VdfgTmp_hff8a2099__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003616_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003111_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h94e7c39f__0)))))));
    vlSelf->__VdfgTmp_h2712d491__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003646_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000795_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h3ec183f3__0)))))));
    vlSelf->wasmetal_core__DOT___048234_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004192_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004191_)));
    vlSelf->wasmetal_core__DOT___048236_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004226_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001537_)));
    vlSelf->__VdfgTmp_h52266111__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003468_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003105_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h39365f5c__0)))))));
    vlSelf->__VdfgTmp_h7f6ab5bd__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003498_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000796_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_haaa3ad0b__0)))))));
    vlSelf->wasmetal_core__DOT___048189_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004636_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004635_)));
    vlSelf->wasmetal_core__DOT___048191_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004670_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001569_)));
    vlSelf->__VdfgTmp_hcde84ebb__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003542_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003107_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h6d082533__0)))))));
    vlSelf->__VdfgTmp_hd5a2b04d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003572_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000825_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_he2dbc386__0)))))));
    vlSelf->__VdfgTmp_h0adea875__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004136_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003117_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hbea96df5__0)))))));
    vlSelf->__VdfgTmp_h2566b586__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004166_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000824_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_ha15d8995__0)))))));
    vlSelf->wasmetal_core__DOT___048696_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003672_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003671_)));
    vlSelf->wasmetal_core__DOT___048693_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003706_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001581_)));
    vlSelf->__VdfgTmp_h79860539__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004210_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003119_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h01f51344__0)))))));
    vlSelf->__VdfgTmp_hf0dacca2__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004240_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000848_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h3fc388f6__0)))))));
    vlSelf->wasmetal_core__DOT___048011_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003970_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003969_)));
    vlSelf->wasmetal_core__DOT___048008_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004004_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001613_)));
    vlSelf->__VdfgTmp_h5978f26f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004654_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003121_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h7ca24d8b__0)))))));
    vlSelf->__VdfgTmp_hbd8e6335__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004684_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000849_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hfa0f79c8__0)))))));
    vlSelf->__VdfgTmp_ha13bce2f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003690_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003689_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_he18e3e19__0)))))));
    vlSelf->__VdfgTmp_h33498483__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003720_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000872_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hca53b37a__0)))))));
    vlSelf->wasmetal_core__DOT___048075_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004266_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004265_)));
    vlSelf->wasmetal_core__DOT___048072_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004300_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001625_)));
    vlSelf->__VdfgTmp_h71a6f88b__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003988_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003113_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb2ba9050__0)))))));
    vlSelf->__VdfgTmp_hb9ea03dd__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004018_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000873_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hde7deab4__0)))))));
    vlSelf->wasmetal_core__DOT___048016_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004044_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004043_)));
    vlSelf->wasmetal_core__DOT___048018_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004078_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001647_)));
    vlSelf->__VdfgTmp_h177129ae__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004284_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003115_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hf4fd0700__0)))))));
    vlSelf->__VdfgTmp_h4a9c07e1__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004314_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000896_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h56fd8038__0)))))));
    vlSelf->__VdfgTmp_h31225405__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004062_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___004061_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb807ebfb__0)))))));
    vlSelf->__VdfgTmp_hf93df92c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004092_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000897_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h5172aa32__0)))))));
    vlSelf->wasmetal_core__DOT___048139_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003828_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003827_)));
    vlSelf->wasmetal_core__DOT___048141_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003862_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000420_)));
    vlSelf->__VdfgTmp_h70d2167a__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003846_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003845_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hed09e4ce__0)))))));
    vlSelf->__VdfgTmp_h64e10f56__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003876_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000927_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h5f9a0992__0)))))));
    vlSelf->wasmetal_core__DOT___048043_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003920_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003919_)));
    vlSelf->wasmetal_core__DOT___048040_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003936_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000433_)));
    vlSelf->wasmetal_core__DOT___048060_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003400_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003399_)));
    vlSelf->wasmetal_core__DOT___048057_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003416_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000465_)));
    vlSelf->wasmetal_core__DOT___048047_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003332_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003331_)));
    vlSelf->wasmetal_core__DOT___048044_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003348_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000477_)));
    vlSelf->wasmetal_core__DOT___048391_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003146_))));
    vlSelf->wasmetal_core__DOT___053385_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x11ff0fffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___053383_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 3U)) 
                                                                       | ((8U 
                                                                           & ((1U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048679_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b12__05d)))));
    vlSelf->wasmetal_core__DOT___053373_ = (1U & (IData)(
                                                         (0xff00e000ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053371_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (2U 
                                                                             & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053122_)))))))));
    vlSelf->wasmetal_core__DOT___003030_ = (1U & (IData)(
                                                         (0xff00ff0f0f8888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_op 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x80U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___003039_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x53ffffffffffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & (vlSelf->insn_op 
                                                                                << 4U)) 
                                                                                | ((0x10U 
                                                                                & (vlSelf->insn_op 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & vlSelf->insn_op) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h11a2e1d4__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___047792_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((0x777ffffU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 4U) 
                                                                               | ((8U 
                                                                                & ((0x4000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002984_)))))) 
                                                                             & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___002981_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002980_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002979_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002978_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002977_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x777ffffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001234_))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___003028_ = (1U & (0xf0f33aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->insn_op 
                                                             >> 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___047955_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047954_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047953_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047789_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h88a73cb4__0))))))))))))));
    vlSelf->wasmetal_core__DOT___003033_ = (1U & (0xfff8f8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h50379cea__0))))));
    vlSelf->wasmetal_core__DOT___070600_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047979_))));
    vlSelf->wasmetal_core__DOT___070606_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047979_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070599_))));
    vlSelf->wasmetal_core__DOT___003029_ = (1U & (0xf0fff88U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047978_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->insn_op 
                                                             >> 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009501_)))))));
    vlSelf->wasmetal_core__DOT___051571_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051570_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051569_))));
    vlSelf->wasmetal_core__DOT___134151___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036778_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134151___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hcb9fc16c__0))));
    vlSelf->wasmetal_core__DOT___028309_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028244_))));
    vlSelf->wasmetal_core__DOT___028308_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028243_))));
    vlSelf->wasmetal_core__DOT___028306_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028241_))));
    vlSelf->wasmetal_core__DOT___028305_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028240_))));
    vlSelf->wasmetal_core__DOT___028304_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028239_))));
    vlSelf->wasmetal_core__DOT___028303_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028238_))));
    vlSelf->wasmetal_core__DOT___028302_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028237_))));
    vlSelf->wasmetal_core__DOT___028301_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028236_))));
    vlSelf->wasmetal_core__DOT___028300_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028235_))));
    vlSelf->wasmetal_core__DOT___028299_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028234_))));
    vlSelf->wasmetal_core__DOT___028298_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028233_))));
    vlSelf->wasmetal_core__DOT___028297_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028232_))));
    vlSelf->wasmetal_core__DOT___028295_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028230_))));
    vlSelf->wasmetal_core__DOT___028294_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028229_))));
    vlSelf->wasmetal_core__DOT___028293_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028228_))));
    vlSelf->wasmetal_core__DOT___028292_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028227_))));
    vlSelf->wasmetal_core__DOT___028291_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028226_))));
    vlSelf->wasmetal_core__DOT___028290_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028225_))));
    vlSelf->wasmetal_core__DOT___028289_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028224_))));
    vlSelf->wasmetal_core__DOT___028288_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028223_))));
    vlSelf->wasmetal_core__DOT___028287_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028222_))));
    vlSelf->wasmetal_core__DOT___028286_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028221_))));
    vlSelf->wasmetal_core__DOT___028316_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028251_))));
    vlSelf->wasmetal_core__DOT___028315_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028250_))));
    vlSelf->wasmetal_core__DOT___028314_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028249_))));
    vlSelf->wasmetal_core__DOT___028313_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028248_))));
    vlSelf->wasmetal_core__DOT___028312_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028247_))));
    vlSelf->wasmetal_core__DOT___028311_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028246_))));
    vlSelf->wasmetal_core__DOT___028310_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028245_))));
    vlSelf->wasmetal_core__DOT___028307_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028242_))));
    vlSelf->wasmetal_core__DOT___028296_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->insn_y) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028231_))));
    vlSelf->wasmetal_core__DOT___028285_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028220_))));
    vlSelf->wasmetal_core__DOT___062960_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5c8f7b91__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052879_)))));
    vlSelf->wasmetal_core__DOT___052890_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052885_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052884_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052882_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h93f3e051__0))))))));
    vlSelf->wasmetal_core__DOT___053355_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052911_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x100000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___052910_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053351_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053350_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___052901_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052893_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___052902_))))))))))));
    vlSelf->wasmetal_core__DOT___053090_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053089_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051201_))));
    vlSelf->wasmetal_core__DOT___062967_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053089_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062493_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062497_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052845_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051201_)))))))));
    vlSelf->wasmetal_core__DOT___064897_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128050___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___064730_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128050___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___063788_ = (1U & (0x7077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128050___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000358_))))));
    vlSelf->wasmetal_core__DOT___064462_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128050___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___046221_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052645_)))));
    vlSelf->__VdfgTmp_h7f45eb21__0 = (((IData)(vlSelf->wasmetal_core__DOT___044280_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052644_));
    vlSelf->wasmetal_core__DOT___052646_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052578_))));
    vlSelf->wasmetal_core__DOT___063447_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050381_)))));
    vlSelf->wasmetal_core__DOT___045287_ = (1U & (IData)(
                                                         (0xfffefeeefeeefeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071468_) 
                                                            << 4U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071467_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___045311_ = (1U & (IData)(
                                                         (0x1010000101000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071468_) 
                                                            << 3U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071467_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___045279_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071448_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071447_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071446_))))));
    vlSelf->wasmetal_core__DOT___045303_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071448_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071447_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071446_))))));
    vlSelf->wasmetal_core__DOT___045280_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071451_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071450_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071449_))))));
    vlSelf->wasmetal_core__DOT___045304_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071451_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071450_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071449_))))));
    vlSelf->wasmetal_core__DOT___045281_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071454_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071453_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071452_))))));
    vlSelf->wasmetal_core__DOT___045305_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071454_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071453_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071452_))))));
    vlSelf->wasmetal_core__DOT___045282_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071457_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071456_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071455_))))));
    vlSelf->wasmetal_core__DOT___045306_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071457_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071456_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071455_))))));
    vlSelf->wasmetal_core__DOT___045283_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071460_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071459_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071458_))))));
    vlSelf->wasmetal_core__DOT___045307_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071460_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071459_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071458_))))));
    vlSelf->wasmetal_core__DOT___045284_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071463_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071462_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071461_))))));
    vlSelf->wasmetal_core__DOT___045308_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071463_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071462_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071461_))))));
    vlSelf->wasmetal_core__DOT___045286_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071466_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071465_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071464_))))));
    vlSelf->wasmetal_core__DOT___045310_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071466_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071465_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071464_))))));
    vlSelf->__VdfgTmp_he0cbb0dc__0 = ((2U & (vlSelf->insn_z 
                                             >> 5U)) 
                                      | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2157de83__0))));
    vlSelf->__VdfgTmp_heaa2bcd7__0 = ((2U & (vlSelf->insn_z 
                                             >> 3U)) 
                                      | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2157de83__0))));
    vlSelf->__VdfgTmp_hed859ce1__0 = ((2U & (vlSelf->insn_z 
                                             >> 4U)) 
                                      | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2157de83__0))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b7__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b7__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 6U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050764_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 7U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b5__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 4U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___049400_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 5U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b2__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___048524_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 2U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b3__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 2U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___048526_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 3U))))));
    vlSelf->wasmetal_core__DOT___051172_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5760b542__0))))));
    vlSelf->wasmetal_core__DOT___050125_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6e193d9b__0))))));
    vlSelf->wasmetal_core__DOT___051180_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h79496643__0))))));
    vlSelf->wasmetal_core__DOT___050665_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb256bb9f__0))))));
    vlSelf->wasmetal_core__DOT___050746_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3eb04205__0))))));
    vlSelf->wasmetal_core__DOT___051127_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7a6ef80c__0))))));
    vlSelf->wasmetal_core__DOT___051156_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h40ae3a4f__0))))));
    vlSelf->wasmetal_core__DOT___051160_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he25b67d8__0))))));
    vlSelf->wasmetal_core__DOT___051164_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h89ddcfc9__0))))));
    vlSelf->wasmetal_core__DOT___050969_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0a9f8029__0))))));
    vlSelf->wasmetal_core__DOT___050991_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6ec6b47d__0))))));
    vlSelf->wasmetal_core__DOT___050973_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8555f3e8__0))))));
    vlSelf->wasmetal_core__DOT___050908_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc0d4cc40__0))))));
    vlSelf->wasmetal_core__DOT___050914_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0a192e7e__0))))));
    vlSelf->wasmetal_core__DOT___051090_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5864b2ba__0))))));
    vlSelf->wasmetal_core__DOT___050890_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc7c61c07__0))))));
    vlSelf->wasmetal_core__DOT___050783_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcafe333f__0))))));
    vlSelf->wasmetal_core__DOT___050779_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h236ea405__0))))));
    vlSelf->wasmetal_core__DOT___050244_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b75__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b74__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b73__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b72__05d)))))))));
    vlSelf->wasmetal_core__DOT___050236_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b99__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b98__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b97__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b96__05d)))))))));
    vlSelf->wasmetal_core__DOT___050240_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b119__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b118__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b117__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b116__05d)))))))));
    vlSelf->wasmetal_core__DOT___050196_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b179__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b178__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b177__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b176__05d)))))))));
    vlSelf->wasmetal_core__DOT___049912_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b131__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b130__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b129__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b128__05d)))))))));
    vlSelf->wasmetal_core__DOT___050204_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b151__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b150__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b149__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b148__05d)))))))));
    vlSelf->wasmetal_core__DOT___050220_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b195__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b194__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b193__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b192__05d)))))))));
    vlSelf->wasmetal_core__DOT___050216_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b235__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b234__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b233__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b232__05d)))))))));
    vlSelf->wasmetal_core__DOT___050212_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b247__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b246__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b245__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b244__05d)))))))));
    vlSelf->wasmetal_core__DOT___049976_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b75__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b74__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b73__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b72__05d)))))))));
    vlSelf->wasmetal_core__DOT___049980_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b99__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b98__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b97__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b96__05d)))))))));
    vlSelf->wasmetal_core__DOT___049984_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b119__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b118__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b117__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b116__05d)))))))));
    vlSelf->wasmetal_core__DOT___050000_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b179__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b178__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b177__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b176__05d)))))))));
    vlSelf->wasmetal_core__DOT___049996_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b131__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b130__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b129__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b128__05d)))))))));
    vlSelf->wasmetal_core__DOT___050004_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b151__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b150__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b149__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b148__05d)))))))));
    vlSelf->wasmetal_core__DOT___050016_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b195__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b194__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b193__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b192__05d)))))))));
    vlSelf->wasmetal_core__DOT___050020_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b235__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b234__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b233__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b232__05d)))))))));
    vlSelf->wasmetal_core__DOT___050024_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b247__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b246__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b245__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b244__05d)))))))));
    vlSelf->wasmetal_core__DOT___051176_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd8443bfe__0))))));
    vlSelf->wasmetal_core__DOT___051144_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1aa87dc1__0))))));
    vlSelf->wasmetal_core__DOT___051152_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h139eafce__0))))));
    vlSelf->wasmetal_core__DOT___050987_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hef41fa97__0))))));
    vlSelf->wasmetal_core__DOT___051086_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h47e0de34__0))))));
    vlSelf->wasmetal_core__DOT___050886_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc408f28d__0))))));
    vlSelf->wasmetal_core__DOT___050310_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h02a1ae9a__0))))));
    vlSelf->wasmetal_core__DOT___050303_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8c9e90c9__0))))));
    vlSelf->wasmetal_core__DOT___050318_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8546e85d__0))))));
    vlSelf->wasmetal_core__DOT___051005_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hefac84ff__0))))));
    vlSelf->wasmetal_core__DOT___051078_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf782be94__0))))));
    vlSelf->wasmetal_core__DOT___051001_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6727edf3__0))))));
    vlSelf->wasmetal_core__DOT___050232_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b87__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b86__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b85__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b84__05d)))))))));
    vlSelf->wasmetal_core__DOT___050200_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b171__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b170__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b169__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b168__05d)))))))));
    vlSelf->wasmetal_core__DOT___050224_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b215__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b214__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b213__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b212__05d)))))))));
    vlSelf->wasmetal_core__DOT___049972_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b87__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b86__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b85__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b84__05d)))))))));
    vlSelf->wasmetal_core__DOT___049992_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b171__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b170__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b169__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b168__05d)))))))));
    vlSelf->wasmetal_core__DOT___050012_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b215__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b214__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b213__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b212__05d)))))))));
    vlSelf->wasmetal_core__DOT___050314_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf05a0261__0))))));
    vlSelf->wasmetal_core__DOT___051074_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_haf724a20__0))))));
    vlSelf->wasmetal_core__DOT___050184_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___050188_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___050180_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___049956_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___049964_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___049960_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___050174_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___049934_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b0__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___048522_)))))) 
                                     << 1U)) | (1U 
                                                & vlSelf->cmd_index)))));
    vlSelf->__VdfgTmp_h2f11896e__0 = (((IData)(vlSelf->wasmetal_core__DOT___048522_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b6__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b6__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 5U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050766_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 6U))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__data_sizes__02ewords__02e0__02e0__ADDRARDADDR 
        = (0x803fU | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b7__05d) 
                       << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                    << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                 << 0xbU) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                    << 0xaU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                       << 9U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                          << 8U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                             << 7U) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                               << 6U)))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b4__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 3U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___049402_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 4U))))));
    vlSelf->wasmetal_core__DOT___053972_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050766_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049402_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d))))));
    vlSelf->wasmetal_core__DOT___053987_ = (1U & (0x99900999U 
                                                  >> 
                                                  ((0x10U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1bU)) 
                                                   | ((8U 
                                                       & (vlSelf->insn_x 
                                                          >> 0x1cU)) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7cea807__0)))));
    vlSelf->wasmetal_core__DOT___044486_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___044485_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___044487_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b31__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xcaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he7cea807__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___044479_ = (1U & (0xfffffffeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b13__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b12__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b11__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b10__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b31__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b31__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1eU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050924_)))))) 
                                     << 1U)) | (vlSelf->cmd_index 
                                                >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b19__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b19__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x12U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050945_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x13U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b16__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b16__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xfU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050947_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x10U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b8__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b8__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 7U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050959_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 8U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b22__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b22__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x15U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050952_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x16U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b29__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b29__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1cU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050937_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1dU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b25__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b25__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x18U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050927_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___053971_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050927_))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b28__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b28__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x1bU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050919_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x1cU))))));
    vlSelf->wasmetal_core__DOT___070592_ = (1U & (IData)(
                                                         (0x3500000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050937_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050919_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050924_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 0x1dU)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_x 
                                                                             >> 0x1eU))))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b23__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b23__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x16U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050950_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x17U))))));
    vlSelf->wasmetal_core__DOT___053964_ = (1U & (IData)(
                                                         (0xa2a200a28a008a8aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x12U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x13U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_x 
                                                                        >> 0x12U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 0x13U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b23__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050950_))))))))))));
    vlSelf->wasmetal_core__DOT___070591_ = (1U & (IData)(
                                                         (0x3500000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050950_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050952_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050927_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 0x17U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_x 
                                                                             >> 0x18U))))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b17__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b17__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0x10U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050943_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0x11U))))));
    vlSelf->wasmetal_core__DOT___053986_ = (1U & (IData)(
                                                         (0x1428000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_he16c95bc__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053980_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050919_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050943_)))))))));
    vlSelf->wasmetal_core__DOT___070590_ = (1U & (IData)(
                                                         (0x3500000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050943_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050947_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050945_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 0x11U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_x 
                                                                             >> 0x12U))))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b9__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b9__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 8U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050957_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 9U))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b13__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b13__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xcU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050935_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xdU))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b11__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b11__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xaU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050954_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xbU))))));
    vlSelf->wasmetal_core__DOT___053979_ = (1U & (IData)(
                                                         (0x4141410000414141ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 7U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_x 
                                                                  >> 8U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_x 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 0x14U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b11__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050954_))))))))))));
    vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b12__05d 
        = (1U & (0x3aU >> (((IData)(vlSelf->busy) << 2U) 
                           | ((2U & ((0xf0f33aaU >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__query_index__05b12__05d) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & (vlSelf->insn_y 
                                                            >> 0xbU)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___050933_)))))) 
                                     << 1U)) | (1U 
                                                & (vlSelf->cmd_index 
                                                   >> 0xcU))))));
    vlSelf->wasmetal_core__DOT___070589_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050933_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050954_))));
    vlSelf->wasmetal_core__DOT___031354_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1eU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031353_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1dU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031351_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1cU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031350_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1bU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031349_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1aU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031348_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x19U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031347_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x18U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031346_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x17U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031345_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x16U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031344_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x15U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031343_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x14U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031342_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x13U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031340_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x12U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031339_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x11U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031338_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x10U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031337_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xfU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031336_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xeU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031335_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xdU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031334_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xcU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031333_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xbU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031332_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xaU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031331_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 9U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031361_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 8U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031360_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 7U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031359_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 6U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031358_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 5U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031357_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 4U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031356_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 3U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031355_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031352_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071847_)))));
    vlSelf->wasmetal_core__DOT___031330_ = (1U & (0xf40bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051564_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071847_))))));
    vlSelf->wasmetal_core__DOT___053436_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053091_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5c8f7b91__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052834_)))));
    vlSelf->__VdfgTmp_h8ecdfd77__0 = (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052833_));
    vlSelf->__VdfgTmp_h56f16561__0 = (((IData)(vlSelf->wasmetal_core__DOT___052835_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052834_));
    vlSelf->wasmetal_core__DOT___053572_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052834_))));
    vlSelf->wasmetal_core__DOT___053957_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045851_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052649_)))));
    vlSelf->wasmetal_core__DOT___052650_ = (1U & (0x1f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052649_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048516_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052643_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048433_))))));
    vlSelf->wasmetal_core__DOT___071035_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b7__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 7U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071039_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b6__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 6U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071043_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b5__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 5U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071050_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b10__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 9U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071054_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b9__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 8U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071058_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b8__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071095_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b19__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x11U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071099_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b18__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x10U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071103_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b17__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__parity)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071110_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b22__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x14U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071114_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b21__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x13U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071118_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b20__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x12U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071155_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b31__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x1cU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071159_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b30__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x1bU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071163_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b29__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x1aU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071170_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b34__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x1fU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071174_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b33__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x1eU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071178_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b32__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x1dU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071215_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b43__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x27U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071219_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b42__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x26U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071223_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b41__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x25U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071230_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b46__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x29U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071234_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b45__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x28U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071238_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b44__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                >> 3U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071006_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 1U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071010_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data))))))));
    vlSelf->wasmetal_core__DOT___071020_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b4__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 4U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071024_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b3__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 3U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071028_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b2__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 2U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071065_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b13__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0xcU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071069_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b12__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0xbU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071073_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b11__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0xaU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071080_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b16__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0xfU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071084_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b15__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0xeU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071088_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b14__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0xdU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071125_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b25__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x17U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071129_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b24__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x16U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071133_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b23__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x15U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071140_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b28__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x19U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071144_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b27__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x18U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071148_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b26__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071185_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b37__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x21U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071189_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b36__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x20U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071193_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b35__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071200_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b40__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x24U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071204_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b39__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x23U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071208_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b38__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x22U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___071245_ = (1U & (0xf0880000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b47__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x2aU)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))));
    vlSelf->wasmetal_core__DOT___007882_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h93039dba__0)))));
    vlSelf->wasmetal_core__DOT___007870_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc8dfb864__0)))));
    vlSelf->wasmetal_core__DOT___007886_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h78b443e9__0)))));
    vlSelf->wasmetal_core__DOT___054807_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h51befd44__0)))));
    vlSelf->wasmetal_core__DOT___054809_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004043_))))));
    vlSelf->wasmetal_core__DOT___054815_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6d3f2850__0)))));
    vlSelf->wasmetal_core__DOT___054808_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003449_))))));
    vlSelf->wasmetal_core__DOT___054810_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3b966d55__0)))));
    vlSelf->wasmetal_core__DOT___054816_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h633a8051__0)))));
    vlSelf->wasmetal_core__DOT___054818_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1eef7f72__0)))));
    vlSelf->wasmetal_core__DOT___054820_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha84b0b95__0)))));
    vlSelf->wasmetal_core__DOT___007894_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd3bfd495__0)))));
    vlSelf->wasmetal_core__DOT___054987_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004413_))))));
    vlSelf->wasmetal_core__DOT___054989_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h979ce723__0)))));
    vlSelf->wasmetal_core__DOT___054995_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003101_))))));
    vlSelf->wasmetal_core__DOT___054998_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003313_))))));
    vlSelf->wasmetal_core__DOT___054988_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf41e7ecd__0)))));
    vlSelf->wasmetal_core__DOT___054990_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h46681fd6__0)))));
    vlSelf->wasmetal_core__DOT___054996_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003121_))))));
    vlSelf->wasmetal_core__DOT___055000_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf9b00456__0)))));
    vlSelf->wasmetal_core__DOT___054948_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004339_))))));
    vlSelf->wasmetal_core__DOT___054950_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h52bd55da__0)))));
    vlSelf->wasmetal_core__DOT___054956_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003099_))))));
    vlSelf->wasmetal_core__DOT___054958_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfd72e8ff__0)))));
    vlSelf->wasmetal_core__DOT___054949_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004191_))))));
    vlSelf->wasmetal_core__DOT___054951_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005283_))))));
    vlSelf->wasmetal_core__DOT___054957_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003119_))))));
    vlSelf->wasmetal_core__DOT___054959_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5f6c8a95__0)))));
    vlSelf->wasmetal_core__DOT___054898_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha853ba7f__0)))));
    vlSelf->wasmetal_core__DOT___054899_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heb8a147e__0)))));
    vlSelf->wasmetal_core__DOT___054900_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003919_))))));
    vlSelf->wasmetal_core__DOT___054901_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004875_))))));
    vlSelf->wasmetal_core__DOT___054907_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003117_))))));
    vlSelf->wasmetal_core__DOT___054909_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004857_))))));
    vlSelf->wasmetal_core__DOT___054906_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h51fc7bb2__0)))));
    vlSelf->wasmetal_core__DOT___054908_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003901_))))));
    vlSelf->wasmetal_core__DOT___051493_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004709_))))));
    vlSelf->wasmetal_core__DOT___051498_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003827_))))));
    vlSelf->wasmetal_core__DOT___051496_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8541949a__0)))));
    vlSelf->wasmetal_core__DOT___054863_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdb184deb__0)))));
    vlSelf->wasmetal_core__DOT___054865_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h136edfac__0)))));
    vlSelf->wasmetal_core__DOT___054860_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h18ff28cf__0)))));
    vlSelf->wasmetal_core__DOT___054861_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003107_))))));
    vlSelf->wasmetal_core__DOT___051491_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003523_))))));
    vlSelf->wasmetal_core__DOT___054767_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003233_))))));
    vlSelf->wasmetal_core__DOT___054768_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003597_))))));
    vlSelf->wasmetal_core__DOT___054769_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004265_))))));
    vlSelf->wasmetal_core__DOT___054775_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003095_))))));
    vlSelf->wasmetal_core__DOT___054779_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003115_))))));
    vlSelf->wasmetal_core__DOT___054770_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb12ee9bf__0)))));
    vlSelf->wasmetal_core__DOT___054777_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003111_))))));
    vlSelf->wasmetal_core__DOT___054781_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h10697dc9__0)))));
    vlSelf->wasmetal_core__DOT___007907_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h77a25d8c__0)))));
    vlSelf->wasmetal_core__DOT___054708_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003150_))))));
    vlSelf->wasmetal_core__DOT___054701_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h691e257b__0)))));
    vlSelf->wasmetal_core__DOT___054691_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003091_))))));
    vlSelf->wasmetal_core__DOT___054682_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h73150903__0)))));
    vlSelf->wasmetal_core__DOT___054705_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf440d852__0)))));
    vlSelf->wasmetal_core__DOT___054698_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005079_))))));
    vlSelf->wasmetal_core__DOT___054688_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h23f02d0a__0)))));
    vlSelf->wasmetal_core__DOT___054674_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005061_))))));
    vlSelf->wasmetal_core__DOT___007915_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2b4ef23a__0)))));
    vlSelf->wasmetal_core__DOT___007923_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h47fa9bfe__0)))));
    vlSelf->wasmetal_core__DOT___007946_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h30cac7a1__0)))));
    vlSelf->wasmetal_core__DOT___007931_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5fd7d7a9__0)))));
    vlSelf->wasmetal_core__DOT___007954_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5011624a__0)))));
    vlSelf->wasmetal_core__DOT___007962_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h32ee57a6__0)))));
    vlSelf->wasmetal_core__DOT___055033_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc9d89c9c__0)))));
    vlSelf->wasmetal_core__DOT___055035_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005147_))))));
    vlSelf->wasmetal_core__DOT___055044_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5c8699d0__0)))));
    vlSelf->wasmetal_core__DOT___055041_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003103_))))));
    vlSelf->wasmetal_core__DOT___055034_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003671_))))));
    vlSelf->wasmetal_core__DOT___055036_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005599_))))));
    vlSelf->wasmetal_core__DOT___055046_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005581_))))));
    vlSelf->wasmetal_core__DOT___055042_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003689_))))));
    vlSelf->wasmetal_core__DOT___007970_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hce5538fe__0)))));
    vlSelf->wasmetal_core__DOT___007983_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3daf64ed__0)))));
    vlSelf->wasmetal_core__DOT___007991_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5a182b30__0)))));
    vlSelf->wasmetal_core__DOT___007999_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he974eeb2__0)))));
    vlSelf->wasmetal_core__DOT___008048_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0cc9f882__0)))));
    vlSelf->wasmetal_core__DOT___008123_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6e881f1b__0)))));
    vlSelf->wasmetal_core__DOT___008198_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9dd568d9__0)))));
    vlSelf->wasmetal_core__DOT___008273_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h483290db__0)))));
    vlSelf->wasmetal_core__DOT___008349_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h379ad787__0)))));
    vlSelf->wasmetal_core__DOT___008424_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h56116db4__0)))));
    vlSelf->wasmetal_core__DOT___008032_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h560b7672__0)))));
    vlSelf->wasmetal_core__DOT___008040_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h63306680__0)))));
    vlSelf->wasmetal_core__DOT___008056_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3e3e53ad__0)))));
    vlSelf->wasmetal_core__DOT___008069_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd86a0826__0)))));
    vlSelf->wasmetal_core__DOT___008077_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9cad1664__0)))));
    vlSelf->wasmetal_core__DOT___008085_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf0334e7f__0)))));
    vlSelf->wasmetal_core__DOT___008107_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8670d2e8__0)))));
    vlSelf->wasmetal_core__DOT___008115_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h975aebd1__0)))));
    vlSelf->wasmetal_core__DOT___008131_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbaf6c8a7__0)))));
    vlSelf->wasmetal_core__DOT___008144_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbf5b2f76__0)))));
    vlSelf->wasmetal_core__DOT___008152_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9206c0aa__0)))));
    vlSelf->wasmetal_core__DOT___008160_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hec1752e3__0)))));
    vlSelf->wasmetal_core__DOT___008182_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h80fb591c__0)))));
    vlSelf->wasmetal_core__DOT___008257_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he040c9e4__0)))));
    vlSelf->wasmetal_core__DOT___008333_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd06fbc0c__0)))));
    vlSelf->wasmetal_core__DOT___008408_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h139d3776__0)))));
    vlSelf->wasmetal_core__DOT___008190_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4bc445dd__0)))));
    vlSelf->wasmetal_core__DOT___008206_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb0eafd09__0)))));
    vlSelf->wasmetal_core__DOT___008219_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h45ac64ad__0)))));
    vlSelf->wasmetal_core__DOT___008227_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd87e5f33__0)))));
    vlSelf->wasmetal_core__DOT___008235_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h218f194f__0)))));
    vlSelf->wasmetal_core__DOT___008265_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h268e4ef9__0)))));
    vlSelf->wasmetal_core__DOT___008281_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc65b9dd7__0)))));
    vlSelf->wasmetal_core__DOT___008294_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8c7509c5__0)))));
    vlSelf->wasmetal_core__DOT___008302_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5dede88d__0)))));
    vlSelf->wasmetal_core__DOT___008310_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb948b455__0)))));
    vlSelf->wasmetal_core__DOT___008341_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h375e931a__0)))));
    vlSelf->wasmetal_core__DOT___008357_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbf523586__0)))));
    vlSelf->wasmetal_core__DOT___008370_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc67fdbf4__0)))));
    vlSelf->wasmetal_core__DOT___008378_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heb331328__0)))));
    vlSelf->wasmetal_core__DOT___008386_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha541df85__0)))));
    vlSelf->wasmetal_core__DOT___008416_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0)))));
    vlSelf->wasmetal_core__DOT___008432_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0)))));
    vlSelf->wasmetal_core__DOT___008445_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0)))));
    vlSelf->wasmetal_core__DOT___008453_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0)))));
    vlSelf->wasmetal_core__DOT___008461_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h46733dea__0)))));
    vlSelf->__VdfgTmp_h7678d7b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h598b279f__0)));
    vlSelf->__VdfgTmp_hd0975535__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc23ff14f__0)));
    vlSelf->__VdfgTmp_h2cdc7e5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5d0edfe8__0)));
    vlSelf->__VdfgTmp_h81bae7c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0ee6a0be__0)));
    vlSelf->__VdfgTmp_hce5bccc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hd5ee5b41__0)));
    vlSelf->wasmetal_core__DOT___008007_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb96516e6__0)))));
    vlSelf->__VdfgTmp_h38ad22b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hfec86816__0)));
    vlSelf->wasmetal_core__DOT___008093_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3e1a5258__0)))));
    vlSelf->wasmetal_core__DOT___008168_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd6a330ca__0)))));
    vlSelf->wasmetal_core__DOT___008243_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h877e6c65__0)))));
    vlSelf->wasmetal_core__DOT___008318_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2b7d2fec__0)))));
    vlSelf->wasmetal_core__DOT___008394_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3378cabf__0)))));
    vlSelf->wasmetal_core__DOT___008469_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdb4c449f__0)))));
    vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034309_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___054543_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128640___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
    vlSelf->wasmetal_core__DOT___054544_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128640___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
    vlSelf->wasmetal_core__DOT___054545_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128640___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
    vlSelf->wasmetal_core__DOT___054546_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128647___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
    vlSelf->wasmetal_core__DOT___054547_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128647___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
    vlSelf->wasmetal_core__DOT___054548_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128647___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
    vlSelf->wasmetal_core__DOT___054549_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128647___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
    vlSelf->wasmetal_core__DOT___054550_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128648___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001370_)))));
    vlSelf->wasmetal_core__DOT___054551_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128648___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001382_)))));
    vlSelf->wasmetal_core__DOT___054552_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128648___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001414_)))));
    vlSelf->wasmetal_core__DOT___054553_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128648___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001426_)))));
    vlSelf->wasmetal_core__DOT___054554_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128649___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001525_)))));
    vlSelf->wasmetal_core__DOT___054555_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128649___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001537_)))));
    vlSelf->wasmetal_core__DOT___054556_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128649___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001569_)))));
    vlSelf->wasmetal_core__DOT___054557_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128649___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001581_)))));
    vlSelf->wasmetal_core__DOT___054558_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128650___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001613_)))));
    vlSelf->wasmetal_core__DOT___054559_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128650___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001625_)))));
    vlSelf->wasmetal_core__DOT___054560_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128650___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001647_)))));
    vlSelf->wasmetal_core__DOT___054561_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128650___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000420_)))));
    vlSelf->wasmetal_core__DOT___054562_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128651___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000433_)))));
    vlSelf->wasmetal_core__DOT___054563_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128651___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000465_)))));
    vlSelf->wasmetal_core__DOT___054564_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128651___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000477_)))));
    vlSelf->wasmetal_core__DOT___054565_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128651___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000499_)))));
    vlSelf->wasmetal_core__DOT___054566_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128652___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000521_)))));
    vlSelf->wasmetal_core__DOT___054567_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128652___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000543_)))));
    vlSelf->wasmetal_core__DOT___054568_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128652___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000565_)))));
    vlSelf->wasmetal_core__DOT___054569_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128652___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000592_)))));
    vlSelf->wasmetal_core__DOT___054570_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128653___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000614_)))));
    vlSelf->wasmetal_core__DOT___054571_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128653___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000636_)))));
    vlSelf->wasmetal_core__DOT___054572_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128653___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000658_)))));
    vlSelf->wasmetal_core__DOT___054573_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128653___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005617_)))));
    vlSelf->wasmetal_core__DOT___054542_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128640___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
    vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034477_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___054639_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_wide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052805_))));
    vlSelf->wasmetal_core__DOT___019799_ = (1U & (IData)(
                                                         (0x700000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053751_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052956_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053426_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x7fff0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053749_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053745_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h63180e3e__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b7__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b6__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b1__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf90c45d9__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053740_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b27__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b26__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b24__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053739_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heb1fb9b9__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b23__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b22__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b16__05d)))))))))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha85820a5__0))))))));
    vlSelf->wasmetal_core__DOT___053347_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053334_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha85820a5__0))));
    vlSelf->wasmetal_core__DOT___039819_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128222___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039798_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128222___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039797_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128222___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039780_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128222___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039411_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128223___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039775_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128223___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039794_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128223___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039793_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128223___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039791_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128224___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___039790_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128224___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039801_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128224___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039804_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128224___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039806_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128225___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039795_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128225___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039413_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128225___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039789_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128225___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039817_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128226___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039813_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128226___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039811_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128226___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039803_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128226___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039810_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128227___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039809_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128227___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039812_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128227___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039808_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128227___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039814_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128228___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039815_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128228___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039821_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128228___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039818_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128228___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039802_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128229___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039414_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128229___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039807_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128229___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039816_ = (1U & (IData)(
                                                         (0xeeaa2a2a22aa2a2aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128229___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___048210_ = (1U & (0xa008aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->insn_op) 
                                                         | (IData)(vlSelf->__VdfgTmp_h50379cea__0))))));
    vlSelf->wasmetal_core__DOT___048430_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045703_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044168_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___045715_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___044180_))))));
    vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_z >> 8U) & (IData)(vlSelf->wasmetal_core__DOT___027958_));
    vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x100U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 8U) : (IData)(vlSelf->wasmetal_core__DOT___030493_)));
    vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032894_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d));
    vlSelf->wasmetal_core__DOT___065859_ = (1U & (0x33207f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b11__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065853_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065852_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065851_)))))));
    vlSelf->wasmetal_core__DOT___066378_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x3fff20003fff3fffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b16__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066343_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                              << 2U)) 
                                                                          | ((4U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___066342_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066341_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x330f5500000000ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((1U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                              >> 2U))) 
                                                                         << 5U)) 
                                                                     | ((0x18U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                            << 3U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___064361_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064360_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___064445_))))))))))));
    vlSelf->wasmetal_core__DOT___066511_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066505_))));
    vlSelf->wasmetal_core__DOT___066590_ = (1U & (0x80b000f0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b19__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066588_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066587_)))))));
    vlSelf->wasmetal_core__DOT___066757_ = (1U & (0x80b000f0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b21__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066755_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066754_)))))));
    vlSelf->wasmetal_core__DOT___066840_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066835_))));
    vlSelf->wasmetal_core__DOT___067019_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xcfff4000cfffcfffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b24__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067005_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                              << 2U)) 
                                                                          | ((4U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___067004_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067003_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xaa330f00000000ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((1U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                              >> 2U))) 
                                                                         << 5U)) 
                                                                     | ((0x18U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                            << 3U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___065519_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h82ca1536__0)))))))))));
    vlSelf->wasmetal_core__DOT___067064_ = (1U & (IData)(
                                                         (0x30f0200030f030fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067054_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065659_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h61c930cb__0)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___067048_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___067051_)))))))));
    vlSelf->wasmetal_core__DOT___067138_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067133_))));
    vlSelf->wasmetal_core__DOT___067440_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067435_))));
    vlSelf->wasmetal_core__DOT___067649_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064711_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067646_)))));
    vlSelf->wasmetal_core__DOT___067716_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064840_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067714_)))));
    vlSelf->wasmetal_core__DOT___067795_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065031_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067793_)))));
    vlSelf->wasmetal_core__DOT___066933_ = (1U & (IData)(
                                                         (0x30f0200030f030fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066924_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x55330f00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065483_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3c0e85cc__0)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___066919_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066921_)))))))));
    vlSelf->wasmetal_core__DOT___065484_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3c0e85cc__0))));
    vlSelf->wasmetal_core__DOT___065379_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h96c6858e__0))));
    vlSelf->wasmetal_core__DOT___066837_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065377_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h96c6858e__0)))));
    vlSelf->wasmetal_core__DOT___067843_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065148_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067842_)))));
    vlSelf->wasmetal_core__DOT___065222_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h84a28025__0))));
    vlSelf->wasmetal_core__DOT___066747_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065221_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h84a28025__0)))));
    vlSelf->wasmetal_core__DOT___070303_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069749_))));
    vlSelf->wasmetal_core__DOT___065141_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2f6e42c0__0))));
    vlSelf->wasmetal_core__DOT___067887_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065228_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067885_)))));
    vlSelf->wasmetal_core__DOT___067948_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065385_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067945_)))));
    vlSelf->wasmetal_core__DOT___068010_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065490_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068008_)))));
    vlSelf->wasmetal_core__DOT___068063_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065517_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068061_)))));
    vlSelf->wasmetal_core__DOT___068137_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065657_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068136_)))));
    vlSelf->wasmetal_core__DOT___068223_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065852_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068222_)))));
    vlSelf->wasmetal_core__DOT___068191_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065766_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068188_)))));
    vlSelf->wasmetal_core__DOT___068277_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065963_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068275_)))));
    vlSelf->wasmetal_core__DOT___068329_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066032_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068328_)))));
    vlSelf->wasmetal_core__DOT___068386_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066188_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068384_)))));
    vlSelf->wasmetal_core__DOT___068460_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066230_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068459_)))));
    vlSelf->wasmetal_core__DOT___064713_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064697_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064696_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xff00ff00f0f0eeeeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064694_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064693_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf050f030f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064267_) 
                                                                                << 5U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                                                << 3U)) 
                                                                                | ((2U 
                                                                                & vlSelf->mem_rdata[0U]) 
                                                                                | (1U 
                                                                                & (vlSelf->mem_rdata[0U] 
                                                                                >> 2U))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064690_))))))))))))))));
    vlSelf->wasmetal_core__DOT___067650_ = (1U & (IData)(
                                                         (0xfbfff3f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b33__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064697_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064709_)))))))));
    vlSelf->wasmetal_core__DOT___065687_ = (1U & (IData)(
                                                         (0x5f3f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((0x33207f7fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b9__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065658_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065657_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065656_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f0ccaaU 
                                                                            >> 
                                                                            ((0x10U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 4U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065659_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064681_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064694_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065662_)))))))));
    vlSelf->wasmetal_core__DOT___067798_ = (1U & (0x7033U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065024_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b35__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065034_)))))));
    vlSelf->wasmetal_core__DOT___065773_ = (1U & (IData)(
                                                         (0x70707777ff00ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065768_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065767_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065766_)))))))));
    vlSelf->wasmetal_core__DOT___070238_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069637_))));
    vlSelf->wasmetal_core__DOT___069224_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067533_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069221_)))));
    vlSelf->wasmetal_core__DOT___069457_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065490_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068008_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069452_))))));
    vlSelf->wasmetal_core__DOT___068835_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066919_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068833_)))));
    vlSelf->wasmetal_core__DOT___070177_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069546_))));
    vlSelf->wasmetal_core__DOT___069548_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065852_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068222_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069546_))))));
    vlSelf->wasmetal_core__DOT___069030_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067245_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069027_)))));
    vlSelf->wasmetal_core__DOT___069900_ = (1U & (IData)(
                                                         (0xaa330f0000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067245_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069027_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___069894_)))))));
    vlSelf->wasmetal_core__DOT___069353_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b67__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065031_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067793_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069346_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xd7U 
                                                                  >> 
                                                                  ((4U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065037_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))))));
    vlSelf->wasmetal_core__DOT___069730_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066587_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068636_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069727_))))));
    vlSelf->wasmetal_core__DOT___068638_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066587_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068636_)))));
    vlSelf->wasmetal_core__DOT___069403_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b69__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065228_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067885_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069395_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xa23fU 
                                                                  >> 
                                                                  ((0xcU 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       << 1U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065232_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0xf8ff00ff00ff00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h62686ece__0))))))))))))));
    vlSelf->wasmetal_core__DOT___069773_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066754_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068733_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069770_))))));
    vlSelf->wasmetal_core__DOT___068735_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066754_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068733_)))));
    vlSelf->wasmetal_core__DOT___070206_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069588_))));
    vlSelf->wasmetal_core__DOT___069595_ = (1U & (0x7f300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b77__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___066032_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068328_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069588_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x4ea0U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hd4f38404__0)))))))));
    vlSelf->wasmetal_core__DOT___069941_ = (1U & (IData)(
                                                         (0xaa330f0000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067389_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069122_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___069937_)))))));
    vlSelf->wasmetal_core__DOT___069125_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067389_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069122_)))));
    vlSelf->wasmetal_core__DOT___070150_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069500_))));
    vlSelf->wasmetal_core__DOT___069502_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065657_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068136_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069500_))))));
    vlSelf->wasmetal_core__DOT___068931_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067048_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068929_)))));
    vlSelf->wasmetal_core__DOT___069859_ = (1U & (IData)(
                                                         (0xaa330f0000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067048_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068929_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___069855_)))))));
    vlSelf->wasmetal_core__DOT___069302_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b65__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___064711_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067646_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069290_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xa27fU 
                                                                  >> 
                                                                  ((0xcU 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                       << 1U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064707_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___069295_)))))))))));
    vlSelf->wasmetal_core__DOT___069685_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066439_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068522_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069682_))))));
    vlSelf->wasmetal_core__DOT___068524_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066439_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068522_)))));
    vlSelf->wasmetal_core__DOT___069192_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067435_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069189_)))));
    vlSelf->wasmetal_core__DOT___069961_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067435_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069189_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069958_))))));
    vlSelf->wasmetal_core__DOT___070221_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069611_))));
    vlSelf->wasmetal_core__DOT___069618_ = (1U & (0x7f300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b78__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___066188_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068384_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069611_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x4aU 
                                                                  >> 
                                                                  ((4U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___066185_)))))))))));
    vlSelf->wasmetal_core__DOT___069428_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b70__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065385_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067945_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069421_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xd7U 
                                                                  >> 
                                                                  ((4U 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065389_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))))));
    vlSelf->wasmetal_core__DOT___069795_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066835_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068783_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069791_))))));
    vlSelf->wasmetal_core__DOT___068786_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066835_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068783_)))));
    vlSelf->wasmetal_core__DOT___069523_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065766_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069519_))))));
    vlSelf->wasmetal_core__DOT___068999_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067133_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068996_)))));
    vlSelf->wasmetal_core__DOT___069876_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067133_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069873_))))));
    vlSelf->wasmetal_core__DOT___068589_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066505_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068586_)))));
    vlSelf->wasmetal_core__DOT___070043_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069323_))));
    vlSelf->wasmetal_core__DOT___069326_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064840_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067714_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069323_))))));
    vlSelf->wasmetal_core__DOT___070075_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069371_))));
    vlSelf->wasmetal_core__DOT___069378_ = (1U & (0x7f300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b68__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xaacc0fffU 
                                                                 >> 
                                                                 ((0x18U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065148_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067842_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___069371_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x7fff800000000000ULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h5851eae3__0))))))))));
    vlSelf->wasmetal_core__DOT___068688_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066700_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068686_)))));
    vlSelf->wasmetal_core__DOT___069573_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065963_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068275_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069571_))))));
    vlSelf->wasmetal_core__DOT___070186_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069571_))));
    vlSelf->wasmetal_core__DOT___069917_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067284_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069074_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___069915_))))));
    vlSelf->wasmetal_core__DOT___069076_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067284_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___069074_)))));
    vlSelf->wasmetal_core__DOT___070128_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069480_))));
    vlSelf->wasmetal_core__DOT___069838_ = (1U & (IData)(
                                                         (0xaa330f0000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067004_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068880_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___069834_)))))));
    vlSelf->wasmetal_core__DOT___068881_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067004_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068880_)))));
    vlSelf->wasmetal_core__DOT___068505_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066342_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068504_)))));
    vlSelf->__VdfgTmp_h0e48eaa1__0 = (((IData)(vlSelf->wasmetal_core__DOT___065673_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067059_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___067634_))))))));
    vlSelf->wasmetal_core__DOT___065576_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065534_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065533_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065532_)))))))));
    vlSelf->wasmetal_core__DOT___065870_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065867_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065866_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h38f5e1f6__0))))))))))));
    vlSelf->__VdfgTmp_h28baf300__0 = (((IData)(vlSelf->wasmetal_core__DOT___065866_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067230_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___067780_))))))));
    vlSelf->__VdfgTmp_he6f0d7f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___065750_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067120_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___067692_))))))));
    vlSelf->wasmetal_core__DOT___065753_ = (1U & (0x20003fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b10__05d) 
                                                    << 4U) 
                                                   | ((0xcU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065750_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065749_))))));
    vlSelf->__VdfgTmp_h051c8ed8__0 = (((IData)(vlSelf->wasmetal_core__DOT___065984_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067276_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (4U 
                                                              >> 
                                                              (2U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___067549_)) 
                                                                  << 1U)))))))));
    vlSelf->__VdfgTmp_hc00cbbb6__0 = (((IData)(vlSelf->wasmetal_core__DOT___066044_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067374_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (4U 
                                                              >> 
                                                              (2U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___067633_)) 
                                                                  << 1U)))))))));
    vlSelf->wasmetal_core__DOT___066050_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               >> 2U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066044_)))));
    vlSelf->wasmetal_core__DOT___066247_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066244_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066243_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfffe000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h88f593f0__0))))))))))));
    vlSelf->__VdfgTmp_h482142a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___066243_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067518_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   (2U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (2U 
                                                                         & ((4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___067547_) 
                                                                              << 1U)) 
                                                                            << 1U))) 
                                                                       << 1U))) 
                                                                  << 1U)))))))));
    vlSelf->wasmetal_core__DOT___066178_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066175_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066174_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066173_)))))))));
    vlSelf->__VdfgTmp_h0c18689a__0 = (((IData)(vlSelf->wasmetal_core__DOT___066174_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067416_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   (2U 
                                                                    & ((1U 
                                                                        >> (IData)(vlSelf->wasmetal_core__DOT___067548_)) 
                                                                       << 1U))) 
                                                                  << 1U)))))))));
    vlSelf->wasmetal_core__DOT___066379_ = (1U & (0x80ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066355_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066354_)))))));
    vlSelf->__VdfgTmp_h9b35e8c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___066354_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067551_)))));
    vlSelf->__VdfgTmp_h6c009ef6__0 = (((IData)(vlSelf->wasmetal_core__DOT___066454_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067635_)))));
    vlSelf->wasmetal_core__DOT___066460_ = (1U & (0x40ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066455_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066454_)))))));
    vlSelf->wasmetal_core__DOT___064637_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064634_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064633_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064632_)))))))));
    vlSelf->__VdfgTmp_he7e046c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___067061_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___067634_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
}
