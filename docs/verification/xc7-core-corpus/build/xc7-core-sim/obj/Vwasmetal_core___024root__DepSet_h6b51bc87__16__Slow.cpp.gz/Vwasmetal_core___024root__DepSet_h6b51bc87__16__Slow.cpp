#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__41(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__41\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___015659_;
    wasmetal_core__DOT___015659_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015679_;
    wasmetal_core__DOT___015679_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015682_;
    wasmetal_core__DOT___015682_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015683_;
    wasmetal_core__DOT___015683_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015687_;
    wasmetal_core__DOT___015687_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015736_;
    wasmetal_core__DOT___015736_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015759_;
    wasmetal_core__DOT___015759_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015766_;
    wasmetal_core__DOT___015766_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015767_;
    wasmetal_core__DOT___015767_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015834_;
    wasmetal_core__DOT___015834_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015846_;
    wasmetal_core__DOT___015846_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015847_;
    wasmetal_core__DOT___015847_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015860_;
    wasmetal_core__DOT___015860_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015869_;
    wasmetal_core__DOT___015869_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015876_;
    wasmetal_core__DOT___015876_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015902_;
    wasmetal_core__DOT___015902_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015947_;
    wasmetal_core__DOT___015947_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015948_;
    wasmetal_core__DOT___015948_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023277_;
    wasmetal_core__DOT___023277_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023925_;
    wasmetal_core__DOT___023925_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024052_;
    wasmetal_core__DOT___024052_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027462_;
    wasmetal_core__DOT___027462_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035753_;
    wasmetal_core__DOT___035753_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035970_;
    wasmetal_core__DOT___035970_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035981_;
    wasmetal_core__DOT___035981_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045872_;
    wasmetal_core__DOT___045872_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045873_;
    wasmetal_core__DOT___045873_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045896_;
    wasmetal_core__DOT___045896_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045897_;
    wasmetal_core__DOT___045897_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058768_;
    wasmetal_core__DOT___058768_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058774_;
    wasmetal_core__DOT___058774_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058908_;
    wasmetal_core__DOT___058908_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127607___O;
    wasmetal_core__DOT____Vcellout___127607___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127608___O;
    wasmetal_core__DOT____Vcellout___127608___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___127950___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___127950___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___127966___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127966___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128245___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128245___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h838bb85c__0;
    __VdfgTmp_h838bb85c__0 = 0;
    CData/*1:0*/ __VdfgTmp_hfc488d72__0;
    __VdfgTmp_hfc488d72__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4fb57fe8__0;
    __VdfgTmp_h4fb57fe8__0 = 0;
    CData/*1:0*/ __VdfgTmp_h03eaf1be__0;
    __VdfgTmp_h03eaf1be__0 = 0;
    CData/*2:0*/ __VdfgTmp_h898161e8__0;
    __VdfgTmp_h898161e8__0 = 0;
    CData/*3:0*/ __VdfgTmp_hdfd93176__0;
    __VdfgTmp_hdfd93176__0 = 0;
    CData/*5:0*/ __VdfgTmp_hf2bf1435__0;
    __VdfgTmp_hf2bf1435__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6b2d1b17__0;
    __VdfgTmp_h6b2d1b17__0 = 0;
    CData/*3:0*/ __VdfgTmp_h5e2f8bee__0;
    __VdfgTmp_h5e2f8bee__0 = 0;
    CData/*3:0*/ __VdfgTmp_h19b58510__0;
    __VdfgTmp_h19b58510__0 = 0;
    CData/*1:0*/ __VdfgTmp_h91f24ade__0;
    __VdfgTmp_h91f24ade__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___054445_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054447_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___045082_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071244_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071243_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071242_))))))));
    vlSelf->wasmetal_core__DOT___045106_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071244_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071243_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071242_)))))))));
    vlSelf->wasmetal_core__DOT___045083_ = (1U & (0x7150U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071251_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___CO) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071250_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071249_)))))));
    vlSelf->wasmetal_core__DOT___045107_ = (1U & (0x41000041U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___CO) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071249_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071250_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071251_)))))));
    wasmetal_core__DOT___045872_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbd97d07b__0)))))));
    wasmetal_core__DOT___045873_ = (1U & (0xbfabbbaaU 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                  << 2U)) 
                                              | ((8U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___CO) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___045897_ = (1U & (0x41000041U 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                  << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                           >> 2U)) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___CO) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___045896_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127899___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___004904_)))))))));
    wasmetal_core__DOT___128245___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030278_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128245___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d));
    wasmetal_core__DOT___127966___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127966___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127950___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___006595_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___023202_))));
    wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023202_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127519___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128547___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d)))))) 
           ^ ((((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)) 
                & (IData)(vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033473_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127623___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024048_)))));
    wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023789_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127589___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d));
    vlSelf->wasmetal_core__DOT___058923_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058921_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058920_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hfcfdf45d__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0)))))))))));
    vlSelf->wasmetal_core__DOT___058813_ = (1U & (0x7fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058811_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb70db301__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha9e2ef67__0))))));
    wasmetal_core__DOT____Vcellout___127607___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d)))))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023921_)))));
    wasmetal_core__DOT___023925_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d) {
        wasmetal_core__DOT___024052_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d;
        wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d;
    } else {
        wasmetal_core__DOT___024052_ = vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___023925_;
    }
    wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b21__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128867___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___035986_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071821_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b33__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT___035984_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b32__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071819_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b31__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___036002_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071836_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b48__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___036000_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b47__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071834_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b46__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___043119_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017299_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h182596d5__0))));
    vlSelf->wasmetal_core__DOT___036001_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071835_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b47__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___035999_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071833_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b45__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___035966_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071803_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b15__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___035964_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071801_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b13__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___035974_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071810_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b22__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___035972_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b21__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071808_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b20__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___035987_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b35__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071822_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b34__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d)))))))));
    vlSelf->wasmetal_core__DOT___035985_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b33__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b32__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___036008_ = (1U & (0xf807U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b54__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b54__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0))))))));
    wasmetal_core__DOT___035981_ = (1U & (IData)((0xffffeac00000153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b2__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071789_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b1__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b1__05d)))))))));
    wasmetal_core__DOT___035970_ = (1U & (IData)((0xffffeac00000153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b1__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071788_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b0__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___058532_ = (1U & (0x40000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058528_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d 
        = (1U & (0xa3U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017895_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                    >> 3U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d 
        = (1U & (0xa3U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017896_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                    >> 2U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                               >> 1U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                             << 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O))))));
    wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023430_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023441_)
            : (IData)(vlSelf->wasmetal_core__DOT___023430_));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hfe3e676b__0)))) {
        wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d;
        wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b54__05d;
        wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d;
    } else {
        wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036955_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134179___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hfe3e676b__0))));
    vlSelf->wasmetal_core__DOT___043070_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                               << 2U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                     >> 1U)) 
                                                                 | ((2U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___043074_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b57__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O) 
                                               >> 1U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b56__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                             << 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127460___O))))));
    wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023551_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023562_)
            : (IData)(vlSelf->wasmetal_core__DOT___023551_));
    vlSelf->wasmetal_core__DOT___045039_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071908_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___071339_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071338_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___070777_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054448_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x37U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___070880_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054447_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x37U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___045061_ = ((IData)(vlSelf->wasmetal_core__DOT___045107_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045106_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045104_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045103_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045102_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045101_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045100_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045099_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045098_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045097_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___045096_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045095_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045115_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045114_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045113_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045112_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045111_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045110_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045109_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045108_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045105_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045094_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045070_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045081_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045084_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045085_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045086_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045087_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045088_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045089_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045090_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045091_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045071_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___045072_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045073_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045074_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045075_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045076_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045077_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045078_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045079_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045080_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045082_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045083_));
    vlSelf->wasmetal_core__DOT___045851_ = ((IData)(wasmetal_core__DOT___045897_)
                                             ? ((IData)(wasmetal_core__DOT___045896_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045894_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045893_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045892_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045891_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045890_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045889_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045888_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045887_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___045886_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045885_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045905_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045904_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045903_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045902_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045901_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045900_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045899_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045898_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045895_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045884_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045860_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045871_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045874_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045875_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045876_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045877_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045878_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045879_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045880_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045881_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045861_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___045862_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045863_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045864_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045865_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045866_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045867_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045868_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045869_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045870_))
                                                 : (IData)(wasmetal_core__DOT___045872_))
                                             : (IData)(wasmetal_core__DOT___045873_));
    vlSelf->wasmetal_core__DOT____Vcellout___128245___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030280_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030279_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030278_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030277_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___030279_)
                 ? (IData)(wasmetal_core__DOT___128245___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128245___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128245___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030211_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127966___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
           ^ (((IData)(wasmetal_core__DOT___127966___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127966___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127966___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027453_)))));
    vlSelf->wasmetal_core__DOT___027457_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127966___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127950___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027392_)
              ? (IData)(vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b63__05d)) 
            << 3U) | (IData)(wasmetal_core__DOT___127950___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127950___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027392_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027391_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027390_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027389_)))) 
           ^ (((IData)(wasmetal_core__DOT___127950___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027322_)));
    vlSelf->__VdfgTmp_h180177b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___006596_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006595_));
    vlSelf->wasmetal_core__DOT____Vcellout___127519___O 
        = (((8U & ((0x5cU >> (IData)(vlSelf->__VdfgTmp_haf233eab__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___023202_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023191_) 
                                          << 1U) | 
                                         (1U & (0xeU 
                                                >> (IData)(vlSelf->__VdfgTmp_hb47377e1__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127519___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (0xeU 
                                              >> (IData)(vlSelf->__VdfgTmp_hb47377e1__0))) 
                                          << 1U)))));
    wasmetal_core__DOT___023277_ = ((0x5cU >> (IData)(vlSelf->__VdfgTmp_haf233eab__0)) 
                                    & (IData)(wasmetal_core__DOT___127519___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___057532_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0ccaa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O) 
                                                                                >> 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d))))))))))));
    vlSelf->wasmetal_core__DOT___057284_ = (1U & (IData)(
                                                         (0xff00aaaaf0f0ccccULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d)))))))));
    vlSelf->wasmetal_core__DOT___012343_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f0ccccff00aaaaULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___013002_ = (1U & (IData)(
                                                         (0x3355ff0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O) 
                                                                             >> 3U))))))))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d) {
        wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d;
        wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d;
    } else {
        wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024052_;
        wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023790_)
            ? (IData)(wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d));
    vlSelf->wasmetal_core__DOT___060557_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127607___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___060543_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(wasmetal_core__DOT____Vcellout___127607___O)))));
    vlSelf->wasmetal_core__DOT___058758_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127607___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d))));
    vlSelf->wasmetal_core__DOT___058761_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127607___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d))));
    vlSelf->__VdfgTmp_ha2ad37d5__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127607___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005996_));
    vlSelf->__VdfgTmp_h43f5f2ec__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127607___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006065_));
    wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b22__05d) 
           & (IData)(wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___035970_) ? (IData)(vlSelf->wasmetal_core__DOT___128795___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b1__05d));
    vlSelf->__VdfgTmp_h7cb02621__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051266_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                              >> 3U)))))));
    vlSelf->__VdfgTmp_hc2af737a__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051268_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                              >> 2U)))))));
    wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023431_)
            ? (IData)(wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023431_));
    vlSelf->wasmetal_core__DOT____Vcellout___128789___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128775___S) 
           ^ (((IData)(wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h7a977bbe__0)))) {
        vlSelf->wasmetal_core__DOT___035869_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d;
        wasmetal_core__DOT___035753_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b55__05d;
        vlSelf->wasmetal_core__DOT___035725_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d;
    } else {
        vlSelf->wasmetal_core__DOT___035869_ = wasmetal_core__DOT___128789___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___035753_ = wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___035725_ = wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___134179___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036956_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036955_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036954_) 
                                   << 1U) | (1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__) 
               << 3U) | ((IData)(vlSelf->wasmetal_core__DOT___134179___DOT__CO__BRA__1__KET__) 
                         << 2U)));
    vlSelf->wasmetal_core__DOT___036944_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036956_)
                                                   ? (IData)(wasmetal_core__DOT___134179___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7a977bbe__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128779___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128775___S) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128779___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128775___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128775___S) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128775___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    __VdfgTmp_hfc488d72__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b57__05d) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d));
    __VdfgTmp_h4fb57fe8__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b56__05d) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d));
    wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023552_)
            ? (IData)(wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023552_));
    vlSelf->wasmetal_core__DOT___045038_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071339_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___045014_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071339_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054241_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                   << 3U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054243_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071337_))))));
    vlSelf->wasmetal_core__DOT___070779_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054446_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070777_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x36U)))))))))));
    vlSelf->wasmetal_core__DOT___070778_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054446_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x36U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___070882_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054445_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070880_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x36U)))))))))));
    vlSelf->wasmetal_core__DOT___070881_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070880_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054445_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x36U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___053957_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045851_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052649_)))));
    vlSelf->wasmetal_core__DOT___044855_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h0f43979c__0)))))))))));
    vlSelf->wasmetal_core__DOT___044879_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h0f43979c__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d)))))))));
    __VdfgTmp_h91f24ade__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O)) 
                              | (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d)))));
    vlSelf->wasmetal_core__DOT___063348_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128360___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128448___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063350_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128360___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128448___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063352_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128360___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128448___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063354_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128360___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128448___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027457_));
    vlSelf->wasmetal_core__DOT___006232_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127519___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006159_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf92fc642__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hf92fc642__0)))))));
    wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__ 
        = ((0x5cU >> (IData)(vlSelf->__VdfgTmp_h1d759fa4__0)) 
           & (IData)(wasmetal_core__DOT___023277_));
    wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)
            : (IData)(wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127589___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023791_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023790_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023789_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023788_)))) 
           ^ (((IData)(wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127589___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127589___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023724_)))));
    vlSelf->wasmetal_core__DOT___023728_ = ((IData)(vlSelf->wasmetal_core__DOT___023791_)
                                             ? (IData)(wasmetal_core__DOT___127589___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d));
    vlSelf->wasmetal_core__DOT___023793_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060557_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d))));
    vlSelf->wasmetal_core__DOT___023792_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060543_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d))));
    vlSelf->wasmetal_core__DOT___058875_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058761_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hcf1816fa__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d))))));
    vlSelf->wasmetal_core__DOT___058767_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127623___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058761_))));
    vlSelf->wasmetal_core__DOT___023795_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d))));
    vlSelf->wasmetal_core__DOT___023794_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d))));
    vlSelf->wasmetal_core__DOT___058874_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d))));
    vlSelf->wasmetal_core__DOT___058773_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127623___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128867___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b23__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b22__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b21__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128867___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128867___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036411_)))));
    vlSelf->wasmetal_core__DOT___036416_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b23__05d) 
                                            & (IData)(wasmetal_core__DOT___128867___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___035981_) ? (IData)(wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b2__05d));
    vlSelf->wasmetal_core__DOT___036960_ = (1U & (0xb4U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7cb02621__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc2af737a__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127551___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023445_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023431_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023430_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___023445_)
                       ? (IData)(wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__)
                       : (~ (IData)(vlSelf->wasmetal_core__DOT___023445_))) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___127551___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___127551___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___023441_)))));
    vlSelf->wasmetal_core__DOT___036959_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc2af737a__0)) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_hfc488d72__0))));
    if ((1U & (6U >> (IData)(__VdfgTmp_h4fb57fe8__0)))) {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d;
        wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b56__05d;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___035869_;
        wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___035753_;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___035725_;
    }
    vlSelf->wasmetal_core__DOT___036958_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(__VdfgTmp_hfc488d72__0)) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_h4fb57fe8__0))));
    vlSelf->wasmetal_core__DOT___036957_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(__VdfgTmp_h4fb57fe8__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7a977bbe__0))));
    __VdfgTmp_h03eaf1be__0 = ((2U & ((~ (6U >> (IData)(__VdfgTmp_hfc488d72__0))) 
                                     << 1U)) | (1U 
                                                & (~ 
                                                   (6U 
                                                    >> (IData)(__VdfgTmp_h4fb57fe8__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127568___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023566_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023552_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023551_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___023566_)
                       ? (IData)(wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__)
                       : (~ (IData)(vlSelf->wasmetal_core__DOT___023566_))) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___127568___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___127568___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___023562_)))));
    vlSelf->wasmetal_core__DOT___044993_ = ((IData)(vlSelf->wasmetal_core__DOT___045039_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045038_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045036_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045035_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045034_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045033_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045032_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045031_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045030_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045029_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___045028_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045027_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045047_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045046_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045045_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045044_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045043_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045042_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045041_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045040_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045037_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045026_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045002_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045013_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045016_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045017_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045018_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045019_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045020_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045021_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045022_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045023_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045003_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___045004_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045005_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045006_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045007_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045008_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045009_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045010_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045011_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045012_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045014_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045015_));
    vlSelf->wasmetal_core__DOT___045242_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070778_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054444_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x35U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___045218_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070779_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054448_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x37U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054444_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070778_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x35U))))))))))))));
    vlSelf->wasmetal_core__DOT___044970_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070881_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054443_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x35U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___044946_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070882_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054447_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x37U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054443_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070881_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x35U))))))))))))));
    vlSelf->wasmetal_core__DOT___053965_ = (1U & (IData)(
                                                         (0x110044000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053957_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050764_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048526_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b7__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___050766_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d))))))))))));
    vlSelf->wasmetal_core__DOT___044856_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(__VdfgTmp_h91f24ade__0)))))))))));
    vlSelf->wasmetal_core__DOT___044880_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(__VdfgTmp_h91f24ade__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127966___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d))))))));
    wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023235_) 
           & (IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127624___O 
        = ((4U | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)) 
                         << 1U)) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d))))) 
           ^ (((IData)(wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127624___DOT__CO__BRA__2__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127624___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024052_)))));
    vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023792_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023728_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d));
    wasmetal_core__DOT____Vcellout___127608___O = (
                                                   ((4U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)) 
                                                        << 2U)) 
                                                    | ((2U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d))))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)
                                                       ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)
                                                       : (IData)(wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127608___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127608___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023925_)))));
    vlSelf->__VdfgTmp_h460f8c4e__0 = (((IData)(vlSelf->wasmetal_core__DOT___060014_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128867___O) 
                                                          >> 3U)))));
    vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b24__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036416_));
    vlSelf->wasmetal_core__DOT____Vcellout___128795___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035992_) 
             << 3U) | (((IData)(wasmetal_core__DOT___035981_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___035970_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128795___DOT__CO__BRA__0__KET__)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(wasmetal_core__DOT___128795___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128795___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035936_ = ((IData)(vlSelf->wasmetal_core__DOT___035992_)
                                             ? (IData)(wasmetal_core__DOT___128795___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b3__05d));
    __VdfgTmp_hdfd93176__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                 >> 2U)))));
    __VdfgTmp_h898161e8__0 = ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O)) 
                              | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                        >> 2U)) | (1U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                      >> 1U))));
    __VdfgTmp_h838bb85c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                               >> 2U)));
    vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d 
        = (1U & (0xbfff0000U >> ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                           << 2U)) 
                                 | (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                                   << 1U) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                        >> 3U))))))));
    vlSelf->wasmetal_core__DOT___048704_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                             << 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127634___O))))));
    if ((1U & (6U >> (IData)(__VdfgTmp_hfc488d72__0)))) {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036957_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036944_)
                  : (6U >> (IData)(__VdfgTmp_h4fb57fe8__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128780___O 
        = ((IData)(__VdfgTmp_h03eaf1be__0) ^ (((((1U 
                                                  & (6U 
                                                     >> (IData)(__VdfgTmp_hfc488d72__0)))
                                                  ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b57__05d)
                                                  : (IData)(wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__)) 
                                                << 2U) 
                                               | ((IData)(wasmetal_core__DOT___128780___DOT__CO__BRA__0__KET__) 
                                                  << 1U)) 
                                              | (IData)(wasmetal_core__DOT___035753_)));
    vlSelf->wasmetal_core__DOT____Vcellinp___128776___S 
        = ((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h7cb02621__0))) 
                  << 3U)) | ((4U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_hc2af737a__0))) 
                                    << 2U)) | (IData)(__VdfgTmp_h03eaf1be__0)));
    vlSelf->wasmetal_core__DOT___043071_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O))))))))));
    vlSelf->wasmetal_core__DOT___043075_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127567___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O))))))))));
    vlSelf->__VdfgTmp_h540d21cf__0 = ((2U & ((0x4fU 
                                              >> ((4U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058677_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                           >> 3U))))) 
                                             << 1U)) 
                                      | (1U & (0x4fU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058677_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                            >> 2U)))))));
    vlSelf->wasmetal_core__DOT___005680_ = (1U & (0x40ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___005682_ = (1U & (0x40ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                  >> 3U))))))));
    vlSelf->__VdfgTmp_h59f45271__0 = ((8U & ((8U >> 
                                              (3U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                >> 2U))) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                 >> 1U)))));
    vlSelf->wasmetal_core__DOT___051264_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127635___O))))));
    vlSelf->wasmetal_core__DOT___052701_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044993_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052648_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___045061_)))));
    vlSelf->wasmetal_core__DOT___045197_ = ((IData)(vlSelf->wasmetal_core__DOT___045243_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045242_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045240_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045239_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045238_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045237_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045236_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045235_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045234_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045233_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___045232_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045231_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045251_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045250_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045249_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045248_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045247_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045246_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045245_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045244_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045241_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045230_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045206_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045217_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045220_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045221_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045222_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045223_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045224_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045225_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045226_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045227_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045207_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___045208_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045209_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045210_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045211_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045212_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045213_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045214_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045215_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045216_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045218_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045219_));
    vlSelf->wasmetal_core__DOT___044925_ = ((IData)(vlSelf->wasmetal_core__DOT___044971_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___044970_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___044968_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044967_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044966_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044965_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044964_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044963_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044962_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044961_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044960_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___044959_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___044979_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___044978_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___044977_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___044976_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___044975_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___044974_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___044973_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___044972_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___044969_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___044958_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___044934_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___044945_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___044948_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___044949_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___044950_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___044951_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___044952_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___044953_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___044954_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___044955_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___044935_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___044936_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044937_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044938_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044939_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044940_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044941_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044942_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044943_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044944_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044946_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044947_));
    vlSelf->wasmetal_core__DOT___053992_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053987_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053986_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053985_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xa2a200a28a008a8aULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0xbU)) 
                                                                                | ((0xcU 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xcU)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0xdU)) 
                                                                                | (1U 
                                                                                & (0xa28aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0x11U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x12U)) 
                                                                                | (1U 
                                                                                & (0x41000041U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0xeU)) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xfU)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0xeU)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xfU)) 
                                                                                | (1U 
                                                                                & (0x18U 
                                                                                >> 
                                                                                ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xdU)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0xeU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048519_)))))))))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053973_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053972_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053971_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((6U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b29__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050937_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xeee0eee0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049400_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049402_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048524_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4141410000414141ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & (vlSelf->insn_y 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & (vlSelf->insn_x 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_x 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & vlSelf->insn_y) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2f11896e__0)))))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053966_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053965_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053964_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x4141410000414141ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0x15U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x17U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0x16U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x17U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b22__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050952_))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x1414140000141414ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 5U)) 
                                                                                | ((0x10U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 6U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b8__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050959_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2f11896e__0)))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (9U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b9__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050957_))))))))))))))))))));
    wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__ 
        = ((0x5cU >> (IData)(vlSelf->__VdfgTmp_h58a856e0__0)) 
           & (IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023793_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d));
    vlSelf->__VdfgTmp_h5b8de47f__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127608___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006238_));
    vlSelf->__VdfgTmp_hab870e45__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127608___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006155_));
    vlSelf->__VdfgTmp_ha55183ab__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127608___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006159_));
    vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__1__KET__ 
        = ((0x1eU >> (IData)(vlSelf->__VdfgTmp_h963234d4__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036003_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035936_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b4__05d));
    vlSelf->wasmetal_core__DOT___015607_ = (1U & (IData)(
                                                         (0xbfff000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                  << 2U)) 
                                                              | (IData)(__VdfgTmp_hdfd93176__0))))));
    vlSelf->wasmetal_core__DOT___015606_ = (1U & (IData)(
                                                         (0xbfff000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                  << 3U)) 
                                                              | (IData)(__VdfgTmp_hdfd93176__0))))));
    vlSelf->wasmetal_core__DOT___051535_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005663_)
                                                   ? (IData)(
                                                             (0x3f01010101010101ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                                                      << 3U) 
                                                                     | (IData)(__VdfgTmp_h898161e8__0))))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(__VdfgTmp_h898161e8__0))));
    vlSelf->wasmetal_core__DOT___015613_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                     >> 3U) 
                                                    & (0xbfffffff00000000ULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            << 5U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h838bb85c__0))))))));
    vlSelf->wasmetal_core__DOT___005686_ = (1U & (0x4000ffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h838bb85c__0))))));
    vlSelf->__VdfgTmp_hb5be14c3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                                       << 5U) | ((0x1cU 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                     << 1U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___005687_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d)))));
    vlSelf->wasmetal_core__DOT___018504_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048704_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9e4ff193__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d 
        = (1U & (0x4fcfcfcU >> (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___048704_) 
                                               << 2U) 
                                              | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)))))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hc2af737a__0)))) {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036958_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(__VdfgTmp_hfc488d72__0))));
    vlSelf->__VdfgTmp_h647f0add__0 = (((IData)(vlSelf->wasmetal_core__DOT___005680_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005683_));
    vlSelf->__VdfgTmp_hd339b1da__0 = (((IData)(vlSelf->wasmetal_core__DOT___005682_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005681_));
    vlSelf->wasmetal_core__DOT___005678_ = (1U & (0xf0d50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h59f45271__0))));
    vlSelf->__VdfgTmp_h97610f75__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051264_));
    vlSelf->wasmetal_core__DOT___036647_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051264_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d))));
    vlSelf->wasmetal_core__DOT___052848_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052701_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052702_))));
    vlSelf->wasmetal_core__DOT___053587_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052702_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052701_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052650_)))));
    vlSelf->wasmetal_core__DOT___052708_ = (1U & (IData)(
                                                         (0x4400f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052702_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051202_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051204_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052701_)))))))));
    vlSelf->wasmetal_core__DOT___051203_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045197_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___CO) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___050371_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044925_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___CO) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___054188_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003288_)))))))));
    vlSelf->wasmetal_core__DOT___054190_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004832_)))))))));
    vlSelf->wasmetal_core__DOT___054192_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054191_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004758_)))))))));
    vlSelf->wasmetal_core__DOT___054194_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004536_)))))))));
    vlSelf->wasmetal_core__DOT___054196_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004388_)))))))));
    vlSelf->wasmetal_core__DOT___054198_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054197_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004462_)))))))));
    vlSelf->wasmetal_core__DOT___054200_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004610_)))))))));
    vlSelf->wasmetal_core__DOT___054202_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003794_)))))))));
    vlSelf->wasmetal_core__DOT___054204_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003646_)))))))));
    vlSelf->wasmetal_core__DOT___054206_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003498_)))))))));
    vlSelf->wasmetal_core__DOT___054208_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003572_)))))))));
    vlSelf->wasmetal_core__DOT___054210_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054209_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004166_)))))))));
    vlSelf->wasmetal_core__DOT___054212_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004240_)))))))));
    vlSelf->wasmetal_core__DOT___054214_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004684_)))))))));
    vlSelf->wasmetal_core__DOT___054216_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054215_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003720_)))))))));
    vlSelf->wasmetal_core__DOT___054218_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004018_)))))))));
    vlSelf->wasmetal_core__DOT___054220_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004314_)))))))));
    vlSelf->wasmetal_core__DOT___054222_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054221_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004092_)))))))));
    vlSelf->wasmetal_core__DOT___054224_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054223_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003876_)))))))));
    vlSelf->wasmetal_core__DOT___054226_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003948_)))))))));
    vlSelf->wasmetal_core__DOT___054228_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054227_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003428_)))))))));
    vlSelf->wasmetal_core__DOT___054230_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003360_)))))))));
    vlSelf->wasmetal_core__DOT___054232_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005176_)))))))));
    vlSelf->wasmetal_core__DOT___054234_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054233_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005108_)))))))));
    vlSelf->wasmetal_core__DOT___054236_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005380_)))))))));
    vlSelf->wasmetal_core__DOT___054238_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004972_)))))))));
    vlSelf->wasmetal_core__DOT___054240_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054239_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005040_)))))))));
    vlSelf->wasmetal_core__DOT___054242_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004904_)))))))));
    vlSelf->wasmetal_core__DOT___054244_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005312_)))))))));
    vlSelf->wasmetal_core__DOT___054246_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054245_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005244_)))))))));
    vlSelf->wasmetal_core__DOT___054248_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005636_)))))))));
    vlSelf->wasmetal_core__DOT___054319_ = (1U & (IData)(
                                                         (0x33305550fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054187_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128120___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000693_)))))))));
    vlSelf->wasmetal_core__DOT___054317_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000665_))))));
    vlSelf->wasmetal_core__DOT___054037_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003190_)))))));
    vlSelf->wasmetal_core__DOT___054041_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054040_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003270_)))))));
    vlSelf->wasmetal_core__DOT___054045_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054044_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004818_)))))));
    vlSelf->wasmetal_core__DOT___054049_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054048_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004744_)))))));
    vlSelf->wasmetal_core__DOT___054053_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054052_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004522_)))))));
    vlSelf->wasmetal_core__DOT___054057_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054056_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004374_)))))));
    vlSelf->wasmetal_core__DOT___054061_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054060_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004448_)))))));
    vlSelf->wasmetal_core__DOT___054065_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054064_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004596_)))))));
    vlSelf->wasmetal_core__DOT___054069_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054068_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003780_)))))));
    vlSelf->wasmetal_core__DOT___054073_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054072_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003632_)))))));
    vlSelf->wasmetal_core__DOT___054077_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054076_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003484_)))))));
    vlSelf->wasmetal_core__DOT___054081_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054080_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003558_)))))));
    vlSelf->wasmetal_core__DOT___054085_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054084_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004152_)))))));
    vlSelf->wasmetal_core__DOT___054089_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054088_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004226_)))))));
    vlSelf->wasmetal_core__DOT___054093_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054092_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004670_)))))));
    vlSelf->wasmetal_core__DOT___054097_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054096_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003706_)))))));
    vlSelf->wasmetal_core__DOT___054101_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054100_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004004_)))))));
    vlSelf->wasmetal_core__DOT___054105_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004300_)))))));
    vlSelf->wasmetal_core__DOT___054109_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054108_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004078_)))))));
    vlSelf->wasmetal_core__DOT___054113_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054112_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003862_)))))));
    vlSelf->wasmetal_core__DOT___054117_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054116_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003936_)))))));
    vlSelf->wasmetal_core__DOT___054121_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054120_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003416_)))))));
    vlSelf->wasmetal_core__DOT___054125_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054124_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003348_)))))));
    vlSelf->wasmetal_core__DOT___054129_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054128_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005164_)))))));
    vlSelf->wasmetal_core__DOT___054133_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054132_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005096_)))))));
    vlSelf->wasmetal_core__DOT___054137_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054136_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005368_)))))));
    vlSelf->wasmetal_core__DOT___054160_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054159_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004960_)))))));
    vlSelf->wasmetal_core__DOT___054164_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054163_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005028_)))))));
    vlSelf->wasmetal_core__DOT___054168_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054167_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004892_)))))));
    vlSelf->wasmetal_core__DOT___054172_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054171_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005300_)))))));
    vlSelf->wasmetal_core__DOT___054176_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054175_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005232_)))))));
    vlSelf->wasmetal_core__DOT___054180_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054179_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005618_)))))));
    vlSelf->wasmetal_core__DOT___054249_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O))))))));
    vlSelf->wasmetal_core__DOT___054251_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054253_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054255_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054257_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O))))))));
    vlSelf->wasmetal_core__DOT___054259_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054261_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054263_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054265_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O))))))));
    vlSelf->wasmetal_core__DOT___054267_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054269_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054271_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054273_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O))))))));
    vlSelf->wasmetal_core__DOT___054279_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054281_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054283_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054285_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O))))))));
    vlSelf->wasmetal_core__DOT___054287_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054289_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054291_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054293_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O))))))));
    vlSelf->wasmetal_core__DOT___054295_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054297_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054299_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054301_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O))))))));
    vlSelf->wasmetal_core__DOT___054303_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054305_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054307_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054309_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O))))))));
    vlSelf->wasmetal_core__DOT___054311_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054313_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054315_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054183_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003208_)))));
    wasmetal_core__DOT___027462_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127967___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___O) 
           ^ (((IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127967___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027457_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127526___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023241_) 
             << 3U) | ((4U & ((0x5cU >> (IData)(vlSelf->__VdfgTmp_h58a856e0__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___023235_) 
                                          << 1U) | 
                                         (1U & (0x5cU 
                                                >> (IData)(vlSelf->__VdfgTmp_h1d759fa4__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023277_)))));
    vlSelf->wasmetal_core__DOT___023305_ = ((IData)(vlSelf->wasmetal_core__DOT___023241_) 
                                            & (IData)(wasmetal_core__DOT___127526___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023794_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d));
    vlSelf->wasmetal_core__DOT___023799_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5b8de47f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d))));
    vlSelf->wasmetal_core__DOT___023798_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d))));
    wasmetal_core__DOT___058908_ = (1U & (1U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5b8de47f__0))))));
    wasmetal_core__DOT___058768_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058760_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058759_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127624___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127623___O) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058758_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)))))))))));
    vlSelf->wasmetal_core__DOT___023797_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d))));
    vlSelf->wasmetal_core__DOT___058876_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058873_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___058912_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058758_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058761_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0)))))))));
    wasmetal_core__DOT___058774_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127624___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0))))));
    wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b26__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036010_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b5__05d));
    vlSelf->__VdfgTmp_h1a6a5523__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015607_));
    __VdfgTmp_h6b2d1b17__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015828_)));
    __VdfgTmp_h5e2f8bee__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015656_))));
    wasmetal_core__DOT___015759_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___015606_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___015634_));
    __VdfgTmp_h19b58510__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015763_))));
    vlSelf->__VdfgTmp_h5ba5065d__0 = (((IData)(vlSelf->wasmetal_core__DOT___051535_) 
                                       << 1U) | (1U 
                                                 & (0x80U 
                                                    >> 
                                                    ((4U 
                                                      & ((0xf0d5U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h59f45271__0)) 
                                                         << 2U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h540d21cf__0)))));
    vlSelf->wasmetal_core__DOT___017325_ = (1U & (0x2b00d4ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051535_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xf0d5U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h59f45271__0)) 
                                                          << 3U)) 
                                                      | ((6U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058677_))))));
    vlSelf->wasmetal_core__DOT___058269_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x55550f0f00ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015645_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015812_)))))))));
    vlSelf->wasmetal_core__DOT___015730_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h63c4ff94__0))))))));
    vlSelf->wasmetal_core__DOT___058221_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xf0f5555333300ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc84aef23__0)))))));
    vlSelf->wasmetal_core__DOT___058226_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015654_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015651_)))))));
    vlSelf->wasmetal_core__DOT___058245_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015651_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___015606_)))));
    vlSelf->__VdfgTmp_h6d3ce6b7__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___015763_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___015613_));
    wasmetal_core__DOT___015876_ = (1U & (0x503U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h9a784e39__0)))));
    if (vlSelf->wasmetal_core__DOT___015613_) {
        vlSelf->wasmetal_core__DOT___016003_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015681_))))));
        wasmetal_core__DOT___015846_ = (1U & (0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h46ff4218__0)))));
        vlSelf->wasmetal_core__DOT___016044_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2c2f1e15__0)))));
        vlSelf->wasmetal_core__DOT___015772_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hdeec5a49__0)))));
        wasmetal_core__DOT___015947_ = (1U & (0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hb34385bd__0)))));
        vlSelf->wasmetal_core__DOT___015981_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015636_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015635_))));
        vlSelf->wasmetal_core__DOT___058222_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___015651_)));
        if (vlSelf->wasmetal_core__DOT___013549_) {
            vlSelf->wasmetal_core__DOT___015602_ = 
                (1U & (0x23U >> (IData)(vlSelf->__VdfgTmp_h7d202e30__0)));
            vlSelf->wasmetal_core__DOT___015604_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___015612_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015611_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___015610_)))));
        } else {
            vlSelf->wasmetal_core__DOT___015602_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___015622_)));
            vlSelf->wasmetal_core__DOT___015604_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___015612_)));
        }
        vlSelf->wasmetal_core__DOT___015735_ = (1U 
                                                & (0x2333U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h12d5b185__0)))));
        wasmetal_core__DOT___015736_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015621_)) 
                                              & (0xfdfU 
                                                 >> (IData)(vlSelf->__VdfgTmp_h12c4c12e__0))));
        vlSelf->wasmetal_core__DOT___015737_ = (1U 
                                                & (0x23U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015747_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006651_)))));
        vlSelf->wasmetal_core__DOT___015738_ = vlSelf->wasmetal_core__DOT___015614_;
        vlSelf->wasmetal_core__DOT___015686_ = vlSelf->wasmetal_core__DOT___015725_;
        vlSelf->wasmetal_core__DOT___015839_ = vlSelf->wasmetal_core__DOT___015724_;
        wasmetal_core__DOT___015687_ = vlSelf->wasmetal_core__DOT___015719_;
        vlSelf->wasmetal_core__DOT___015867_ = vlSelf->wasmetal_core__DOT___015718_;
        vlSelf->wasmetal_core__DOT___015688_ = vlSelf->wasmetal_core__DOT___015710_;
        vlSelf->wasmetal_core__DOT___015868_ = vlSelf->wasmetal_core__DOT___015709_;
        vlSelf->wasmetal_core__DOT___015689_ = vlSelf->wasmetal_core__DOT___015698_;
        wasmetal_core__DOT___015869_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015697_));
        vlSelf->wasmetal_core__DOT___015910_ = wasmetal_core__DOT___015759_;
        vlSelf->wasmetal_core__DOT___015897_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___015606_)) 
                                                & (IData)(vlSelf->wasmetal_core__DOT___015762_));
        vlSelf->wasmetal_core__DOT___016019_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015656_))))));
        vlSelf->wasmetal_core__DOT___016045_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(__VdfgTmp_h19b58510__0)));
        vlSelf->wasmetal_core__DOT___015821_ = (1U 
                                                & (0xc0afU 
                                                   >> (IData)(__VdfgTmp_h19b58510__0)));
    } else {
        vlSelf->wasmetal_core__DOT___016003_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015676_))))));
        wasmetal_core__DOT___015846_ = (1U & (0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___015672_))))));
        vlSelf->wasmetal_core__DOT___016044_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015673_))))));
        vlSelf->wasmetal_core__DOT___015772_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015674_))))));
        wasmetal_core__DOT___015947_ = (1U & (0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___015666_))))));
        vlSelf->wasmetal_core__DOT___015981_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015637_))
                                                    : 
                                                   (7U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb584f1fd__0))));
        vlSelf->wasmetal_core__DOT___058222_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___015654_));
        if (vlSelf->wasmetal_core__DOT___013549_) {
            vlSelf->wasmetal_core__DOT___015602_ = 
                (1U & (0x203U >> (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015621_) 
                                              << 2U) 
                                             | (IData)(vlSelf->__VdfgTmp_h514789fb__0)))));
            wasmetal_core__DOT___015869_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015781_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfacd537a__0))));
        } else {
            vlSelf->wasmetal_core__DOT___015602_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___015621_)));
            wasmetal_core__DOT___015869_ = (1U & (1U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___015781_)));
        }
        vlSelf->wasmetal_core__DOT___015735_ = (1U 
                                                & (0x2333U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7d202e30__0))));
        wasmetal_core__DOT___015736_ = (1U & (0x23U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015750_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___013466_)))));
        vlSelf->wasmetal_core__DOT___015737_ = (1U 
                                                & (0xe0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015612_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc4d25f20__0)))));
        vlSelf->wasmetal_core__DOT___015604_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___015614_));
        vlSelf->wasmetal_core__DOT___015738_ = vlSelf->wasmetal_core__DOT___015725_;
        vlSelf->wasmetal_core__DOT___015686_ = vlSelf->wasmetal_core__DOT___015724_;
        vlSelf->wasmetal_core__DOT___015839_ = vlSelf->wasmetal_core__DOT___015719_;
        wasmetal_core__DOT___015687_ = vlSelf->wasmetal_core__DOT___015718_;
        vlSelf->wasmetal_core__DOT___015867_ = vlSelf->wasmetal_core__DOT___015710_;
        vlSelf->wasmetal_core__DOT___015688_ = vlSelf->wasmetal_core__DOT___015709_;
        vlSelf->wasmetal_core__DOT___015868_ = vlSelf->wasmetal_core__DOT___015698_;
        vlSelf->wasmetal_core__DOT___015689_ = vlSelf->wasmetal_core__DOT___015697_;
        vlSelf->wasmetal_core__DOT___015910_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___015606_)) 
                                                & (IData)(vlSelf->wasmetal_core__DOT___015633_));
        vlSelf->wasmetal_core__DOT___015897_ = wasmetal_core__DOT___015759_;
        vlSelf->wasmetal_core__DOT___016019_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(__VdfgTmp_h19b58510__0)));
        vlSelf->wasmetal_core__DOT___016045_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(__VdfgTmp_h5e2f8bee__0)));
        vlSelf->wasmetal_core__DOT___015821_ = (1U 
                                                & (0xafcfU 
                                                   >> (IData)(__VdfgTmp_h5e2f8bee__0)));
    }
    vlSelf->__VdfgTmp_hffe7d15f__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h31f6f19a__0)))));
    __VdfgTmp_hf2bf1435__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h31f6f19a__0)))));
    vlSelf->wasmetal_core__DOT___058243_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015654_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h31f6f19a__0))))))));
    vlSelf->wasmetal_core__DOT___016018_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdeec5a49__0))))))));
    vlSelf->wasmetal_core__DOT___015992_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x55550f0f00ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015678_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015677_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015676_)))))))));
    wasmetal_core__DOT___015847_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                    & (IData)((0xf0f5555333300ffULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hccfff196__0)))))));
    vlSelf->wasmetal_core__DOT___016043_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h46ff4218__0))))))));
    vlSelf->wasmetal_core__DOT___015771_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h20099147__0))))))));
    vlSelf->wasmetal_core__DOT___016020_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff55550f0f3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015765_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015665_)))))))));
    vlSelf->wasmetal_core__DOT___015994_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h10a18780__0))))))));
    vlSelf->wasmetal_core__DOT___015848_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xf0f333300ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb34385bd__0))))))));
    vlSelf->wasmetal_core__DOT___058244_ = (1U & (IData)(
                                                         (0xff00aaaaf0f0ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc84aef23__0)))))));
    vlSelf->wasmetal_core__DOT___015818_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x333355550f0f00ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2c2f1e15__0))))))));
    vlSelf->wasmetal_core__DOT___016116_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x55550f0f00ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015671_)))))))));
    wasmetal_core__DOT___015948_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                    & (IData)((0xff555533330f0fULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb73d1e0b__0))))))));
    vlSelf->wasmetal_core__DOT___015926_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h46ff4218__0))))))));
    vlSelf->wasmetal_core__DOT___015928_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfcfb0a06__0))))))));
    vlSelf->wasmetal_core__DOT___015909_ = (1U & (IData)(
                                                         (0xfff8f800000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015635_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb584f1fd__0)))))));
    vlSelf->wasmetal_core__DOT___015896_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015635_))))));
    vlSelf->wasmetal_core__DOT___058246_ = (1U & (IData)(
                                                         (0xccccf0f0ff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015635_)))))))));
    vlSelf->wasmetal_core__DOT___015605_ = ((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___015613_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___015634_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___015633_)));
    vlSelf->wasmetal_core__DOT___015943_ = ((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___015613_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___015762_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___015634_)));
    vlSelf->__VdfgTmp_hf420cd01__0 = (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015681_));
    wasmetal_core__DOT___015834_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015671_))))));
    wasmetal_core__DOT___015679_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015677_))))));
    wasmetal_core__DOT___015902_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015667_))))));
    wasmetal_core__DOT___015766_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_hfcfb0a06__0)))));
    wasmetal_core__DOT___015767_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015665_))))));
    vlSelf->wasmetal_core__DOT___015603_ = (1U & (IData)(
                                                         (0xa0a0f0f00cc00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015747_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015750_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8523194f__0))))))));
    wasmetal_core__DOT___015682_ = (1U & (0xff100000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h83a6d262__0))));
    wasmetal_core__DOT___015683_ = (1U & (IData)((0xf3f5f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he3b69f57__0)))));
    vlSelf->wasmetal_core__DOT___015684_ = (1U & (IData)(
                                                         (0xf3f5f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h9cde2904__0)))));
    wasmetal_core__DOT___015659_ = ((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013508_));
    vlSelf->wasmetal_core__DOT___016021_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                   >> 1U) 
                                                  & (IData)(
                                                            (0x7000000000000ULL 
                                                             >> 
                                                             ((0x30U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O))))))))));
    vlSelf->__VdfgTmp_h1a0326f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005686_));
    wasmetal_core__DOT___015860_ = (1U & (IData)((0x550f33ffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___015656_)))))))));
    vlSelf->wasmetal_core__DOT___015597_ = (1U & (IData)(
                                                         (0xbfff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051510_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048132_)))))))));
    vlSelf->wasmetal_core__DOT___015596_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005686_))));
    vlSelf->wasmetal_core__DOT___015594_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005686_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d 
        = (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___005688_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005686_)))));
    vlSelf->wasmetal_core__DOT___017936_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018504_))));
    vlSelf->wasmetal_core__DOT___017193_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018504_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___058529_ = (1U & (1U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 1U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d))))));
    vlSelf->wasmetal_core__DOT___043072_ = (1U & (IData)(
                                                         (0x5757577f01010115ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xf0d5U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h59f45271__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h540d21cf__0))))))));
    vlSelf->wasmetal_core__DOT___017196_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048704_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                               >> 2U))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf0d5U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h59f45271__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d))))));
    vlSelf->wasmetal_core__DOT___043076_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___005686_)
                                                    ? (IData)(
                                                              (0x700000000070ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb5be14c3__0)))
                                                    : (IData)(
                                                              (0x3300000000700000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb5be14c3__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___005686_)
                                                    ? (IData)(
                                                              (0x7000088888fULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb5be14c3__0)))
                                                    : (IData)(
                                                              (0xcc00000000070000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb5be14c3__0))))));
    vlSelf->wasmetal_core__DOT___006589_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)
                                                   ? (IData)(
                                                             (0xfff03330aaa02220ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005689_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005688_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005687_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d))))))))
                                                   : 
                                                  (0x80U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005689_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005688_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005687_))))));
    vlSelf->wasmetal_core__DOT___005679_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005689_)) 
                                                  & (IData)(
                                                            (0xfc54f000f000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005688_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005687_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005686_))))))))));
    vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___005689_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128790___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128776___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035869_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h7cb02621__0)))) {
        vlSelf->wasmetal_core__DOT___035873_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d;
        vlSelf->wasmetal_core__DOT___035729_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d;
    } else {
        vlSelf->wasmetal_core__DOT___035873_ = vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___035729_ = vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036959_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__1__KET__)
                  : (9U >> (IData)(vlSelf->__VdfgTmp_hc2af737a__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128776___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128776___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035725_)))));
    vlSelf->wasmetal_core__DOT___049341_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd339b1da__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h647f0add__0))))));
    vlSelf->__VdfgTmp_hfa042eae__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hd339b1da__0))));
    vlSelf->__VdfgTmp_h07e5b5ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___005678_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005677_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d 
        = (1U & (IData)((0x111f111f111fffffULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005677_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005678_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005680_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005683_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hd339b1da__0))))))));
    vlSelf->wasmetal_core__DOT___058087_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005677_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005678_))));
    vlSelf->wasmetal_core__DOT___036961_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036647_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7cb02621__0))));
    vlSelf->wasmetal_core__DOT___052855_ = (1U & (IData)(
                                                         (0xff40404000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051202_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052849_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052848_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051204_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052650_)))))))));
    vlSelf->wasmetal_core__DOT___046425_ = (1U & (IData)(
                                                         (0xaafff3f0f3f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063445_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfd0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___063441_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063417_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0xef0f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063428_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063439_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbfffffff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063401_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063398_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x700U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xffffffffffff00feULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___045321_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052577_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___045469_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___044280_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052578_)))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063369_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052678_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053095_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xd000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063435_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063367_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053568_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053592_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052848_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063364_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048486_)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063418_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___063379_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063380_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)))))))))));
    vlSelf->wasmetal_core__DOT___053596_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052687_))));
    vlSelf->wasmetal_core__DOT___053251_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052692_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052708_))));
    vlSelf->wasmetal_core__DOT___067605_ = (1U & (0xc500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054478_))))));
    vlSelf->wasmetal_core__DOT___068554_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x10U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___067748_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b35__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054191_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068019_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 6U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068078_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 7U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068154_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 9U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068239_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xaU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068292_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054209_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xbU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068346_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xcU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068401_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xdU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___067896_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 4U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___067962_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054197_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 5U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___067809_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 3U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068425_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054215_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xeU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068477_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xfU)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___068103_ = (1U & (IData)(
                                                         (0xf020a030f030f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0bbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054203_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 8U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053485_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8819515__0))))))));
    vlSelf->wasmetal_core__DOT___063790_ = (1U & (IData)(
                                                         (0xc5f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063789_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063788_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048277_)))))))));
    vlSelf->wasmetal_core__DOT___068606_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054478_))));
    vlSelf->wasmetal_core__DOT___053362_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050382_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044240_)))));
    vlSelf->wasmetal_core__DOT___065935_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054083_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066080_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067311_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065601_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065799_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066398_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054103_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066524_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066646_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054115_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066768_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066892_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054127_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065410_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065186_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065697_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054071_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066275_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054095_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066312_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b16__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066601_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b19__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066851_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067453_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065895_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067341_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066122_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___064896_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054047_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065061_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___065300_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054059_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067074_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054135_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067152_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054158_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067193_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___066969_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054131_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___067479_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054178_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___064729_ = (1U & (IData)(
                                                         (0x3f33151115111511ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a2b49a7__0))))))));
    vlSelf->wasmetal_core__DOT___064464_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050371_)))));
    vlSelf->wasmetal_core__DOT___050383_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050371_))));
    vlSelf->wasmetal_core__DOT___067604_ = (1U & (0xf00088U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b64__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                         >> 0x39U)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))));
    vlSelf->wasmetal_core__DOT___054318_ = (1U & (0x3f5fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054317_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128120___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___CO) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054038_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054037_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128130___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128121___O))))))));
    vlSelf->wasmetal_core__DOT___054042_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054041_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128130___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128121___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054046_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054045_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128130___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128121___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054050_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054049_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128130___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128121___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054054_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054053_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128131___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128122___O))))))));
    vlSelf->wasmetal_core__DOT___054058_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054057_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128131___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128122___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054062_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054061_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128131___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128122___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054066_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054065_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128131___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128122___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054070_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054069_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128132___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128123___O))))))));
    vlSelf->wasmetal_core__DOT___054074_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054073_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128132___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128123___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054078_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128132___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128123___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054082_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054081_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128132___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128123___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054086_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054085_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128133___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128124___O))))))));
    vlSelf->wasmetal_core__DOT___054090_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054089_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128133___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128124___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054094_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128133___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128124___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054098_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054097_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128133___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128124___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054102_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128134___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128125___O))))))));
    vlSelf->wasmetal_core__DOT___054106_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054105_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128134___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128125___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054110_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054109_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128134___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128125___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054114_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054113_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128134___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128125___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054118_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054117_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128135___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128126___O))))))));
    vlSelf->wasmetal_core__DOT___054122_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054121_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128135___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128126___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054126_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054125_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128135___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128126___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054130_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054129_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128135___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128126___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054134_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054133_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128136___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128127___O))))))));
    vlSelf->wasmetal_core__DOT___054138_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054137_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128136___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128127___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054161_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054160_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128136___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128127___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054165_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054164_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128136___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128127___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054169_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054168_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128137___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___O))))))));
    vlSelf->wasmetal_core__DOT___054173_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054172_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128137___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054177_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054176_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128137___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054181_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054180_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128137___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054250_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054249_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128112___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O))))))));
    vlSelf->wasmetal_core__DOT___054252_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054251_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128112___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054254_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054253_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128112___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054256_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054255_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128112___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054258_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054257_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128113___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O))))))));
    vlSelf->wasmetal_core__DOT___054260_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054259_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128113___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054262_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054261_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128113___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054264_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054263_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128113___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054266_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054265_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128114___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O))))))));
    vlSelf->wasmetal_core__DOT___054268_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054267_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128114___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054270_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054269_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128114___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054272_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054271_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128114___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054274_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054273_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128115___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O))))))));
    vlSelf->wasmetal_core__DOT___054280_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054279_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128115___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054282_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054281_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128115___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054284_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054283_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128115___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054286_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054285_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128116___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O))))))));
    vlSelf->wasmetal_core__DOT___054288_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054287_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128116___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054290_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054289_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128116___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054292_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054291_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128116___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054294_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054293_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128117___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O))))))));
    vlSelf->wasmetal_core__DOT___054296_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054295_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128117___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054298_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054297_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128117___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054300_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054299_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128117___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054302_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054301_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128118___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O))))))));
    vlSelf->wasmetal_core__DOT___054304_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054303_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128118___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054306_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054305_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128118___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054308_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054307_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128118___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128082___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054310_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054309_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128119___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O))))))));
    vlSelf->wasmetal_core__DOT___054312_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054311_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128119___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054314_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054313_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128119___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054316_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054315_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128119___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054184_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bb0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054183_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054182_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___028661_)
                                                                          ? (IData)(vlSelf->wasmetal_core__DOT___128101___DOT__CO__BRA__2__KET__)
                                                                          : (IData)(vlSelf->wasmetal_core__DOT___005618_)) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053989_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127968___O 
        = ((1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___CO) 
                  >> 3U)) ^ ((0x3ffffffeU & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___CO) 
                                              >> 2U) 
                                             & ((IData)(wasmetal_core__DOT___027462_) 
                                                << 1U))) 
                             | (IData)(wasmetal_core__DOT___027462_)));
    vlSelf->__VdfgTmp_h1660624e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d)))));
    vlSelf->__VdfgTmp_habbe61e7__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O) 
                                             >> 2U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d)))));
    vlSelf->wasmetal_core__DOT___005977_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127526___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xff03fe02ff03aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h5ab387cb__0))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h5ab387cb__0))))));
    vlSelf->wasmetal_core__DOT___006038_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127526___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006065_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h9fc18e31__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9fc18e31__0)))))));
    vlSelf->wasmetal_core__DOT___006039_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127526___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xff03fe02ff03aaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5b8459c4__0))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5b8459c4__0))))));
    vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__0__KET__ 
        = ((0x5cU >> (IData)(vlSelf->__VdfgTmp_h3b955ce1__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___023305_));
    vlSelf->wasmetal_core__DOT____Vcellout___127590___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023795_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023794_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023793_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023792_)))) 
           ^ (((IData)(wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023728_)))));
    vlSelf->wasmetal_core__DOT___023732_ = ((IData)(vlSelf->wasmetal_core__DOT___023795_)
                                             ? (IData)(wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d));
    vlSelf->wasmetal_core__DOT___058910_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058909_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058908_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h6b40bfd0__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdd48e33a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hd2dd278c__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h85736cb0__0)))))))))));
    vlSelf->wasmetal_core__DOT___058783_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058767_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058766_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127620___O)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfc74bd0d__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127623___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___058784_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058774_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058773_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127622___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127619___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hde857550__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128868___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b26__05d) 
                        << 2U) | ((2U & ((0x1eU >> (IData)(vlSelf->__VdfgTmp_h963234d4__0)) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b24__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036416_)))));
    vlSelf->wasmetal_core__DOT___036420_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036011_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b6__05d));
    vlSelf->wasmetal_core__DOT___058267_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1a6a5523__0))));
    vlSelf->wasmetal_core__DOT___015949_ = (1U & (0x3f0050U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h6b2d1b17__0)))));
    vlSelf->wasmetal_core__DOT___017300_ = ((IData)(vlSelf->wasmetal_core__DOT___017325_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___015828_)
                                                ? (IData)(
                                                          (0xfcff0000aaffULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hca71c93a__0)))
                                                : (IData)(
                                                          (0xffff0300ffff5500ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hca71c93a__0)))));
    if (vlSelf->wasmetal_core__DOT___015606_) {
        vlSelf->wasmetal_core__DOT___058268_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015876_));
        vlSelf->wasmetal_core__DOT___015983_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015645_))))));
        vlSelf->wasmetal_core__DOT___015991_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015834_));
        vlSelf->wasmetal_core__DOT___015817_ = wasmetal_core__DOT___015679_;
        vlSelf->wasmetal_core__DOT___016017_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hb73d1e0b__0)))));
        vlSelf->wasmetal_core__DOT___015849_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015766_));
        vlSelf->wasmetal_core__DOT___016115_ = wasmetal_core__DOT___015767_;
        vlSelf->wasmetal_core__DOT___015925_ = wasmetal_core__DOT___015902_;
        vlSelf->wasmetal_core__DOT___016029_ = (1U 
                                                & (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015684_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015681_))))));
    } else {
        vlSelf->wasmetal_core__DOT___058268_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015636_))))));
        vlSelf->wasmetal_core__DOT___015983_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015876_));
        vlSelf->wasmetal_core__DOT___015991_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015672_))))));
        vlSelf->wasmetal_core__DOT___015817_ = wasmetal_core__DOT___015834_;
        vlSelf->wasmetal_core__DOT___016017_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015902_));
        vlSelf->wasmetal_core__DOT___015849_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015657_))))));
        vlSelf->wasmetal_core__DOT___016115_ = wasmetal_core__DOT___015766_;
        vlSelf->wasmetal_core__DOT___015925_ = wasmetal_core__DOT___015767_;
        vlSelf->wasmetal_core__DOT___016029_ = (1U 
                                                & (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h3f94b345__0)))));
    }
    vlSelf->wasmetal_core__DOT___015982_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xf0f5555333300ffULL 
                                                       >> (IData)(__VdfgTmp_hf2bf1435__0))));
    vlSelf->wasmetal_core__DOT___058276_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058243_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058245_)))));
    vlSelf->__VdfgTmp_hf69e15ee__0 = (((IData)(wasmetal_core__DOT___015847_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015846_));
    vlSelf->__VdfgTmp_h0dbc0f0f__0 = (((IData)(wasmetal_core__DOT___015846_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015847_));
    vlSelf->__VdfgTmp_hcaafbee5__0 = (((IData)(vlSelf->wasmetal_core__DOT___016043_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016044_));
    vlSelf->__VdfgTmp_h70395930__0 = (((IData)(vlSelf->wasmetal_core__DOT___016044_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016043_));
    vlSelf->wasmetal_core__DOT___016122_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015771_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015772_))));
    vlSelf->wasmetal_core__DOT___015953_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___015948_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___015947_))));
    vlSelf->__VdfgTmp_h0d424198__0 = (((IData)(wasmetal_core__DOT___015947_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015948_));
    vlSelf->__VdfgTmp_ha6796979__0 = (((IData)(vlSelf->wasmetal_core__DOT___058244_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058246_));
    vlSelf->wasmetal_core__DOT___058224_ = (1U & (0xeef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xf0f0aaaaccccff00ULL 
                                                                   >> (IData)(__VdfgTmp_hf2bf1435__0))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058222_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015606_))))));
    vlSelf->__VdfgTmp_ha298e6e0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058222_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___015878_)))));
    vlSelf->wasmetal_core__DOT___058286_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015943_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015735_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___015606_)))));
    vlSelf->__VdfgTmp_hc102c9b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___015603_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015602_));
    vlSelf->__VdfgTmp_hd3573026__0 = (((IData)(wasmetal_core__DOT___015736_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015735_));
    vlSelf->__VdfgTmp_h7f4536ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015736_));
    vlSelf->__VdfgTmp_he2a347e4__0 = (((IData)(wasmetal_core__DOT___015687_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015686_));
    vlSelf->__VdfgTmp_h12dd4af8__0 = (((IData)(vlSelf->wasmetal_core__DOT___015867_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015839_));
    vlSelf->__VdfgTmp_hc3174423__0 = (((IData)(vlSelf->wasmetal_core__DOT___015688_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015687_));
    vlSelf->__VdfgTmp_h29141d8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015689_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015688_));
    vlSelf->wasmetal_core__DOT___015850_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015867_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015868_)))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(wasmetal_core__DOT___015869_))
                                                    : 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h649aadfd__0))))));
    vlSelf->__VdfgTmp_h7369d2e1__0 = ((2U & ((IData)(
                                                     (0xf0f335500000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                              << 3U) 
                                                             | (((IData)(wasmetal_core__DOT___015869_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h649aadfd__0))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                ? (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h20099147__0))))
                                                : (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015678_))))))));
    vlSelf->__VdfgTmp_h766529e2__0 = (((IData)(wasmetal_core__DOT___015869_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015868_));
    vlSelf->wasmetal_core__DOT___016030_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___015683_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___015682_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015689_)))))));
    vlSelf->__VdfgTmp_ha302ee77__0 = (((IData)(wasmetal_core__DOT___015683_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015682_));
    vlSelf->wasmetal_core__DOT___015816_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff00ff0f55553333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015684_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hccfff196__0)))))));
    vlSelf->__VdfgTmp_h36951d10__0 = ((((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                        & (IData)((0xfff0fff0ffff1111ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015684_) 
                                                        << 4U) 
                                                       | (((IData)(wasmetal_core__DOT___015683_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___015682_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf420cd01__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                     ? 
                                                    (0x503U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3f94b345__0))))
                                                     : (IData)(wasmetal_core__DOT___015679_))));
    vlSelf->wasmetal_core__DOT___016046_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x55553333ff00ff0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___015659_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h10a18780__0))))))));
    vlSelf->wasmetal_core__DOT___015950_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff00ff0f33335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___015659_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd1c7c886__0))))))));
    vlSelf->wasmetal_core__DOT___015831_ = (1U & (0xcdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___015659_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015658_))))));
    vlSelf->__VdfgTmp_h6c8cc102__0 = ((2U & ((0x3050000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1a0326f2__0))))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                         & (IData)(
                                                   (0xff33330f0f5555ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015656_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___015763_))))))))));
    vlSelf->wasmetal_core__DOT___015969_ = (IData)(
                                                   ((0xcU 
                                                     == 
                                                     (0xcU 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O))) 
                                                    & (IData)(wasmetal_core__DOT___015860_)));
    vlSelf->wasmetal_core__DOT___015851_ = (IData)(
                                                   ((4U 
                                                     == 
                                                     (0xcU 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O))) 
                                                    & (IData)(wasmetal_core__DOT___015860_)));
    vlSelf->wasmetal_core__DOT___015927_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                >> 2U)) 
                                            & (IData)(wasmetal_core__DOT___015860_));
    vlSelf->wasmetal_core__DOT___058326_ = (1U & (IData)(
                                                         (0x3a00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6d3ce6b7__0))))))));
    vlSelf->wasmetal_core__DOT___058260_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058226_)))));
    vlSelf->wasmetal_core__DOT___015995_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x3f005000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h6b2d1b17__0)))))));
    vlSelf->wasmetal_core__DOT___016132_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            & (IData)(
                                                      (0x33330f0f00ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                                                  << 2U) 
                                                                 | (((IData)(wasmetal_core__DOT___015736_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015839_)))))))));
    vlSelf->wasmetal_core__DOT___016125_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            & (IData)(
                                                      (0x33330f0f00ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015603_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015602_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015686_)))))))));
    vlSelf->__VdfgTmp_h2acad42a__0 = ((2U & ((IData)(
                                                     (0xf0fff1100000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015605_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015981_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___015602_)))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                ? (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015603_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015686_)))))
                                                : (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___015687_))))))));
}
