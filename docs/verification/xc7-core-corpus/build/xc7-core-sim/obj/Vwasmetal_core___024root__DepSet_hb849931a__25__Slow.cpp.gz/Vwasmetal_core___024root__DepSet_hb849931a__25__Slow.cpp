#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__42(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__42\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006582_;
    wasmetal_core__DOT___006582_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015598_;
    wasmetal_core__DOT___015598_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015599_;
    wasmetal_core__DOT___015599_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015819_;
    wasmetal_core__DOT___015819_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015826_;
    wasmetal_core__DOT___015826_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015963_;
    wasmetal_core__DOT___015963_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015976_;
    wasmetal_core__DOT___015976_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015977_;
    wasmetal_core__DOT___015977_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015993_;
    wasmetal_core__DOT___015993_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016004_;
    wasmetal_core__DOT___016004_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016033_;
    wasmetal_core__DOT___016033_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016051_;
    wasmetal_core__DOT___016051_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016071_;
    wasmetal_core__DOT___016071_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016097_;
    wasmetal_core__DOT___016097_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016123_;
    wasmetal_core__DOT___016123_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017373_;
    wasmetal_core__DOT___017373_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043085_;
    wasmetal_core__DOT___043085_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044837_;
    wasmetal_core__DOT___044837_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048489_;
    wasmetal_core__DOT___048489_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051533_;
    wasmetal_core__DOT___051533_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058231_;
    wasmetal_core__DOT___058231_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058240_;
    wasmetal_core__DOT___058240_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058252_;
    wasmetal_core__DOT___058252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058272_;
    wasmetal_core__DOT___058272_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058273_;
    wasmetal_core__DOT___058273_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058278_;
    wasmetal_core__DOT___058278_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058281_;
    wasmetal_core__DOT___058281_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058285_;
    wasmetal_core__DOT___058285_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058289_;
    wasmetal_core__DOT___058289_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058311_;
    wasmetal_core__DOT___058311_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058318_;
    wasmetal_core__DOT___058318_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058327_;
    wasmetal_core__DOT___058327_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058340_;
    wasmetal_core__DOT___058340_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058814_;
    wasmetal_core__DOT___058814_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058818_;
    wasmetal_core__DOT___058818_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058915_;
    wasmetal_core__DOT___058915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058922_;
    wasmetal_core__DOT___058922_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063368_;
    wasmetal_core__DOT___063368_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067661_;
    wasmetal_core__DOT___067661_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067727_;
    wasmetal_core__DOT___067727_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068971_;
    wasmetal_core__DOT___068971_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069093_;
    wasmetal_core__DOT___069093_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069142_;
    wasmetal_core__DOT___069142_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069161_;
    wasmetal_core__DOT___069161_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069236_;
    wasmetal_core__DOT___069236_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___072263_;
    wasmetal_core__DOT___072263_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___072264_;
    wasmetal_core__DOT___072264_ = 0;
    CData/*2:0*/ wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0;
    wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hd06a07d0__0;
    __VdfgTmp_hd06a07d0__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc9f60877__0;
    __VdfgTmp_hc9f60877__0 = 0;
    CData/*2:0*/ __VdfgTmp_hb26667c8__0;
    __VdfgTmp_hb26667c8__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5be2ea26__0;
    __VdfgTmp_h5be2ea26__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9c4bb670__0;
    __VdfgTmp_h9c4bb670__0 = 0;
    CData/*2:0*/ __VdfgTmp_h7e4803dd__0;
    __VdfgTmp_h7e4803dd__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf54ed2ea__0;
    __VdfgTmp_hf54ed2ea__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2fff67d0__0;
    __VdfgTmp_h2fff67d0__0 = 0;
    CData/*1:0*/ __VdfgTmp_he0d9cd96__0;
    __VdfgTmp_he0d9cd96__0 = 0;
    CData/*1:0*/ __VdfgTmp_he6226459__0;
    __VdfgTmp_he6226459__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1a57c023__0;
    __VdfgTmp_h1a57c023__0 = 0;
    CData/*1:0*/ __VdfgTmp_hdf3675f5__0;
    __VdfgTmp_hdf3675f5__0 = 0;
    CData/*3:0*/ __VdfgTmp_h61bc6a8d__0;
    __VdfgTmp_h61bc6a8d__0 = 0;
    CData/*3:0*/ __VdfgTmp_hc7c22dbd__0;
    __VdfgTmp_hc7c22dbd__0 = 0;
    CData/*1:0*/ __VdfgTmp_h5abf1189__0;
    __VdfgTmp_h5abf1189__0 = 0;
    CData/*3:0*/ __VdfgTmp_h816ad3b7__0;
    __VdfgTmp_h816ad3b7__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha292b77c__0;
    __VdfgTmp_ha292b77c__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___016072_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015943_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058246_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015735_)))))))));
    vlSelf->wasmetal_core__DOT___016063_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058221_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015981_))))));
    vlSelf->__VdfgTmp_h2eec3533__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                       << 2U) | ((2U 
                                                  & (((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                       ? 
                                                      (0x503U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h63c4ff94__0))))
                                                       : 
                                                      (0x503U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___015648_)))))) 
                                                     << 1U)) 
                                                 | ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    & (IData)(
                                                              (0x5555333300ff0f0fULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hffe7d15f__0))))));
    vlSelf->wasmetal_core__DOT___058253_ = (1U & (0x30a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6d3ce6b7__0))))));
    vlSelf->__VdfgTmp_h2900ee3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (0xcaU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1a0326f2__0)))))));
    vlSelf->wasmetal_core__DOT___015840_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015839_))))));
    vlSelf->wasmetal_core__DOT___015806_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015686_))))));
    if (vlSelf->wasmetal_core__DOT___015607_) {
        vlSelf->wasmetal_core__DOT___016062_ = (1U 
                                                & (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015605_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015602_))))));
        vlSelf->wasmetal_core__DOT___015732_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hd3573026__0)))));
        vlSelf->wasmetal_core__DOT___015820_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc3174423__0))));
        wasmetal_core__DOT___016071_ = (1U & (0x503U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h7f4536ab__0)))));
        wasmetal_core__DOT___058240_ = (1U & (0x503U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hc102c9b5__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___016062_ = (1U 
                                                & (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015603_))))));
        vlSelf->wasmetal_core__DOT___015732_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015737_))))));
        vlSelf->wasmetal_core__DOT___015820_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015689_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_ha302ee77__0)))));
        wasmetal_core__DOT___016071_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015840_));
        wasmetal_core__DOT___058240_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015806_));
    }
    vlSelf->__VdfgTmp_h75158e97__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d));
    vlSelf->__VdfgTmp_h8e7aae2a__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h647f0add__0))));
    vlSelf->wasmetal_core__DOT___019014_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058528_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017936_))));
    vlSelf->__VdfgTmp_hf6eff41b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017193_));
    vlSelf->wasmetal_core__DOT___018505_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x10000000U 
                                                        >> 
                                                        ((0x10U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                             << 4U)) 
                                                         | ((8U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
                                                            | ((4U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)) 
                                                                   << 2U)) 
                                                               | ((2U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___058528_)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058529_))));
    vlSelf->wasmetal_core__DOT___058531_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058529_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058528_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___043068_ = ((IData)(vlSelf->wasmetal_core__DOT___043076_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___043075_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___043074_)
                                                  ? 
                                                 ((~ (IData)(vlSelf->wasmetal_core__DOT___043073_)) 
                                                  & (IData)(vlSelf->wasmetal_core__DOT___043069_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___043070_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___043071_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___043072_));
    vlSelf->wasmetal_core__DOT___017411_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043073_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043075_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043074_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043076_))))));
    vlSelf->wasmetal_core__DOT___058093_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006589_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d))));
    wasmetal_core__DOT___006582_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006589_)) 
                                    & ((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       & (IData)((0xfffffffffffffffeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005677_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005678_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005682_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005681_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h647f0add__0)))))))));
    vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT___036647_) {
        vlSelf->wasmetal_core__DOT___128791___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d;
        vlSelf->wasmetal_core__DOT___128777___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128791___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___035873_;
        vlSelf->wasmetal_core__DOT___128777___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___035729_;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___134180___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036960_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036959_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036958_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036957_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036944_)))));
    vlSelf->wasmetal_core__DOT___036948_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036960_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7cb02621__0))));
    vlSelf->wasmetal_core__DOT___006583_ = (1U & (IData)(
                                                         (0xeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005682_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005681_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005680_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005683_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h07e5b5ff__0))))))));
    vlSelf->wasmetal_core__DOT___005666_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005683_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005679_))
                                                   : (IData)(
                                                             (0xf0f0f0f0f0f0f01ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005682_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005681_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005680_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005679_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h07e5b5ff__0)))))))));
    vlSelf->wasmetal_core__DOT___058086_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135064___B 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
            << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d));
    vlSelf->wasmetal_core__DOT___058089_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058087_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049341_))));
    vlSelf->__VdfgTmp_hcbf9eea7__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058087_));
    vlSelf->wasmetal_core__DOT___052862_ = (1U & (IData)(
                                                         (0xefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052855_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052703_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf5578d4c__0))))))));
    wasmetal_core__DOT___072264_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053593_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053586_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hca0be130__0))))))));
    vlSelf->wasmetal_core__DOT___053510_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053251_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052690_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052689_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053250_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052709_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053249_)))))))));
    vlSelf->wasmetal_core__DOT___072265_ = (1U & (IData)(
                                                         (0x1f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053251_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053509_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052696_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca0be130__0))))))));
    vlSelf->wasmetal_core__DOT___063821_ = (1U & (IData)(
                                                         (0x3f15151500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063790_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053990_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050381_)))))))));
    vlSelf->wasmetal_core__DOT___053370_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053366_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053365_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053364_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053363_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053362_)))))));
    vlSelf->wasmetal_core__DOT___065938_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065935_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001520_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001521_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004174_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h31a231e1__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066083_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066080_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001532_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001533_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004248_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd35a9dc8__0)))))))))))));
    vlSelf->wasmetal_core__DOT___067315_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067311_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000609_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000610_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001120_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001121_))))))))))));
    vlSelf->wasmetal_core__DOT___065605_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065601_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001365_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001366_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003802_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07a3b670__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065803_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065799_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001409_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001410_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003506_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h01d0ee79__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066401_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066398_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001620_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001621_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004322_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h39926e96__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066527_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066524_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001642_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001643_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004100_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hccc0d080__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066649_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066646_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000428_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000429_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001323_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001324_))))))))))));
    vlSelf->wasmetal_core__DOT___066771_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066768_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000460_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000461_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___000976_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___000977_))))))))))));
    vlSelf->wasmetal_core__DOT___066895_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066892_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000494_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000495_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001010_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001011_))))))))))));
    vlSelf->wasmetal_core__DOT___065414_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065410_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001483_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001484_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004618_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he0dafd81__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065189_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065186_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001439_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001440_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004396_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd438e6c0__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065701_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065697_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001377_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001378_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003654_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he23a6b26__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066279_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066275_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001576_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001577_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003728_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9b219d07__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066315_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066312_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001608_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001609_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004026_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h58c7b8aa__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066604_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066601_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000412_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000413_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003884_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf33ae1e8__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066854_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066851_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000472_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000473_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___000988_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___000989_))))))))))));
    vlSelf->wasmetal_core__DOT___067457_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067453_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000653_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000654_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001164_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001165_))))))))))));
    vlSelf->wasmetal_core__DOT___065899_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065895_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001421_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001422_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003580_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc1c0d33f__0)))))))))))));
    vlSelf->wasmetal_core__DOT___067345_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067341_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000631_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000632_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001142_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001143_))))))))))));
    vlSelf->wasmetal_core__DOT___066125_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066122_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001564_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001565_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004692_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h21caabb4__0)))))))))))));
    vlSelf->wasmetal_core__DOT___064900_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064896_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001882_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001883_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004766_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he2ad86dc__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065063_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065061_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001433_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001434_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004544_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h50f5670e__0)))))))))))));
    vlSelf->wasmetal_core__DOT___065304_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065300_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001471_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001472_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004470_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b977022__0)))))))))))));
    vlSelf->wasmetal_core__DOT___067077_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067074_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000538_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000539_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001054_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001055_))))))))))));
    vlSelf->wasmetal_core__DOT___067155_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000560_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000561_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001076_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001077_))))))))))));
    vlSelf->wasmetal_core__DOT___067196_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067193_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000587_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000588_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001098_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001099_))))))))))));
    vlSelf->wasmetal_core__DOT___066972_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066969_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000516_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___000517_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001032_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___001033_))))))))))));
    vlSelf->wasmetal_core__DOT___067482_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xd000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___067479_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067478_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067477_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((4U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054178_))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                              << 1U) 
                                                                             | (vlSelf->insn_imm[0U] 
                                                                                >> 0x1fU)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___064732_ = (1U & (IData)(
                                                         (0xbbb00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064729_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001870_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001871_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004840_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4cb51258__0)))))))))))));
    vlSelf->wasmetal_core__DOT___064467_ = (1U & (IData)(
                                                         (0x4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064465_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064464_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064463_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___053588_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050381_))));
    vlSelf->wasmetal_core__DOT___051222_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050382_))));
    vlSelf->wasmetal_core__DOT___068557_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068554_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067608_ = (1U & (IData)(
                                                         (0xfdf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067606_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067605_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054182_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))))));
    vlSelf->wasmetal_core__DOT___068607_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068605_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054221_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068656_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068655_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054223_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068704_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068703_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068753_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068752_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054227_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068797_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068796_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068852_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068851_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068899_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068898_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054233_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067751_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067748_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054191_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068022_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068019_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068081_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068078_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068157_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068154_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068242_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068239_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068295_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068292_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054209_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068349_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068346_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068404_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068401_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067899_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067896_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067965_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067962_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054197_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067726_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067724_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067812_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068428_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068425_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054215_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068480_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068477_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___067658_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067657_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068106_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068103_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054203_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068943_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068942_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069041_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069040_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054239_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069091_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069090_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069140_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069139_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___068969_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068968_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069233_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069232_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___069159_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054245_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050371_)))))));
    vlSelf->wasmetal_core__DOT___054185_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054036_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128138___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___CO) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___044858_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1660624e__0)))))))))));
    vlSelf->wasmetal_core__DOT___044882_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1660624e__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127967___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d))))))));
    vlSelf->wasmetal_core__DOT___044859_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127968___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127968___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_habbe61e7__0)))))))))));
    vlSelf->wasmetal_core__DOT___044883_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_habbe61e7__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127968___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d))))))));
    vlSelf->wasmetal_core__DOT___006122_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006039_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006232_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005977_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___023202_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127519___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023243_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023797_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023732_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d));
    wasmetal_core__DOT___058915_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058912_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058911_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058910_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7a46858f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h263b1cf5__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he93f6ca8__0)))))))))));
    wasmetal_core__DOT___058814_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058784_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058783_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058782_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> 
                                                                 ((2U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127620___O) 
                                                                      >> 2U)) 
                                                                  | (1U 
                                                                     & (4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_had5b18f3__0))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> 
                                                                    ((2U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127621___O) 
                                                                         >> 1U)) 
                                                                     | (1U 
                                                                        & (4U 
                                                                           >> (IData)(vlSelf->__VdfgTmp_hcf1816fa__0))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (8U 
                                                                     >> 
                                                                     ((2U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127624___O) 
                                                                          >> 1U)) 
                                                                      | (1U 
                                                                         & (4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5b8de47f__0))))))))))))));
    vlSelf->__VdfgTmp_h3056fe7c__0 = ((8U & ((0x10U 
                                              >> (IData)(vlSelf->__VdfgTmp_h963234d4__0)) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128868___O) 
                                                 >> 1U)))));
    vlSelf->__VdfgTmp_h5ac6c849__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058478_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128868___O)))));
    vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036420_));
    vlSelf->wasmetal_core__DOT____Vcellout___128801___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036012_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036011_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036010_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036003_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035936_)))));
    vlSelf->wasmetal_core__DOT___035957_ = ((IData)(vlSelf->wasmetal_core__DOT___036012_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b7__05d));
    vlSelf->__VdfgTmp_hee741df9__0 = (((IData)(vlSelf->wasmetal_core__DOT___058267_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015596_)));
    vlSelf->__VdfgTmp_h14009f5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___015910_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015909_));
    vlSelf->wasmetal_core__DOT___015731_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015896_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015897_))));
    vlSelf->__VdfgTmp_hbb3c60ea__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016020_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___016019_))));
    vlSelf->wasmetal_core__DOT___058262_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016019_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016020_)))));
    vlSelf->wasmetal_core__DOT___015964_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015821_))));
    vlSelf->wasmetal_core__DOT___043121_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017300_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017298_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017297_)))));
    vlSelf->wasmetal_core__DOT___043103_ = (1U & (IData)(
                                                         (0xffffffffff404040ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017298_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017300_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017325_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057798_)))))))));
    vlSelf->wasmetal_core__DOT___017206_ = ((IData)(vlSelf->wasmetal_core__DOT___017300_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___017299_) 
                                               & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017298_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017297_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h182596d5__0)))))));
    vlSelf->wasmetal_core__DOT___058238_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0f335500000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha298e6e0__0)))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___015613_)
                                                          ? 
                                                         (0x503U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___015812_)))))
                                                          : 
                                                         (0x305U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___015645_))))))))));
    vlSelf->__VdfgTmp_h7f6f5bfd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015992_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015991_));
    vlSelf->wasmetal_core__DOT___058331_ = (1U & (IData)(
                                                         (0xeeee0000fff0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016020_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016019_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016017_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016018_)))))))));
    vlSelf->__VdfgTmp_hf1a5f561__0 = (((IData)(vlSelf->wasmetal_core__DOT___016018_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016017_));
    vlSelf->__VdfgTmp_h5b5b6b1b__0 = (((IData)(vlSelf->wasmetal_core__DOT___015849_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015848_));
    vlSelf->wasmetal_core__DOT___058283_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016116_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016115_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015772_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015771_)))))))));
    vlSelf->wasmetal_core__DOT___058230_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016115_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016116_)))));
    vlSelf->wasmetal_core__DOT___015931_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015926_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015925_))));
    vlSelf->__VdfgTmp_h86126eef__0 = (((IData)(vlSelf->wasmetal_core__DOT___015925_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015926_));
    vlSelf->__VdfgTmp_h4f78e4d3__0 = ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                        & (IData)((0xfff0fff055553333ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015897_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015896_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd3573026__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                     ? 
                                                    (0x305U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015839_)))))
                                                     : 
                                                    (0x305U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015867_))))))));
    vlSelf->__VdfgTmp_h1811098d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd3573026__0));
    vlSelf->__VdfgTmp_h9a38454b__0 = ((2U & ((0x3500U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_ha6796979__0)))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                ? (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015943_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015735_)))))
                                                : (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h7f4536ab__0)))))));
    vlSelf->wasmetal_core__DOT___015978_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015603_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he2a347e4__0))))))));
    __VdfgTmp_hb26667c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___015688_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_he2a347e4__0));
    vlSelf->wasmetal_core__DOT___016007_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h12dd4af8__0))))))));
    wasmetal_core__DOT___016051_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                    & (IData)((0xff555533330f0fULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015868_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h12dd4af8__0))))))));
    __VdfgTmp_hdf3675f5__0 = ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                & (IData)((0xff00ff5533330f0fULL 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015605_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc102c9b5__0)))))))) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                ? (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he2a347e4__0))))
                                                : (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h29141d8d__0)))))));
    wasmetal_core__DOT___015976_ = (1U & (0x5300U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h29141d8d__0)))));
    __VdfgTmp_h7e4803dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h766529e2__0));
    if (vlSelf->wasmetal_core__DOT___015606_) {
        wasmetal_core__DOT___015977_ = (1U & (0xeU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_ha302ee77__0))));
        wasmetal_core__DOT___015993_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015831_));
        wasmetal_core__DOT___015819_ = (1U & (0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h10a18780__0)))));
    } else {
        wasmetal_core__DOT___015977_ = (1U & (0xf1U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015684_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hf420cd01__0)))));
        wasmetal_core__DOT___015993_ = (1U & (0x35U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd1c7c886__0)))));
        wasmetal_core__DOT___015819_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015831_));
    }
    __VdfgTmp_h5abf1189__0 = (((IData)(vlSelf->wasmetal_core__DOT___016030_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016029_));
    __VdfgTmp_he6226459__0 = (((IData)(vlSelf->wasmetal_core__DOT___016029_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016030_));
    wasmetal_core__DOT___015826_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___015817_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015816_))));
    __VdfgTmp_h816ad3b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                               << 3U) | ((4U & ((4U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___058267_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___015594_))) 
                                                << 2U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT___016045_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___016046_))));
    __VdfgTmp_ha292b77c__0 = (((IData)(vlSelf->wasmetal_core__DOT___016046_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016045_));
    wasmetal_core__DOT___058272_ = (1U & (0xfc00aaU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016045_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016046_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___058267_)))))));
    wasmetal_core__DOT___015599_ = (1U & (IData)((0xeeee0000fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015950_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015949_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h0d424198__0))))))));
    vlSelf->wasmetal_core__DOT___015954_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015950_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015949_))));
    vlSelf->__VdfgTmp_h45982c59__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h6c8cc102__0)));
    wasmetal_core__DOT___058231_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6c8cc102__0))));
    __VdfgTmp_hc9f60877__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015969_));
    vlSelf->wasmetal_core__DOT___058317_ = (1U & (0xe000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015927_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015928_)))))));
    vlSelf->wasmetal_core__DOT___015932_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015927_))));
    if (vlSelf->wasmetal_core__DOT___015594_) {
        vlSelf->wasmetal_core__DOT___015979_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015983_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___015982_))));
        vlSelf->wasmetal_core__DOT___058335_ = (1U 
                                                & (0xf0e0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h70395930__0)))));
        if (vlSelf->wasmetal_core__DOT___015596_) {
            wasmetal_core__DOT___058281_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h36951d10__0)));
            wasmetal_core__DOT___058278_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)));
        } else {
            wasmetal_core__DOT___058281_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015954_));
            wasmetal_core__DOT___058278_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015932_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___015979_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015981_))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015605_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015602_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___015606_))))));
        vlSelf->wasmetal_core__DOT___058335_ = (1U 
                                                & (0xf0e0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_ha292b77c__0)))));
        wasmetal_core__DOT___058281_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015596_)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___015953_)));
        wasmetal_core__DOT___058278_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015596_)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___015931_)));
    }
    vlSelf->wasmetal_core__DOT___058363_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058326_))));
    vlSelf->wasmetal_core__DOT___058254_ = (1U & (0xf011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xfefefefe000000ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015983_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015982_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058222_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h1a6a5523__0))))))) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2acad42a__0)))));
    vlSelf->wasmetal_core__DOT___058364_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x4000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h2900ee3d__0)))))));
    wasmetal_core__DOT___016097_ = (1U & (1U >> ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                   & (IData)(
                                                             (0xfff0fff055553333ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015910_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015909_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hc102c9b5__0)))))))) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                        ? (IData)(vlSelf->wasmetal_core__DOT___015806_)
                                                        : 
                                                       (0x503U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hc3174423__0)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h75158e97__0))));
    vlSelf->wasmetal_core__DOT___036952_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfa042eae__0))));
    vlSelf->wasmetal_core__DOT___018507_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058531_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                         >> 1U)))));
    wasmetal_core__DOT___017373_ = ((IData)(vlSelf->wasmetal_core__DOT___017412_) 
                                    & (IData)((0xefff1000000000ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017411_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017410_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017409_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017408_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017407_)))))))));
    vlSelf->wasmetal_core__DOT___036292_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005686_)) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128846___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005686_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036961_)
            ? (IData)(vlSelf->wasmetal_core__DOT___036948_)
            : (IData)(vlSelf->wasmetal_core__DOT___036647_));
    vlSelf->__VdfgTmp_h11374272__0 = (((IData)(vlSelf->wasmetal_core__DOT___006583_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005679_));
    vlSelf->wasmetal_core__DOT___017803_ = (1U & (0xf0f000ddU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b2__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b3__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02emajorExc_Z)))))));
    vlSelf->wasmetal_core__DOT___040073_ = (1U & (0xeaeaea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005679_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058086_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b2__05d)))))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0)))) {
        wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d;
        wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d;
    } else {
        wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128791___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128777___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___036951_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfa042eae__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0))));
    vlSelf->wasmetal_core__DOT___036962_ = (1U & (0xb4U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h97610f75__0))));
    wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0 = ((4U 
                                                   & ((~ 
                                                       (6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfa042eae__0))) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((~ 
                                                          (6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (~ (IData)(vlSelf->wasmetal_core__DOT___036647_)))));
    vlSelf->wasmetal_core__DOT___053101_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051218_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052863_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052862_)))));
    vlSelf->wasmetal_core__DOT___019794_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___072264_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053594_)))));
    vlSelf->wasmetal_core__DOT___039561_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039533_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039535_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039554_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039545_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039544_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039543_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039542_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039869_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___040088_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b9__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039523_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b10__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039540_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039539_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039538_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039537_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039546_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039547_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039548_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039562_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039558_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039557_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039556_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b21__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039555_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039870_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039549_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b24__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039536_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039553_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039552_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b27__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039551_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039550_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039559_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xcaU 
                                                                >> (IData)(vlSelf->__VdfgTmp_he7cea807__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039560_ = (1U & (IData)(
                                                         (0x2aaaeaaa2aaa2aaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053594_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___072264_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___019796_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___072265_))));
    vlSelf->wasmetal_core__DOT___039477_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054250_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128298___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039446_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054252_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128298___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039445_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054254_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128298___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039448_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054256_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128298___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039449_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054258_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128305___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039450_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054260_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128305___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039467_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054262_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128305___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039460_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054264_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128305___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039459_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054266_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128306___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___039458_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054268_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128306___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039457_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054270_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128306___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039861_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054272_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128306___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039451_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054274_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128307___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039444_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054280_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128307___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039456_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054282_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128307___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039455_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054284_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128307___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039454_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054286_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128308___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039453_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054288_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128308___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039461_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054290_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128308___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039462_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054292_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128308___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039463_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054294_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128309___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039469_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054296_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128309___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039863_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054298_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128309___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039471_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054300_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128309___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039473_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054302_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128310___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039468_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054304_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128310___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039862_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054306_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128310___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039464_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054308_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128310___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039452_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054310_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128311___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039474_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054312_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128311___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039472_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054314_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128311___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039470_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054316_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128311___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___039466_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054318_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128312___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___039465_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054319_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128312___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072265_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT___019804_ = (1U & (IData)(
                                                         (0xbf00bfbf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053370_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053369_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053368_)))))))));
    vlSelf->wasmetal_core__DOT___065945_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065939_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065938_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065937_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b12__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___066090_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066083_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066082_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___065617_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3f15000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065605_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065604_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b8__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___063451_))))))))))));
    vlSelf->wasmetal_core__DOT___065807_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3f15000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065803_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065802_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065801_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b10__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___063451_))))))))))));
    vlSelf->wasmetal_core__DOT___065191_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065190_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065189_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065188_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___065705_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3f15000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065701_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065700_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065699_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b9__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___063451_))))))))))));
    vlSelf->wasmetal_core__DOT___067461_ = (1U & (IData)(
                                                         (0x3f15000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067457_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067456_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067455_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b30__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063451_)))))))));
    vlSelf->wasmetal_core__DOT___065903_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3f15000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065899_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065898_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065897_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b11__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___063451_))))))))))));
    vlSelf->wasmetal_core__DOT___066129_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066126_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066125_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066124_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b14__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___066977_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066973_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066972_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066971_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b24__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___067490_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x2a3f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067482_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067481_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053011_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3edf8090__0))))))));
    vlSelf->wasmetal_core__DOT___064744_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064733_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064732_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064731_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___064479_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3f15151500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064467_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064466_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053011_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h365733f0__0))))))));
    vlSelf->wasmetal_core__DOT___019793_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x10000U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053588_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053587_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___052694_)))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053590_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053589_)))));
    vlSelf->wasmetal_core__DOT___053597_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053593_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053588_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052695_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052700_)))))));
    wasmetal_core__DOT___063368_ = (1U & (0x10U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___063366_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___053588_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___052849_)))));
    vlSelf->wasmetal_core__DOT___051229_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051225_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050365_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051222_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xffff100000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051205_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051204_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___052710_ = (1U & (IData)(
                                                         (0x1f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051222_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052695_)))))))));
    vlSelf->wasmetal_core__DOT___068609_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068607_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b50__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068658_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068656_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b51__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068706_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068704_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b52__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068755_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068753_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b53__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068799_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068797_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b54__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068854_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068852_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b55__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068901_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068899_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b56__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___067760_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067751_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067750_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf98ad324__0))))))));
    vlSelf->wasmetal_core__DOT___019403_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068022_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068021_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068020_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h94bf9d34__0))))))));
    vlSelf->wasmetal_core__DOT___068085_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068081_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068080_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068079_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0ee6a0be__0))))))));
    vlSelf->wasmetal_core__DOT___068161_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068157_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068156_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068155_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h38fb75d8__0))))))));
    vlSelf->wasmetal_core__DOT___068246_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068242_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068241_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068240_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8d1b60d2__0))))))));
    vlSelf->wasmetal_core__DOT___068299_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068295_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068294_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068293_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h598b279f__0))))))));
    vlSelf->wasmetal_core__DOT___068353_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068349_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068348_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068347_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1fd76cb3__0))))))));
    vlSelf->wasmetal_core__DOT___068408_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068404_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068403_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068402_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2cbbdbef__0))))))));
    wasmetal_core__DOT___067727_ = (1U & (IData)((0x3faf00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067726_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067725_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054478_)))))))));
    vlSelf->wasmetal_core__DOT___019398_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067812_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067811_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067810_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h20a4ea67__0))))))));
    vlSelf->wasmetal_core__DOT___068432_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068428_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068427_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068426_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h97b1be8c__0))))))));
    vlSelf->wasmetal_core__DOT___068487_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068480_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068479_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068478_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfec86816__0))))))));
    wasmetal_core__DOT___067661_ = (1U & (0x3faf0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___067658_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___054478_)))))));
    vlSelf->wasmetal_core__DOT___068110_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068106_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068105_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068104_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfe166c9c__0))))))));
    vlSelf->wasmetal_core__DOT___068945_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068943_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b57__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___069043_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069041_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b59__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    wasmetal_core__DOT___069093_ = (1U & (0xf7f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___069091_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b60__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    wasmetal_core__DOT___069142_ = (1U & (0xf7f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___069140_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b61__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    wasmetal_core__DOT___068971_ = (1U & (0xf7f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___068969_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b58__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    wasmetal_core__DOT___069236_ = (1U & (0x3faf0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___069233_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b63__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___054478_)))))));
    wasmetal_core__DOT___069161_ = (1U & (0xf7f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___069159_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b62__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    wasmetal_core__DOT___044837_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044883_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___044882_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___044880_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044879_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044878_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044877_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044876_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044875_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044874_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044873_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___044872_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___044871_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___044891_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___044890_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___044889_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___044888_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___044887_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___044886_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___044885_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___044884_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___044881_)
                                                                     ? 
                                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044870_))
                                                                     : 
                                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044881_)))
                                                                    : 
                                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044884_)))
                                                                   : 
                                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044885_)))
                                                                  : 
                                                                 (~ (IData)(vlSelf->wasmetal_core__DOT___044886_)))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___044863_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___044864_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___044865_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___044866_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___044867_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___044847_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___044848_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___044849_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044850_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044851_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044852_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044853_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044854_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044855_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044856_))
                                               : (IData)(vlSelf->wasmetal_core__DOT___044858_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___044859_)));
    wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023181_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023798_)
            ? (IData)(wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d));
    wasmetal_core__DOT___058922_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058917_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058916_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058915_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hf2c31503__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0)))))))))));
    wasmetal_core__DOT___058818_ = (1U & (IData)((0xb00000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058814_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058813_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058812_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___005882_)))))))));
    vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b29__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036013_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035957_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b8__05d));
    vlSelf->wasmetal_core__DOT___058365_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hee741df9__0))))));
    vlSelf->wasmetal_core__DOT___058294_ = (1U & ((~ 
                                                   (0x40U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hee741df9__0))) 
                                                  & (IData)(
                                                            (0x1111ffff000fffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016046_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016045_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h70395930__0)))))))));
    vlSelf->wasmetal_core__DOT___058336_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x80U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hee741df9__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015597_))));
    vlSelf->wasmetal_core__DOT___058239_ = (1U & (0xf011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xaaaaccccf0f0ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9a784e39__0))))))) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h14009f5a__0)))));
    wasmetal_core__DOT___058285_ = (1U & (IData)((0xccccaaaaf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015731_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xaaaaccccff00f0f0ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hffe7d15f__0))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058226_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___015730_)))))))));
    __VdfgTmp_h5be2ea26__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015731_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015730_)));
    vlSelf->__VdfgTmp_h9b99f784__0 = ((2U & ((0x1000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h2900ee3d__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___058262_));
    vlSelf->wasmetal_core__DOT___058322_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015964_))));
    wasmetal_core__DOT___043085_ = ((IData)(vlSelf->wasmetal_core__DOT___043121_)
                                     ? ((IData)(vlSelf->wasmetal_core__DOT___043120_)
                                         ? ((IData)(vlSelf->wasmetal_core__DOT___043119_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___017201_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___043118_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___043117_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___043116_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___043115_)
                                                     ? 
                                                    ((1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb820c59b__0)))
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043125_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043124_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043123_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043122_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___017375_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___017269_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___017371_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___017372_)
                                                              ? 
                                                             ((~ (IData)(vlSelf->wasmetal_core__DOT___017412_)) 
                                                              & (IData)(vlSelf->wasmetal_core__DOT___043095_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043104_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043105_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043106_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043107_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043108_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043109_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043110_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043111_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043112_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___043096_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___043097_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___043098_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___043099_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___043100_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___043101_))
                                         : (IData)(vlSelf->wasmetal_core__DOT___043102_))
                                     : (IData)(vlSelf->wasmetal_core__DOT___043103_));
    __VdfgTmp_hc7c22dbd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_h7f6f5bfd__0)));
    vlSelf->__VdfgTmp_h9d948fd9__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf1a5f561__0)));
    __VdfgTmp_h2fff67d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015851_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h5b5b6b1b__0));
    vlSelf->wasmetal_core__DOT___058297_ = ((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                            & (IData)(
                                                      (0xeeee0000fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015927_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015928_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h86126eef__0))))))));
    wasmetal_core__DOT___058340_ = (1U & (IData)((0xeeee0000fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015928_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015927_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h86126eef__0))))))));
    vlSelf->wasmetal_core__DOT___058264_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058260_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xeU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2eec3533__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4f78e4d3__0))))));
    wasmetal_core__DOT___016123_ = (1U & (1U >> ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                   & (IData)(
                                                             (0x555533330f0f00ffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                                      << 3U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h1811098d__0))))))) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                        ? 
                                                       (0x503U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h12dd4af8__0))))
                                                        : 
                                                       (0x503U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h766529e2__0)))))))));
    __VdfgTmp_h1a57c023__0 = ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                & (IData)((0xff00ff5533330f0fULL 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015943_) 
                                                      << 3U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h1811098d__0))))))) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___015840_)
                                                : (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015868_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015867_))))))));
    wasmetal_core__DOT___016033_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                    & (IData)((0xff555533330f0fULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                          << 3U) 
                                                         | (IData)(__VdfgTmp_hb26667c8__0)))))));
    wasmetal_core__DOT___015598_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                    & (IData)((0x555533330f0f00ffULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015689_) 
                                                          << 3U) 
                                                         | (IData)(__VdfgTmp_hb26667c8__0)))))));
    __VdfgTmp_h9c4bb670__0 = ((2U & ((0xacU >> (IData)(__VdfgTmp_h7e4803dd__0)) 
                                     << 1U)) | (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h12dd4af8__0)))));
    wasmetal_core__DOT___016004_ = (1U & (0x5300U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            << 3U) 
                                           | (IData)(__VdfgTmp_h7e4803dd__0))));
    __VdfgTmp_he0d9cd96__0 = (((IData)(wasmetal_core__DOT___015977_) 
                               << 1U) | (IData)(wasmetal_core__DOT___015976_));
    vlSelf->wasmetal_core__DOT___058305_ = (1U & (0x5500fcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015817_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015816_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015820_)))))));
    wasmetal_core__DOT___058273_ = (1U & (IData)((0xeeee0000fff00000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016043_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016044_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_he6226459__0))))))));
    vlSelf->wasmetal_core__DOT___058361_ = (1U & (IData)(
                                                         (0xfef0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h816ad3b7__0))))));
    vlSelf->wasmetal_core__DOT___058315_ = (1U & (IData)(
                                                         (0xfef000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h816ad3b7__0))))));
    vlSelf->wasmetal_core__DOT___058354_ = (1U & ((1U 
                                                   & (0x40U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hee741df9__0)))
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (0xe000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hcaafbee5__0))))
                                                    : 
                                                   (0xe000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_ha292b77c__0)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b57__05d 
        = (1U & (0x4000bfffU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___015954_)))))));
    vlSelf->wasmetal_core__DOT___058356_ = (1U & (IData)(
                                                         (0xee0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015954_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0d424198__0))))))));
    vlSelf->__VdfgTmp_h1ac41acf__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015954_)));
    wasmetal_core__DOT___058327_ = (1U & (IData)((0xeeee0000fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015994_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___015993_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015991_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___015992_)))))))));
    __VdfgTmp_h61bc6a8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015994_) 
                                           << 1U) | (IData)(wasmetal_core__DOT___015993_))));
    wasmetal_core__DOT___058252_ = (1U & (0xe0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___015993_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___015994_)))));
    wasmetal_core__DOT___015963_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___015818_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___015819_))));
    __VdfgTmp_hf54ed2ea__0 = (((IData)(wasmetal_core__DOT___015819_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015818_));
    if (vlSelf->wasmetal_core__DOT___015596_) {
        wasmetal_core__DOT___058289_ = (1U & (0x1111000fU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015848_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015849_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0dbc0f0f__0))))));
        if (vlSelf->wasmetal_core__DOT___015594_) {
            vlSelf->wasmetal_core__DOT___058324_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___016132_)));
            vlSelf->wasmetal_core__DOT___058351_ = 
                (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_hf69e15ee__0))));
            vlSelf->wasmetal_core__DOT___058248_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___015850_)));
            vlSelf->wasmetal_core__DOT___058323_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___016125_)));
            vlSelf->wasmetal_core__DOT___058242_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___015820_)));
        } else {
            vlSelf->wasmetal_core__DOT___058324_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___016132_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015850_))));
            vlSelf->wasmetal_core__DOT___058351_ = 
                (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h5b5b6b1b__0))));
            vlSelf->wasmetal_core__DOT___058248_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hf69e15ee__0)));
            vlSelf->wasmetal_core__DOT___058323_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___016125_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015820_))));
            vlSelf->wasmetal_core__DOT___058242_ = 
                (1U & (IData)(wasmetal_core__DOT___015826_));
        }
        vlSelf->wasmetal_core__DOT___058296_ = (1U 
                                                & (0xe0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9a38454b__0))));
        wasmetal_core__DOT___058318_ = (1U & (1U >> (IData)(__VdfgTmp_hdf3675f5__0)));
        wasmetal_core__DOT___058311_ = (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2acad42a__0)));
        vlSelf->wasmetal_core__DOT___058308_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016072_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___016071_))));
        vlSelf->wasmetal_core__DOT___058314_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016097_));
        vlSelf->wasmetal_core__DOT___058316_ = (1U 
                                                & (1U 
                                                   >> (IData)(__VdfgTmp_h1a57c023__0)));
        vlSelf->wasmetal_core__DOT___058295_ = (1U 
                                                & (0xe0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & (((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                             ? 
                                                            (0xeU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h14009f5a__0)))
                                                             : 
                                                            (0x53U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc102c9b5__0))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0xe0U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058268_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___058269_)))))))));
    } else {
        wasmetal_core__DOT___058289_ = (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___015969_)));
        if (vlSelf->wasmetal_core__DOT___015594_) {
            vlSelf->wasmetal_core__DOT___058324_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h0dbc0f0f__0)));
            wasmetal_core__DOT___058318_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h36951d10__0)));
            wasmetal_core__DOT___058311_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___015976_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___015977_))));
            vlSelf->wasmetal_core__DOT___058314_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h5abf1189__0)));
            vlSelf->wasmetal_core__DOT___058248_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h2fff67d0__0)));
            vlSelf->wasmetal_core__DOT___058316_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)));
            vlSelf->wasmetal_core__DOT___058323_ = 
                (1U & (IData)(wasmetal_core__DOT___015826_));
            vlSelf->wasmetal_core__DOT___058242_ = 
                (1U & (1U >> (IData)(__VdfgTmp_hf54ed2ea__0)));
        } else {
            vlSelf->wasmetal_core__DOT___058324_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___015848_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015849_))));
            wasmetal_core__DOT___058318_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015953_));
            wasmetal_core__DOT___058311_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7f6f5bfd__0)));
            vlSelf->wasmetal_core__DOT___058314_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hcaafbee5__0)));
            vlSelf->wasmetal_core__DOT___058248_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___015851_)));
            vlSelf->wasmetal_core__DOT___058316_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___015931_));
            vlSelf->wasmetal_core__DOT___058323_ = 
                (1U & (IData)(wasmetal_core__DOT___015963_));
            vlSelf->wasmetal_core__DOT___058242_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___015821_)));
        }
        vlSelf->wasmetal_core__DOT___058296_ = (1U 
                                                & ((IData)(wasmetal_core__DOT___016051_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                    : 
                                                   (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h7369d2e1__0))))));
        vlSelf->wasmetal_core__DOT___058351_ = (1U 
                                                & (8U 
                                                   >> (IData)(__VdfgTmp_hc9f60877__0)));
        vlSelf->wasmetal_core__DOT___058308_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015850_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h0dbc0f0f__0)))));
        vlSelf->wasmetal_core__DOT___058295_ = (1U 
                                                & ((IData)(wasmetal_core__DOT___016033_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                    : 
                                                   (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h5abf1189__0))))));
    }
    vlSelf->wasmetal_core__DOT___058362_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xe000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h45982c59__0))))));
    vlSelf->wasmetal_core__DOT___058349_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xe00U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h45982c59__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058283_)))));
    __VdfgTmp_hd06a07d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___058230_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058231_));
    vlSelf->__VdfgTmp_hac8f2958__0 = (((IData)(wasmetal_core__DOT___058231_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058230_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b60__05d 
        = (1U & (0x807fU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                         << 2U) | (IData)(__VdfgTmp_hc9f60877__0)))));
    vlSelf->wasmetal_core__DOT___016450_ = (1U & (IData)(
                                                         (0xf0f01111ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058289_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccccaaaaf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058286_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058244_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058243_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058246_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016132_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___015850_))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b56__05d 
        = (1U & (0x4000bfffU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___015932_)))))));
    vlSelf->wasmetal_core__DOT___058355_ = (1U & (IData)(
                                                         (0xee0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015932_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h86126eef__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b61__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058363_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b28__05d 
        = (1U & (0x55c0aa3fU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015969_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___058324_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b62__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058364_))));
    vlSelf->wasmetal_core__DOT___058249_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xffaa0fccU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058245_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058244_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___058243_)))))) 
                                                             << 2U)) 
                                                         | (((IData)(wasmetal_core__DOT___016071_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___016072_)))))));
    vlSelf->wasmetal_core__DOT___058091_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006589_)))));
    vlSelf->wasmetal_core__DOT___040074_ = (1U & (IData)(
                                                         (0x2aea2a2aeaeaeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006583_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___049343_ = (1U & (IData)(
                                                         (0xf0004400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h75158e97__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049341_)))))))));
    vlSelf->wasmetal_core__DOT___036009_ = (1U & (0xbb0bbbbU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b54__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048948_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b53__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b52__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d)))))));
    vlSelf->__VdfgTmp_h7b6a46b3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d));
    vlSelf->__VdfgTmp_he488fa83__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp___135065___A 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
            << 0x12U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                          << 0x11U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d) 
                                        << 0x10U) | 
                                       (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                         << 0xfU) | 
                                        (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d) 
                                          << 0xeU) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                             << 0xdU) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                << 0xcU) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d) 
                                                   << 0xbU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d) 
                                                      << 0xaU) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d) 
                                                         << 9U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d) 
                                                            << 8U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d) 
                                                               << 7U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                                  << 6U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___017195_ = (((IData)(vlSelf->wasmetal_core__DOT___017375_) 
                                             & ((IData)(vlSelf->wasmetal_core__DOT___017374_) 
                                                & (IData)(
                                                          (0x8000000000000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___017373_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017372_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017371_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017370_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hb820c59b__0))))))))) 
                                            & (((IData)(vlSelf->wasmetal_core__DOT___017342_) 
                                                & (IData)(
                                                          (0x1001000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017341_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017340_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017339_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017338_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h6cc9accb__0)))))))) 
                                               & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017203_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___017234_) 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT___017233_) 
                                                                            & (IData)(
                                                                                (0x9009000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017232_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017231_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5fa4cdd4__0))))))) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017201_))))))))));
    wasmetal_core__DOT___051533_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U)) 
                                                            | (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                  >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___017519_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                         >> 3U)))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hfa042eae__0)))) {
        wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d;
        wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d;
    } else {
        wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036962_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0))));
    vlSelf->wasmetal_core__DOT___019792_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053590_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053589_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053595_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053594_)))))))));
    vlSelf->wasmetal_core__DOT___063400_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063367_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050397_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___063368_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053568_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053592_)))))))));
    vlSelf->wasmetal_core__DOT___063371_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063367_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053569_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053355_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053093_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053592_)))))))));
    vlSelf->wasmetal_core__DOT___063426_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h93f3e051__0))))))));
    vlSelf->wasmetal_core__DOT___019797_ = (1U & (IData)(
                                                         (0xb000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051230_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051229_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051228_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051227_)))))))));
    wasmetal_core__DOT___072263_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052712_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052711_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052710_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052709_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___052708_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052707_)))))))));
    vlSelf->wasmetal_core__DOT___067736_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbbb00000U 
                                                                         >> 
                                                                         (((IData)(wasmetal_core__DOT___067727_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053926_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84433958__0))))))));
    vlSelf->wasmetal_core__DOT___067670_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___067661_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067660_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067659_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd2ae5a25__0))))))));
    vlSelf->wasmetal_core__DOT___069099_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___069093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b60__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc23ff14f__0))))))));
    vlSelf->wasmetal_core__DOT___069147_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___069142_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069141_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b61__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h26fdb0d9__0))))))));
    vlSelf->wasmetal_core__DOT___068975_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___068971_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068970_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b58__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h99cf87be__0))))))));
    vlSelf->wasmetal_core__DOT___069239_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___069236_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069235_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069234_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h965c3061__0))))))));
    vlSelf->wasmetal_core__DOT___069167_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___069161_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069160_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b62__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf266c674__0))))))));
    wasmetal_core__DOT___048489_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___044837_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___CO) 
                                                        >> 2U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___044240_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127527___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023182_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023181_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023243_) 
                                   << 1U) | (1U & (0x5cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3b955ce1__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023305_)))));
    vlSelf->wasmetal_core__DOT___023246_ = ((IData)(vlSelf->wasmetal_core__DOT___023182_) 
                                            & (IData)(wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127591___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023799_) 
             << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023798_) 
                        << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023797_))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___023799_)
                 ? (IData)(wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023732_)))));
    vlSelf->wasmetal_core__DOT___058928_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058924_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058923_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058922_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h87705c6a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h8ddb6508__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h276f18a3__0)))))))))));
    vlSelf->wasmetal_core__DOT___058929_ = (1U & ((IData)(
                                                          (0x1000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___058862_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058861_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058860_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___006204_))) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___003806_))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (4U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___006144_))))))))))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___017453_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017452_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017451_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058840_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058839_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058838_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005928_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003811_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006178_))))))))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((8U 
                                                                               >> 
                                                                               ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058824_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058823_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058822_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005889_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006065_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xb00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___058818_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058817_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058816_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005802_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006238_))))))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058752_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058751_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058750_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127629___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h87705c6a__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127627___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hff1f1b74__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127628___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd093a298__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058724_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058723_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058722_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127630___O)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127629___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h276f18a3__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127625___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b30__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036014_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b9__05d));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b63__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058365_))));
    vlSelf->wasmetal_core__DOT___058306_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___058240_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058239_))))));
    vlSelf->wasmetal_core__DOT___058241_ = (1U & (0xffaa0c0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___058240_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058239_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058238_)))))));
    vlSelf->wasmetal_core__DOT___058303_ = (1U & (IData)(
                                                         (0xafcf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015732_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h5be2ea26__0)))))));
    vlSelf->wasmetal_core__DOT___058232_ = (1U & ((~ 
                                                   (0x5030000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xaaaaccccff00f0f0ULL 
                                                                           >> (IData)(vlSelf->__VdfgTmp_hffe7d15f__0))) 
                                                                  << 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___058226_))))))) 
                                                  & (IData)(
                                                            (0xff00ff00ffafffcfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015732_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 3U) 
                                                                    | (IData)(__VdfgTmp_h5be2ea26__0))))))));
    vlSelf->wasmetal_core__DOT___058360_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9b99f784__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b59__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058322_)))));
    vlSelf->wasmetal_core__DOT___017197_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043068_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017411_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___043085_)))));
    vlSelf->wasmetal_core__DOT___058353_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016021_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (0xe000U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h9d948fd9__0))
                                                    : 
                                                   (0xe000U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hbb3c60ea__0)))));
    vlSelf->__VdfgTmp_he58e0004__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                       << 3U) | (IData)(__VdfgTmp_h2fff67d0__0));
    vlSelf->wasmetal_core__DOT___058341_ = (1U & (IData)(
                                                         (0xfff1ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058340_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___016051_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)))))))))));
    vlSelf->wasmetal_core__DOT___058518_ = (1U & (0xfefU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058340_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___016051_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015594_)))))));
    vlSelf->wasmetal_core__DOT___058321_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                            ? (IData)(wasmetal_core__DOT___016123_)
                                                            : 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___016122_)
                                                             : 
                                                            (1U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___016116_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___016115_))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xe000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h45982c59__0)))))));
    vlSelf->wasmetal_core__DOT___016448_ = (1U & (IData)(
                                                         (0xff00f0f011111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058285_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___016123_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058283_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xe00U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h45982c59__0)))))))))));
    vlSelf->wasmetal_core__DOT___058334_ = (1U & (0xf10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___016033_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_he6226459__0))))));
    vlSelf->wasmetal_core__DOT___058342_ = (1U & (IData)(
                                                         (0xfff1ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___015599_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___015598_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h36951d10__0)))))))))));
    vlSelf->wasmetal_core__DOT___016441_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                     & (IData)(
                                                               (0xeeee0000fff0ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015949_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015950_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h0d424198__0)))))))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                          ? 
                                                         (0xe0U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016063_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___016062_))))
                                                          : 
                                                         ((IData)(wasmetal_core__DOT___015598_)
                                                           ? 
                                                          (2U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                           : 
                                                          (0xe00U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h36951d10__0))))))))));
    vlSelf->wasmetal_core__DOT___058225_ = (1U & ((~ (IData)(
                                                             (0x1111fff000000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016062_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016063_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___058224_))))))))) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffefULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___015599_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___015598_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((1U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h36951d10__0)) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___015594_))))))))));
    vlSelf->__VdfgTmp_hf599dae9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058297_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___058296_)))));
    vlSelf->wasmetal_core__DOT___058302_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h9c4bb670__0)))));
    vlSelf->wasmetal_core__DOT___058233_ = ((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                            & (IData)(
                                                      (0x55553333fff0fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015772_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015771_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h9c4bb670__0))))))));
    vlSelf->__VdfgTmp_ha2f7036a__0 = (((IData)(wasmetal_core__DOT___016004_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016003_));
    vlSelf->__VdfgTmp_hfb1d3885__0 = (((IData)(vlSelf->wasmetal_core__DOT___016003_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016004_));
    vlSelf->wasmetal_core__DOT___058255_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015992_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015991_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_he0d9cd96__0))))))));
    vlSelf->wasmetal_core__DOT___058346_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___058272_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058273_)))));
    vlSelf->wasmetal_core__DOT___058275_ = (1U & (IData)(
                                                         (0xaaaaff0003030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___016097_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___058273_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___058272_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfff01111U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & ((0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha298e6e0__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058269_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058268_)))))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b55__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058361_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b47__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058354_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b49__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058356_))));
    vlSelf->wasmetal_core__DOT___058319_ = (1U & (0xff00bfbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___058318_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1ac41acf__0)))));
    vlSelf->wasmetal_core__DOT___058348_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058281_))));
    vlSelf->wasmetal_core__DOT___016447_ = (1U & (IData)(
                                                         (0xf0f01111ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058281_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f000eeU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058221_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058224_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015981_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015607_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_hdf3675f5__0))))))));
    vlSelf->wasmetal_core__DOT___058328_ = (1U & (IData)(
                                                         (0x1f1f00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058327_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058326_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015978_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                               << 2U) 
                                                                              | (IData)(__VdfgTmp_he0d9cd96__0))))))))))));
    vlSelf->wasmetal_core__DOT___058352_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015995_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (0xe000U 
                                                    >> (IData)(__VdfgTmp_hc7c22dbd__0))
                                                    : 
                                                   (0xe000U 
                                                    >> (IData)(__VdfgTmp_h61bc6a8d__0)))));
    vlSelf->wasmetal_core__DOT___016451_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___015995_)
                                                         ? 
                                                        (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                         : 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                          ? 
                                                         (0xe0U 
                                                          >> (IData)(__VdfgTmp_hc7c22dbd__0))
                                                          : 
                                                         (0xe0U 
                                                          >> (IData)(__VdfgTmp_h61bc6a8d__0)))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      & (IData)(
                                                                (0xff00fff0f0fefeULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015979_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015978_) 
                                                                            << 2U) 
                                                                           | (IData)(__VdfgTmp_he0d9cd96__0)))))))))));
    vlSelf->wasmetal_core__DOT___016442_ = (1U & (0xff001f1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___058311_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___058252_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058253_)))))));
    vlSelf->__VdfgTmp_h240228f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___058253_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058252_));
    vlSelf->__VdfgTmp_hf1c161b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015964_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___015963_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (1U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015816_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___015817_))))))));
    vlSelf->__VdfgTmp_hb564d990__0 = (((IData)(vlSelf->wasmetal_core__DOT___015821_) 
                                       << 2U) | (IData)(__VdfgTmp_hf54ed2ea__0));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b58__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058362_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b42__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058349_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b50__05d 
        = (1U & (0xe0001fffU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                << 2U) 
                                               | (IData)(__VdfgTmp_hd06a07d0__0))))));
    vlSelf->__VdfgTmp_hbec899f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hd06a07d0__0)));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b44__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058351_))));
    vlSelf->__VdfgTmp_h3c71f500__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016450_));
    vlSelf->wasmetal_core__DOT___016460_ = (1U & (IData)(
                                                         (0x7fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058364_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058363_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058355_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015969_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015596_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b48__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058355_))));
    vlSelf->wasmetal_core__DOT___058347_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058278_))));
    vlSelf->wasmetal_core__DOT___058279_ = (1U & (IData)(
                                                         (0xf0f01111ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058278_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f0ccaaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058276_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha6796979__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_h1a57c023__0))))))));
    vlSelf->__VdfgTmp_h86dfc376__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058315_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058314_))));
    vlSelf->wasmetal_core__DOT___040084_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128789___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___040099_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128789___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___040103_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128789___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___040100_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128789___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___040076_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128790___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___040101_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128790___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___040098_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128790___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___040080_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128790___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase 
        = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049343_))));
    vlSelf->wasmetal_core__DOT___036007_ = (1U & (IData)(
                                                         (0xffff753000008acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b53__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b53__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___071561_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058086_)))))))));
    vlSelf->wasmetal_core__DOT___058090_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7b6a46b3__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h11374272__0))));
    vlSelf->wasmetal_core__DOT___017156_ = (1U & ((~ 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b3__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005670_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                      ? 
                                                     (0x7f5f3f0fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006583_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005679_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___006582_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_he488fa83__0)))))
                                                      : 
                                                     (0xb333U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006583_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005679_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___006582_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xdf2f20dU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0))))))))));
    vlSelf->__VdfgTmp_hc204a2d8__0 = ((4U & ((9U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___017194_))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017196_)));
    vlSelf->wasmetal_core__DOT___057697_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051533_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057695_))));
    vlSelf->wasmetal_core__DOT___036315_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017519_))));
    vlSelf->wasmetal_core__DOT___013209_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___051533_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___057693_ = (1U & (0xe0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                               >> 1U))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___013621_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___057689_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017519_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128791___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0))) 
                   << 3U)) | (IData)(wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0)) 
           ^ (((IData)(wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128791___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035873_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0)))) {
        vlSelf->wasmetal_core__DOT___035864_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d;
        vlSelf->wasmetal_core__DOT___035721_ = wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__;
    } else {
        vlSelf->wasmetal_core__DOT___035864_ = wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___035721_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d;
    }
    vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036951_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hfa042eae__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128777___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0)) 
                   << 3U)) | (IData)(wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0)) 
           ^ (((IData)(wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128777___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035729_)))));
    vlSelf->wasmetal_core__DOT___019795_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___072263_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___072262_))));
    vlSelf->wasmetal_core__DOT___039447_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128330___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039417_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128330___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039418_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128330___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039419_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128330___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039436_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128337___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039429_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128337___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039428_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128337___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039427_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128337___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039426_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128338___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___040089_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128338___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039420_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128338___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039416_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128338___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039425_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128339___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039424_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128339___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039423_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128339___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039422_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128339___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039430_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128340___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039431_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128340___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039432_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128340___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039438_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128340___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___040091_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128341___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039440_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128341___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039442_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128341___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039437_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128341___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___040090_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128342___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039433_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128342___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039421_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128342___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039443_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128342___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039441_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128343___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039439_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128343___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039435_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128343___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039434_ = (1U & (IData)(
                                                         (0xea2aea2aeaea2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128343___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___039534_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054038_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128378___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039476_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054042_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128378___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039487_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054046_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128378___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039865_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054050_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128378___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039489_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054054_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128385___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039491_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054058_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128385___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039483_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054062_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128385___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039864_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054066_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128385___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039478_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054070_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128386___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___039475_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054074_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128386___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039500_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054078_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128386___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039490_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054082_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128386___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039488_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054086_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128387___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039482_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054090_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128387___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039479_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054094_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128387___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039486_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054098_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128387___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039480_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054102_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128388___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039485_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054106_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128388___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039481_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054110_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128388___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039492_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054114_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128388___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039493_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054118_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128389___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039494_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054122_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128389___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039514_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054126_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128389___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039504_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054130_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128389___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039503_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054134_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128390___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039502_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054138_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128390___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039501_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054161_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128390___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039866_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054165_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128390___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039495_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054169_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128391___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039484_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054173_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128391___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039499_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054177_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128391___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039498_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054181_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128391___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___039497_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054185_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128392___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___039505_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054190_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128392___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b34__05d)))))))));
    vlSelf->wasmetal_core__DOT___039506_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054192_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128392___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___039507_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054194_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128393___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT___039528_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054196_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128393___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b37__05d)))))))));
    vlSelf->wasmetal_core__DOT___039518_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054198_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128393___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___039517_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054200_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128393___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___039516_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054202_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128379___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___039515_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054204_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128379___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___039867_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054206_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128379___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___039508_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054208_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128379___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b43__05d)))))))));
    vlSelf->wasmetal_core__DOT___039496_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054210_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128380___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___039513_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054212_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128380___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___039512_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054214_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128380___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___039511_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054216_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128380___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___039510_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054218_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128381___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___039519_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054220_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128381___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b49__05d)))))))));
    vlSelf->wasmetal_core__DOT___039520_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054222_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128381___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___039521_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054224_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128381___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT___039541_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054226_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128382___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT___039532_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054228_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128382___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___039531_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054230_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128382___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d)))))))));
    vlSelf->wasmetal_core__DOT___039530_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054232_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128382___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d)))))))));
    vlSelf->wasmetal_core__DOT___039529_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054234_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128383___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___039868_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054236_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128383___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d)))))))));
    vlSelf->wasmetal_core__DOT___039522_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054238_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128383___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d)))))))));
    vlSelf->wasmetal_core__DOT___039509_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054240_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128383___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___039527_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054242_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128384___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___039526_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054244_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128384___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d)))))))));
    vlSelf->wasmetal_core__DOT___039525_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054246_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128384___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d)))))))));
    vlSelf->wasmetal_core__DOT___039524_ = (1U & (IData)(
                                                         (0xea2aea2a2a2aeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054248_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128384___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072262_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___072263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b63__05d)))))))));
    vlSelf->wasmetal_core__DOT___053574_ = (1U & (IData)(
                                                         (0x8b8bff00bbbbff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053572_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___048489_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052841_)))))))));
    vlSelf->wasmetal_core__DOT___053489_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048489_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048488_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048486_)))))));
    vlSelf->__VdfgTmp_h1205819c__0 = (((IData)(wasmetal_core__DOT___048489_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009544_));
    vlSelf->wasmetal_core__DOT___007872_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009541_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___048489_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048488_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048487_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048486_)))))));
    vlSelf->wasmetal_core__DOT___005849_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127527___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb31c73a1__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h397c5a04__0)))));
    vlSelf->wasmetal_core__DOT___005783_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127527___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h444b75da__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h399a9b9d__0)))));
}
