#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__7(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__7\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___067639_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h46342433__0))));
    vlSelf->__VdfgTmp_h1f61adb3__0 = (((IData)(vlSelf->wasmetal_core__DOT___067376_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___067633_)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->wasmetal_core__DOT___067878_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc01ceff5__0))));
    vlSelf->__VdfgTmp_hdbe4c80a__0 = (((IData)(vlSelf->wasmetal_core__DOT___066741_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067874_)))));
    vlSelf->__VdfgTmp_h7b734092__0 = (((IData)(vlSelf->wasmetal_core__DOT___067232_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___067780_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->__VdfgTmp_h37cccaef__0 = ((2U & ((0xa3U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h799a13b5__0))) 
                                             << 1U)) 
                                      | (1U & (0xc5U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h90da4ee0__0)))));
    vlSelf->__VdfgTmp_h205cfcf2__0 = (((IData)(vlSelf->wasmetal_core__DOT___066574_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067781_)))));
    vlSelf->wasmetal_core__DOT___068001_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h066a303e__0))));
    vlSelf->wasmetal_core__DOT___066934_ = (1U & (IData)(
                                                         (0x4000cfff00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b23__05d) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066931_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xffff01ffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h38f5e1f6__0)))))))))));
    vlSelf->__VdfgTmp_he61b9416__0 = (((IData)(vlSelf->wasmetal_core__DOT___066931_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067996_)))));
    vlSelf->__VdfgTmp_hf4f03bfc__0 = (((IData)(vlSelf->wasmetal_core__DOT___067520_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((4U 
                                                                    >> 
                                                                    (2U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___067547_) 
                                                                          << 1U)) 
                                                                        << 1U))) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->__VdfgTmp_hbbe8c33f__0 = (((IData)(vlSelf->wasmetal_core__DOT___067419_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___067548_)) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->wasmetal_core__DOT___067425_ = (1U & (IData)(
                                                         (0xffffff4000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067421_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067420_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___067419_)))))))));
    vlSelf->__VdfgTmp_h4f29c7eb__0 = ((2U & ((0xa3U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_ha0f18469__0))) 
                                             << 1U)) 
                                      | (1U & (0xc5U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h94800df3__0)))));
    vlSelf->__VdfgTmp_he5ddd7d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___066826_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067928_)))));
    vlSelf->__VdfgTmp_h1f0809ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___067121_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___067692_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->__VdfgTmp_he8248827__0 = ((2U & ((0xa3U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_hd3e9f05a__0))) 
                                             << 1U)) 
                                      | (1U & (0xc5U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h321017d8__0)))));
    vlSelf->wasmetal_core__DOT___066513_ = (1U & (IData)(
                                                         (0xcccccccc5f000f0fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066351_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xacU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha9e0ea4b__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b18__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x4000cfffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b18__05d) 
                                                                              << 4U) 
                                                                             | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066498_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066497_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3616a991__0)))))))))));
    vlSelf->__VdfgTmp_h44e97a03__0 = (((IData)(vlSelf->wasmetal_core__DOT___066498_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067693_)))));
    vlSelf->wasmetal_core__DOT___067850_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd98b4743__0))));
    vlSelf->wasmetal_core__DOT___066704_ = (1U & (0x40ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066694_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066693_)))))));
    vlSelf->__VdfgTmp_h657da1af__0 = (((IData)(vlSelf->wasmetal_core__DOT___066693_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067847_)))));
    vlSelf->wasmetal_core__DOT___067290_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               >> 2U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067277_)))));
    vlSelf->__VdfgTmp_h33628a1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___067277_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___067549_)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->__VdfgTmp_hb4521a0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___067014_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___067550_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->wasmetal_core__DOT___069477_ = (1U & (IData)(
                                                         (0xf0a030f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b72__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_hf36de292__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h01abed45__0))))));
    vlSelf->__VdfgTmp_h220538c2__0 = ((2U & ((0xa3U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h01abed45__0))) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf36de292__0)))));
    vlSelf->wasmetal_core__DOT___069271_ = (1U & (IData)(
                                                         (0x20000000fcffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b64__05d) 
                                                            << 5U) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067552_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___064588_))))))));
    vlSelf->__VdfgTmp_h62827519__0 = (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___067552_));
    vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027829_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b6__05d));
    vlSelf->wasmetal_core__DOT___067629_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha5948160__0))));
    vlSelf->__VdfgTmp_h42ebc2c2__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hea3a75f9__0)) 
                                             << 1U)) 
                                      | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h1dd3182a__0))));
    vlSelf->__VdfgTmp_h91af3af4__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h9b0680c9__0)) 
                                             << 1U)) 
                                      | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_he6eb1d70__0))));
    vlSelf->__VdfgTmp_h51979f8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___065681_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___066428_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->__VdfgTmp_h0afb0546__0 = (((IData)(vlSelf->wasmetal_core__DOT___066059_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___066427_)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->wasmetal_core__DOT___067379_ = (1U & (0xb33U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb159a4d2__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b29__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h085758ad__0))))))));
    vlSelf->wasmetal_core__DOT___069935_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b93__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb159a4d2__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h085758ad__0)))))))));
    vlSelf->wasmetal_core__DOT___067870_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb19dabb4__0))));
    vlSelf->wasmetal_core__DOT___066744_ = (1U & (0xb33U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h96a0f125__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b21__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h96fdd1ca__0))))))));
    vlSelf->wasmetal_core__DOT___069768_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b85__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h96a0f125__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h96fdd1ca__0)))))))));
    vlSelf->wasmetal_core__DOT___067778_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf4606e0f__0))));
    vlSelf->wasmetal_core__DOT___066577_ = (1U & (0xb33U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hded1dcfc__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b19__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hec74e4aa__0))))))));
    vlSelf->wasmetal_core__DOT___069725_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b83__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hded1dcfc__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hec74e4aa__0)))))))));
    vlSelf->wasmetal_core__DOT___067235_ = (1U & (0xb33U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h729a2b0d__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b27__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he6a138a7__0))))))));
    vlSelf->__VdfgTmp_h9e5b6509__0 = (((IData)(vlSelf->wasmetal_core__DOT___065878_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___066562_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->wasmetal_core__DOT___069448_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf05030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b71__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc97edddd__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h55dc4d97__0)))))))));
    vlSelf->__VdfgTmp_h1fe62345__0 = ((4U & ((0x53U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_hc97edddd__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h55dc4d97__0));
    vlSelf->__VdfgTmp_hdda09bd4__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_had85000c__0)) 
                                             << 1U)) 
                                      | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h0160c9d2__0))));
    vlSelf->__VdfgTmp_he90c68e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___066255_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((4U 
                                                                    >> 
                                                                    (2U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___066359_) 
                                                                          << 1U)) 
                                                                        << 1U))) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->wasmetal_core__DOT___069214_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b63__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h8c50959a__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h009830e9__0)))))))));
    vlSelf->wasmetal_core__DOT___067523_ = (1U & (0xb33U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h8c50959a__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b31__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h009830e9__0))))))));
    vlSelf->wasmetal_core__DOT___067832_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h720d5baf__0))));
    vlSelf->wasmetal_core__DOT___069747_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b84__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h34d9c714__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hc1dcc953__0)))))))));
    vlSelf->wasmetal_core__DOT___068679_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b52__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h34d9c714__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hc1dcc953__0)))))))));
    vlSelf->wasmetal_core__DOT___069921_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069912_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h940ea061__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b92__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h892c3f8b__0))))))));
    vlSelf->wasmetal_core__DOT___066006_ = (1U & (0x100U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0x2a3f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065975_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[0U] 
                                                                              >> 0xaU)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0x40000000cfffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b12__05d) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h90496874__0)))))))))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xffffff8000000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065996_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___065995_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 1U)) 
                                                                             | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065994_)))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xffffff8000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___065986_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065985_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065984_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x5f3f0f0f00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                         << 5U) 
                                                                        | ((0x10U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                               << 4U)) 
                                                                           | ((8U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                              | ((4U 
                                                                                & ((IData)(
                                                                                (0x3fff20003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b12__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065964_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065963_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065962_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf0f0aaccU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065965_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065132_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065131_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065968_))))))))))))));
    vlSelf->__VdfgTmp_h134a2a5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___065994_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___066361_)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->wasmetal_core__DOT___069830_ = (1U & (IData)(
                                                         (0xdfff500000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b88__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6d71fd2__0))))))));
    vlSelf->__VdfgTmp_h13c22a42__0 = ((4U & ((0x53U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_hf103d5a5__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h07d01a7e__0));
    vlSelf->wasmetal_core__DOT___070000_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x20000000fcffffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b96__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                         << 3U)) 
                                                                     | ((8U 
                                                                         & ((4U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                            << 3U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h53aa4fbe__0))))))))));
    vlSelf->wasmetal_core__DOT___067573_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x20000000fcffffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b32__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                         << 3U)) 
                                                                     | ((8U 
                                                                         & ((8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                            << 3U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h53aa4fbe__0))))))))));
    vlSelf->wasmetal_core__DOT___066158_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066157_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066156_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066155_)))))))));
    vlSelf->__VdfgTmp_hf7e1e4a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___066156_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___066360_)) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->wasmetal_core__DOT___067925_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0ce087b0__0))));
    vlSelf->wasmetal_core__DOT___069789_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b86__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h72f36192__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h6b577092__0)))))))));
    vlSelf->wasmetal_core__DOT___068776_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b54__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h72f36192__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h6b577092__0)))))))));
    vlSelf->wasmetal_core__DOT___067126_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b26__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h5ea85090__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha458d092__0)))))))));
    vlSelf->__VdfgTmp_h95565af9__0 = (((IData)(vlSelf->wasmetal_core__DOT___065780_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___066485_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))))));
    vlSelf->wasmetal_core__DOT___067685_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4147928__0))));
    vlSelf->wasmetal_core__DOT___069703_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b82__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he200cacd__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf114f092__0)))))))));
    vlSelf->wasmetal_core__DOT___068579_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b50__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_he200cacd__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf114f092__0)))))))));
    vlSelf->wasmetal_core__DOT___065046_ = (1U & (IData)(
                                                         (0x153f151500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064996_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064995_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064994_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064993_)))))))));
    vlSelf->wasmetal_core__DOT___069303_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069285_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069284_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b65__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h729278ac__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8ba6f27a__0))))))))))))));
    vlSelf->wasmetal_core__DOT___067621_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8ba6f27a__0))));
    vlSelf->wasmetal_core__DOT___068538_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b49__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hbfa812aa__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h82d7bb11__0)))))))));
    vlSelf->wasmetal_core__DOT___070265_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070264_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hbfa812aa__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b113__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h82d7bb11__0)))))))))));
    vlSelf->wasmetal_core__DOT___067041_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b25__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067038_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___067037_)))))));
    vlSelf->wasmetal_core__DOT___068918_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068915_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068914_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b57__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h06351ce7__0))))))));
    vlSelf->wasmetal_core__DOT___070367_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070366_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068914_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b121__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h06351ce7__0))))))));
    vlSelf->wasmetal_core__DOT___068123_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b41__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7fac6026__0))))));
    vlSelf->wasmetal_core__DOT___070146_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b105__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7fac6026__0))))));
    vlSelf->wasmetal_core__DOT___065648_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b9__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065646_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065645_)))))));
    vlSelf->wasmetal_core__DOT___065280_ = (1U & (IData)(
                                                         (0x7f000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065266_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065265_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065264_)))))))));
    vlSelf->__VdfgTmp_h26de3b10__0 = (((IData)(vlSelf->wasmetal_core__DOT___065264_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___066722_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->wasmetal_core__DOT___066745_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066728_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hfef6b839__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b21__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4bfb58f6__0)))))))))));
    vlSelf->wasmetal_core__DOT___070315_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070314_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hfef6b839__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b117__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7592c2bc__0))))))));
    vlSelf->wasmetal_core__DOT___068722_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068719_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hfef6b839__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b53__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7592c2bc__0))))))));
    vlSelf->wasmetal_core__DOT___067380_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067364_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067363_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b29__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___067362_)))))))));
    vlSelf->wasmetal_core__DOT___070210_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070204_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068310_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b109__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068309_)))))))));
    vlSelf->wasmetal_core__DOT___068315_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b45__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___068310_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___068309_)))))));
    vlSelf->wasmetal_core__DOT___069596_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069586_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066019_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b77__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066018_)))))))));
    vlSelf->wasmetal_core__DOT___066021_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b13__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066019_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066018_)))))));
    vlSelf->wasmetal_core__DOT___070416_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070415_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b125__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0ae37f35__0))))))));
    vlSelf->wasmetal_core__DOT___069111_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069108_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b61__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0ae37f35__0))))))));
    vlSelf->wasmetal_core__DOT___069354_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069342_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069341_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b67__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2ca328d2__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07b43cae__0))))))))))))));
    vlSelf->__VdfgTmp_hba46d6b9__0 = ((4U & ((0x53U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h2ca328d2__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h07b43cae__0));
    vlSelf->wasmetal_core__DOT___066578_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066560_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8a2bba7d__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b19__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h285454e8__0)))))))))));
    vlSelf->wasmetal_core__DOT___070289_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070288_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8a2bba7d__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b115__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h90ebf68e__0))))))));
    vlSelf->wasmetal_core__DOT___068625_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068622_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8a2bba7d__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b51__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h90ebf68e__0))))))));
    vlSelf->wasmetal_core__DOT___069892_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069891_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067219_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b91__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h99c00636__0))))))));
    vlSelf->wasmetal_core__DOT___067236_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067220_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067219_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b27__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h99c00636__0))))))));
    vlSelf->wasmetal_core__DOT___069016_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069013_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069012_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b59__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca367735__0))))))));
    vlSelf->wasmetal_core__DOT___070391_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070390_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069012_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b123__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca367735__0))))))));
    vlSelf->wasmetal_core__DOT___068208_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b43__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h759c5442__0))))));
    vlSelf->wasmetal_core__DOT___070173_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b107__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h759c5442__0))))));
    vlSelf->wasmetal_core__DOT___065843_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b11__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065841_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065840_)))))));
    vlSelf->wasmetal_core__DOT___070339_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070338_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h312e660c__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b119__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h056e943f__0))))))));
    vlSelf->wasmetal_core__DOT___068822_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068819_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h312e660c__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b55__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h056e943f__0))))))));
    vlSelf->wasmetal_core__DOT___065472_ = (1U & (0x80ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065460_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065459_)))))));
    vlSelf->__VdfgTmp_h7e9d016d__0 = (((IData)(vlSelf->wasmetal_core__DOT___065459_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___066941_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->wasmetal_core__DOT___068446_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b47__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h007a378e__0))))));
    vlSelf->wasmetal_core__DOT___070234_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b111__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h007a378e__0))))));
    vlSelf->wasmetal_core__DOT___069975_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069974_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067507_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b95__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1c76f20b__0))))))));
    vlSelf->wasmetal_core__DOT___067524_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067508_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067507_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b31__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1c76f20b__0))))))));
    vlSelf->wasmetal_core__DOT___070441_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070440_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b127__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___069203_)))))))));
    vlSelf->wasmetal_core__DOT___069213_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b63__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069204_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069203_)))))));
    vlSelf->wasmetal_core__DOT___066219_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b15__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066217_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066216_)))))));
    vlSelf->wasmetal_core__DOT___066705_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066684_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h34d9c714__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b20__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc1dcc953__0)))))))))));
    vlSelf->wasmetal_core__DOT___070306_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070301_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h34d9c714__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b116__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc1dcc953__0)))))))))));
    vlSelf->wasmetal_core__DOT___069367_ = (1U & (0xf53fU 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8b2cdea2__0))));
    vlSelf->__VdfgTmp_h82ca3c22__0 = ((4U & ((0xfe7fffffU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                   << 4U) 
                                                  | ((0xcU 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                         << 2U)) 
                                                     | (3U 
                                                        & (~ 
                                                           (1U 
                                                            | (2U 
                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                                  << 1U)))))))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h8b2cdea2__0));
    vlSelf->wasmetal_core__DOT___067292_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067271_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h940ea061__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b28__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h892c3f8b__0))))))));
    vlSelf->wasmetal_core__DOT___070404_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070403_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h940ea061__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b124__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h18d94502__0))))))));
    vlSelf->wasmetal_core__DOT___069068_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069064_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h940ea061__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b60__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h18d94502__0))))))));
    vlSelf->wasmetal_core__DOT___070357_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x20000fff3ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b120__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h400b6e72__0)))))))));
    vlSelf->wasmetal_core__DOT___068873_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x20000fff3ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b56__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((8U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h400b6e72__0)))))))));
    vlSelf->wasmetal_core__DOT___070131_ = (1U & (IData)(
                                                         (0x2000000f3ffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b104__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h29064caf__0)))))));
    vlSelf->wasmetal_core__DOT___069661_ = (1U & (0x77070000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069657_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069656_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0xfU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069262_)))))));
    vlSelf->wasmetal_core__DOT___070252_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070249_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070248_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xeU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x2000000f3ffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b112__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha2b9b4b9__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___068498_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068495_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068494_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xeU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x2000000f3ffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b48__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha2b9b4b9__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___069999_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x2000000f3ffffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b96__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                         << 3U)) 
                                                                     | ((8U 
                                                                         & ((4U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                            << 3U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hf68b7cf3__0))))))))));
    vlSelf->wasmetal_core__DOT___067572_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x2000000f3ffffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b32__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                         << 3U)) 
                                                                     | ((8U 
                                                                         & ((8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                            << 3U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hf68b7cf3__0))))))))));
    vlSelf->wasmetal_core__DOT___069263_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x2000000f3ffffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b64__05d) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                         << 1U)) 
                                                                     | ((8U 
                                                                         & ((4U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 1U))) 
                                                                            << 3U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hf68b7cf3__0))))))))));
    vlSelf->wasmetal_core__DOT___069619_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069609_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066166_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b78__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066165_)))))))));
    vlSelf->wasmetal_core__DOT___070225_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070219_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068364_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b110__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068363_)))))))));
    vlSelf->wasmetal_core__DOT___068377_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b46__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___068364_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___068363_)))))));
    vlSelf->wasmetal_core__DOT___069954_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069953_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067409_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b94__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___067408_)))))))));
    vlSelf->wasmetal_core__DOT___069178_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069175_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069174_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b62__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h460c2b6b__0))))))));
    vlSelf->wasmetal_core__DOT___070428_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070427_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069174_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b126__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h460c2b6b__0))))))));
    vlSelf->wasmetal_core__DOT___065365_ = (1U & (IData)(
                                                         (0xffffff8000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065353_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065352_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065351_)))))))));
    vlSelf->__VdfgTmp_hdcdbebf8__0 = (((IData)(vlSelf->wasmetal_core__DOT___065351_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___066804_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O))))));
    vlSelf->wasmetal_core__DOT___070327_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070326_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha4f5f30b__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b118__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h97331d2b__0)))))))))));
    vlSelf->wasmetal_core__DOT___068775_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b54__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_ha4f5f30b__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h97331d2b__0)))))))));
    vlSelf->wasmetal_core__DOT___066819_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066812_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha4f5f30b__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h97331d2b__0)))))))))));
    vlSelf->wasmetal_core__DOT___069318_ = (1U & (0xac00000U 
                                                  >> 
                                                  ((0x1cU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0696502e__0))));
    vlSelf->__VdfgTmp_hb47a572e__0 = ((4U & ((0xf53fU 
                                              >> ((0xcU 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      << 2U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_hdfea75fb__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h0696502e__0));
    vlSelf->wasmetal_core__DOT___070277_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070276_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h02ac2502__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b114__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h23f4485c__0)))))))))));
    vlSelf->wasmetal_core__DOT___066491_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066483_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h02ac2502__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h23f4485c__0)))))))))));
    vlSelf->wasmetal_core__DOT___068578_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b50__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h02ac2502__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h23f4485c__0)))))))));
    vlSelf->wasmetal_core__DOT___068985_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068982_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068981_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b58__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5ef74162__0))))))));
    vlSelf->wasmetal_core__DOT___070379_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070378_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068981_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b122__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5ef74162__0))))))));
    vlSelf->wasmetal_core__DOT___069872_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069871_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b90__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___067106_)))))))));
    vlSelf->wasmetal_core__DOT___067127_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067110_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xdfc00000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b26__05d) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((8U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                              >> 2U))) 
                                                                         << 2U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067107_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___067106_)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0x1aU))))))));
    vlSelf->wasmetal_core__DOT___068181_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b42__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfabdc4bc__0))))));
    vlSelf->wasmetal_core__DOT___070160_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b106__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfabdc4bc__0))))));
    vlSelf->wasmetal_core__DOT___069516_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b74__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8c3c8979__0))))));
    vlSelf->wasmetal_core__DOT___065411_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b7__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128051___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___065187_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128051___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___065058_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128051___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___065301_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128051___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_x >> 8U) & (IData)(vlSelf->wasmetal_core__DOT___028184_));
    vlSelf->wasmetal_core__DOT____Vcellout___128042___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028116_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028113_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028102_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028091_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028084_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028116_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT___044760_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & vlSelf->function_locals) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                                        >> 1U)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 6U)))))))));
    vlSelf->wasmetal_core__DOT___044772_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_locals 
                                                                  >> 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 4U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 5U))))))))));
    vlSelf->wasmetal_core__DOT___044759_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_locals 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 3U)))))))));
    vlSelf->wasmetal_core__DOT___044771_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128315___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & vlSelf->function_locals) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__0__KET__ 
        = ((~ (vlSelf->function_params >> 8U)) & (IData)(vlSelf->wasmetal_core__DOT___030975_));
    vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032702_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d));
    vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037212_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h0d1b5516__0))));
    vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026385_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b6__05d));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b0__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054482_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128516___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b0__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054482_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128524___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b0__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054482_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128601___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b0__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054482_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02erow__05b1__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054484_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128516___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02erow__05b1__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054484_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128524___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02erow__05b1__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054484_) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128601___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02erow__05b1__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___054484_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054481_)))));
    vlSelf->wasmetal_core__DOT__value_aux__05b66__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052068_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h8fdf3668__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___004791_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h5f8f87da__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b88__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052087_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7762895e__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005087_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h8a29f22b__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b89__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052091_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h0352b565__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005359_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1c23d9bd__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b91__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052089_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h0e2ba734__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005019_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_he20a0bf9__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b50__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052439_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbe4c2cfb__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hccc0d080__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b52__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052118_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hcef8ef16__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h651ffab0__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b54__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052422_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h85029f86__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2e9416a5__0))))))));
    vlSelf->wasmetal_core__DOT___052640_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b64__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001817_))))));
    vlSelf->wasmetal_core__DOT___052745_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b72__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002525_))))));
    vlSelf->wasmetal_core__DOT___053131_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b80__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002047_))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b49__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052435_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h650b1858__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h39926e96__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b67__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052067_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc4d9060a__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___004717_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h6be40165__0)))))))))));
    vlSelf->wasmetal_core__DOT___062340_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b70__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001750_))))));
    vlSelf->wasmetal_core__DOT___052743_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b71__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002205_))))));
    vlSelf->wasmetal_core__DOT___052794_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b78__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002159_))))));
    vlSelf->wasmetal_core__DOT___053141_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b90__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002821_))))));
    vlSelf->wasmetal_core__DOT___052740_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b92__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002739_))))));
    vlSelf->wasmetal_core__DOT___053143_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b93__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002779_))))));
    vlSelf->wasmetal_core__DOT___053176_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b103__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002215_))))));
    vlSelf->wasmetal_core__DOT___053149_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b96__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001827_))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b32__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052414_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h1512c46f__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h0683198f__0))))))));
    vlSelf->wasmetal_core__DOT___052790_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b76__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002085_))))));
    vlSelf->wasmetal_core__DOT___053133_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b81__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002250_))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b56__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052164_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbc0682c2__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hec62ba82__0))))))));
    vlSelf->wasmetal_core__DOT___052792_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b77__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002122_))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b51__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052443_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6366d506__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf33ae1e8__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b53__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052123_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h397ad7fb__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc0a5660d__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b55__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052427_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h80bc039f__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc6c0965f__0))))))));
    vlSelf->wasmetal_core__DOT___052642_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b65__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001908_))))));
    vlSelf->wasmetal_core__DOT___052714_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b68__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001260_))))));
    vlSelf->wasmetal_core__DOT___053157_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b99__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002018_))))));
    vlSelf->wasmetal_core__DOT___053173_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b102__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001760_))))));
    vlSelf->wasmetal_core__DOT___053180_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b104__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002535_))))));
    vlSelf->wasmetal_core__DOT___053205_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b110__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002169_))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b73__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052077_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha5352532__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003605_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h24f58f01__0)))))))))));
    vlSelf->wasmetal_core__DOT___053203_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b108__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002095_))))));
    vlSelf->wasmetal_core__DOT___053201_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b109__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002132_))))));
    vlSelf->wasmetal_core__DOT___053234_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b116__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002333_))))));
    vlSelf->wasmetal_core__DOT___053242_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b120__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002670_))))));
    vlSelf->wasmetal_core__DOT___052716_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b69__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001685_))))));
    vlSelf->wasmetal_core__DOT___052788_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b75__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002362_))))));
    vlSelf->wasmetal_core__DOT___053151_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b97__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001918_))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b40__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052112_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb4397905__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h07a3b670__0))))))));
    vlSelf->wasmetal_core__DOT___053153_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b98__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001983_))))));
    vlSelf->wasmetal_core__DOT___053222_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b112__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002057_))))));
    vlSelf->wasmetal_core__DOT___053169_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b100__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001270_))))));
    vlSelf->wasmetal_core__DOT___052729_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b74__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002440_))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b105__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052342_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h14a07dbf__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hae654b01__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b123__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052279_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h0589a813__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h70f8ca0f__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b34__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052181_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf3a0142d__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h4cb51258__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b35__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052150_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb26c7187__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he2ad86dc__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b42__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052494_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc5f6f937__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h01d0ee79__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b44__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052261_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h807ad9d2__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h31a231e1__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b46__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052127_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc3ffba8a__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h21caabb4__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b12__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052201_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h17123258__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h56e67fc1__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b38__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052406_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc5320df5__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2b977022__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b43__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052498_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h456da093__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc1c0d33f__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b60__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052186_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h664f8c0a__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5ef7d401__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b83__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052071_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h587b33f1__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hdcdc0b33__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b13__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052251_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h63a71256__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_habe5487e__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b28__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052210_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7f8a4a6e__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd0875e26__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b37__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052501_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd6e95fa8__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd438e6c0__0))))))));
    vlSelf->wasmetal_core__DOT___053167_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b101__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001695_))))));
    vlSelf->wasmetal_core__DOT___053182_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b106__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002450_))))));
    vlSelf->wasmetal_core__DOT___062440_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b107__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002372_))))));
    vlSelf->wasmetal_core__DOT___053224_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b111__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002493_))))));
    vlSelf->wasmetal_core__DOT___053240_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b119__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002952_))))));
    vlSelf->wasmetal_core__DOT___053244_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b121__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002709_))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b57__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052173_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7def20ec__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hfbb7166b__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b59__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052481_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h56d0d6d1__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hdf96a80c__0))))))));
    vlSelf->wasmetal_core__DOT___053230_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b113__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002260_))))));
    vlSelf->wasmetal_core__DOT___053228_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b114__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002306_))))));
    vlSelf->wasmetal_core__DOT___053232_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b115__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001217_))))));
    vlSelf->wasmetal_core__DOT___053236_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b117__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002610_))))));
    vlSelf->wasmetal_core__DOT___053238_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b118__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002573_))))));
    vlSelf->wasmetal_core__DOT___053246_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b122__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002831_))))));
    vlSelf->wasmetal_core__DOT___053159_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b124__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002749_))))));
    vlSelf->wasmetal_core__DOT___053161_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b125__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002789_))))));
    vlSelf->wasmetal_core__DOT___053253_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b126__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002913_))))));
    vlSelf->wasmetal_core__DOT___053165_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b127__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003072_))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b7__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052545_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6fd66007__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h86663798__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b17__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h40e72268__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h152b96e8__0))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b18__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9975f0a8__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h4c7ff695__0))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b33__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052154_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h13262e9c__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h319b52f0__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b36__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052490_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h8fdaff69__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h50f5670e__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b45__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052196_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha87e62b8__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd35a9dc8__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b8__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052380_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he0f0059b__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h3b706e40__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b20__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hfbabec73__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h1dec8a5e__0))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b21__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hda033d4f__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h6effbe38__0))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b5__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052457_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h84bf9c8c__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc8d1ef5e__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b9__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052375_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hfc0ecf20__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h63bcab38__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b23__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052517_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha29002c9__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5d3f3876__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b61__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052146_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc60de2b1__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5085d456__0))))))));
    vlSelf->wasmetal_core__DOT___052798_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b79__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002483_))))));
    vlSelf->wasmetal_core__DOT___053135_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b82__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002296_))))));
    vlSelf->wasmetal_core__DOT___053137_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b84__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002343_))))));
    vlSelf->wasmetal_core__DOT___053139_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b86__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002583_))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b15__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052385_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he721caff__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h121dc976__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b30__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052220_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h95441b9a__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h38fef573__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b63__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052168_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6aba24e3__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h98b5e894__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b87__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052103_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h128bed99__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h106a7f5e__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b10__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052467_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd1ab5007__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h382fd4d9__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b11__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052472_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h42734187__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd416e14c__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b47__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052131_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h57e567b8__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9b219d07__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b39__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052410_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hce8a559f__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he0dafd81__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b58__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052486_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb19b1393__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h26403b1c__0))))))));
    vlSelf->wasmetal_core__DOT___053145_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b94__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002903_))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b14__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052393_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hfc69f4da__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcb57359d__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b16__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h7409986d__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hd259e3cd__0))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b41__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052135_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd28cbf2a__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he23a6b26__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b19__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052550_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he64a7376__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5d5da343__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b22__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052522_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h5b213075__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h3c70beb3__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b6__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052533_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hefb6870d__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc4ffb8dc__0))))))));
    vlSelf->wasmetal_core__DOT___062383_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b85__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002620_))))));
    vlSelf->wasmetal_core__DOT___053147_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b95__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003082_))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b29__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052215_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4279d3a2__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf146791e__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b26__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052512_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd5f7fb83__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hbb570836__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b62__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052159_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h81e66010__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2ee186c3__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b48__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052431_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf5ca71c3__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h58c7b8aa__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b25__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb1ddac1d__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hdc070dcf__0))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b24__05d 
        = (1U & (0xf0f3355U >> (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(
                                                        (0x3f303f300ff5555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                           << 5U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h27610e5d__0)))) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h329ed040__0))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b27__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052564_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4d1ee432__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h1a1b2f4c__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b3__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052241_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h156b8e5c__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h60503c86__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b2__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052246_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h261d1fb9__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc4c8e202__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b4__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052462_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h9b52bb5d__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h55f072d8__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b31__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052230_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h149fa621__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h7752095d__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b1__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052205_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6a684ffb__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he7820a50__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b0__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052540_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h173fc958__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he9245313__0))))))));
    vlSelf->wasmetal_core__DOT___007197_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053773_))));
    vlSelf->__VdfgTmp_hdc23a011__0 = (((IData)(vlSelf->wasmetal_core__DOT___070621_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___042683_));
    vlSelf->wasmetal_core__DOT___042595_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042590_))));
    vlSelf->wasmetal_core__DOT___062494_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053087_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062493_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052897_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052733_)))))));
    vlSelf->wasmetal_core__DOT___053354_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053353_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052853_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053087_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052905_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052733_)))))))));
    vlSelf->wasmetal_core__DOT___052908_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052907_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052733_))));
    vlSelf->wasmetal_core__DOT___053054_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 7U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 8U))))));
    vlSelf->wasmetal_core__DOT___053055_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 8U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 9U))))));
    vlSelf->wasmetal_core__DOT___053056_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0xbU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xcU))))));
    vlSelf->wasmetal_core__DOT___053057_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0xcU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xdU))))));
    vlSelf->wasmetal_core__DOT___053052_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 9U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xaU))))));
    vlSelf->wasmetal_core__DOT___053053_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0xaU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xbU))))));
    vlSelf->wasmetal_core__DOT___053050_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0xdU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xeU))))));
    vlSelf->wasmetal_core__DOT___053051_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0xeU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xfU))))));
    vlSelf->wasmetal_core__DOT___053049_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___053048_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___053046_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          << 1U)) 
                                                      | (1U 
                                                         & vlSelf->insn_x)))));
    vlSelf->wasmetal_core__DOT___053047_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & vlSelf->insn_z) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___053021_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 4U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 5U))))));
    vlSelf->wasmetal_core__DOT___053023_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 3U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 4U))))));
    vlSelf->wasmetal_core__DOT___052734_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 5U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 6U))))));
    vlSelf->wasmetal_core__DOT___052735_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 6U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 7U))))));
    vlSelf->wasmetal_core__DOT___053024_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x14U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x15U))))));
    vlSelf->wasmetal_core__DOT___053025_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x18U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___053026_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x13U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x14U))))));
    vlSelf->wasmetal_core__DOT___053028_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x1aU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x1bU))))));
    vlSelf->wasmetal_core__DOT___053029_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x15U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x16U))))));
    vlSelf->wasmetal_core__DOT___053030_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x10U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x11U))))));
    vlSelf->wasmetal_core__DOT___053031_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x1bU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x1cU))))));
    vlSelf->wasmetal_core__DOT___053032_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x1cU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x1dU))))));
    vlSelf->wasmetal_core__DOT___053033_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0xfU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x10U))))));
    vlSelf->wasmetal_core__DOT___053034_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x11U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x12U))))));
    vlSelf->wasmetal_core__DOT___053035_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x12U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x13U))))));
    vlSelf->wasmetal_core__DOT___053036_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x17U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x18U))))));
    vlSelf->wasmetal_core__DOT___053037_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x1dU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x1eU))))));
    vlSelf->wasmetal_core__DOT___053027_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_z 
                                                          >> 0x1eU)) 
                                                      | (vlSelf->insn_x 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___048395_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048390_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048389_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x1000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___048374_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___048373_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048372_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048371_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048370_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048369_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x1ff00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048380_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048379_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048378_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048377_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048376_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((0x1fU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048382_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048381_)))) 
                                                                  & (IData)(
                                                                            (1ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007036_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007035_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007032_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007031_))))))))))))))));
    vlSelf->wasmetal_core__DOT___048394_ = (1U & (IData)(
                                                         (0x7000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048355_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048354_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048353_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048352_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048351_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000354_)))))))));
    vlSelf->wasmetal_core__DOT___007203_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048422_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007055_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3900e5db__0))))))));
    vlSelf->wasmetal_core__DOT___007205_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048422_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007055_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3900e5db__0))))));
    vlSelf->wasmetal_core__DOT___045197_ = ((IData)(vlSelf->wasmetal_core__DOT___045243_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045242_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045240_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045239_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045238_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045237_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045236_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045235_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045234_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045233_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___045232_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___045231_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___045251_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___045250_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___045249_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___045248_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___045247_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___045246_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___045245_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___045244_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___045241_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___045230_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___045206_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___045217_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___045220_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___045221_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___045222_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___045223_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___045224_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___045225_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___045226_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___045227_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___045207_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___045208_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045209_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045210_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045211_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045212_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045213_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045214_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045215_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045216_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045218_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045219_));
    vlSelf->wasmetal_core__DOT___044925_ = ((IData)(vlSelf->wasmetal_core__DOT___044971_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___044970_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___044968_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044967_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044966_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044965_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044964_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044963_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044962_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044961_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044960_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___044959_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___044979_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___044978_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___044977_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___044976_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___044975_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___044974_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___044973_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___044972_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___044969_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___044958_)) 
                                                                    & (IData)(vlSelf->wasmetal_core__DOT___044934_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___044945_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___044948_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___044949_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___044950_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___044951_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___044952_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___044953_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___044954_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___044955_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___044935_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___044936_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044937_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044938_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044939_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044940_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044941_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044942_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044943_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044944_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044946_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044947_));
    vlSelf->wasmetal_core__DOT___063367_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053263_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052883_)))));
    vlSelf->wasmetal_core__DOT___044396_ = ((IData)(vlSelf->wasmetal_core__DOT___044442_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___044441_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___044439_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044438_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044437_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044436_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044435_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044434_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044433_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044432_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044431_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___044430_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___044450_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___044449_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___044448_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___044447_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___044446_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___044445_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___044444_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___044443_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___044440_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___044429_) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___044405_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___044416_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___044419_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___044420_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___044421_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___044422_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___044423_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___044424_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___044425_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___044426_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___044406_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___044407_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044408_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044409_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044410_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044411_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044412_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044413_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044414_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044415_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044417_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044418_));
    vlSelf->wasmetal_core__DOT___052804_ = (1U & (0xeU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___034488_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___034489_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052801_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034477_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034492_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034499_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034498_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034479_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___034478_)))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (0x80000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034493_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034494_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034495_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x80000000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034476_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034483_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034482_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha80d5d1f__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034507_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034497_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034506_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034496_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034500_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___034501_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x8000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___034484_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034491_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___034485_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___034490_))))))))))))))))))))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052802_))));
    vlSelf->wasmetal_core__DOT___070024_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->insn_imm[3U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053485_))));
    vlSelf->wasmetal_core__DOT___069273_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & vlSelf->insn_y)))))))));
    vlSelf->wasmetal_core__DOT___069331_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___069430_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 1U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 6U))))))))));
    vlSelf->wasmetal_core__DOT___069464_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 7U))))))))));
    vlSelf->wasmetal_core__DOT___069484_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 5U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 8U))))))))));
    vlSelf->wasmetal_core__DOT___069575_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 7U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 9U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0xcU))))))))));
    vlSelf->wasmetal_core__DOT___069620_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 9U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0xbU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0xeU))))))))));
    vlSelf->wasmetal_core__DOT___069666_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0xbU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x10U))))))))));
    vlSelf->wasmetal_core__DOT___069688_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0xcU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0xeU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x11U))))))))));
    vlSelf->wasmetal_core__DOT___069840_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0x13U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x15U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x18U))))))))));
    vlSelf->wasmetal_core__DOT___069861_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0x14U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x19U))))))))));
    vlSelf->wasmetal_core__DOT___069881_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0x15U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x17U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x1aU))))))))));
    vlSelf->wasmetal_core__DOT___069902_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0x16U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x18U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x1bU))))))))));
    vlSelf->wasmetal_core__DOT___069922_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0x17U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x19U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x1cU))))))))));
    vlSelf->wasmetal_core__DOT___069943_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               >> 0x18U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0x1dU))))))))));
    vlSelf->wasmetal_core__DOT___067606_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054182_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___069304_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___069355_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & vlSelf->insn_x) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___069380_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_imm[2U] 
                                                               << 1U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 4U))))))))));
    vlSelf->wasmetal_core__DOT___068605_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b50__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054221_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x11U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068655_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b51__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054223_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x12U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068703_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b52__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x13U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068752_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b53__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054227_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x14U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068796_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b54__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x15U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068851_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b55__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x16U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068898_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b56__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054233_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x17U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___067724_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___067657_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & vlSelf->insn_imm[1U]) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068942_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b57__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x18U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___069040_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b59__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054239_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1aU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___069090_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b60__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1bU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___069139_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b61__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1cU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___068968_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b58__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x19U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___069232_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b63__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1eU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___069158_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b62__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054245_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[1U] 
                                                                           >> 0x1dU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))))));
    vlSelf->wasmetal_core__DOT___053488_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052899_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053485_))));
    vlSelf->wasmetal_core__DOT___063789_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053990_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[0U] 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))))))));
    vlSelf->__VdfgTmp_hc55be417__0 = (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h652beeee__0));
    vlSelf->wasmetal_core__DOT___050941_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b20__05d))));
    vlSelf->wasmetal_core__DOT___063414_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053567_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3eb9c9bf__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9c6bfb0c__0))))))));
    vlSelf->wasmetal_core__DOT___048486_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & ((~ (IData)(
                                                          (0x8000000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___048476_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___048474_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048473_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048472_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___048471_))))))))) 
                                               | (IData)(
                                                         (0x7fffffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007043_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007042_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048452_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048451_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x100U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048446_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048305_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048270_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048324_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019280_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007190_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x80U 
                                                                            >> 
                                                                            ((4U 
                                                                              & (((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                                                | (IData)(
                                                                                (0x55557f7fffffc0ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & (vlSelf->insn_op 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_op 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & vlSelf->insn_op) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___000375_)))))))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___048458_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048456_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048455_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048454_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048469_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048468_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048467_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048466_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048465_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048464_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___070044_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063450_))));
    vlSelf->wasmetal_core__DOT___066983_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061519_))));
    vlSelf->wasmetal_core__DOT___061584_ = (1U & (0xffefefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061519_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048434_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048448_)))))));
    vlSelf->wasmetal_core__DOT___061553_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061519_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___061536_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061519_))));
    vlSelf->wasmetal_core__DOT___061527_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061519_))));
    vlSelf->wasmetal_core__DOT___061522_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061519_))));
    vlSelf->__VdfgTmp_h824f53a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___064477_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->__VdfgTmp_hb4cc7c9a__0 = (((IData)(vlSelf->wasmetal_core__DOT___060719_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___060718_));
    vlSelf->wasmetal_core__DOT___055315_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052732_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055312_))));
    vlSelf->__VdfgTmp_h648a31a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010378_));
    vlSelf->wasmetal_core__DOT___056601_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009691_))));
    vlSelf->wasmetal_core__DOT___009693_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053780_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053767_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053766_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054671_))))));
    vlSelf->wasmetal_core__DOT___010092_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007193_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007192_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054671_)))));
    vlSelf->__VdfgTmp_ha091cfd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063859_));
    vlSelf->wasmetal_core__DOT___066407_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066282_))));
    vlSelf->wasmetal_core__DOT___056541_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011740_))));
    vlSelf->wasmetal_core__DOT___008974_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___033033_))));
    vlSelf->wasmetal_core__DOT___008810_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___033033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009653_))));
    vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hb2eda61f__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h47317805__0))));
    if (vlSelf->wasmetal_core__DOT___000418_) {
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d 
            = vlSelf->wasmetal_core__DOT___001875_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d 
            = vlSelf->wasmetal_core__DOT___001887_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d 
            = vlSelf->wasmetal_core__DOT___001438_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d 
            = vlSelf->wasmetal_core__DOT___001444_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d 
            = vlSelf->wasmetal_core__DOT___001476_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d 
            = vlSelf->wasmetal_core__DOT___001488_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d 
            = vlSelf->wasmetal_core__DOT___001370_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d 
            = vlSelf->wasmetal_core__DOT___001382_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d 
            = vlSelf->wasmetal_core__DOT___001414_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d 
            = vlSelf->wasmetal_core__DOT___001426_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d 
            = vlSelf->wasmetal_core__DOT___001525_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d 
            = vlSelf->wasmetal_core__DOT___001537_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d 
            = vlSelf->wasmetal_core__DOT___001569_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d 
            = vlSelf->wasmetal_core__DOT___001581_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d 
            = vlSelf->wasmetal_core__DOT___001625_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d 
            = vlSelf->wasmetal_core__DOT___001647_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d 
            = vlSelf->wasmetal_core__DOT___000420_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d 
            = vlSelf->wasmetal_core__DOT___000433_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d 
            = vlSelf->wasmetal_core__DOT___000465_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d 
            = vlSelf->wasmetal_core__DOT___000477_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d 
            = vlSelf->wasmetal_core__DOT___000499_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d 
            = vlSelf->wasmetal_core__DOT___000521_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d 
            = vlSelf->wasmetal_core__DOT___000543_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d 
            = vlSelf->wasmetal_core__DOT___000565_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d 
            = vlSelf->wasmetal_core__DOT___000592_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d 
            = vlSelf->wasmetal_core__DOT___000614_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d 
            = vlSelf->wasmetal_core__DOT___000636_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d 
            = vlSelf->wasmetal_core__DOT___000658_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d 
            = vlSelf->wasmetal_core__DOT___000926_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d 
            = vlSelf->wasmetal_core__DOT___001169_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d 
            = vlSelf->wasmetal_core__DOT___000981_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d 
            = vlSelf->wasmetal_core__DOT___000993_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d 
            = vlSelf->wasmetal_core__DOT___001015_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d 
            = vlSelf->wasmetal_core__DOT___001037_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d 
            = vlSelf->wasmetal_core__DOT___001059_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d 
            = vlSelf->wasmetal_core__DOT___001081_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d 
            = vlSelf->wasmetal_core__DOT___001103_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d 
            = vlSelf->wasmetal_core__DOT___001125_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d 
            = vlSelf->wasmetal_core__DOT___001147_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d 
            = vlSelf->wasmetal_core__DOT___001613_;
    } else {
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d 
            = vlSelf->wasmetal_core__DOT___001874_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d 
            = vlSelf->wasmetal_core__DOT___001886_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d 
            = vlSelf->wasmetal_core__DOT___001437_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d 
            = vlSelf->wasmetal_core__DOT___001443_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d 
            = vlSelf->wasmetal_core__DOT___001475_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d 
            = vlSelf->wasmetal_core__DOT___001487_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d 
            = vlSelf->wasmetal_core__DOT___001369_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d 
            = vlSelf->wasmetal_core__DOT___001381_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d 
            = vlSelf->wasmetal_core__DOT___001413_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d 
            = vlSelf->wasmetal_core__DOT___001425_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d 
            = vlSelf->wasmetal_core__DOT___001524_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d 
            = vlSelf->wasmetal_core__DOT___001536_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d 
            = vlSelf->wasmetal_core__DOT___001568_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d 
            = vlSelf->wasmetal_core__DOT___001580_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d 
            = vlSelf->wasmetal_core__DOT___001624_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d 
            = vlSelf->wasmetal_core__DOT___001646_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d 
            = vlSelf->wasmetal_core__DOT___000419_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d 
            = vlSelf->wasmetal_core__DOT___000432_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d 
            = vlSelf->wasmetal_core__DOT___000464_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d 
            = vlSelf->wasmetal_core__DOT___000476_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d 
            = vlSelf->wasmetal_core__DOT___000498_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d 
            = vlSelf->wasmetal_core__DOT___000520_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d 
            = vlSelf->wasmetal_core__DOT___000542_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d 
            = vlSelf->wasmetal_core__DOT___000564_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d 
            = vlSelf->wasmetal_core__DOT___000591_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d 
            = vlSelf->wasmetal_core__DOT___000613_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d 
            = vlSelf->wasmetal_core__DOT___000635_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d 
            = vlSelf->wasmetal_core__DOT___000657_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d 
            = vlSelf->wasmetal_core__DOT___001327_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d 
            = vlSelf->wasmetal_core__DOT___001168_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d 
            = vlSelf->wasmetal_core__DOT___000980_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d 
            = vlSelf->wasmetal_core__DOT___000992_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d 
            = vlSelf->wasmetal_core__DOT___001014_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d 
            = vlSelf->wasmetal_core__DOT___001036_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d 
            = vlSelf->wasmetal_core__DOT___001058_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d 
            = vlSelf->wasmetal_core__DOT___001080_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d 
            = vlSelf->wasmetal_core__DOT___001102_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d 
            = vlSelf->wasmetal_core__DOT___001124_;
        vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d 
            = vlSelf->wasmetal_core__DOT___001146_;
        vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d 
            = vlSelf->wasmetal_core__DOT___001612_;
    }
    vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hc231438f__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h132c3402__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hac359f24__0))));
    vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h8696f73b__0))));
    vlSelf->wasmetal_core__DOT___000666_ = (1U & (0xb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044819_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048286_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048285_)))))));
    vlSelf->wasmetal_core__DOT___048431_ = (1U & (0x40ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044819_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048286_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048429_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048285_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf8000000U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048426_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048425_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h9fdaf630__0))))))))))));
    vlSelf->wasmetal_core__DOT___063364_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050435_))));
    vlSelf->wasmetal_core__DOT___053018_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053015_))));
    vlSelf->wasmetal_core__DOT___063448_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063446_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062498_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052902_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050366_))))));
    vlSelf->wasmetal_core__DOT___053272_ = (1U & (IData)(
                                                         (0x1010000101000ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053271_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0x80000000U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___047790_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___047792_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0x1fff0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___047964_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x4000U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___047786_)))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x1f00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053264_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003010_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047954_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x4000U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048328_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1fff000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___002978_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053266_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x4000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___047783_)))))))))))))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                                        >> 2U)) 
                                                                    | (1U 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O)))))))));
    vlSelf->wasmetal_core__DOT___001811_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048797_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048796_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048794_)))))))));
    vlSelf->wasmetal_core__DOT___001810_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d))))));
    vlSelf->wasmetal_core__DOT___001902_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048808_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048807_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048805_)))))))));
    vlSelf->wasmetal_core__DOT___001901_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d))))));
    vlSelf->wasmetal_core__DOT___001951_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048800_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004783_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___001950_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d))))));
    vlSelf->wasmetal_core__DOT___001996_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048803_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004709_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004727_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___001995_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d))))));
    vlSelf->wasmetal_core__DOT___001254_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048878_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048877_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048875_)))))))));
    vlSelf->wasmetal_core__DOT___001253_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d))))));
    vlSelf->wasmetal_core__DOT___001679_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048885_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048883_)))))))));
    vlSelf->wasmetal_core__DOT___001678_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d))))));
    vlSelf->wasmetal_core__DOT___001744_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048893_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048892_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048890_)))))))));
    vlSelf->wasmetal_core__DOT___001743_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d))))));
    vlSelf->wasmetal_core__DOT___002199_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048753_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048752_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048750_)))))))));
    vlSelf->wasmetal_core__DOT___002198_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d))))));
    vlSelf->wasmetal_core__DOT___002519_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048740_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048739_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048737_)))))))));
    vlSelf->wasmetal_core__DOT___002518_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d))))));
    vlSelf->wasmetal_core__DOT___002396_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048768_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048767_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048765_)))))))));
    vlSelf->wasmetal_core__DOT___002395_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d))))));
    vlSelf->wasmetal_core__DOT___002924_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048840_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005147_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc2efa860__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3378cabf__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___002925_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d))))));
    vlSelf->wasmetal_core__DOT___002642_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048865_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005079_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8aa65d09__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h139d3776__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___002643_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d))))));
    vlSelf->wasmetal_core__DOT___002681_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048845_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005351_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h339d407e__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___002682_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d))))));
    vlSelf->wasmetal_core__DOT___002434_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048783_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048782_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048780_)))))))));
    vlSelf->wasmetal_core__DOT___002433_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d))))));
    vlSelf->wasmetal_core__DOT___002800_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004943_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4403b5cc__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h56116db4__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___002801_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d))))));
    vlSelf->wasmetal_core__DOT___002842_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048868_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005011_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2d637bc4__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___002843_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d))))));
    vlSelf->wasmetal_core__DOT___002356_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048776_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048775_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048773_)))))))));
    vlSelf->wasmetal_core__DOT___002355_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d))))));
    vlSelf->wasmetal_core__DOT___002720_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048855_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004875_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1bd58642__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___002721_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d))))));
    vlSelf->wasmetal_core__DOT___002760_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048848_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb73e868c__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___002761_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d))))));
    vlSelf->wasmetal_core__DOT___003055_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048926_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005581_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h67e9fb36__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8696f73b__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___003056_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d))))));
    vlSelf->wasmetal_core__DOT___002884_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048873_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005215_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb1867682__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h46733dea__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___002885_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d))))));
    vlSelf->wasmetal_core__DOT___002079_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048836_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048834_)))))))));
    vlSelf->wasmetal_core__DOT___002078_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d))))));
    vlSelf->wasmetal_core__DOT___048908_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))))))));
    vlSelf->wasmetal_core__DOT___048910_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0))))))));
    vlSelf->wasmetal_core__DOT___048916_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___048913_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d)))))));
    vlSelf->wasmetal_core__DOT___002116_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048813_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048812_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048810_)))))))));
    vlSelf->wasmetal_core__DOT___002115_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d))))));
    vlSelf->wasmetal_core__DOT___047800_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003097_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))))))));
    vlSelf->wasmetal_core__DOT___048906_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT___047809_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))))))));
    vlSelf->wasmetal_core__DOT___048907_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___002153_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048826_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048825_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048823_)))))))));
    vlSelf->wasmetal_core__DOT___002152_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d))))));
    vlSelf->wasmetal_core__DOT___047827_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))))))));
    vlSelf->wasmetal_core__DOT___048912_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d)))))));
    vlSelf->wasmetal_core__DOT___047819_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))))))));
    vlSelf->wasmetal_core__DOT___048905_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d)))))));
    vlSelf->wasmetal_core__DOT___047879_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003109_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc231438f__0))))))));
    vlSelf->wasmetal_core__DOT___048896_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___002477_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048733_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048732_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048731_)))))))));
    vlSelf->wasmetal_core__DOT___002479_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d))))));
    vlSelf->wasmetal_core__DOT___047887_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))))))));
    vlSelf->wasmetal_core__DOT___048895_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d)))))));
    vlSelf->wasmetal_core__DOT___047905_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003105_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))))))));
    vlSelf->wasmetal_core__DOT___048897_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d)))))));
    vlSelf->wasmetal_core__DOT___002041_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048821_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048820_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048818_)))))))));
    vlSelf->wasmetal_core__DOT___002040_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d))))));
    vlSelf->wasmetal_core__DOT___047897_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))))))));
    vlSelf->wasmetal_core__DOT___048894_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___002244_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048760_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048757_)))))))));
    vlSelf->wasmetal_core__DOT___002243_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d))))));
    vlSelf->wasmetal_core__DOT___047847_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))))))));
    vlSelf->wasmetal_core__DOT___048899_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d)))))));
    vlSelf->wasmetal_core__DOT___047839_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))))))));
    vlSelf->wasmetal_core__DOT___048904_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d)))))));
    vlSelf->wasmetal_core__DOT___002281_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048763_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004043_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h22b2afd4__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___002280_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d))))));
    vlSelf->wasmetal_core__DOT___047857_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h132c3402__0))))))));
    vlSelf->wasmetal_core__DOT___048901_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___047867_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047862_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___047861_))))));
    vlSelf->wasmetal_core__DOT___048898_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d)))))));
    vlSelf->wasmetal_core__DOT___047941_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))))))));
    vlSelf->wasmetal_core__DOT___048918_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d)))))));
    vlSelf->wasmetal_core__DOT___000156_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048881_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003827_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003845_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___000155_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d))))));
    vlSelf->wasmetal_core__DOT___047933_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))))))));
    vlSelf->wasmetal_core__DOT___048921_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT___048902_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT___048919_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d)))))));
    vlSelf->wasmetal_core__DOT___002317_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048748_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h63a6348e__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___002318_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d))))));
}
