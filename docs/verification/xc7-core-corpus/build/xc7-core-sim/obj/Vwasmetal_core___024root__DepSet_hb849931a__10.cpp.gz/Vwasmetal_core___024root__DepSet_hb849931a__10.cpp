#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__16(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__16\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___019277_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055864_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055863_))))));
    vlSelf->wasmetal_core__DOT___055992_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055990_))));
    vlSelf->wasmetal_core__DOT___019240_ = (1U & (IData)(
                                                         (0xf000000eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060712_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h12bbe12d__0))))));
    vlSelf->wasmetal_core__DOT___055997_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h12bbe12d__0))));
    vlSelf->wasmetal_core__DOT___054966_ = (1U & (0xeeeefff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054947_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054940_))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___054943_))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___054942_))))))))));
    vlSelf->wasmetal_core__DOT___055031_ = (1U & (0xeeeefff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055026_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055019_))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___055022_))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___055021_))))))))));
    vlSelf->wasmetal_core__DOT___011103_ = (1U & (0xff4f4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5aecec62__0)))));
    vlSelf->wasmetal_core__DOT___010084_ = (1U & (0xff4f4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5aecec62__0)))));
    vlSelf->wasmetal_core__DOT___010085_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001437_)))));
    vlSelf->__VdfgTmp_hfa759b39__0 = (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010722_));
    vlSelf->wasmetal_core__DOT___010396_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001886_)))));
    vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034178_) 
           | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d));
    vlSelf->wasmetal_core__DOT___010395_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001874_)))));
    vlSelf->wasmetal_core__DOT___010182_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___010530_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056274_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___010124_ = (1U & (0xfbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056274_))))));
    vlSelf->wasmetal_core__DOT___007693_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053782_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_op 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008495_)))));
    vlSelf->wasmetal_core__DOT___010101_ = (1U & (0xf004444U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053782_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___008495_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___008500_)))))));
    vlSelf->wasmetal_core__DOT___007235_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053782_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008500_)))));
    vlSelf->wasmetal_core__DOT___007234_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053782_))));
    vlSelf->wasmetal_core__DOT___007204_ = ((IData)(vlSelf->wasmetal_core__DOT___007208_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___007197_)) 
                                               | (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007196_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007207_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007193_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007192_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007191_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007195_))))))))));
    vlSelf->wasmetal_core__DOT___063864_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048372_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063835_))));
    vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030115_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d));
    vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030243_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d));
    vlSelf->wasmetal_core__DOT___064904_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064903_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001886_))));
    vlSelf->wasmetal_core__DOT___065622_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063834_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065621_)))));
    vlSelf->wasmetal_core__DOT___063968_ = (1U & (IData)(
                                                         (0x40007fffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048304_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063967_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___042174_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___042173_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___042177_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063965_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048368_)))))))));
    vlSelf->wasmetal_core__DOT___065710_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064478_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065709_)))));
    vlSelf->wasmetal_core__DOT___065812_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064741_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065811_)))));
    vlSelf->wasmetal_core__DOT___065908_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064903_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065907_)))));
    vlSelf->wasmetal_core__DOT___065932_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065076_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065931_)))));
    vlSelf->wasmetal_core__DOT___066077_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065201_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066076_)))));
    vlSelf->wasmetal_core__DOT___066134_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065309_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066133_)))));
    vlSelf->wasmetal_core__DOT___066269_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065426_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066268_)))));
    vlSelf->__VdfgTmp_h826c8569__0 = ((4U & ((0xe8U 
                                              >> (IData)(vlSelf->__VdfgTmp_h4ea6bbba__0)) 
                                             << 2U)) 
                                      | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h563f0a85__0)) 
                                                << 1U)) 
                                         | (1U & (0x2bU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h21594217__0)))));
    vlSelf->__VdfgTmp_h2a821aa8__0 = ((4U & ((0x69U 
                                              >> (IData)(vlSelf->__VdfgTmp_h4598addd__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x69U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h21594217__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_ha753d377__0)))));
    vlSelf->__VdfgTmp_h4720a72d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h0033f05e__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha753d377__0)))));
    vlSelf->wasmetal_core__DOT___064911_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h00f9b844__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063880_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbbb75ece__0)))));
    if (vlSelf->wasmetal_core__DOT___042095_) {
        vlSelf->wasmetal_core__DOT___042284_ = vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042307_ = vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042072_ = vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042106_ = vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042403_ = vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042391_ = vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042224_ = vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042212_ = vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__;
    } else {
        vlSelf->wasmetal_core__DOT___042284_ = vlSelf->wasmetal_core__DOT___042295_;
        vlSelf->wasmetal_core__DOT___042307_ = vlSelf->wasmetal_core__DOT___042317_;
        vlSelf->wasmetal_core__DOT___042072_ = vlSelf->wasmetal_core__DOT___042083_;
        vlSelf->wasmetal_core__DOT___042106_ = vlSelf->wasmetal_core__DOT___042116_;
        vlSelf->wasmetal_core__DOT___042403_ = vlSelf->wasmetal_core__DOT___042317_;
        vlSelf->wasmetal_core__DOT___042391_ = vlSelf->wasmetal_core__DOT___042295_;
        vlSelf->wasmetal_core__DOT___042224_ = vlSelf->wasmetal_core__DOT___042116_;
        vlSelf->wasmetal_core__DOT___042212_ = vlSelf->wasmetal_core__DOT___042083_;
    }
    if (vlSelf->wasmetal_core__DOT___042177_) {
        vlSelf->wasmetal_core__DOT___042427_ = vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042451_ = vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042131_ = vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042199_ = vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042248_ = vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042272_ = vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042378_ = vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042332_ = vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__;
    } else {
        vlSelf->wasmetal_core__DOT___042427_ = vlSelf->wasmetal_core__DOT___042354_;
        vlSelf->wasmetal_core__DOT___042451_ = vlSelf->wasmetal_core__DOT___042387_;
        vlSelf->wasmetal_core__DOT___042131_ = vlSelf->wasmetal_core__DOT___042153_;
        vlSelf->wasmetal_core__DOT___042199_ = vlSelf->wasmetal_core__DOT___042208_;
        vlSelf->wasmetal_core__DOT___042248_ = vlSelf->wasmetal_core__DOT___042153_;
        vlSelf->wasmetal_core__DOT___042272_ = vlSelf->wasmetal_core__DOT___042208_;
        vlSelf->wasmetal_core__DOT___042378_ = vlSelf->wasmetal_core__DOT___042387_;
        vlSelf->wasmetal_core__DOT___042332_ = vlSelf->wasmetal_core__DOT___042354_;
    }
    vlSelf->wasmetal_core__DOT___001899_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xfff0ffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001935_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001934_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & (((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                                                ? 
                                                                               (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001724_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001723_)))))
                                                                                : 
                                                                               (0xecU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000666_)
                                                                                 ? (IData)(
                                                                                (0xf0055003300ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003269_))))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001937_)))))) 
                                                                              << 1U)) 
                                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                             & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001730_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001729_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001726_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001725_))))))))))))))))));
    if (vlSelf->wasmetal_core__DOT___000170_) {
        if (vlSelf->wasmetal_core__DOT___000169_) {
            vlSelf->wasmetal_core__DOT___002593_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hd61aa5bc__0))));
            vlSelf->wasmetal_core__DOT___002316_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hb54a817c__0))));
            vlSelf->wasmetal_core__DOT___002641_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hc6bfb5bb__0))));
            vlSelf->wasmetal_core__DOT___002923_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h7357dd51__0))));
            vlSelf->wasmetal_core__DOT___002680_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h95b0aa6a__0))));
            vlSelf->wasmetal_core__DOT___002841_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_he2ba16db__0))));
        } else {
            vlSelf->wasmetal_core__DOT___002593_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001721_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___001720_)))));
            vlSelf->wasmetal_core__DOT___002316_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001337_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___001336_)))));
            vlSelf->wasmetal_core__DOT___002641_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002650_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___002649_)))));
            vlSelf->wasmetal_core__DOT___002923_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002932_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___002931_)))));
            vlSelf->wasmetal_core__DOT___002680_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002689_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___002688_)))));
            vlSelf->wasmetal_core__DOT___002841_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hea3488cd__0))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___002593_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002601_)))));
        vlSelf->wasmetal_core__DOT___002316_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002324_)))));
        vlSelf->wasmetal_core__DOT___002641_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xfff00000eeeeULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hcd5a09ca__0))))))));
        vlSelf->wasmetal_core__DOT___002923_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002933_)))));
        vlSelf->wasmetal_core__DOT___002680_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xfff00000eeeeULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hd0a40acf__0))))))));
        vlSelf->wasmetal_core__DOT___002841_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___002853_))));
    }
    vlSelf->wasmetal_core__DOT___001948_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xfff0ffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001964_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001963_) 
                                                                        << 2U) 
                                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001343_)
                                                                             : (IData)(vlSelf->wasmetal_core__DOT___001859_)) 
                                                                           << 1U) 
                                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                             & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001497_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001496_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001495_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001342_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___001740_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048888_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                      & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001654_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001498_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001497_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001496_))))))))) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002562_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002563_)))))))));
    vlSelf->wasmetal_core__DOT___001251_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xfff0ffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001337_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001336_) 
                                                                        << 2U) 
                                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001344_)
                                                                             : (IData)(vlSelf->wasmetal_core__DOT___001343_)) 
                                                                           << 1U) 
                                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                             & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001498_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001497_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001496_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001495_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___002075_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048831_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002106_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002105_)) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdf798121__0))))))));
    vlSelf->wasmetal_core__DOT___065423_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065420_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065419_)))));
    vlSelf->wasmetal_core__DOT___067205_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064924_)))));
    vlSelf->wasmetal_core__DOT___064931_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064924_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064923_)))));
    vlSelf->wasmetal_core__DOT___065198_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065195_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065194_)))));
    vlSelf->wasmetal_core__DOT___066095_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065195_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___067086_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064499_)))));
    vlSelf->wasmetal_core__DOT___064513_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064499_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064498_)))));
    vlSelf->wasmetal_core__DOT___002352_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048778_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002142_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002382_)) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hea3488cd__0))))))));
    vlSelf->wasmetal_core__DOT___002112_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048815_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002143_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002142_)) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1e7febb9__0))))))));
    vlSelf->wasmetal_core__DOT___065317_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065314_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065313_)))));
    vlSelf->wasmetal_core__DOT___066140_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065314_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___067164_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064755_)))));
    vlSelf->wasmetal_core__DOT___064761_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064755_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064754_)))));
    vlSelf->wasmetal_core__DOT___065950_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065078_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___065081_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065078_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065077_)))));
    if (vlSelf->wasmetal_core__DOT___000182_) {
        vlSelf->wasmetal_core__DOT___002893_ = vlSelf->wasmetal_core__DOT___001849_;
        vlSelf->wasmetal_core__DOT___002811_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h73960028__0)))));
        vlSelf->wasmetal_core__DOT___002564_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                    ? 
                                                   (0xeU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h73960028__0))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001784_)))));
    } else {
        vlSelf->wasmetal_core__DOT___002893_ = vlSelf->wasmetal_core__DOT___002111_;
        vlSelf->wasmetal_core__DOT___002811_ = (1U 
                                                & (0x30005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___001785_)))))));
        vlSelf->wasmetal_core__DOT___002564_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                    ? 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001785_)))
                                                    : 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___001783_))))));
    }
    vlSelf->__VdfgTmp_h81d9e1ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___002730_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002729_));
    vlSelf->__VdfgTmp_h9934c93f__0 = (((IData)(vlSelf->wasmetal_core__DOT___002509_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002510_));
    vlSelf->wasmetal_core__DOT___002475_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xffff4444fffffff0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002510_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002509_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h703a7a56__0)))))))));
    vlSelf->wasmetal_core__DOT___064774_ = (1U & (0xdf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064771_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063908_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064770_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x4fff00ff00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___063901_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063915_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063916_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063922_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063921_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064748_)))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063902_)))))));
    vlSelf->wasmetal_core__DOT___065065_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048345_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063925_))));
    vlSelf->__VdfgTmp_h10a668fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___063926_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063925_));
    vlSelf->__VdfgTmp_hb62f452d__0 = (((IData)(vlSelf->wasmetal_core__DOT___002324_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb54a817c__0));
    vlSelf->__VdfgTmp_h22ba1a50__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h170507c4__0)));
    vlSelf->wasmetal_core__DOT___048832_ = (1U & (0xe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h170507c4__0))))));
    vlSelf->wasmetal_core__DOT___068897_ = (1U & (IData)(
                                                         (0xff0044440000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048861_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048862_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcd5a09ca__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000169_)))))))));
    vlSelf->__VdfgTmp_hfd6c95b6__0 = ((4U & ((IData)(
                                                     (0xfff00000eeeeULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcd5a09ca__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_hc6bfb5bb__0));
    vlSelf->__VdfgTmp_h0da24f1d__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcd5a09ca__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                          ? (IData)(vlSelf->wasmetal_core__DOT___001850_)
                                          : (IData)(vlSelf->wasmetal_core__DOT___001849_)));
    vlSelf->__VdfgTmp_h5a517e30__0 = ((4U & ((IData)(
                                                     (0x33000f0055ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h89619cd0__0)))))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h5e317429__0));
    vlSelf->__VdfgTmp_h5b64371c__0 = ((2U & ((IData)(
                                                     (0x330f5500000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h89619cd0__0)))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                ? (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001784_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001781_)))))
                                                : (IData)(vlSelf->wasmetal_core__DOT___001850_))));
    vlSelf->wasmetal_core__DOT___069138_ = (1U & (IData)(
                                                         (0xff0044440000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048849_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048850_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hcf8aa4a8__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000169_)))))))));
    vlSelf->wasmetal_core__DOT___001898_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002272_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002271_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb0eb761__0))))))));
    vlSelf->__VdfgTmp_h6dac888a__0 = (((IData)(vlSelf->wasmetal_core__DOT___002933_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7357dd51__0));
    vlSelf->wasmetal_core__DOT___048771_ = ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                            & (IData)(
                                                      (0x3300f00055ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h804cf86b__0)))))));
    vlSelf->__VdfgTmp_hb4d5b900__0 = ((2U & ((IData)(
                                                     (0x33f05500000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h804cf86b__0)))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                ? (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000923_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___000921_)))))
                                                : (IData)(vlSelf->wasmetal_core__DOT___000924_))));
    vlSelf->wasmetal_core__DOT___065911_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064924_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064929_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064923_)))))))));
    vlSelf->wasmetal_core__DOT___065713_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064499_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064511_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064498_)))))))));
    vlSelf->wasmetal_core__DOT___066659_ = (1U & (IData)(
                                                         (0x33000f0055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065076_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065931_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066653_)))))))));
    vlSelf->wasmetal_core__DOT___066537_ = (1U & (IData)(
                                                         (0x3300f00055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064741_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065811_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066531_)))))))));
    vlSelf->wasmetal_core__DOT___066905_ = (1U & (IData)(
                                                         (0x33000f0055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065426_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066268_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066899_)))))))));
    vlSelf->wasmetal_core__DOT___066412_ = (1U & (IData)(
                                                         (0x3300f00055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064478_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065709_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066405_)))))))));
    vlSelf->wasmetal_core__DOT___066781_ = (1U & (IData)(
                                                         (0x33000f0055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065201_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066076_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066775_)))))))));
    vlSelf->wasmetal_core__DOT___065815_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064755_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064759_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064754_)))))))));
    vlSelf->wasmetal_core__DOT___065625_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063983_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063995_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063982_)))))))));
    vlSelf->wasmetal_core__DOT___063997_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063983_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063982_)))));
    vlSelf->wasmetal_core__DOT___065055_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a2cc5a2__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbbb75ece__0))))));
    vlSelf->wasmetal_core__DOT___063929_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbbb75ece__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5a2cc5a2__0))))));
    vlSelf->wasmetal_core__DOT___001808_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xfff0ffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001854_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001853_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & (((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                                ? (IData)(vlSelf->wasmetal_core__DOT___001859_)
                                                                                : 
                                                                               (0xc05U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001339_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0ffccffaa000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003189_)))))))))))))) 
                                                                              << 1U)) 
                                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                             & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001496_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001495_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001342_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001341_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___002515_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048742_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002460_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___001770_)) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002649_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002650_)))))))));
    vlSelf->wasmetal_core__DOT___002430_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048786_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002105_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002460_)) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hae207145__0))))))));
    vlSelf->wasmetal_core__DOT___002195_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048755_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                      & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000177_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000176_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001731_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001730_))))))))) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002931_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002932_)))))))));
    vlSelf->wasmetal_core__DOT___002392_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048770_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002382_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002225_)) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002688_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002689_)))))))));
    vlSelf->__VdfgTmp_h51461c8e__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d)))))) 
                                             << 2U)) 
                                      | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___000170_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h07a6aef0__0))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___001934_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001935_))))
                                                  : 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                  | (1U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hdb0eb761__0)))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___000152_)));
    vlSelf->wasmetal_core__DOT___002393_ = (1U & (IData)(
                                                         (0xff00f000ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he278c168__0)))))));
    vlSelf->__VdfgTmp_hd9c0d0dd__0 = ((2U & (((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                              & (IData)(
                                                        (0xfff0ffff1111ffffULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001721_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001720_) 
                                                                    << 2U) 
                                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                         ? (IData)(vlSelf->wasmetal_core__DOT___001728_)
                                                                         : (IData)(vlSelf->wasmetal_core__DOT___001727_)) 
                                                                       << 1U) 
                                                                      | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                         & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000176_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001731_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001730_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001729_))))))))))))))))) 
                                             << 1U)) 
                                      | (1U & (0xf00011U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he9d730e6__0))))));
    vlSelf->wasmetal_core__DOT___002759_ = (1U & ((1U 
                                                   & (IData)(
                                                             (0xeULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                   << 4U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hcf8aa4a8__0))))))
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___000152_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9be80f53__0))))
                                                    : 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1e7febb9__0)))))));
    vlSelf->wasmetal_core__DOT___002113_ = (1U & (IData)(
                                                         (0xff00ff00ff000eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048816_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9be80f53__0))))))));
    vlSelf->wasmetal_core__DOT___069154_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8025ed93__0))));
    vlSelf->wasmetal_core__DOT___064762_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007036_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063838_))));
    vlSelf->__VdfgTmp_hcf6e1765__0 = (((IData)(vlSelf->wasmetal_core__DOT___063838_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007036_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___063824_)));
    vlSelf->wasmetal_core__DOT___068963_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068892_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068962_)))));
    vlSelf->__VdfgTmp_hb27da868__0 = (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068790_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___068892_))))));
    vlSelf->__VdfgTmp_h280fcf30__0 = (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068936_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___069034_))))));
    vlSelf->wasmetal_core__DOT___068791_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068697_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068790_)))));
    vlSelf->__VdfgTmp_h10281295__0 = (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068845_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___068936_))))));
    vlSelf->wasmetal_core__DOT___068698_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068599_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068697_)))));
    vlSelf->wasmetal_core__DOT___068846_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068746_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068845_)))));
    vlSelf->wasmetal_core__DOT___068747_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068649_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068746_)))));
    vlSelf->wasmetal_core__DOT___068600_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068473_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068599_)))));
    vlSelf->wasmetal_core__DOT___068650_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068547_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068649_)))));
    vlSelf->wasmetal_core__DOT___068474_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068396_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068473_)))));
    vlSelf->wasmetal_core__DOT___068397_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068287_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068396_)))));
    vlSelf->wasmetal_core__DOT___068548_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068420_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068547_)))));
    vlSelf->wasmetal_core__DOT___068288_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068149_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068287_)))));
    vlSelf->wasmetal_core__DOT___068421_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068341_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068420_)))));
    vlSelf->wasmetal_core__DOT___068150_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068073_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068149_)))));
    vlSelf->wasmetal_core__DOT___068342_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068234_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068341_)))));
    vlSelf->wasmetal_core__DOT___068074_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067968_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068073_)))));
    vlSelf->wasmetal_core__DOT___068235_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068098_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068234_)))));
    vlSelf->wasmetal_core__DOT___068099_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068025_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068098_)))));
    vlSelf->wasmetal_core__DOT___067816_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067815_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h958b2749__0))))));
    vlSelf->wasmetal_core__DOT___067969_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067815_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067968_)))));
    vlSelf->wasmetal_core__DOT___068026_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067902_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068025_)))));
    vlSelf->wasmetal_core__DOT___067755_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067754_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd78cc544__0))))));
    vlSelf->wasmetal_core__DOT___067903_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067754_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067902_)))));
    vlSelf->wasmetal_core__DOT___067731_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h958b2749__0))))))));
    vlSelf->wasmetal_core__DOT___067593_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067447_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067592_)))));
    vlSelf->wasmetal_core__DOT___067665_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067496_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd78cc544__0))))))));
    vlSelf->wasmetal_core__DOT___067448_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067300_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067447_)))));
    vlSelf->wasmetal_core__DOT___067301_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067145_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067300_)))));
    vlSelf->wasmetal_core__DOT___067146_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067145_)))));
    vlSelf->wasmetal_core__DOT___066963_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066843_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066962_)))));
    vlSelf->wasmetal_core__DOT___066844_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066638_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066843_)))));
    vlSelf->wasmetal_core__DOT___066639_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066516_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066638_)))));
    vlSelf->wasmetal_core__DOT___067497_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067330_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067496_)))));
    vlSelf->wasmetal_core__DOT___066517_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066304_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066516_)))));
    vlSelf->wasmetal_core__DOT___067331_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067186_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067330_)))));
    vlSelf->wasmetal_core__DOT___066305_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066116_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066304_)))));
    vlSelf->wasmetal_core__DOT___067187_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067067_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067186_)))));
    vlSelf->wasmetal_core__DOT___067068_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066884_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067067_)))));
    vlSelf->wasmetal_core__DOT___066117_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065925_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066116_)))));
    vlSelf->wasmetal_core__DOT___066885_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066760_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066884_)))));
    vlSelf->wasmetal_core__DOT___066761_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066593_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066760_)))));
    vlSelf->wasmetal_core__DOT___065926_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065793_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065925_)))));
    vlSelf->wasmetal_core__DOT___066594_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066390_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066593_)))));
    vlSelf->wasmetal_core__DOT___065794_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065595_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065793_)))));
    vlSelf->wasmetal_core__DOT___066391_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066260_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066390_)))));
    vlSelf->wasmetal_core__DOT___066261_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066070_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066260_)))));
    vlSelf->wasmetal_core__DOT___065596_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065291_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065595_)))));
    vlSelf->wasmetal_core__DOT___065292_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065070_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065291_)))));
    vlSelf->wasmetal_core__DOT___066071_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065889_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066070_)))));
    vlSelf->wasmetal_core__DOT___065890_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065691_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065889_)))));
    vlSelf->wasmetal_core__DOT___065692_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065404_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065691_)))));
    vlSelf->wasmetal_core__DOT___065405_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065175_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065404_)))));
    vlSelf->wasmetal_core__DOT___065071_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064723_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065070_)))));
    vlSelf->wasmetal_core__DOT___065176_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064890_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065175_)))));
    vlSelf->wasmetal_core__DOT___064891_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064482_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064890_)))));
    vlSelf->wasmetal_core__DOT___064483_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064482_))));
    vlSelf->wasmetal_core__DOT___064724_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063827_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064723_)))));
    vlSelf->wasmetal_core__DOT___063829_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063827_))));
    vlSelf->wasmetal_core__DOT___049041_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049032_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049031_))));
    vlSelf->wasmetal_core__DOT___050522_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049039_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049032_))));
    vlSelf->wasmetal_core__DOT___049451_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049279_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049282_))));
    vlSelf->wasmetal_core__DOT___049284_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049280_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049279_))));
    vlSelf->__VdfgTmp_h249d4881__0 = (((IData)(vlSelf->wasmetal_core__DOT___049351_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049354_));
    vlSelf->__VdfgTmp_h4d50854c__0 = (((IData)(vlSelf->wasmetal_core__DOT___049354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049353_));
    vlSelf->wasmetal_core__DOT___049490_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049077_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049082_))));
    vlSelf->wasmetal_core__DOT___049084_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049078_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049077_))));
    vlSelf->wasmetal_core__DOT___050519_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049031_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049022_))));
    vlSelf->wasmetal_core__DOT___049283_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049282_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049281_))));
    vlSelf->__VdfgTmp_h45e6cf8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___049353_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049360_));
    vlSelf->wasmetal_core__DOT___049083_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049081_))));
    vlSelf->wasmetal_core__DOT___049024_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049022_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049021_))));
    vlSelf->wasmetal_core__DOT___049450_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049281_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049248_))));
    vlSelf->__VdfgTmp_h94c83f35__0 = (((IData)(vlSelf->wasmetal_core__DOT___049360_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049359_));
    vlSelf->__VdfgTmp_h3b672e02__0 = (((IData)(vlSelf->wasmetal_core__DOT___049081_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049125_));
    vlSelf->wasmetal_core__DOT___053910_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053689_))));
    vlSelf->wasmetal_core__DOT___053646_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___051706_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___053663_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___051650_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051651_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051549_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051650_))));
    vlSelf->__VdfgTmp_h84446dc0__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((IData)(
                                                              (0xaaaaf0f0ff00ccccULL 
                                                               >> 
                                                               ((8U 
                                                                 & ((0xacU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3d1308f6__0)) 
                                                                    << 3U)) 
                                                                | ((4U 
                                                                    & ((0xacU 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hce2b20fd__0)) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((0xacU 
                                                                           >> (IData)(vlSelf->__VdfgTmp_h6d3ebca4__0)) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (0xacU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_ha0b2e14a__0)))))))) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (IData)(
                                                               (0xff00ccccf0f0aaaaULL 
                                                                >> 
                                                                ((8U 
                                                                  & ((0xacU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hce73595f__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4f58838a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb043089c__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hb2b84c00__0))))))))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___048673_));
    vlSelf->wasmetal_core__DOT___049926_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049382_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6a1d65be__0))));
    vlSelf->wasmetal_core__DOT___053640_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___051690_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___053652_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___051719_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051779_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051631_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___051648_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___051526_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050828_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___049023_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049014_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049013_))));
    vlSelf->wasmetal_core__DOT___050518_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049021_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049014_))));
    vlSelf->wasmetal_core__DOT___049447_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049247_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049249_))));
    vlSelf->wasmetal_core__DOT___049251_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049248_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049247_))));
    vlSelf->__VdfgTmp_h57526782__0 = (((IData)(vlSelf->wasmetal_core__DOT___049359_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049358_));
    vlSelf->__VdfgTmp_h20ec44fd__0 = (((IData)(vlSelf->wasmetal_core__DOT___049358_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049357_));
    vlSelf->wasmetal_core__DOT___049502_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049124_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049131_))));
    vlSelf->__VdfgTmp_hc0f91dc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___049125_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049124_));
    vlSelf->wasmetal_core__DOT___050977_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (4U 
                                                                 >> 
                                                                 (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_habccd4be__0))))))))))));
    vlSelf->wasmetal_core__DOT___049370_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc4ac601e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h09589e24__0))))));
    vlSelf->wasmetal_core__DOT___051426_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2b3afffd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x35U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha4843895__0))))));
    vlSelf->wasmetal_core__DOT___051904_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xcaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha4843895__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2b3afffd__0))))));
    vlSelf->wasmetal_core__DOT___049144_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0a02dc0e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049142_))));
    vlSelf->wasmetal_core__DOT___049700_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049501_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049503_))));
    vlSelf->wasmetal_core__DOT___049630_ = (1U & (0xc5U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hebb238d0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049152_))))));
    vlSelf->wasmetal_core__DOT___049545_ = (1U & (0xc5U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd698a5e2__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049321_))))));
    vlSelf->wasmetal_core__DOT___051647_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xcaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc497fe80__0))))));
    vlSelf->wasmetal_core__DOT___049714_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x35U 
                                                        >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc497fe80__0))))));
    vlSelf->wasmetal_core__DOT___049684_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049464_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049465_))));
    vlSelf->__VdfgTmp_h69fe2c1e__0 = (((IData)(vlSelf->wasmetal_core__DOT___049849_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049853_));
    vlSelf->wasmetal_core__DOT___049099_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049098_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049097_))));
    vlSelf->wasmetal_core__DOT___050525_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049835_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049839_))));
    vlSelf->wasmetal_core__DOT___049266_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049263_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049262_))));
    vlSelf->wasmetal_core__DOT___049173_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hebb238d0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x35U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hef58fdbd__0))))));
    vlSelf->wasmetal_core__DOT___049324_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd698a5e2__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049319_))));
    vlSelf->__VdfgTmp_h6e22e397__0 = (((IData)(vlSelf->wasmetal_core__DOT___049853_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049852_));
    vlSelf->wasmetal_core__DOT___049483_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049097_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049066_))));
    vlSelf->wasmetal_core__DOT___049843_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049839_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049838_))));
    vlSelf->wasmetal_core__DOT___049458_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049262_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049273_))));
    vlSelf->wasmetal_core__DOT___050064_ = (1U & (0xc0aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((4U 
                                                                >> 
                                                                (2U 
                                                                 & ((0xacU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                                    << 1U))) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049530_)))));
    vlSelf->wasmetal_core__DOT___051751_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051582_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___051689_))))));
    vlSelf->wasmetal_core__DOT___051763_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051614_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> 
                                                              (1U 
                                                               & (0x53U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hb6137419__0)))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___051741_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051550_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___051650_))))));
    vlSelf->__VdfgTmp_hd957e182__0 = (((IData)(vlSelf->wasmetal_core__DOT___049852_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049854_));
    vlSelf->__VdfgTmp_h9726a7a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___049854_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049608_));
    vlSelf->__VdfgTmp_hc8d2269b__0 = (((IData)(vlSelf->wasmetal_core__DOT___049065_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049072_));
    vlSelf->wasmetal_core__DOT___049074_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049066_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049065_))));
    vlSelf->wasmetal_core__DOT___049842_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049841_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049840_))));
    vlSelf->wasmetal_core__DOT___050524_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049838_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049841_))));
    vlSelf->wasmetal_core__DOT___049453_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049272_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049276_))));
    vlSelf->wasmetal_core__DOT___049278_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049273_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049272_))));
    vlSelf->wasmetal_core__DOT___049513_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha51ab883__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc497fe80__0))))));
    vlSelf->wasmetal_core__DOT___049467_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049466_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049465_))));
    vlSelf->wasmetal_core__DOT___049629_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x35U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hef58fdbd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2121b61a__0))))));
    vlSelf->wasmetal_core__DOT___049661_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049319_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049300_))));
    vlSelf->wasmetal_core__DOT___050629_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050625_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050624_))));
    vlSelf->wasmetal_core__DOT___051646_ = (1U & (0x5cU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha51ab883__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049518_))));
    vlSelf->wasmetal_core__DOT___049713_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha51ab883__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049518_))));
    vlSelf->wasmetal_core__DOT___051485_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050620_))));
    vlSelf->wasmetal_core__DOT___049683_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049466_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049472_))));
    vlSelf->wasmetal_core__DOT___052591_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15ceac3d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2b3afffd__0))))));
    vlSelf->wasmetal_core__DOT___049618_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049132_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0a02dc0e__0))))));
    vlSelf->wasmetal_core__DOT___051425_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049575_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049563_))));
    vlSelf->wasmetal_core__DOT___049207_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2121b61a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcb165b79__0))))));
    vlSelf->wasmetal_core__DOT___051416_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050515_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050509_))));
    vlSelf->wasmetal_core__DOT___049310_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049300_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf18161ea__0))))));
    vlSelf->wasmetal_core__DOT___050730_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050624_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050627_))));
    vlSelf->wasmetal_core__DOT___049520_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049518_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049517_))));
    vlSelf->wasmetal_core__DOT___050634_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050620_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050619_))));
    vlSelf->wasmetal_core__DOT___049474_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049472_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049471_))));
    vlSelf->wasmetal_core__DOT___050792_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050788_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050787_))));
    vlSelf->wasmetal_core__DOT___049798_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049504_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049500_))));
    vlSelf->wasmetal_core__DOT___049578_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049563_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049562_))));
    vlSelf->wasmetal_core__DOT___051833_ = (1U & (IData)(
                                                         (0xaaccf00000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 5U)) 
                                                           | ((4U 
                                                               & ((0xcaU 
                                                                   >> 
                                                                   ((2U 
                                                                     & ((0xacU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hebb238d0__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (8U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049152_))))) 
                                                                  << 2U)) 
                                                              | ((2U 
                                                                  & ((0xacU 
                                                                      >> 
                                                                      ((2U 
                                                                        & ((0xcaU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hef58fdbd__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2121b61a__0))))) 
                                                                     << 1U)) 
                                                                 | (1U 
                                                                    & (0xacU 
                                                                       >> 
                                                                       ((2U 
                                                                         & ((0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hcb165b79__0)) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (0xacU 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h10a4b2d7__0))))))))))));
    vlSelf->wasmetal_core__DOT___049632_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcb165b79__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h10a4b2d7__0))))));
    vlSelf->wasmetal_core__DOT___050516_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050509_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050508_))));
    vlSelf->wasmetal_core__DOT___049663_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf18161ea__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049308_))));
    vlSelf->wasmetal_core__DOT___049887_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049617_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049616_))));
    vlSelf->wasmetal_core__DOT___050628_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050627_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050626_))));
    vlSelf->wasmetal_core__DOT___049712_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049517_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049516_))));
    vlSelf->wasmetal_core__DOT___051484_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050619_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050608_))));
    vlSelf->wasmetal_core__DOT___049601_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049471_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049470_))));
    vlSelf->wasmetal_core__DOT___050694_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048590_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048589_))));
    vlSelf->wasmetal_core__DOT___051318_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049562_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2cac88ff__0))))));
    vlSelf->wasmetal_core__DOT___049206_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10a4b2d7__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049204_))));
    vlSelf->wasmetal_core__DOT___051415_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050508_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048999_))));
    vlSelf->wasmetal_core__DOT___049309_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049307_))));
    vlSelf->wasmetal_core__DOT___049146_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049121_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049120_))));
    vlSelf->wasmetal_core__DOT___050689_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050626_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h92ec5796__0))))));
    vlSelf->wasmetal_core__DOT___049519_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049516_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h97f76463__0))))));
    vlSelf->wasmetal_core__DOT___050610_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050608_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050607_))));
    vlSelf->wasmetal_core__DOT___049473_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049469_))));
    vlSelf->wasmetal_core__DOT___050048_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050047_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050046_))));
    vlSelf->wasmetal_core__DOT___049506_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049500_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049499_))));
    vlSelf->wasmetal_core__DOT___049577_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2cac88ff__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd0aa9c81__0))))));
    vlSelf->wasmetal_core__DOT___049631_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049204_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7ec4412__0))))));
    vlSelf->wasmetal_core__DOT___049001_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048999_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048998_))));
    vlSelf->wasmetal_core__DOT___049662_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049259_))));
    vlSelf->wasmetal_core__DOT___049619_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049616_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049615_))));
    vlSelf->wasmetal_core__DOT___050623_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h92ec5796__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6f0935bb__0))))));
    vlSelf->wasmetal_core__DOT___049711_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h97f76463__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h337a7e76__0))))));
    vlSelf->wasmetal_core__DOT___051483_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050607_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050602_))));
    vlSelf->wasmetal_core__DOT___049600_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049469_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049457_))));
    vlSelf->wasmetal_core__DOT___049384_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047951_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047950_))));
    vlSelf->wasmetal_core__DOT___049701_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048589_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049699_))));
    vlSelf->wasmetal_core__DOT___051317_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd0aa9c81__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd992aaf0__0))))));
    vlSelf->wasmetal_core__DOT___049112_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf7ec4412__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049109_))));
    vlSelf->wasmetal_core__DOT___051414_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048998_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048981_))));
    vlSelf->wasmetal_core__DOT___049269_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049259_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049258_))));
    vlSelf->wasmetal_core__DOT___049749_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049120_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049748_))));
    vlSelf->wasmetal_core__DOT___050688_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6f0935bb__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h65c50ed7__0))))));
    vlSelf->wasmetal_core__DOT___049488_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h337a7e76__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049485_))));
    vlSelf->wasmetal_core__DOT___050609_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050602_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049837_))));
    vlSelf->wasmetal_core__DOT___049461_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049457_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049456_))));
    vlSelf->wasmetal_core__DOT___050791_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050790_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050789_))));
    vlSelf->wasmetal_core__DOT___049797_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049499_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049796_))));
    vlSelf->wasmetal_core__DOT___053212_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd992aaf0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h15d2df15__0))))));
    vlSelf->wasmetal_core__DOT___049576_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd992aaf0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h15d2df15__0))))));
    vlSelf->wasmetal_core__DOT___049622_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049109_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049100_))));
    vlSelf->wasmetal_core__DOT___049000_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048981_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048980_))));
    vlSelf->wasmetal_core__DOT___049656_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049258_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h32efca0f__0))))));
    vlSelf->wasmetal_core__DOT___050543_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049057_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049056_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049055_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___049054_)))))));
    vlSelf->wasmetal_core__DOT___049886_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049615_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049885_))));
    vlSelf->wasmetal_core__DOT___049858_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h65c50ed7__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h40926396__0))))));
    vlSelf->wasmetal_core__DOT___049704_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049485_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfc74b95b__0))))));
    vlSelf->wasmetal_core__DOT___049845_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049836_))));
    vlSelf->wasmetal_core__DOT___049589_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049456_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049459_))));
    vlSelf->wasmetal_core__DOT___049531_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049527_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049526_))));
    vlSelf->wasmetal_core__DOT___051989_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xaaaaccccf0f0ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___050787_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050790_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050789_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___049815_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xff55ccf0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___049814_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h951148c2__0))))))));
    vlSelf->__VdfgTmp_h54bf9a7e__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___049815_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___049814_))) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (IData)(vlSelf->__VdfgTmp_h951148c2__0))));
    vlSelf->wasmetal_core__DOT___049927_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047952_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047951_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047950_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___047949_)))))));
    vlSelf->wasmetal_core__DOT___049383_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047949_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049382_))));
    vlSelf->__VdfgTmp_ha128d41e__0 = ((2U & ((IData)(
                                                     (0xaaaaccccf0f0ff00ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___051433_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050851_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050850_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___050849_)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009520_));
    vlSelf->wasmetal_core__DOT___050855_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050851_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050850_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050849_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___050848_)))))));
    vlSelf->__VdfgTmp_he62a830e__0 = ((2U & ((IData)(
                                                     (0xf0f0aaaaccccff00ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___049645_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___049644_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf09b90d7__0))))) 
                                             << 1U)) 
                                      | (1U & (0x10U 
                                               >> (4U 
                                                   & ((4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                             << 1U)) 
                                                           << 1U))) 
                                                      << 2U)))));
    vlSelf->wasmetal_core__DOT___050829_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049645_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050827_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf09b90d7__0))))));
    vlSelf->__VdfgTmp_had82d15e__0 = ((2U & ((IData)(
                                                     (0xaaaaccccf0f0ff00ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___049056_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___049055_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049054_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___049440_)))))) 
                                             << 1U)) 
                                      | (1U & (0xff55ccf0U 
                                               >> (IData)(vlSelf->__VdfgTmp_h35851421__0))));
    vlSelf->wasmetal_core__DOT___049898_ = (1U & (IData)(
                                                         (0x5555ccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049440_) 
                                                            << 3U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h35851421__0)))));
    vlSelf->wasmetal_core__DOT___049241_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xcaU 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___049227_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049226_))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xcaU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbd292e75__0))))));
    vlSelf->wasmetal_core__DOT___049765_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049227_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049238_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbd292e75__0))))));
    vlSelf->wasmetal_core__DOT___051347_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051056_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051346_))));
    vlSelf->wasmetal_core__DOT___051057_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049748_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051056_))));
    vlSelf->wasmetal_core__DOT___051521_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051288_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051520_))));
    vlSelf->wasmetal_core__DOT___051289_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049885_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051288_))));
    vlSelf->wasmetal_core__DOT___051367_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051113_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051366_))));
    vlSelf->wasmetal_core__DOT___051114_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049796_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051113_))));
    vlSelf->wasmetal_core__DOT___051327_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050692_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051326_))));
    vlSelf->wasmetal_core__DOT___050693_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049699_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050692_))));
    vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___047991_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042682_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042587_))));
    vlSelf->__VdfgTmp_h08bc6edf__0 = (((IData)(vlSelf->wasmetal_core__DOT___042642_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___042612_));
    vlSelf->wasmetal_core__DOT___048118_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042642_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042612_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048117_)))));
    vlSelf->wasmetal_core__DOT___042703_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042707_) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___042704_))))));
    if (vlSelf->wasmetal_core__DOT___042539_) {
        vlSelf->wasmetal_core__DOT___042601_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
        vlSelf->wasmetal_core__DOT___042632_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___042539_));
    } else if (vlSelf->wasmetal_core__DOT___042542_) {
        if (vlSelf->wasmetal_core__DOT___042541_) {
            if (vlSelf->wasmetal_core__DOT___042536_) {
                vlSelf->wasmetal_core__DOT___042601_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
                vlSelf->wasmetal_core__DOT___042632_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042536_));
            } else {
                vlSelf->wasmetal_core__DOT___042601_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042606_)
                              ? (IData)(vlSelf->wasmetal_core__DOT___135025___DOT__CO__BRA__0__KET__)
                              : (~ (IData)(vlSelf->wasmetal_core__DOT___042704_))));
                vlSelf->wasmetal_core__DOT___042632_ 
                    = (1U & ((IData)(vlSelf->wasmetal_core__DOT___042636_)
                              ? (IData)(vlSelf->wasmetal_core__DOT___135029___DOT__CO__BRA__0__KET__)
                              : (~ (IData)(vlSelf->wasmetal_core__DOT___042749_))));
            }
        } else {
            vlSelf->wasmetal_core__DOT___042601_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
            vlSelf->wasmetal_core__DOT___042632_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___042541_)));
        }
    } else {
        vlSelf->wasmetal_core__DOT___042601_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
        vlSelf->wasmetal_core__DOT___042632_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___042542_)));
    }
    vlSelf->wasmetal_core__DOT___048121_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042713_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042554_))));
    vlSelf->wasmetal_core__DOT___048130_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042739_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042576_))));
    vlSelf->wasmetal_core__DOT___042748_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___042539_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___042542_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___042541_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___042536_)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___042626_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135053___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042749_))))));
    vlSelf->__VdfgTmp_h4702c863__0 = (((IData)(vlSelf->wasmetal_core__DOT___042731_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___042622_));
    vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026476_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b2__05d));
    vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036786_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036753_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h1c8d20fd__0))));
    vlSelf->wasmetal_core__DOT___063099_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063096_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063095_)))))));
    vlSelf->wasmetal_core__DOT___063105_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063102_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063101_)))))));
    vlSelf->wasmetal_core__DOT___063111_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063108_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063107_)))))));
    vlSelf->wasmetal_core__DOT___063117_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063114_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063113_)))))));
    vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028312_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028247_));
    vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026584_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001875_));
    vlSelf->wasmetal_core__DOT___053589_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053586_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h19b7a9a0__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052693_)))));
    vlSelf->wasmetal_core__DOT___062989_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053586_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___062974_))));
    vlSelf->wasmetal_core__DOT___071266_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071264_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054099_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___071274_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071273_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___071279_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071278_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054135_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___071294_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071293_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___071299_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071298_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___071314_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071313_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___071319_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071318_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT___071334_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071333_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___071339_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071338_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___071269_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071268_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054111_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___071284_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071283_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___071289_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071288_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054178_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___071304_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071303_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___071309_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071308_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___071324_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071323_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT___071329_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071328_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___045002_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8134fe6e__0)))))))))));
    vlSelf->wasmetal_core__DOT___045026_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8134fe6e__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054039_)))))))));
    vlSelf->wasmetal_core__DOT___045013_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h57cd27d4__0)))))))))));
    vlSelf->wasmetal_core__DOT___045037_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h57cd27d4__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054051_)))))))));
    vlSelf->wasmetal_core__DOT___045017_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h77f7c585__0)))))))))));
    vlSelf->wasmetal_core__DOT___045041_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h77f7c585__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054075_)))))))));
    vlSelf->wasmetal_core__DOT___045018_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054087_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hbe940684__0)))))))))));
    vlSelf->wasmetal_core__DOT___045042_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbe940684__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054091_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054087_)))))))));
    vlSelf->wasmetal_core__DOT___045016_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8a76b5de__0)))))))))));
    vlSelf->wasmetal_core__DOT___045040_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8a76b5de__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054063_)))))))));
    vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031357_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128655___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034315_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034314_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034313_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034312_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034375_)))));
    vlSelf->wasmetal_core__DOT___034379_ = ((IData)(vlSelf->wasmetal_core__DOT___034315_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128671___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034483_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034482_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034481_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034480_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034536_)))));
    vlSelf->wasmetal_core__DOT___034540_ = ((IData)(vlSelf->wasmetal_core__DOT___034483_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027344_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b1__05d));
    vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_z >> 0xeU) & (IData)(vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__2__KET__ 
        = (1U & ((0x4000U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 0xeU) : (IData)(vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032869_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032836_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___062705_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128012___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 8U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062697_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128165___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O))))))));
    vlSelf->wasmetal_core__DOT___062716_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128012___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 9U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062708_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128165___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062727_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128012___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xaU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062719_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128165___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062738_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128012___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0xbU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062730_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128165___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027804_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027771_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b12__05d));
    vlSelf->wasmetal_core__DOT___065617_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3f15000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065605_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065604_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b8__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___063451_))))))))))));
    vlSelf->wasmetal_core__DOT___065807_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3f15000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065803_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065802_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065801_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b10__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___063451_))))))))))));
    vlSelf->wasmetal_core__DOT___065705_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3f15000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065701_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065700_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065699_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b9__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___063451_))))))))))));
    vlSelf->wasmetal_core__DOT___065903_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3f15000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065899_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065898_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065897_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b11__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___063451_))))))))))));
    vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_x >> 0xeU) & (IData)(vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028122_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 9U)));
    vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__2__KET__ 
        = ((~ (vlSelf->function_params >> 0xeU)) & (IData)(vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___070640_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b9__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032677_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032644_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___134211___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037187_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___037155_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h638a3747__0))));
    vlSelf->wasmetal_core__DOT___063519_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063527_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063535_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063543_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___054493_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127836___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054495_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127836___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054497_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127836___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054499_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127844___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127836___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026360_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026327_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b12__05d));
    vlSelf->wasmetal_core__DOT___053096_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xbf00bfbf00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___053084_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053083_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053082_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050411_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050421_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050410_)))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f000000e0e00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053078_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053065_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053060_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053064_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x80U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053049_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053048_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053064_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053022_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053023_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053021_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053060_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053045_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053066_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xbfff30004000cfffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053066_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053060_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053065_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053046_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053047_)))))))))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf0f0fdfU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___025060_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052732_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (vlSelf->insn_w 
                                                                            >> 1U))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128402___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___031968_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___031967_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___031960_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128402___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063457_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__1__KET__ 
        = (IData)((3U == (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O))));
    vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030714_));
    vlSelf->wasmetal_core__DOT___062123_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___062118_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054999_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5d11eb70__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007387_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007392_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___062090_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062084_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf03fc3ad__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hacafe368__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c7215cb__0)))))))))))));
    vlSelf->wasmetal_core__DOT___062067_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___062062_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae784e62__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007361_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007366_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___062035_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcb315704__0))))));
    vlSelf->wasmetal_core__DOT___062031_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062025_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h70e31548__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcb315704__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0286ce7d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___054973_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054971_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h90c7fdf4__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h379220a5__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcb315704__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055177_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055175_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x33330f0f00ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054940_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054941_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054943_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054955_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054954_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054953_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054952_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054963_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf5533ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb52e5b74__0)))))))))))));
    vlSelf->wasmetal_core__DOT___019319_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054955_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054954_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054953_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054952_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff33330f0f5555ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054963_) 
                                                                               << 3U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hb52e5b74__0))))))))))));
    vlSelf->wasmetal_core__DOT___062005_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061990_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb6cab41b__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007334_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007336_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc5a57f40__0))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07c00df2__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061971_ = (1U & (IData)(
                                                         (0x5555ccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061965_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2447f2cc__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4212348e__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2a3772ca__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061984_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061975_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac54b2bd__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd03398e3__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7208d2a5__0))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x3333555500ff0f0fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061979_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ffde934__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h64c25376__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ad5bd42__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___055155_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055153_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054904_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054919_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054918_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054916_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054905_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054903_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054913_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf5533ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4481aac1__0)))))))))))));
    vlSelf->wasmetal_core__DOT___054920_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___009643_)
                                                   ? 
                                                  (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(
                                                                   (0x3333555500ff0f0fULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054919_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054918_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054917_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054916_)))))))) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((4U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0xff33ff550f0f0f0fULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054896_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc9c602ec__0)))))))))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0xc0aU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054915_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054914_))))))))))
                                                   : 
                                                  (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0xf0f333300ff5555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054905_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054904_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054903_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054902_)))))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xff33330f0f5555ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054913_) 
                                                                             << 3U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h4481aac1__0))))))))))));
    vlSelf->wasmetal_core__DOT___061945_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061941_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054864_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28d1a2cd__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007301_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc04b3f0__0))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfcd73105__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061877_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061873_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054819_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h98124bc4__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007273_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007275_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h05777dd7__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061805_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061801_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xf0f0ccccff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6995c07d__0))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007247_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha1697357__0))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf1275c5a__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___055118_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054773_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054772_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054771_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054786_)))))))));
    vlSelf->wasmetal_core__DOT___054799_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf6b3ca0e__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfce0919b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb919cd7__0))))))))))))));
    vlSelf->wasmetal_core__DOT___054798_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f0eeeeff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054766_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33ff550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054757_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha9869a20__0))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf3f5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2ba92b9e__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054758_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054773_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054772_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054771_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054786_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5e28409c__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___062103_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___062094_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7b1ed1fb__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h99d3b9a6__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1e1103c4__0))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x3333555500ff0f0fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062098_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1f51ea8e__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb0afff05__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf366d942__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___055186_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055183_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054994_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054982_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054981_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054979_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054993_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054992_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054991_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055005_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf5533ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc6adb13e__0)))))))))))));
    vlSelf->wasmetal_core__DOT___055013_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f0eeeeff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054986_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33ff550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054976_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc326eb38__0))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054977_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054978_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054994_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054993_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054992_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054991_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc6adb13e__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___055147_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055144_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054859_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054880_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054879_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054877_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054858_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054857_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054856_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054870_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf5533ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9a768dd6__0)))))))))))));
    vlSelf->wasmetal_core__DOT___054884_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff33330f0f5555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054859_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054858_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054857_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054856_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff33330f0f5555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054870_) 
                                                                            << 3U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h9a768dd6__0)))))))))));
    vlSelf->wasmetal_core__DOT___054843_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054814_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054813_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054812_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054811_)))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054825_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hafe0013c__0)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff000f33335555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054831_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054830_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054829_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054828_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054835_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054834_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054833_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054832_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___061507_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061496_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061474_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061469_)))));
    vlSelf->wasmetal_core__DOT___061504_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061497_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061496_))));
    vlSelf->wasmetal_core__DOT___061491_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061489_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061488_))));
    vlSelf->wasmetal_core__DOT___062157_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062150_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf07ddd26__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfe0abeab__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hea36c42a__0)))))))))))));
    vlSelf->wasmetal_core__DOT___061506_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061503_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061488_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061483_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061468_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061460_)))))));
    vlSelf->wasmetal_core__DOT___061505_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061503_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061502_))));
    vlSelf->wasmetal_core__DOT___062158_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062139_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he0ff0f52__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28180847__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1dd2f13b__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce1a9eab__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h703df812__0))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f4f4420__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h92c59f9e__0))))))))))))))))));
    vlSelf->wasmetal_core__DOT___055196_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ccccf0f0aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055192_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055040_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055019_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055020_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055022_)))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055039_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055038_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055037_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055051_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xf5533ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h84a7ba42__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___019337_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055040_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055039_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055038_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055037_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff33330f0f5555ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055051_) 
                                                                               << 3U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h84a7ba42__0))))))))))));
    vlSelf->wasmetal_core__DOT___061795_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061773_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___061796_ = (1U & (IData)(
                                                         (0x30f020a030f03000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061774_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061773_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x153f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061763_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061762_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048402_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048403_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061761_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061649_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061674_)))))))));
    vlSelf->wasmetal_core__DOT___061866_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061838_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___061867_ = (1U & (IData)(
                                                         (0x30f020a030f03000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061863_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061838_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0x77707770777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048402_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061855_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061648_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007417_)))))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061831_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061830_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb587b232__0))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___061653_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061687_)))))))));
    vlSelf->wasmetal_core__DOT___061849_ = (1U & (0x60U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061838_)))));
    vlSelf->wasmetal_core__DOT___061928_ = (1U & (0x60U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061907_)))));
    vlSelf->wasmetal_core__DOT___061919_ = (1U & (0xeee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061908_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061907_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaaaccccf0f0ff00ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061899_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061898_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ae2b9ea__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061653_)))))));
    vlSelf->wasmetal_core__DOT___061514_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061490_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061476_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha1796962__0))))));
    vlSelf->wasmetal_core__DOT___061510_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061477_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061476_))));
    vlSelf->wasmetal_core__DOT___061663_ = (1U & (IData)(
                                                         (0xf030a020f0300030ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061661_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061639_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x5f4c554400000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061654_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061639_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061621_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061620_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h27ece1ce__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048270_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061637_)))))))));
    vlSelf->wasmetal_core__DOT___057679_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055059_))));
    vlSelf->wasmetal_core__DOT___055061_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055059_))));
    vlSelf->wasmetal_core__DOT___061446_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019200_))));
    vlSelf->wasmetal_core__DOT___061724_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055878_))));
    vlSelf->wasmetal_core__DOT___055912_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055910_))));
    vlSelf->wasmetal_core__DOT___055974_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055972_))));
    vlSelf->wasmetal_core__DOT___055981_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055979_))));
    vlSelf->wasmetal_core__DOT___062185_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055935_))));
    vlSelf->wasmetal_core__DOT___060866_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h67f18e55__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055777_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019242_)))))))));
    vlSelf->wasmetal_core__DOT___060779_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h83053a2d__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055759_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019242_)))))))));
    vlSelf->wasmetal_core__DOT___055714_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055712_))));
    vlSelf->wasmetal_core__DOT___061252_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055928_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf0027c26__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___061170_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055917_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7ef390f7__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___061088_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055910_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9ba8d2dd__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___060999_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055903_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0cb45e24__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___060918_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055891_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha7321d4d__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___060833_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055878_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2c8d302e__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___061322_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055935_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd8562240__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___062129_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055047_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019277_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___061448_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019277_))));
    vlSelf->wasmetal_core__DOT___055874_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019277_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___061221_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7e30f70e__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061217_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8565eee7__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061260_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd96a7b90__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061155_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h93fbfa25__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061151_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ce8c3b1__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061178_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haaeadd36__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061075_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h29bca591__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061070_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h34f2d08e__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060985_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9cbd3d8a__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060981_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h31aacdc1__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061012_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h68f6955f__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060887_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3fcf358e__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060929_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb1732b67__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060889_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb372eb0f__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060852_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he43dd87d__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060807_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha7da5f58__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060848_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he7f579a2__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060758_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h1b99479d__0))))))))))));
    vlSelf->wasmetal_core__DOT___060717_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h69457925__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061307_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd3c93d4d__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061303_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h92b02c04__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___019282_ = ((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                            & (IData)(
                                                      (0xfffefff0ff00ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (0xac00U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hb23bd85a__0)))))))))))));
    vlSelf->wasmetal_core__DOT___061332_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2225d234__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061329_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055997_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h567d9bb7__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___055999_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055997_))));
    vlSelf->wasmetal_core__DOT___056005_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055997_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___056905_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d)))))))));
    vlSelf->wasmetal_core__DOT___056779_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056778_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056777_)))))));
    vlSelf->wasmetal_core__DOT___056463_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h33bf650d__0))))))));
    vlSelf->wasmetal_core__DOT___012477_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057092_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057205_)))))));
    vlSelf->wasmetal_core__DOT___056916_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha720ddd6__0))))))));
    vlSelf->wasmetal_core__DOT___011957_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056769_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056768_)))))));
    vlSelf->wasmetal_core__DOT___011353_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056598_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056597_)))))));
    vlSelf->wasmetal_core__DOT___011100_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056331_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056501_)))))));
    vlSelf->wasmetal_core__DOT___057388_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057385_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057384_)))))));
    vlSelf->wasmetal_core__DOT___057322_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012580_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012581_))))));
    vlSelf->wasmetal_core__DOT___057173_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012411_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012412_))))));
    vlSelf->wasmetal_core__DOT___056987_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056984_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056983_)))))));
    vlSelf->wasmetal_core__DOT___056481_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3fcac4a1__0))))))));
    vlSelf->wasmetal_core__DOT___056749_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056746_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056745_)))))));
    vlSelf->wasmetal_core__DOT___057445_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012964_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012965_))))));
    vlSelf->wasmetal_core__DOT___057658_ = (1U & (IData)(
                                                         (0xca00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d)))))))));
    vlSelf->wasmetal_core__DOT___057635_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057573_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057574_)))))));
    vlSelf->__VdfgTmp_hedbbe05b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011103_));
    vlSelf->__VdfgTmp_hdfb2d71e__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___011101_)))));
    vlSelf->wasmetal_core__DOT___011026_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010084_))));
    vlSelf->__VdfgTmp_h15546f37__0 = (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hfa759b39__0));
    vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034179_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d));
    vlSelf->__VdfgTmp_h03ce55f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h3c2b613a__0)));
    vlSelf->__VdfgTmp_hcbffb3b6__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf37b3ae8__0)));
    vlSelf->__VdfgTmp_h3f5e9baf__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h2f9ca2ed__0)));
    vlSelf->__VdfgTmp_h3c35c9c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d));
    vlSelf->__VdfgTmp_h3c506bbe__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d));
    vlSelf->__VdfgTmp_hb9c84dcf__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h13d2f137__0)));
    vlSelf->wasmetal_core__DOT___007792_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007396_))))));
    vlSelf->wasmetal_core__DOT___007789_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007370_))))));
    vlSelf->wasmetal_core__DOT___007786_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007344_))))));
    vlSelf->wasmetal_core__DOT___007782_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007284_))))));
    vlSelf->wasmetal_core__DOT___007778_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007257_))))));
    vlSelf->wasmetal_core__DOT___007776_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007230_))))));
    vlSelf->wasmetal_core__DOT___007754_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007371_))))));
    vlSelf->wasmetal_core__DOT___007739_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007345_))))));
    vlSelf->wasmetal_core__DOT___007717_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007285_))))));
    vlSelf->__VdfgTmp_h7b8e4425__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007258_))));
    vlSelf->__VdfgTmp_h3297ffb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007231_))));
    vlSelf->wasmetal_core__DOT___007639_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007392_))))));
    vlSelf->wasmetal_core__DOT___007618_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007366_))))));
    vlSelf->wasmetal_core__DOT___007584_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007307_))))));
    vlSelf->__VdfgTmp_h1e9537b6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007280_))));
    vlSelf->__VdfgTmp_h65d58b23__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007253_))));
    vlSelf->wasmetal_core__DOT___007769_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007397_))))));
    vlSelf->wasmetal_core__DOT___007659_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007419_))))));
    vlSelf->__VdfgTmp_h3a577ede__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007252_))));
    vlSelf->__VdfgTmp_h02da39da__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007393_))));
    vlSelf->wasmetal_core__DOT___007488_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007367_))))));
    vlSelf->wasmetal_core__DOT___007469_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007308_))))));
    vlSelf->__VdfgTmp_ha44be0e2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007281_))));
    vlSelf->__VdfgTmp_hcd9d6cde__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007254_))));
    vlSelf->wasmetal_core__DOT___007395_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007390_))))));
    vlSelf->wasmetal_core__DOT___007369_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007364_))))));
    vlSelf->wasmetal_core__DOT___007310_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007305_))))));
    vlSelf->wasmetal_core__DOT___007283_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007280_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007278_))))));
    vlSelf->__VdfgTmp_hf8957689__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007253_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007251_))));
    vlSelf->wasmetal_core__DOT___007504_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007420_))))));
    vlSelf->wasmetal_core__DOT___007422_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007417_))))));
    vlSelf->wasmetal_core__DOT___010090_ = (1U & (IData)(
                                                         (0xaaf0cc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054821_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054817_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054819_)))))))));
    vlSelf->wasmetal_core__DOT___007834_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007307_)))))))));
    vlSelf->wasmetal_core__DOT___010588_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0ccccff00aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007280_)))))))));
    vlSelf->wasmetal_core__DOT___011712_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0ccccff00aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007253_)))))))));
    vlSelf->__VdfgTmp_h5812bf47__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007234_));
    vlSelf->wasmetal_core__DOT___010753_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xff00aaaaf0f0ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007393_)))))))));
    vlSelf->wasmetal_core__DOT___010131_ = (1U & (0xff550f33U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd5551ada__0)))));
    vlSelf->wasmetal_core__DOT___010110_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                   ? 
                                                  (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007470_)))))
                                                   : 
                                                  (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007471_)))))));
    vlSelf->__VdfgTmp_h544074d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he9d168d9__0)));
    vlSelf->wasmetal_core__DOT___007798_ = (1U & (IData)(
                                                         (0xff00aaaaf0f0ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007280_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007281_)))))))));
    vlSelf->wasmetal_core__DOT___010140_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007364_)))))))));
    vlSelf->wasmetal_core__DOT___010150_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007340_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007338_)))))))));
    vlSelf->wasmetal_core__DOT___055135_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc86399cc__0))))));
    vlSelf->wasmetal_core__DOT___055136_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc52c52a3__0)))));
    vlSelf->__VdfgTmp_hd5b4e54d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007770_))))));
    vlSelf->wasmetal_core__DOT___053783_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2814f082__0))))));
    vlSelf->wasmetal_core__DOT___053784_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h8893fd49__0))))));
    vlSelf->wasmetal_core__DOT___053785_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h42498a1f__0))))));
    vlSelf->wasmetal_core__DOT___053786_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3caf5d97__0))))));
    vlSelf->wasmetal_core__DOT___053787_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h52f4f13a__0))))));
    vlSelf->wasmetal_core__DOT___053788_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7780ec55__0))))));
    vlSelf->wasmetal_core__DOT___053789_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha292c154__0))))));
    vlSelf->wasmetal_core__DOT___053790_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd1bccf33__0))))));
    if (vlSelf->wasmetal_core__DOT___007235_) {
        vlSelf->wasmetal_core__DOT___009780_ = (1U 
                                                & (IData)(
                                                          (0xf0f0aaaaff00ccccULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___007391_)))))))));
        if (vlSelf->wasmetal_core__DOT___007204_) {
            vlSelf->wasmetal_core__DOT___010164_ = 
                (1U & (0x35U >> (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h13d2f137__0))));
            vlSelf->wasmetal_core__DOT___009783_ = 
                (1U & (0x35U >> (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_hc98b4d16__0))));
        } else {
            vlSelf->wasmetal_core__DOT___010164_ = 
                (1U & (0x35U >> (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_he182d032__0))));
            vlSelf->wasmetal_core__DOT___009783_ = 
                (1U & (0x35U >> (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h161030dd__0))));
        }
        vlSelf->wasmetal_core__DOT___009815_ = (1U 
                                                & (IData)(
                                                          (0xf0f0aaaaff00ccccULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___007365_)))))))));
        vlSelf->wasmetal_core__DOT___009782_ = (1U 
                                                & (IData)(
                                                          (0xf0f0aaaaff00ccccULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007335_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___007339_)))))))));
        vlSelf->wasmetal_core__DOT___009794_ = (1U 
                                                & (IData)(
                                                          (0xf0f0aaaaff00ccccULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___007306_)))))))));
        vlSelf->wasmetal_core__DOT___009792_ = (1U 
                                                & (IData)(
                                                          (0xf0f555500ff3333ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___007279_)))))))));
        vlSelf->wasmetal_core__DOT___010214_ = (1U 
                                                & (IData)(
                                                          (0xf0f555500ff3333ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007248_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___007252_)))))))));
    } else {
        vlSelf->wasmetal_core__DOT___009780_ = 0U;
        vlSelf->wasmetal_core__DOT___010164_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                   | (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007729_)))));
        vlSelf->wasmetal_core__DOT___009783_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                   | (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007718_)))));
        vlSelf->wasmetal_core__DOT___009815_ = 0U;
        vlSelf->wasmetal_core__DOT___009782_ = 0U;
        vlSelf->wasmetal_core__DOT___009794_ = 0U;
        vlSelf->wasmetal_core__DOT___009792_ = 0U;
        vlSelf->wasmetal_core__DOT___010214_ = 0U;
    }
    vlSelf->__VdfgTmp_hd5802a9c__0 = ((2U & (((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                              & (IData)(
                                                        (0x33ff55ff0fff0fffULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                 << 3U) 
                                                                | (IData)(vlSelf->__VdfgTmp_heeb73844__0))))))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                         & (IData)(
                                                   (0x33ff55ff0fff0fffULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 3U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h898c2bb0__0))))))));
    vlSelf->wasmetal_core__DOT___007660_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007519_));
    vlSelf->wasmetal_core__DOT___007661_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007520_));
    vlSelf->wasmetal_core__DOT___007662_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007518_));
    vlSelf->wasmetal_core__DOT___007663_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007517_));
    vlSelf->wasmetal_core__DOT___054893_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007522_));
    vlSelf->wasmetal_core__DOT___054894_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007521_));
    vlSelf->wasmetal_core__DOT___054895_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007523_));
    vlSelf->wasmetal_core__DOT___054854_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h5b76ab14__0))))))));
    vlSelf->wasmetal_core__DOT___010955_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha38d193b__0))))))));
    vlSelf->wasmetal_core__DOT___054851_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf20faaf0__0))))))));
    vlSelf->wasmetal_core__DOT___054805_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb187f8bb__0))))))));
    vlSelf->wasmetal_core__DOT___010986_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8499ba72__0))))))));
    vlSelf->wasmetal_core__DOT___010980_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h80fea7fc__0))))))));
}
