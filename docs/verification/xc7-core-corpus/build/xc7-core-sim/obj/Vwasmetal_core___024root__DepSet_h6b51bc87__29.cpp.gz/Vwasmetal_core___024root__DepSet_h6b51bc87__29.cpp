#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__34(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__34\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___025065_;
    wasmetal_core__DOT___025065_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025088_;
    wasmetal_core__DOT___025088_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025092_;
    wasmetal_core__DOT___025092_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025095_;
    wasmetal_core__DOT___025095_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025096_;
    wasmetal_core__DOT___025096_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025097_;
    wasmetal_core__DOT___025097_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025098_;
    wasmetal_core__DOT___025098_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036034_;
    wasmetal_core__DOT___036034_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036035_;
    wasmetal_core__DOT___036035_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036036_;
    wasmetal_core__DOT___036036_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056496_;
    wasmetal_core__DOT___056496_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058142_;
    wasmetal_core__DOT___058142_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063840_;
    wasmetal_core__DOT___063840_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063841_;
    wasmetal_core__DOT___063841_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127749___O;
    wasmetal_core__DOT____Vcellout___127749___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127750___O;
    wasmetal_core__DOT____Vcellout___127750___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127751___O;
    wasmetal_core__DOT____Vcellout___127751___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127749___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127749___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127749___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127749___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127749___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127749___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127750___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127750___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127750___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127750___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127750___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127750___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127751___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127751___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127751___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127751___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127751___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127751___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127752___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127752___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127752___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127752___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127752___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127752___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128811___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128811___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128811___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128811___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hc98e0845__0;
    __VdfgTmp_hc98e0845__0 = 0;
    // Body
    wasmetal_core__DOT___058142_ = (1U & (1U >> ((0x10U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135069_.__PVT__alu_sum 
                                                              >> 0xfU)) 
                                                     << 4U)) 
                                                 | (0xfU 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135069_.__PVT__alu_sum 
                                                               >> 8U))))));
    wasmetal_core__DOT___063840_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007034_))));
    vlSelf->wasmetal_core__DOT___043272_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (0x1fU 
                                                              & (IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                         >> 3U)))))));
    vlSelf->wasmetal_core__DOT___043271_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                              >> 1U)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 2U)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha01e8f2f__0))))))));
    wasmetal_core__DOT___036036_ = (1U & (9U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d))));
    wasmetal_core__DOT___036035_ = (1U & (9U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d))));
    wasmetal_core__DOT___036034_ = (1U & (9U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d))));
    wasmetal_core__DOT___025098_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007054_))));
    wasmetal_core__DOT___025097_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___025062_))));
    wasmetal_core__DOT___025096_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___025061_))));
    wasmetal_core__DOT___025095_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___025060_))));
    vlSelf->__VdfgTmp_h18f87701__0 = ((2U & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d));
    vlSelf->wasmetal_core__DOT___061037_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 0xcU)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h413b142d__0))))));
    vlSelf->wasmetal_core__DOT___060945_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 0xbU)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h64194573__0))))));
    vlSelf->wasmetal_core__DOT___060869_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 0xaU)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h67f18e55__0))))));
    vlSelf->wasmetal_core__DOT___060782_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 9U)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h83053a2d__0))))));
    vlSelf->wasmetal_core__DOT___060665_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 8U)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfd347d5f__0))))));
    vlSelf->wasmetal_core__DOT___061200_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 0xeU)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8f3d454e__0))))));
    vlSelf->wasmetal_core__DOT___061118_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 0xdU)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h744f9b35__0))))));
    vlSelf->wasmetal_core__DOT___060667_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 0x10U)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h84d44246__0))))));
    vlSelf->wasmetal_core__DOT___057417_ = (1U & (IData)(
                                                         (0xfaf300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057404_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x2e2e0faaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055661_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 6U)))))))))))))));
    vlSelf->wasmetal_core__DOT___056588_ = (1U & (IData)(
                                                         (0xf0faf0f300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfdd0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                                                >> 1U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                             ? 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___011268_)
                                                                              ? 
                                                                             (0xaa00aacfU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h739b8454__0))))
                                                                              : 
                                                                             (8U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d))))
                                                                             : 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___011268_)
                                                                              ? 
                                                                             (0xaa00aacfU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h739b8454__0))))
                                                                              : 
                                                                             (8U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127678___O)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 9U)))))))))))))));
    wasmetal_core__DOT___056496_ = (1U & (IData)((0xf0f0aacc00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xfbbU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0x1d1d0f55U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___056228_)))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127678___O) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 8U)))))))))))))));
    vlSelf->wasmetal_core__DOT___061280_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                      >> 0xfU)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h69142c13__0))))));
    vlSelf->wasmetal_core__DOT___127736___DOT__CO__BRA__1__KET__ 
        = (IData)((0xc000ULL == (0xc000ULL & vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum)));
    vlSelf->wasmetal_core__DOT___011885_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x55cc0f0f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & (((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 2U))))))))
                                                                                 : 
                                                                                (0x2e2e0faaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010042_))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134164___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                                >> 2U))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128541___O) 
                                                                                >> 2U))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xccaa00000f0fULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((IData)(
                                                                                (0xff00ffffff4040ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056755_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056754_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))))))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xbb88bbbbafa0afafULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056162_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056752_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010045_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf0f00ddU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127719___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                                >> 2U))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___012162_ = (1U & (0xff4fU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056981_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff0fff11ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___056979_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 3U)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xa300U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4c3f9374__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xa03U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4c3f9374__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___058143_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058142_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (vlSymsp->TOP__wasmetal_core__DOT___135069_.__PVT__alu_sum 
                                                                           >> 0xeU)) 
                                                                  << 4U)) 
                                                              | (0xfU 
                                                                 & (IData)(vlSymsp->TOP__wasmetal_core__DOT___135069_.__PVT__alu_sum)))))));
    wasmetal_core__DOT___063841_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063840_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063839_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134183___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___042332_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048379_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048350_)))))))));
    vlSelf->wasmetal_core__DOT___043279_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___036036_) 
                                                    << 4U) 
                                                   | (0xfU 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                 >> 4U))))));
    wasmetal_core__DOT___127749___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___025095_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___025060_));
    vlSelf->wasmetal_core__DOT___043278_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h18f87701__0)) 
                                                       << 2U)) 
                                                   | (((IData)(wasmetal_core__DOT___036034_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___036035_)))));
    wasmetal_core__DOT___128811___DOT__CO__BRA__0__KET__ 
        = (1U & ((9U >> (IData)(vlSelf->__VdfgTmp_h18f87701__0)) 
                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)));
    vlSelf->wasmetal_core__DOT___011077_ = (1U & (IData)(
                                                         (0xff000e00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___056496_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf5fc00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056488_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127728___O) 
                                                                                >> 1U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff00bb00ff000f00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056493_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056492_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127678___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___127736___DOT__CO__BRA__2__KET__ 
        = ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                    >> 0x10U)) & (IData)(vlSelf->wasmetal_core__DOT___127736___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___063852_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063842_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___063841_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___042248_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042131_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048356_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048313_)))))))));
    wasmetal_core__DOT___127749___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___025096_) ? (IData)(wasmetal_core__DOT___127749___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___025061_));
    wasmetal_core__DOT___128811___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036034_) ? (IData)(wasmetal_core__DOT___128811___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d));
    wasmetal_core__DOT___127749___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___025097_) ? (IData)(wasmetal_core__DOT___127749___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___025062_));
    vlSelf->wasmetal_core__DOT____Vcellout___128811___O 
        = ((((IData)(wasmetal_core__DOT___036036_) 
             << 3U) | (((IData)(wasmetal_core__DOT___036035_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___036034_) 
                                   << 1U) | (1U & (9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h18f87701__0)))))) 
           ^ (1U | ((((IData)(wasmetal_core__DOT___036035_)
                       ? (IData)(wasmetal_core__DOT___128811___DOT__CO__BRA__1__KET__)
                       : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d)) 
                     << 3U) | (((IData)(wasmetal_core__DOT___128811___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(wasmetal_core__DOT___128811___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    wasmetal_core__DOT____Vcellout___127749___O = (
                                                   (((IData)(wasmetal_core__DOT___025098_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025097_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025096_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025095_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127749___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127749___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | ((IData)(wasmetal_core__DOT___127749___DOT__CO__BRA__0__KET__) 
                                                          << 1U))));
    wasmetal_core__DOT___025088_ = ((IData)(wasmetal_core__DOT___025098_)
                                     ? (IData)(wasmetal_core__DOT___127749___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT___007054_));
    vlSelf->wasmetal_core__DOT___062029_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                               << 4U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_hebd182eb__0)))));
    vlSelf->wasmetal_core__DOT___061933_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                               << 4U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4ab1d453__0)))));
    vlSelf->wasmetal_core__DOT___062088_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                               << 4U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_h401bf3cf__0)))));
    vlSelf->wasmetal_core__DOT___061853_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                               << 4U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_h8be24d75__0)))));
    vlSelf->wasmetal_core__DOT___061969_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                               << 4U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2014cd64__0)))));
    vlSelf->wasmetal_core__DOT___061635_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                               << 4U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6ef442fa__0)))));
    vlSelf->wasmetal_core__DOT___061790_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                               << 4U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_h84babf9f__0)))));
    vlSelf->wasmetal_core__DOT___043860_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127749___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127749___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127749___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha01e8f2f__0))))))));
    vlSelf->wasmetal_core__DOT___043868_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127749___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127749___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127749___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)))))))));
    __VdfgTmp_hc98e0845__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                               << 1U) | (1U & ((IData)(wasmetal_core__DOT____Vcellout___127749___O) 
                                               >> 3U)));
    wasmetal_core__DOT___127750___DOT__CO__BRA__0__KET__ 
        = ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                    >> 4U)) & (IData)(wasmetal_core__DOT___025088_));
    wasmetal_core__DOT___127750___DOT__CO__BRA__1__KET__ 
        = ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                    >> 5U)) & (IData)(wasmetal_core__DOT___127750___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127750___DOT__CO__BRA__2__KET__ 
        = ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                    >> 6U)) & (IData)(wasmetal_core__DOT___127750___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127750___O = (0xfU 
                                                   & ((IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 4U)) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127750___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127750___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127750___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___025088_))))));
    wasmetal_core__DOT___025092_ = ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                             >> 7U)) 
                                    & (IData)(wasmetal_core__DOT___127750___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___043861_ = (1U & (IData)(
                                                         (0xfffffffffffffff2ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127750___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127750___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127750___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___127750___O)) 
                                                                    | (IData)(__VdfgTmp_hc98e0845__0))))))));
    wasmetal_core__DOT___127751___DOT__CO__BRA__0__KET__ 
        = ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                    >> 8U)) & (IData)(wasmetal_core__DOT___025092_));
    vlSelf->wasmetal_core__DOT___043869_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043861_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hc98e0845__0))));
    wasmetal_core__DOT___127751___DOT__CO__BRA__1__KET__ 
        = ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                    >> 9U)) & (IData)(wasmetal_core__DOT___127751___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127751___DOT__CO__BRA__2__KET__ 
        = ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                    >> 0xaU)) & (IData)(wasmetal_core__DOT___127751___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127751___O = (0xfU 
                                                   & ((IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                               >> 8U)) 
                                                      ^ 
                                                      (((IData)(wasmetal_core__DOT___127751___DOT__CO__BRA__2__KET__) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___127751___DOT__CO__BRA__1__KET__) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___127751___DOT__CO__BRA__0__KET__) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___025092_))))));
    wasmetal_core__DOT___025065_ = ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                             >> 0xbU)) 
                                    & (IData)(wasmetal_core__DOT___127751___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127752___DOT__CO__BRA__0__KET__ 
        = ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                    >> 0xcU)) & (IData)(wasmetal_core__DOT___025065_));
    wasmetal_core__DOT___127752___DOT__CO__BRA__1__KET__ 
        = ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                    >> 0xdU)) & (IData)(wasmetal_core__DOT___127752___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127752___DOT__CO__BRA__2__KET__ 
        = ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                    >> 0xeU)) & (IData)(wasmetal_core__DOT___127752___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127752___O 
        = (0xfU & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                            >> 0xcU)) ^ (((IData)(wasmetal_core__DOT___127752___DOT__CO__BRA__2__KET__) 
                                          << 3U) | 
                                         (((IData)(wasmetal_core__DOT___127752___DOT__CO__BRA__1__KET__) 
                                           << 2U) | 
                                          (((IData)(wasmetal_core__DOT___127752___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___025065_))))));
    vlSelf->wasmetal_core__DOT___025069_ = ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                     >> 0xfU)) 
                                            & (IData)(wasmetal_core__DOT___127752___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___043870_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127751___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127751___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127751___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127751___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127752___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127752___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___127753___DOT__CO__BRA__0__KET__ 
        = ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                    >> 0x10U)) & (IData)(vlSelf->wasmetal_core__DOT___025069_));
}

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__35(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__35\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___024961_;
    wasmetal_core__DOT___024961_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024992_;
    wasmetal_core__DOT___024992_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025006_;
    wasmetal_core__DOT___025006_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025073_;
    wasmetal_core__DOT___025073_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025078_;
    wasmetal_core__DOT___025078_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025082_;
    wasmetal_core__DOT___025082_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025612_;
    wasmetal_core__DOT___025612_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025643_;
    wasmetal_core__DOT___025643_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025680_;
    wasmetal_core__DOT___025680_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025683_;
    wasmetal_core__DOT___025683_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025684_;
    wasmetal_core__DOT___025684_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025685_;
    wasmetal_core__DOT___025685_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025686_;
    wasmetal_core__DOT___025686_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025687_;
    wasmetal_core__DOT___025687_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025688_;
    wasmetal_core__DOT___025688_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025689_;
    wasmetal_core__DOT___025689_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025694_;
    wasmetal_core__DOT___025694_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025705_;
    wasmetal_core__DOT___025705_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025716_;
    wasmetal_core__DOT___025716_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025727_;
    wasmetal_core__DOT___025727_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025738_;
    wasmetal_core__DOT___025738_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025749_;
    wasmetal_core__DOT___025749_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025752_;
    wasmetal_core__DOT___025752_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025753_;
    wasmetal_core__DOT___025753_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025754_;
    wasmetal_core__DOT___025754_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026039_;
    wasmetal_core__DOT___026039_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026070_;
    wasmetal_core__DOT___026070_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026081_;
    wasmetal_core__DOT___026081_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026084_;
    wasmetal_core__DOT___026084_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026085_;
    wasmetal_core__DOT___026085_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026086_;
    wasmetal_core__DOT___026086_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026087_;
    wasmetal_core__DOT___026087_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026088_;
    wasmetal_core__DOT___026088_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026089_;
    wasmetal_core__DOT___026089_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026090_;
    wasmetal_core__DOT___026090_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026095_;
    wasmetal_core__DOT___026095_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026106_;
    wasmetal_core__DOT___026106_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026117_;
    wasmetal_core__DOT___026117_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026125_;
    wasmetal_core__DOT___026125_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026126_;
    wasmetal_core__DOT___026126_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026127_;
    wasmetal_core__DOT___026127_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026128_;
    wasmetal_core__DOT___026128_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026129_;
    wasmetal_core__DOT___026129_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026130_;
    wasmetal_core__DOT___026130_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043270_;
    wasmetal_core__DOT___043270_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043274_;
    wasmetal_core__DOT___043274_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043275_;
    wasmetal_core__DOT___043275_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043280_;
    wasmetal_core__DOT___043280_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043859_;
    wasmetal_core__DOT___043859_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043865_;
    wasmetal_core__DOT___043865_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043871_;
    wasmetal_core__DOT___043871_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043872_;
    wasmetal_core__DOT___043872_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043873_;
    wasmetal_core__DOT___043873_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060666_;
    wasmetal_core__DOT___060666_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067602_;
    wasmetal_core__DOT___067602_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070627_;
    wasmetal_core__DOT___070627_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127753___O;
    wasmetal_core__DOT____Vcellout___127753___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127754___O;
    wasmetal_core__DOT____Vcellout___127754___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127755___O;
    wasmetal_core__DOT____Vcellout___127755___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127756___O;
    wasmetal_core__DOT____Vcellout___127756___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127783___O;
    wasmetal_core__DOT____Vcellout___127783___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127740___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127740___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127740___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127740___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127740___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127740___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127741___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127741___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127741___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127741___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127741___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127741___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127742___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127742___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127742___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127742___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127742___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127742___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127753___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127753___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127753___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127753___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127754___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127754___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127754___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127754___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127754___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127754___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127755___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127755___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127755___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127755___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127755___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127755___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127756___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127756___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127756___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127756___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127783___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127783___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127783___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127783___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127783___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127783___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127793___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127793___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127793___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127793___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127793___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127793___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127794___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127794___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127794___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127794___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127794___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127794___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127795___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127795___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127795___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127795___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127795___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127795___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127814___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127814___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127814___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127814___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127814___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127814___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127817___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127817___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127817___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127817___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127817___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127817___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127818___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127818___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127818___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127818___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127818___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127818___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127819___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127819___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127819___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127819___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127819___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127819___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hb6d549c0__0;
    __VdfgTmp_hb6d549c0__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9adb1b6a__0;
    __VdfgTmp_h9adb1b6a__0 = 0;
    CData/*2:0*/ __VdfgTmp_h3e41e6f7__0;
    __VdfgTmp_h3e41e6f7__0 = 0;
    CData/*2:0*/ __VdfgTmp_h176f771d__0;
    __VdfgTmp_h176f771d__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___025690_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                                >> 0x10U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                                 >> 0x10U))))));
    wasmetal_core__DOT___025689_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 0xfU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 0xfU))))));
    wasmetal_core__DOT___025688_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 0xeU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 0xeU))))));
    wasmetal_core__DOT___025687_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 0xdU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 0xdU))))));
    wasmetal_core__DOT___025686_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 0xcU))))));
    wasmetal_core__DOT___025685_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 0xbU))))));
    wasmetal_core__DOT___025684_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 0xaU))))));
    wasmetal_core__DOT___025754_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 9U))))));
    wasmetal_core__DOT___025753_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 8U))))));
    wasmetal_core__DOT___025752_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 7U))))));
    wasmetal_core__DOT___025749_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 6U))))));
    wasmetal_core__DOT___025738_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 5U))))));
    wasmetal_core__DOT___025727_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 4U))))));
    wasmetal_core__DOT___025716_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 3U))))));
    wasmetal_core__DOT___025705_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 2U))))));
    wasmetal_core__DOT___025694_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                               >> 1U))))));
    wasmetal_core__DOT___025683_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___135073_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum)))));
    vlSelf->wasmetal_core__DOT___026091_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                                >> 0x10U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                                 >> 0x10U))))));
    wasmetal_core__DOT___026090_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 0xfU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 0xfU))))));
    wasmetal_core__DOT___026089_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 0xeU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 0xeU))))));
    wasmetal_core__DOT___026088_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 0xdU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 0xdU))))));
    wasmetal_core__DOT___026087_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 0xcU))))));
    wasmetal_core__DOT___026086_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 0xbU))))));
    wasmetal_core__DOT___026085_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 0xaU))))));
    wasmetal_core__DOT___026130_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 9U))))));
    wasmetal_core__DOT___026129_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 8U))))));
    wasmetal_core__DOT___026128_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 7U))))));
    wasmetal_core__DOT___026127_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 6U))))));
    wasmetal_core__DOT___026126_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 5U))))));
    wasmetal_core__DOT___026125_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 4U))))));
    wasmetal_core__DOT___026117_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 3U))))));
    wasmetal_core__DOT___026106_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 2U))))));
    wasmetal_core__DOT___026095_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                               >> 1U))))));
    wasmetal_core__DOT___026084_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134225_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum)))));
    wasmetal_core__DOT___127783___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(wasmetal_core__DOT___025683_)) 
                 & (IData)(vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum)));
    wasmetal_core__DOT___127814___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(wasmetal_core__DOT___026084_)) 
                 & (IData)(vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum)));
    wasmetal_core__DOT___127783___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025694_)
                  ? (IData)(wasmetal_core__DOT___127783___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                             >> 1U))));
    wasmetal_core__DOT___127814___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026095_)
                  ? (IData)(wasmetal_core__DOT___127814___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                             >> 1U))));
    wasmetal_core__DOT___127783___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025705_)
                  ? (IData)(wasmetal_core__DOT___127783___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                             >> 2U))));
    wasmetal_core__DOT___127814___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026106_)
                  ? (IData)(wasmetal_core__DOT___127814___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                             >> 2U))));
    wasmetal_core__DOT____Vcellout___127783___O = (
                                                   (((IData)(wasmetal_core__DOT___025716_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025705_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025694_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025683_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127783___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127783___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | ((IData)(wasmetal_core__DOT___127783___DOT__CO__BRA__0__KET__) 
                                                          << 1U))));
    wasmetal_core__DOT___025643_ = (1U & ((IData)(wasmetal_core__DOT___025716_)
                                           ? (IData)(wasmetal_core__DOT___127783___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                      >> 3U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127814___O 
        = ((((IData)(wasmetal_core__DOT___026117_) 
             << 3U) | (((IData)(wasmetal_core__DOT___026106_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___026095_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___026084_)))) 
           ^ (((IData)(wasmetal_core__DOT___127814___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127814___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___127814___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    wasmetal_core__DOT___026070_ = (1U & ((IData)(wasmetal_core__DOT___026117_)
                                           ? (IData)(wasmetal_core__DOT___127814___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                      >> 3U))));
    vlSelf->wasmetal_core__DOT___058151_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127783___O) 
                                                               << 3U)) 
                                                           | (0xfU 
                                                              & (IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___135069_.__PVT__alu_sum 
                                                                         >> 4U)))))));
    wasmetal_core__DOT___127793___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025727_)
                  ? (IData)(wasmetal_core__DOT___025643_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                             >> 4U))));
    wasmetal_core__DOT___043274_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x38U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                       << 3U)) 
                                                   | (7U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                 >> 0xeU)))))));
    vlSelf->wasmetal_core__DOT___061038_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9ba8d2dd__0))))));
    vlSelf->wasmetal_core__DOT___060946_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0cb45e24__0))))));
    vlSelf->wasmetal_core__DOT___060870_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha7321d4d__0))))));
    vlSelf->wasmetal_core__DOT___060783_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2c8d302e__0))))));
    vlSelf->wasmetal_core__DOT___056813_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127680___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127736___O 
        = (((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                   << 3U)) | ((6U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                              >> 0xfU)) 
                                     << 1U)) | (1U 
                                                & (~ (IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                              >> 0xeU)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127736___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127736___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)((vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                   >> 0xeU)) 
                                          << 1U)))));
    wasmetal_core__DOT___024992_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127736___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127753___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___127753___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___012514_ = (1U & (0xf0011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                               ? 
                                                              (1U 
                                                               >> 
                                                               (1U 
                                                                & (0x35U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127681___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                                             >> 3U)))))))
                                                               : 
                                                              (0xee22fa0aU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___012502_))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x33aa0f0f00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                   ? 
                                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                                   & (2U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127681___O)))))
                                                                   : 
                                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                                   & (0xf400U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012506_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___012425_))))))))))))));
    wasmetal_core__DOT___127817___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026125_)
                  ? (IData)(wasmetal_core__DOT___026070_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                             >> 4U))));
    wasmetal_core__DOT___127793___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025738_)
                  ? (IData)(wasmetal_core__DOT___127793___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                             >> 5U))));
    wasmetal_core__DOT___127740___DOT__CO__BRA__0__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___024992_));
    wasmetal_core__DOT___127753___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127753___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___012471_ = (1U & (0xefU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012513_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012514_))))));
    wasmetal_core__DOT___127817___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026126_)
                  ? (IData)(wasmetal_core__DOT___127817___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                             >> 5U))));
    wasmetal_core__DOT___127793___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025749_)
                  ? (IData)(wasmetal_core__DOT___127793___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                             >> 6U))));
    wasmetal_core__DOT___127740___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127740___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127753___O = (
                                                   ((0xeU 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                  >> 0x10U)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127753___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127753___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127753___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___025069_)))));
    wasmetal_core__DOT___025073_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                     >> 2U) & (IData)(wasmetal_core__DOT___127753___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127817___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026127_)
                  ? (IData)(wasmetal_core__DOT___127817___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                             >> 6U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127793___O 
        = ((((IData)(wasmetal_core__DOT___025752_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025749_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025738_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025727_)))) 
           ^ (((IData)(wasmetal_core__DOT___127793___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127793___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127793___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025643_)))));
    wasmetal_core__DOT___025680_ = (1U & ((IData)(wasmetal_core__DOT___025752_)
                                           ? (IData)(wasmetal_core__DOT___127793___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                      >> 7U))));
    wasmetal_core__DOT___127740___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
            >> 3U) & (IData)(wasmetal_core__DOT___127740___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___043871_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127752___O) 
                                                       << 3U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127752___O) 
                                                          << 1U)) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127753___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127753___O) 
                                                                << 1U)) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127753___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127753___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___127754___DOT__CO__BRA__0__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
            >> 3U) & (IData)(wasmetal_core__DOT___025073_));
    vlSelf->wasmetal_core__DOT____Vcellout___127817___O 
        = ((((IData)(wasmetal_core__DOT___026128_) 
             << 3U) | (((IData)(wasmetal_core__DOT___026127_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___026126_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___026125_)))) 
           ^ (((IData)(wasmetal_core__DOT___127817___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127817___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127817___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026070_)))));
    wasmetal_core__DOT___026081_ = (1U & ((IData)(wasmetal_core__DOT___026128_)
                                           ? (IData)(wasmetal_core__DOT___127817___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                      >> 7U))));
    vlSelf->wasmetal_core__DOT___058145_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127793___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127783___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___058147_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127793___O) 
                                                               << 3U)) 
                                                           | ((8U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___127783___O) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (vlSymsp->TOP__wasmetal_core__DOT___135069_.__PVT__alu_sum 
                                                                              >> 0x10U)) 
                                                                     << 2U)) 
                                                                 | (3U 
                                                                    & (IData)(
                                                                              (vlSymsp->TOP__wasmetal_core__DOT___135069_.__PVT__alu_sum 
                                                                               >> 0xcU)))))))));
    wasmetal_core__DOT___127794___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025753_)
                  ? (IData)(wasmetal_core__DOT___025680_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                             >> 8U))));
    vlSelf->wasmetal_core__DOT___061119_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7ef390f7__0))))));
    vlSelf->wasmetal_core__DOT___061201_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf0027c26__0))))));
    wasmetal_core__DOT___060666_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                        >> 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc63c8631__0))))));
    vlSelf->wasmetal_core__DOT___061279_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd8562240__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127740___O 
        = (((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                   << 3U)) | (7U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                    >> 1U))) ^ (((IData)(wasmetal_core__DOT___127740___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(wasmetal_core__DOT___127740___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___127740___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___024992_)))));
    wasmetal_core__DOT___025006_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                    & (IData)(wasmetal_core__DOT___127740___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127754___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
           & (IData)(wasmetal_core__DOT___127754___DOT__CO__BRA__0__KET__));
    __VdfgTmp_hb6d549c0__0 = ((2U & ((0xf110000U >> 
                                      (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                        << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                   << 3U) 
                                                  | ((4U 
                                                      & ((0xf044U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 3U) 
                                                           | ((4U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O) 
                                                                  << 1U)) 
                                                              | ((2U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                         << 2U)) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (0xee22fa0a00000000ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010054_)))))))) 
                                                            << 1U)) 
                                                        | (1U 
                                                           & (IData)(
                                                                     (0xf0f000005533ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127731___O)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O) 
                                                                                >> 1U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))))))))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xff00f000ff00ee00ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & (((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                           ? 
                                                                          (1U 
                                                                           >> 
                                                                           (1U 
                                                                            & (0x35U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127681___O)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O)))))))
                                                                           : 
                                                                          (0xee22fa0aU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010054_))))))) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                              ? 
                                                                             ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                                              & (2U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127681___O) 
                                                                                >> 1U)))))
                                                                              : 
                                                                             ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                                              & (0xf400U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012687_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012685_))))))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0x33aa0f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                                                >> 1U)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                                                >> 1U)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___012861_ = (1U & (0xefU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xf110000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((0xf044U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (0xee22fa0a00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010033_)))))))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127731___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O) 
                                                                                >> 2U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf0f000000eeULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057435_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127681___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                                                >> 1U)))))))
                                                                                 : 
                                                                                (0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010033_))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((~ 
                                                                                (0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127681___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0)))) 
                                                                                & (IData)(
                                                                                (0xff00ffffff1fffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012879_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h18f44539__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))))))));
    vlSelf->wasmetal_core__DOT___056528_ = (1U & (IData)(
                                                         (0xf3f0f5fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                      & (IData)(
                                                                                (0xfffff1111ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011149_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055938_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127682___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                                                >> 3U))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf0440000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055869_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127680___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 0x10U))))))))))))))))))) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaa00ff0f0f0c0cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056512_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x33aa0f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff000b00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056506_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heef7d961__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010896_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055938_)))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x1111000fU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056518_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                                                & (2U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127680___O)))))
                                                                                 : 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                                                & (0x3a00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9167c706__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127730___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xee22fa0a00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055869_)))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___013191_ = (1U & (0xefU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xf110000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((0xf044U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O) 
                                                                                >> 1U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (0xee22fa0a00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013181_)))))))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127732___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O) 
                                                                                >> 3U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___009691_)
                                                                ? 
                                                               (1U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                  << 1U) 
                                                                 | (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                        ? 
                                                                       (1U 
                                                                        >> 
                                                                        (1U 
                                                                         & (0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127681___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                                                >> 2U)))))))
                                                                        : 
                                                                       (0xee22fa0aU 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013181_))))))))))
                                                                : 
                                                               (0xf1U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013177_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 2U) 
                                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                            & (IData)(
                                                                                (0xf3f5f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013184_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h638ad0d9__0)))))))) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127681___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))))))))))))))));
    wasmetal_core__DOT___127818___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026129_)
                  ? (IData)(wasmetal_core__DOT___026081_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                             >> 8U))));
    wasmetal_core__DOT___127794___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025754_)
                  ? (IData)(wasmetal_core__DOT___127794___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                             >> 9U))));
    vlSelf->wasmetal_core__DOT___060670_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060667_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___060666_)))));
    wasmetal_core__DOT___127741___DOT__CO__BRA__0__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___025006_));
    wasmetal_core__DOT___127754___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127754___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___012662_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_hb6d549c0__0))));
    wasmetal_core__DOT___127818___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026130_)
                  ? (IData)(wasmetal_core__DOT___127818___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                             >> 9U))));
    wasmetal_core__DOT___127794___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025684_)
                  ? (IData)(wasmetal_core__DOT___127794___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                             >> 0xaU))));
    wasmetal_core__DOT___127741___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127741___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127754___O = (
                                                   ((0xeU 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                          >> 3U))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127754___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127754___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127754___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025073_)))));
    wasmetal_core__DOT___025078_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                     >> 2U) & (IData)(wasmetal_core__DOT___127754___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127818___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026085_)
                  ? (IData)(wasmetal_core__DOT___127818___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                             >> 0xaU))));
    vlSelf->wasmetal_core__DOT____Vcellout___127794___O 
        = ((((IData)(wasmetal_core__DOT___025685_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025684_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025754_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025753_)))) 
           ^ (((IData)(wasmetal_core__DOT___127794___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127794___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127794___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025680_)))));
    wasmetal_core__DOT___025612_ = (1U & ((IData)(wasmetal_core__DOT___025685_)
                                           ? (IData)(wasmetal_core__DOT___127794___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                      >> 0xbU))));
    wasmetal_core__DOT___127741___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
            >> 3U) & (IData)(wasmetal_core__DOT___127741___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127755___DOT__CO__BRA__0__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
            >> 3U) & (IData)(wasmetal_core__DOT___025078_));
    vlSelf->wasmetal_core__DOT____Vcellout___127818___O 
        = ((((IData)(wasmetal_core__DOT___026086_) 
             << 3U) | (((IData)(wasmetal_core__DOT___026085_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___026130_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___026129_)))) 
           ^ (((IData)(wasmetal_core__DOT___127818___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127818___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127818___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026081_)))));
    wasmetal_core__DOT___026039_ = (1U & ((IData)(wasmetal_core__DOT___026086_)
                                           ? (IData)(wasmetal_core__DOT___127818___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                      >> 0xbU))));
    wasmetal_core__DOT___127795___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025686_)
                  ? (IData)(wasmetal_core__DOT___025612_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                             >> 0xcU))));
    wasmetal_core__DOT___043275_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                            >> 3U)))))));
    vlSelf->wasmetal_core__DOT___061035_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h169cd931__0))))));
    vlSelf->wasmetal_core__DOT___060949_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2596a796__0))))));
    vlSelf->wasmetal_core__DOT___060873_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h03e9ae47__0))))));
    vlSelf->wasmetal_core__DOT___060786_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6deef1cd__0))))));
    vlSelf->wasmetal_core__DOT___056814_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127682___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127741___O 
        = (((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                   << 3U)) | (7U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                    >> 1U))) ^ (((IData)(wasmetal_core__DOT___127741___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(wasmetal_core__DOT___127741___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___127741___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___025006_)))));
    wasmetal_core__DOT___024961_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                    & (IData)(wasmetal_core__DOT___127741___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127755___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
           & (IData)(wasmetal_core__DOT___127755___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___056567_ = (1U & (0xf0011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                               ? 
                                                              (1U 
                                                               >> 
                                                               (1U 
                                                                & (0x35U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127682___O)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O)))))))
                                                               : 
                                                              (0xee22fa0aU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___011169_))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x33aa0f0f00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                                                >> 1U)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                                                >> 1U))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                   ? 
                                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                                   & (2U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127682___O) 
                                                                             >> 1U)))))
                                                                   : 
                                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                                   & (0xf400U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011176_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___011174_))))))))))))));
    vlSelf->wasmetal_core__DOT___012511_ = (1U & (IData)(
                                                         (0xfaf3f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                          ? 
                                                                         (2U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___012481_))
                                                                          : 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___010084_)
                                                                           ? (IData)(
                                                                                (0xf000c000f000a00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012481_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012480_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_heaf10b4b__0)))))))
                                                                           : 
                                                                          (4U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___012481_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___012480_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xee22fa0aU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009712_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127683___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                                                >> 3U))))))))))))));
    wasmetal_core__DOT___127819___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026087_)
                  ? (IData)(wasmetal_core__DOT___026039_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                             >> 0xcU))));
    wasmetal_core__DOT___127795___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025687_)
                  ? (IData)(wasmetal_core__DOT___127795___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                             >> 0xdU))));
    vlSelf->wasmetal_core__DOT___061058_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061038_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061035_)))));
    vlSelf->wasmetal_core__DOT___060969_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060946_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060949_)))));
    vlSelf->wasmetal_core__DOT___060899_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060870_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060873_)))));
    vlSelf->wasmetal_core__DOT___060816_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060783_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060786_)))));
    wasmetal_core__DOT___127742___DOT__CO__BRA__0__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___024961_));
    wasmetal_core__DOT___127755___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127755___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___012499_ = (1U & (0xef00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012511_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012512_))))));
    wasmetal_core__DOT___127819___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026088_)
                  ? (IData)(wasmetal_core__DOT___127819___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                             >> 0xdU))));
    wasmetal_core__DOT___127795___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025688_)
                  ? (IData)(wasmetal_core__DOT___127795___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                             >> 0xeU))));
    wasmetal_core__DOT___127742___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127742___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127755___O = (
                                                   ((0xeU 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127817___O) 
                                                          >> 3U))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127755___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127755___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127755___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025078_)))));
    wasmetal_core__DOT___025082_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                     >> 2U) & (IData)(wasmetal_core__DOT___127755___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127819___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026089_)
                  ? (IData)(wasmetal_core__DOT___127819___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                             >> 0xeU))));
    vlSelf->wasmetal_core__DOT____Vcellout___127795___O 
        = ((((IData)(wasmetal_core__DOT___025689_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025688_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025687_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025686_)))) 
           ^ (((IData)(wasmetal_core__DOT___127795___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127795___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127795___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025612_)))));
    vlSelf->wasmetal_core__DOT___025616_ = (1U & ((IData)(wasmetal_core__DOT___025689_)
                                                   ? (IData)(wasmetal_core__DOT___127795___DOT__CO__BRA__2__KET__)
                                                   : (IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                                                              >> 0xfU))));
    wasmetal_core__DOT___127742___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
            >> 3U) & (IData)(wasmetal_core__DOT___127742___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___043872_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127754___O) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___127754___O) 
                                                          << 3U)) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127754___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127754___O) 
                                                                >> 1U)) 
                                                            | (3U 
                                                               & (IData)(wasmetal_core__DOT____Vcellout___127755___O)))))))));
    wasmetal_core__DOT___127756___DOT__CO__BRA__0__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
            >> 3U) & (IData)(wasmetal_core__DOT___025082_));
    vlSelf->wasmetal_core__DOT____Vcellout___127819___O 
        = ((((IData)(wasmetal_core__DOT___026090_) 
             << 3U) | (((IData)(wasmetal_core__DOT___026089_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___026088_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___026087_)))) 
           ^ (((IData)(wasmetal_core__DOT___127819___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127819___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127819___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___026039_)))));
    vlSelf->wasmetal_core__DOT___026043_ = (1U & ((IData)(wasmetal_core__DOT___026090_)
                                                   ? (IData)(wasmetal_core__DOT___127819___DOT__CO__BRA__2__KET__)
                                                   : (IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                                                              >> 0xfU))));
    vlSelf->wasmetal_core__DOT___127796___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025690_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___025616_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135070_.__PVT__alu_sum 
                             >> 0x10U))));
    wasmetal_core__DOT___067602_ = (1U & (0x777U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128253___O) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                       >> 3U)))))));
    wasmetal_core__DOT___043280_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x38U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                       << 3U)) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                         >> 1U))))));
    vlSelf->wasmetal_core__DOT___060661_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h69457925__0))))));
    vlSelf->wasmetal_core__DOT___061116_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h584cbf3b__0))))));
    vlSelf->wasmetal_core__DOT___061198_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7102b895__0))))));
    vlSelf->wasmetal_core__DOT___060697_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h567d9bb7__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127742___O 
        = (((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                   << 3U)) | (7U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                    >> 1U))) ^ (((IData)(wasmetal_core__DOT___127742___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(wasmetal_core__DOT___127742___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___127742___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___024961_)))));
    vlSelf->wasmetal_core__DOT___024965_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                            & (IData)(wasmetal_core__DOT___127742___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127756___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
           & (IData)(wasmetal_core__DOT___127756___DOT__CO__BRA__0__KET__));
    __VdfgTmp_h9adb1b6a__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___009691_)
                                       ? (0xa3U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                               << 2U) 
                                              | ((2U 
                                                  & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                       ? 
                                                      (0x888b8888U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009710_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009709_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___009807_))))))
                                                       : 
                                                      (0x888b8888U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009710_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009709_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___009807_))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x35U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127683___O)) 
                                                           | (1U 
                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O))))))))))
                                       : (1U >> (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(
                                                                (0x33aa0f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O) 
                                                                                >> 1U)))))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                                                >> 1U))))))))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                           ? 
                                                          ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                           & (2U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127683___O) 
                                                                     >> 1U)))))
                                                           : 
                                                          ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                           & (0x3500U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                << 3U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h6b93e166__0)))))))))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xfe0000ffff0000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___057359_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127733___O)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                                                >> 1U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))) 
                                                                            << 1U)) 
                                                                        | ((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                               ? 
                                                                              (0x888b8888U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___009710_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009709_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009807_))))))
                                                                               : 
                                                                              (0x888b8888U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___009710_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009709_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009807_)))))))))))))))));
    __VdfgTmp_h176f771d__0 = (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                               << 2U) | ((2U & (((~ (IData)(vlSelf->wasmetal_core__DOT___009691_)) 
                                                 & (IData)(
                                                           (0xff00ff00fffbfff0ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___013162_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013161_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (0xcc55f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O) 
                                                                                >> 3U)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                                                >> 3U))))))))) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013159_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                          ? 
                                                                         (1U 
                                                                          >> 
                                                                          (1U 
                                                                           & (0x35U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                               | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127683___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                                                >> 2U)))))))
                                                                          : 
                                                                         (0xee22fa0aU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                            << 4U) 
                                                                           | ((8U 
                                                                               & ((0xfef0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009711_))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                                                >> 2U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O) 
                                                                             >> 3U))))))))))));
    __VdfgTmp_h3e41e6f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                               << 2U) | ((2U & ((IData)(
                                                        (0x33550f0f00000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                         ? 
                                                                        (0x888b8888U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009708_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009707_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010972_))))))
                                                                         : 
                                                                        (0x888b8888U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009708_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009707_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010972_))))))) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127683___O) 
                                                                          >> 1U)) 
                                                                      | (1U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                                            >> 1U))))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0xffff000000ef0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057423_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057422_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012969_)))))))))));
    vlSelf->wasmetal_core__DOT___127820___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___026091_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___026043_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134223_.__PVT__alu_sum 
                             >> 0x10U))));
    vlSelf->wasmetal_core__DOT___067613_ = (1U & (IData)(
                                                         (0xf100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___067602_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067601_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x5533f00000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063863_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066307_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067595_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfcc0f0f000000aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0da24f1d__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha952ad99__0)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d)))))))))))))))));
    wasmetal_core__DOT___043270_ = (1U & ((IData)(wasmetal_core__DOT___043280_)
                                           ? ((IData)(wasmetal_core__DOT___043275_) 
                                              & ((IData)(wasmetal_core__DOT___043274_) 
                                                 & ((IData)(
                                                            (1ULL 
                                                             >> 
                                                             (0x3fU 
                                                              & (IData)(
                                                                        (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                         >> 8U))))) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___043279_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043278_) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___043271_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043272_)))))
                                           : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                              >> 2U)));
    vlSelf->wasmetal_core__DOT___060682_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060661_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___060666_)))));
    vlSelf->wasmetal_core__DOT___061137_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061119_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061116_)))));
    vlSelf->wasmetal_core__DOT___061230_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061201_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061198_)))));
    vlSelf->wasmetal_core__DOT___061291_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060697_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061279_)))));
    vlSelf->wasmetal_core__DOT___057395_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127742___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127740___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___057328_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127742___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127740___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___012205_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___009693_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010077_)
                                                      ? 
                                                     (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___011074_))
                                                      : (IData)(
                                                                (0xffff8000ffffffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___011074_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127742___O) 
                                                                         << 4U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h238f5c0e__0))))))));
    vlSelf->wasmetal_core__DOT___127743___DOT__CO__BRA__0__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___024965_));
    wasmetal_core__DOT____Vcellout___127756___O = (
                                                   ((0xeU 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                          >> 3U))) 
                                                   ^ 
                                                   ((0xfffffff8U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                                         << 2U) 
                                                        & ((IData)(wasmetal_core__DOT___127756___DOT__CO__BRA__1__KET__) 
                                                           << 3U))) 
                                                    | (((IData)(wasmetal_core__DOT___127756___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127756___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025082_)))));
    vlSelf->wasmetal_core__DOT___012663_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_h9adb1b6a__0))));
    vlSelf->wasmetal_core__DOT___012694_ = ((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                            & ((1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O))
                                                ? (0xdU 
                                                   >> 
                                                   ((4U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                          ? 
                                                         (0xf0f5f0f3U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012707_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h07e757d2__0)))))
                                                          : 
                                                         (1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___012708_))) 
                                                        << 2U)) 
                                                    | (IData)(__VdfgTmp_h9adb1b6a__0)))
                                                : (0xdU 
                                                   >> 
                                                   ((4U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                          ? 
                                                         (0xfff1f1U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4eea07db__0)))
                                                          : 
                                                         (1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___012753_))) 
                                                        << 2U)) 
                                                    | (IData)(__VdfgTmp_hb6d549c0__0)))));
    vlSelf->wasmetal_core__DOT___013188_ = (1U & (0xef00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 3U)) 
                                                   | (IData)(__VdfgTmp_h176f771d__0))));
    vlSelf->wasmetal_core__DOT___013190_ = (1U & (IData)(
                                                         (0xefefef0000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057661_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057660_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h176f771d__0)))))));
    vlSelf->wasmetal_core__DOT___012862_ = (1U & (IData)(
                                                         (0xff000e00ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012896_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h3e41e6f7__0)))))));
    vlSelf->wasmetal_core__DOT___012885_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___009693_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___012896_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___012899_)
                                                    : (IData)(
                                                              (0xe0e0e0000000000ULL 
                                                               >> 
                                                               ((0x20U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                    << 5U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012895_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012894_) 
                                                                       << 3U) 
                                                                      | (IData)(__VdfgTmp_h3e41e6f7__0)))))))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___012899_)));
    vlSelf->wasmetal_core__DOT___127743___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127743___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___070627_ = (1U & (1U >> ((0x10U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127755___O) 
                                                     << 2U)) 
                                                 | ((0xcU 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127756___O) 
                                                        << 1U)) 
                                                    | ((2U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127755___O) 
                                                           >> 2U)) 
                                                       | (1U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___127756___O)))))));
    vlSelf->wasmetal_core__DOT___127743___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
            >> 3U) & (IData)(vlSelf->wasmetal_core__DOT___127743___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___043873_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___070627_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127756___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___043865_ = (1U & (1U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127756___O) 
                                                     >> 2U)) 
                                                 | (IData)(wasmetal_core__DOT___070627_))));
    wasmetal_core__DOT___043859_ = (1U & ((IData)(wasmetal_core__DOT___043873_)
                                           ? ((IData)(wasmetal_core__DOT___043872_)
                                               ? ((IData)(wasmetal_core__DOT___043871_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___043870_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___043869_)
                                                     ? 
                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___043868_)) 
                                                     & (IData)(vlSelf->wasmetal_core__DOT___043860_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___043861_))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___043870_)))
                                                   : 
                                                  (~ (IData)(wasmetal_core__DOT___043871_)))
                                               : (~ (IData)(wasmetal_core__DOT___043872_)))
                                           : (IData)(wasmetal_core__DOT___043865_)));
    vlSelf->wasmetal_core__DOT___061638_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___043859_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___043270_))));
    vlSelf->wasmetal_core__DOT___062160_ = (1U & (IData)(
                                                         (0xff00ee00ff00f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061638_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054745_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062158_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062157_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x3500U 
                                                                            >> 
                                                                            ((0xcU 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h703df812__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce1a9eab__0)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x305U 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 1U)) 
                                                                              | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h92c59f9e__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f4f4420__0))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061643_ = (1U & (IData)(
                                                         (0x3f2a3f00cf8acfcfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061639_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061638_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054745_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048368_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff00aaaaccccf0f0ULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061635_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he798fe47__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd4ed2ab6__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2142849a__0))))))))))))))))))));
}

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__36(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__36\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___012281_;
    wasmetal_core__DOT___012281_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012515_;
    wasmetal_core__DOT___012515_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012516_;
    wasmetal_core__DOT___012516_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012884_;
    wasmetal_core__DOT___012884_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024969_;
    wasmetal_core__DOT___024969_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024974_;
    wasmetal_core__DOT___024974_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024978_;
    wasmetal_core__DOT___024978_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025372_;
    wasmetal_core__DOT___025372_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025408_;
    wasmetal_core__DOT___025408_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025411_;
    wasmetal_core__DOT___025411_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025412_;
    wasmetal_core__DOT___025412_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025413_;
    wasmetal_core__DOT___025413_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025422_;
    wasmetal_core__DOT___025422_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025433_;
    wasmetal_core__DOT___025433_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025444_;
    wasmetal_core__DOT___025444_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025455_;
    wasmetal_core__DOT___025455_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025466_;
    wasmetal_core__DOT___025466_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025477_;
    wasmetal_core__DOT___025477_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025480_;
    wasmetal_core__DOT___025480_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025481_;
    wasmetal_core__DOT___025481_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025482_;
    wasmetal_core__DOT___025482_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025620_;
    wasmetal_core__DOT___025620_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025625_;
    wasmetal_core__DOT___025625_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025629_;
    wasmetal_core__DOT___025629_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025691_;
    wasmetal_core__DOT___025691_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025692_;
    wasmetal_core__DOT___025692_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025693_;
    wasmetal_core__DOT___025693_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025695_;
    wasmetal_core__DOT___025695_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025696_;
    wasmetal_core__DOT___025696_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025697_;
    wasmetal_core__DOT___025697_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025698_;
    wasmetal_core__DOT___025698_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025699_;
    wasmetal_core__DOT___025699_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025700_;
    wasmetal_core__DOT___025700_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025701_;
    wasmetal_core__DOT___025701_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025702_;
    wasmetal_core__DOT___025702_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025703_;
    wasmetal_core__DOT___025703_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025704_;
    wasmetal_core__DOT___025704_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025706_;
    wasmetal_core__DOT___025706_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025707_;
    wasmetal_core__DOT___025707_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025902_;
    wasmetal_core__DOT___025902_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025906_;
    wasmetal_core__DOT___025906_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025909_;
    wasmetal_core__DOT___025909_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025910_;
    wasmetal_core__DOT___025910_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025911_;
    wasmetal_core__DOT___025911_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025920_;
    wasmetal_core__DOT___025920_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025931_;
    wasmetal_core__DOT___025931_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025932_;
    wasmetal_core__DOT___025932_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025933_;
    wasmetal_core__DOT___025933_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025934_;
    wasmetal_core__DOT___025934_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025935_;
    wasmetal_core__DOT___025935_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025936_;
    wasmetal_core__DOT___025936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025937_;
    wasmetal_core__DOT___025937_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025938_;
    wasmetal_core__DOT___025938_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026047_;
    wasmetal_core__DOT___026047_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026052_;
    wasmetal_core__DOT___026052_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026056_;
    wasmetal_core__DOT___026056_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026092_;
    wasmetal_core__DOT___026092_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026093_;
    wasmetal_core__DOT___026093_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026094_;
    wasmetal_core__DOT___026094_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026096_;
    wasmetal_core__DOT___026096_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026097_;
    wasmetal_core__DOT___026097_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026098_;
    wasmetal_core__DOT___026098_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026099_;
    wasmetal_core__DOT___026099_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026100_;
    wasmetal_core__DOT___026100_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026101_;
    wasmetal_core__DOT___026101_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026102_;
    wasmetal_core__DOT___026102_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026103_;
    wasmetal_core__DOT___026103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026104_;
    wasmetal_core__DOT___026104_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026105_;
    wasmetal_core__DOT___026105_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026107_;
    wasmetal_core__DOT___026107_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026108_;
    wasmetal_core__DOT___026108_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056679_;
    wasmetal_core__DOT___056679_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056692_;
    wasmetal_core__DOT___056692_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060785_;
    wasmetal_core__DOT___060785_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060872_;
    wasmetal_core__DOT___060872_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060948_;
    wasmetal_core__DOT___060948_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061034_;
    wasmetal_core__DOT___061034_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061115_;
    wasmetal_core__DOT___061115_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067671_;
    wasmetal_core__DOT___067671_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067737_;
    wasmetal_core__DOT___067737_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067761_;
    wasmetal_core__DOT___067761_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067823_;
    wasmetal_core__DOT___067823_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068086_;
    wasmetal_core__DOT___068086_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068111_;
    wasmetal_core__DOT___068111_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068116_;
    wasmetal_core__DOT___068116_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068162_;
    wasmetal_core__DOT___068162_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068247_;
    wasmetal_core__DOT___068247_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068300_;
    wasmetal_core__DOT___068300_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068354_;
    wasmetal_core__DOT___068354_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127796___O;
    wasmetal_core__DOT____Vcellout___127796___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127797___O;
    wasmetal_core__DOT____Vcellout___127797___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127798___O;
    wasmetal_core__DOT____Vcellout___127798___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127799___O;
    wasmetal_core__DOT____Vcellout___127799___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127821___O;
    wasmetal_core__DOT____Vcellout___127821___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127822___O;
    wasmetal_core__DOT____Vcellout___127822___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127823___O;
    wasmetal_core__DOT____Vcellout___127823___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127744___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127744___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127744___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127744___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127744___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127744___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127745___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127745___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127745___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127745___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127745___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127745___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127746___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127746___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127746___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127746___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127746___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127746___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127765___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127765___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127765___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127765___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127765___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127765___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127774___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127774___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127774___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127774___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127774___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127774___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127775___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127775___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127775___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127775___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127775___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127775___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127796___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127796___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127796___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127796___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127797___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127797___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127797___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127797___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127797___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127797___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127798___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127798___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127798___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127798___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127798___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127798___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127799___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127799___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127799___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127799___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127799___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127799___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127806___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127806___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127806___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127806___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127806___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127806___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127807___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127807___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127807___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127807___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127807___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127807___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127808___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127808___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127808___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127808___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127808___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127808___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127820___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127820___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127820___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127820___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127821___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127821___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127821___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127821___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127821___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127821___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127822___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127822___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127822___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127822___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127822___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127822___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127823___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127823___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127823___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127823___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127823___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127823___DOT__CO__BRA__0__KET__ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___025709_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                                >> 0x10U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                                 >> 0x10U))))));
    vlSelf->wasmetal_core__DOT___025708_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                                >> 0xfU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                                 >> 0xfU))))));
    wasmetal_core__DOT___025707_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 0xeU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 0xeU))))));
    wasmetal_core__DOT___025706_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 0xdU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 0xdU))))));
    wasmetal_core__DOT___025704_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 0xcU))))));
    wasmetal_core__DOT___025703_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 0xbU))))));
    wasmetal_core__DOT___025702_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 0xaU))))));
    wasmetal_core__DOT___025701_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 9U))))));
    wasmetal_core__DOT___025700_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 8U))))));
    wasmetal_core__DOT___025699_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 7U))))));
    wasmetal_core__DOT___025698_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 6U))))));
    wasmetal_core__DOT___025697_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 5U))))));
    wasmetal_core__DOT___025696_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 4U))))));
    wasmetal_core__DOT___025695_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 3U))))));
    wasmetal_core__DOT___025693_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 2U))))));
    wasmetal_core__DOT___025692_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                               >> 1U))))));
    wasmetal_core__DOT___025691_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___135074_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum)))));
    vlSelf->wasmetal_core__DOT___026110_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                                >> 0x10U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                                 >> 0x10U))))));
    vlSelf->wasmetal_core__DOT___026109_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                                >> 0xfU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                                 >> 0xfU))))));
    wasmetal_core__DOT___026108_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 0xeU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 0xeU))))));
    wasmetal_core__DOT___026107_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 0xdU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 0xdU))))));
    wasmetal_core__DOT___026105_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 0xcU))))));
    wasmetal_core__DOT___026104_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 0xbU))))));
    wasmetal_core__DOT___026103_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 0xaU))))));
    wasmetal_core__DOT___026102_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 9U))))));
    wasmetal_core__DOT___026101_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 8U))))));
    wasmetal_core__DOT___026100_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 7U))))));
    wasmetal_core__DOT___026099_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 6U))))));
    wasmetal_core__DOT___026098_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 5U))))));
    wasmetal_core__DOT___026097_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 4U))))));
    wasmetal_core__DOT___026096_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 3U))))));
    wasmetal_core__DOT___026094_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 2U))))));
    wasmetal_core__DOT___026093_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                               >> 1U))))));
    wasmetal_core__DOT___026092_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134226_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum)))));
    wasmetal_core__DOT___127796___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025691_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127796___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum)));
    wasmetal_core__DOT___127820___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026092_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127820___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum)));
    wasmetal_core__DOT___127796___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025692_)
                  ? (IData)(wasmetal_core__DOT___127796___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                             >> 1U))));
    wasmetal_core__DOT___127820___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026093_)
                  ? (IData)(wasmetal_core__DOT___127820___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 1U))));
    wasmetal_core__DOT____Vcellout___127796___O = (
                                                   (((IData)(wasmetal_core__DOT___025693_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025692_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025691_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___025690_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127796___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127796___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127796___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___025616_)))));
    wasmetal_core__DOT___025620_ = (1U & ((IData)(wasmetal_core__DOT___025693_)
                                           ? (IData)(wasmetal_core__DOT___127796___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                      >> 2U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127820___O 
        = ((((IData)(wasmetal_core__DOT___026094_) 
             << 3U) | (((IData)(wasmetal_core__DOT___026093_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___026092_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026091_)))) 
           ^ (((IData)(wasmetal_core__DOT___127820___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127820___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127820___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026043_)))));
    wasmetal_core__DOT___026047_ = (1U & ((IData)(wasmetal_core__DOT___026094_)
                                           ? (IData)(wasmetal_core__DOT___127820___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                      >> 2U))));
    wasmetal_core__DOT___025433_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127796___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025422_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127796___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025411_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127796___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___127797___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025695_)
                  ? (IData)(wasmetal_core__DOT___025620_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                             >> 3U))));
    wasmetal_core__DOT___067671_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067668_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128253___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___060785_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_ha7da5f58__0))))));
    wasmetal_core__DOT___056679_ = (1U & (0xcfafU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___056675_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127684___O)) 
                                                    | (1U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127743___O 
        = (((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                   << 3U)) | (7U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127819___O) 
                                    >> 1U))) ^ (((IData)(vlSelf->wasmetal_core__DOT___127743___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___127743___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___127743___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___024965_)))));
    wasmetal_core__DOT___024969_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127743___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___025931_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025920_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025909_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___127821___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026096_)
                  ? (IData)(wasmetal_core__DOT___026047_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 3U))));
    wasmetal_core__DOT___127765___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(wasmetal_core__DOT___025411_)) 
                 & ((IData)(wasmetal_core__DOT____Vcellout___127796___O) 
                    >> 1U)));
    wasmetal_core__DOT___127797___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025696_)
                  ? (IData)(wasmetal_core__DOT___127797___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                             >> 4U))));
    vlSelf->wasmetal_core__DOT___067678_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xff1f00000000ULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___067671_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067670_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067669_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___064515_)))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf033f0f0ffffff55ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdb0eb761__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07a6aef0__0)))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048287_)))));
    vlSelf->wasmetal_core__DOT___060789_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060786_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___060785_)))));
    wasmetal_core__DOT___127806___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(wasmetal_core__DOT___025909_)) 
                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                    >> 1U)));
    wasmetal_core__DOT___127821___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026097_)
                  ? (IData)(wasmetal_core__DOT___127821___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 4U))));
    wasmetal_core__DOT___127765___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025422_)
                  ? (IData)(wasmetal_core__DOT___127765___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127796___O) 
                     >> 2U)));
    wasmetal_core__DOT___127797___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025697_)
                  ? (IData)(wasmetal_core__DOT___127797___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                             >> 5U))));
    wasmetal_core__DOT___127806___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025920_)
                  ? (IData)(wasmetal_core__DOT___127806___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                     >> 2U)));
    wasmetal_core__DOT___127821___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026098_)
                  ? (IData)(wasmetal_core__DOT___127821___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 5U))));
    wasmetal_core__DOT___127765___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025433_)
                  ? (IData)(wasmetal_core__DOT___127765___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127796___O) 
                     >> 3U)));
    wasmetal_core__DOT____Vcellout___127797___O = (
                                                   (((IData)(wasmetal_core__DOT___025698_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025697_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025696_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025695_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127797___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127797___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127797___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025620_)))));
    wasmetal_core__DOT___025625_ = (1U & ((IData)(wasmetal_core__DOT___025698_)
                                           ? (IData)(wasmetal_core__DOT___127797___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                      >> 6U))));
    wasmetal_core__DOT___127806___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025931_)
                  ? (IData)(wasmetal_core__DOT___127806___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127820___O) 
                     >> 3U)));
    wasmetal_core__DOT____Vcellout___127821___O = (
                                                   (((IData)(wasmetal_core__DOT___026099_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___026098_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___026097_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026096_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127821___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127821___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127821___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026047_)))));
    wasmetal_core__DOT___026052_ = (1U & ((IData)(wasmetal_core__DOT___026099_)
                                           ? (IData)(wasmetal_core__DOT___127821___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                      >> 6U))));
    wasmetal_core__DOT___025477_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127797___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025466_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127797___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025455_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127797___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025444_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127797___O)))));
    wasmetal_core__DOT___127798___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025699_)
                  ? (IData)(wasmetal_core__DOT___025625_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                             >> 7U))));
    wasmetal_core__DOT___025935_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127821___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025934_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127821___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025933_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127821___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025932_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127821___O)))));
    wasmetal_core__DOT___127822___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026100_)
                  ? (IData)(wasmetal_core__DOT___026052_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 7U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127765___O 
        = ((((IData)(wasmetal_core__DOT___025444_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025433_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025422_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025411_)))) 
           ^ (((IData)(wasmetal_core__DOT___127765___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127765___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___127765___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    wasmetal_core__DOT___025372_ = (1U & ((IData)(wasmetal_core__DOT___025444_)
                                           ? (IData)(wasmetal_core__DOT___127765___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127797___O)));
    wasmetal_core__DOT___127798___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025700_)
                  ? (IData)(wasmetal_core__DOT___127798___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                             >> 8U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127806___O 
        = ((((IData)(wasmetal_core__DOT___025932_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025931_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025920_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025909_)))) 
           ^ (((IData)(wasmetal_core__DOT___127806___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127806___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___127806___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    wasmetal_core__DOT___025902_ = (1U & ((IData)(wasmetal_core__DOT___025932_)
                                           ? (IData)(wasmetal_core__DOT___127806___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127821___O)));
    wasmetal_core__DOT___127822___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026101_)
                  ? (IData)(wasmetal_core__DOT___127822___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 8U))));
    wasmetal_core__DOT___127774___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025455_)
                  ? (IData)(wasmetal_core__DOT___025372_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127797___O) 
                     >> 1U)));
    wasmetal_core__DOT___127798___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025701_)
                  ? (IData)(wasmetal_core__DOT___127798___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                             >> 9U))));
    wasmetal_core__DOT___067737_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067734_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128253___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___067761_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067758_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128253___O)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___067823_ = ((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                    & (IData)((0x153f00000000ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___019399_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019398_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128254___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    vlSelf->wasmetal_core__DOT___067914_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___067906_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128254___O) 
                                                                           << 2U)) 
                                                                       | ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                                              >> 1U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x5533f00000000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065178_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___066763_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067905_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xcfaf0f0f00000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067899_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067898_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067897_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                                << 2U)) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hcf95a844__0))))))))))));
    wasmetal_core__DOT___061034_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h29bca591__0))))));
    wasmetal_core__DOT___060948_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9cbd3d8a__0))))));
    wasmetal_core__DOT___060872_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb372eb0f__0))))));
    wasmetal_core__DOT___061115_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                        >> 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h93fbfa25__0))))));
    wasmetal_core__DOT___012281_ = (1U & (IData)((0xf3f5f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0x1d1d00000f55ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056241_)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127684___O) 
                                                                   >> 2U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                                     >> 1U))))))))));
    wasmetal_core__DOT___127744___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
           & (IData)(wasmetal_core__DOT___024969_));
    wasmetal_core__DOT___127807___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025933_)
                  ? (IData)(wasmetal_core__DOT___025902_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127821___O) 
                     >> 1U)));
    wasmetal_core__DOT___127822___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026102_)
                  ? (IData)(wasmetal_core__DOT___127822___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 9U))));
    wasmetal_core__DOT___127774___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025466_)
                  ? (IData)(wasmetal_core__DOT___127774___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127797___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127798___O = (
                                                   (((IData)(wasmetal_core__DOT___025702_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025701_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025700_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025699_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127798___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127798___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127798___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025625_)))));
    wasmetal_core__DOT___025629_ = (1U & ((IData)(wasmetal_core__DOT___025702_)
                                           ? (IData)(wasmetal_core__DOT___127798___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                      >> 0xaU))));
    vlSelf->wasmetal_core__DOT___067743_ = (1U & (IData)(
                                                         (0xff1f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___067737_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067736_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067735_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064747_)))))))));
    vlSelf->wasmetal_core__DOT___067767_ = (1U & (IData)(
                                                         (0xff1f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___067761_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067760_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067759_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064913_)))))))));
    vlSelf->wasmetal_core__DOT___067826_ = (1U & (IData)(
                                                         (0xff1f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___067823_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067822_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067821_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065083_)))))))));
    vlSelf->wasmetal_core__DOT___061041_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061035_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___061034_)))));
    vlSelf->wasmetal_core__DOT___060952_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060949_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___060948_)))));
    vlSelf->wasmetal_core__DOT___060876_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060873_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___060872_)))));
    vlSelf->wasmetal_core__DOT___061122_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061116_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___061115_)))));
    vlSelf->wasmetal_core__DOT___057022_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010077_)) 
                                                  & (IData)(
                                                            (0xfff0fffeff00ff00ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___012283_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012282_) 
                                                                  << 4U) 
                                                                 | (((IData)(wasmetal_core__DOT___012281_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012280_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))));
    wasmetal_core__DOT___127744___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127744___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127807___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025934_)
                  ? (IData)(wasmetal_core__DOT___127807___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127821___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127822___O = (
                                                   (((IData)(wasmetal_core__DOT___026103_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___026102_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___026101_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026100_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127822___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127822___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127822___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026052_)))));
    wasmetal_core__DOT___026056_ = (1U & ((IData)(wasmetal_core__DOT___026103_)
                                           ? (IData)(wasmetal_core__DOT___127822___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                      >> 0xaU))));
    wasmetal_core__DOT___127774___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025477_)
                  ? (IData)(wasmetal_core__DOT___127774___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127797___O) 
                     >> 3U)));
    wasmetal_core__DOT___025412_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127798___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025482_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127798___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025481_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127798___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025480_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127798___O)))));
    wasmetal_core__DOT___127799___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025703_)
                  ? (IData)(wasmetal_core__DOT___025629_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                             >> 0xbU))));
    wasmetal_core__DOT___127744___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127744___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127807___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025935_)
                  ? (IData)(wasmetal_core__DOT___127807___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127821___O) 
                     >> 3U)));
    wasmetal_core__DOT___025910_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127822___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025938_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127822___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025937_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127822___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025936_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127822___O)))));
    wasmetal_core__DOT___127823___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026104_)
                  ? (IData)(wasmetal_core__DOT___026056_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 0xbU))));
    vlSelf->wasmetal_core__DOT____Vcellout___127774___O 
        = ((((IData)(wasmetal_core__DOT___025480_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025477_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025466_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025455_)))) 
           ^ (((IData)(wasmetal_core__DOT___127774___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127774___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127774___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025372_)))));
    wasmetal_core__DOT___025408_ = (1U & ((IData)(wasmetal_core__DOT___025480_)
                                           ? (IData)(wasmetal_core__DOT___127774___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127798___O)));
    wasmetal_core__DOT___127799___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025704_)
                  ? (IData)(wasmetal_core__DOT___127799___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                             >> 0xcU))));
    vlSelf->wasmetal_core__DOT____Vcellout___127744___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
           ^ (((IData)(wasmetal_core__DOT___127744___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127744___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127744___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024969_)))));
    wasmetal_core__DOT___024974_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127744___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127807___O 
        = ((((IData)(wasmetal_core__DOT___025936_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025935_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025934_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025933_)))) 
           ^ (((IData)(wasmetal_core__DOT___127807___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127807___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127807___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025902_)))));
    wasmetal_core__DOT___025906_ = (1U & ((IData)(wasmetal_core__DOT___025936_)
                                           ? (IData)(wasmetal_core__DOT___127807___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127822___O)));
    wasmetal_core__DOT___127823___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026105_)
                  ? (IData)(wasmetal_core__DOT___127823___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 0xcU))));
    vlSelf->wasmetal_core__DOT___058152_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127774___O) 
                                                               << 4U)) 
                                                           | ((0xcU 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127765___O)) 
                                                              | ((2U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127796___O) 
                                                                     << 1U)) 
                                                                 | (1U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127795___O) 
                                                                       >> 3U))))))));
    wasmetal_core__DOT___127775___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025481_)
                  ? (IData)(wasmetal_core__DOT___025408_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127798___O) 
                     >> 1U)));
    wasmetal_core__DOT___127799___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025706_)
                  ? (IData)(wasmetal_core__DOT___127799___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                             >> 0xdU))));
    wasmetal_core__DOT___012516_ = (1U & (4U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127744___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010077_))));
    vlSelf->wasmetal_core__DOT___068033_ = ((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                            & (IData)(
                                                      (0x153f00000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019404_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019403_) 
                                                            << 4U) 
                                                           | ((8U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128254___O)) 
                                                              | ((4U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___068086_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068083_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128240___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    vlSelf->wasmetal_core__DOT___067980_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___067972_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128254___O) 
                                                                           << 1U)) 
                                                                       | ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x5533f00000000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065294_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___066846_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067971_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xcfaf0f0f00000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067965_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067964_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067963_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                                << 2U)) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h58f52bdc__0))))))))))));
    wasmetal_core__DOT___068111_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068108_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128240___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    vlSelf->wasmetal_core__DOT___060780_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9d165bb7__0))))));
    vlSelf->wasmetal_core__DOT___060660_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb9d2a0bf__0))))));
    vlSelf->wasmetal_core__DOT___061197_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7e30f70e__0))))));
    vlSelf->wasmetal_core__DOT___057488_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x1d1d00000f55ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012954_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xcfaf0000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127685___O) 
                                                                          >> 1U)) 
                                                                      | (1U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O))))))))))));
    wasmetal_core__DOT___056692_ = (1U & (IData)((0xf3f5f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0x1d1d00000f55ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056249_)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127671___O)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                                     >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___056394_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x88bb8888a0afa0a0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056038_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127671___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___060696_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd3c93d4d__0))))));
    wasmetal_core__DOT___127745___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
           & (IData)(wasmetal_core__DOT___024974_));
    wasmetal_core__DOT___127808___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025937_)
                  ? (IData)(wasmetal_core__DOT___025906_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127822___O) 
                     >> 1U)));
    wasmetal_core__DOT___127823___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026107_)
                  ? (IData)(wasmetal_core__DOT___127823___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 0xdU))));
    wasmetal_core__DOT___127775___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025482_)
                  ? (IData)(wasmetal_core__DOT___127775___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127798___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127799___O = (
                                                   (((IData)(wasmetal_core__DOT___025707_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025706_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025704_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025703_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127799___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127799___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127799___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025629_)))));
    vlSelf->wasmetal_core__DOT___025634_ = (1U & ((IData)(wasmetal_core__DOT___025707_)
                                                   ? (IData)(wasmetal_core__DOT___127799___DOT__CO__BRA__2__KET__)
                                                   : (IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                                                              >> 0xeU))));
    vlSelf->wasmetal_core__DOT___068091_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068086_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065623_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066965_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068076_)))))))))))));
    wasmetal_core__DOT___068116_ = (1U & (IData)((0x5f3f00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___068111_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068110_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___065711_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067070_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___068101_)))))))))))));
    vlSelf->wasmetal_core__DOT___060814_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___060785_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060780_)))));
    vlSelf->wasmetal_core__DOT___060662_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060661_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060660_)))));
    vlSelf->wasmetal_core__DOT___061204_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061198_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061197_)))));
    vlSelf->wasmetal_core__DOT___011739_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010092_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010077_)
                                                      ? 
                                                     (0x3f5fU 
                                                      >> 
                                                      ((8U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0x5555333300f000ffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056684_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056044_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O) 
                                                                                >> 1U))))))))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0x5555333300f000ffULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056696_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056243_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128555___O) 
                                                                                >> 1U))))))))))))))
                                                      : 
                                                     (0x5f3fU 
                                                      >> 
                                                      ((8U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ff0000f1f1ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056680_) 
                                                                               << 4U) 
                                                                              | (((IData)(wasmetal_core__DOT___056679_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((~ (IData)(vlSelf->wasmetal_core__DOT___010376_)) 
                                                                                & (IData)(
                                                                                (0xfffaff33ff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011765_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011764_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011252_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011763_))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127684___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))))))))))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xffffffffff000e00ULL 
                                                                           >> 
                                                                           (((IData)(wasmetal_core__DOT___056692_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056691_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127671___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056689_))))))))))))))));
    vlSelf->wasmetal_core__DOT___060704_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060697_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060696_)))));
    wasmetal_core__DOT___127745___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127745___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127808___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025938_)
                  ? (IData)(wasmetal_core__DOT___127808___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127822___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127823___O = (
                                                   (((IData)(wasmetal_core__DOT___026108_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___026107_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___026105_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026104_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127823___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127823___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127823___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026056_)))));
    vlSelf->wasmetal_core__DOT___026061_ = (1U & ((IData)(wasmetal_core__DOT___026108_)
                                                   ? (IData)(wasmetal_core__DOT___127823___DOT__CO__BRA__2__KET__)
                                                   : (IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                                                              >> 0xeU))));
    wasmetal_core__DOT___127775___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025412_)
                  ? (IData)(wasmetal_core__DOT___127775___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127798___O) 
                     >> 3U)));
    vlSelf->wasmetal_core__DOT___025416_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                                >> 0xeU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127799___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___025415_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                                >> 0xdU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127799___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___025414_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                                >> 0xcU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127799___O) 
                                                         >> 1U)))));
    wasmetal_core__DOT___025413_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___135065_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127799___O)))));
    vlSelf->wasmetal_core__DOT___127800___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025708_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___025634_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                             >> 0xfU))));
    vlSelf->wasmetal_core__DOT___068145_ = (1U & (IData)(
                                                         (0xf0f0f010f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068116_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068115_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068114_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf033f0f0ffffff55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he278c168__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048287_)))))))));
    wasmetal_core__DOT___127745___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127745___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127808___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025910_)
                  ? (IData)(wasmetal_core__DOT___127808___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127822___O) 
                     >> 3U)));
    vlSelf->wasmetal_core__DOT___025914_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                                >> 0xeU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127823___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___025913_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                                >> 0xdU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127823___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___025912_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                                >> 0xcU)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127823___O) 
                                                         >> 1U)))));
    wasmetal_core__DOT___025911_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127823___O)))));
    vlSelf->wasmetal_core__DOT___127824___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___026109_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___026061_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 0xfU))));
    vlSelf->wasmetal_core__DOT____Vcellout___127775___O 
        = ((((IData)(wasmetal_core__DOT___025413_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025412_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025482_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025481_)))) 
           ^ (((IData)(wasmetal_core__DOT___127775___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127775___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127775___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025408_)))));
    vlSelf->wasmetal_core__DOT___025341_ = (1U & ((IData)(wasmetal_core__DOT___025413_)
                                                   ? (IData)(wasmetal_core__DOT___127775___DOT__CO__BRA__2__KET__)
                                                   : (IData)(wasmetal_core__DOT____Vcellout___127799___O)));
    vlSelf->wasmetal_core__DOT___127800___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025709_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127800___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___135071_.__PVT__alu_sum 
                             >> 0x10U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127745___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
           ^ (((IData)(wasmetal_core__DOT___127745___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127745___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127745___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024974_)))));
    wasmetal_core__DOT___024978_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127745___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127808___O 
        = ((((IData)(wasmetal_core__DOT___025911_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025910_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025938_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025937_)))) 
           ^ (((IData)(wasmetal_core__DOT___127808___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127808___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127808___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025906_)))));
    vlSelf->wasmetal_core__DOT___025881_ = (1U & ((IData)(wasmetal_core__DOT___025911_)
                                                   ? (IData)(wasmetal_core__DOT___127808___DOT__CO__BRA__2__KET__)
                                                   : (IData)(wasmetal_core__DOT____Vcellout___127823___O)));
    vlSelf->wasmetal_core__DOT___127824___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___026110_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127824___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134224_.__PVT__alu_sum 
                             >> 0x10U))));
    vlSelf->wasmetal_core__DOT___127776___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025414_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___025341_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127799___O) 
                     >> 1U)));
    vlSelf->wasmetal_core__DOT___011155_ = (1U & ((0x3f5f0000U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_ha1697357__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                      ? 
                                                     (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___011162_))
                                                      : (IData)(
                                                                (0xf0fff0fff0fffeffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011163_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011162_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0x5300U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf1111U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056567_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((~ (IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127732___O)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                                                >> 1U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_))))))))) 
                                                                                & (IData)(
                                                                                (0x57f757f755ff7777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011169_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O) 
                                                                                >> 1U))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x50cU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011255_))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010084_)
                                                                                 ? (IData)(
                                                                                (0xff0000000bULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011255_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011254_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011253_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011252_))))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011255_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011254_))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127680___O)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O)))))))
                                                                                 : 
                                                                                (0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011249_)))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((~ (IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127730___O)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                                                >> 1U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_))))))))) 
                                                                                & (IData)(
                                                                                (0x57f757f755ff7777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011249_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O) 
                                                                                >> 1U))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00f055553333ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056588_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((~ (IData)(
                                                                                (0xff00bb00ff000f00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056574_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056573_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127678___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_))))))))) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                                 ? (IData)(
                                                                                (0xfdfd5d5dffdd55ddULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011276_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011275_))))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011275_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xfff1ff00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056581_) 
                                                                                << 3U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xcccc5f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h65ab9fde__0)))
                                                                                 : 
                                                                                (0xcccc5f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h65ab9fde__0))))) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xff00f4f4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127719___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043735_)))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff11ff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056584_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0x55cf5500U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011285_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2858a73f__0))))
                                                                                 : 
                                                                                (0x55cf5500U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011285_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2858a73f__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056576_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 1U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))))))))))))))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xf0feULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf3f5U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127745___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127743___O) 
                                                                                >> 2U)))))))))))))) 
                                                                                << 1U)) 
                                                                              | ((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                                & ((~ (IData)(
                                                                                (0xfff1f100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056628_) 
                                                                                << 3U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                & (IData)(
                                                                                (0xff0f0f11111111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011293_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011656_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h95aabd6f__0)))))))) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056626_))))))))) 
                                                                                & (IData)(
                                                                                (0xff00ff00fffcfffaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x7fffU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127741___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h22919fe9__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x7fffU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127736___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h22919fe9__0)))))))))))))))))))))));
    vlSelf->__VdfgTmp_h09a23322__0 = ((4U & ((IData)(
                                                     (0xfcfaf0f0ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056543_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0xca00U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___056541_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h98124bc4__0)))) 
                                                                    << 2U)) 
                                                                | (IData)(vlSelf->__VdfgTmp_h7c4aea26__0))))))) 
                                             << 2U)) 
                                      | ((2U & ((IData)(
                                                        (0xff00f000ff00ee00ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056766_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((IData)(
                                                                               (0xff00aaaaf0f03333ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O) 
                                                                                << 1U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128541___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d)))))))) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((IData)(
                                                                                (0xf0f0f0fd00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056739_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xe00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0faa3300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf044U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010058_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127678___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 0xaU)))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xfff11ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056712_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x774477775f505f5fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056708_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127728___O) 
                                                                                >> 3U)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xcc0035U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                                                >> 2U))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009691_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127741___O) 
                                                                                >> 3U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011074_)))))))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O)) 
                                                                            & (IData)(
                                                                                (0xff00ff00fff0fffeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011885_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xdfdddddf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00fff400000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056750_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc7be7ce5__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127736___O) 
                                                                                >> 3U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009692_))))))))))))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056824_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056823_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0ff11ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x153f113315151111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056814_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056813_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056812_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x1d1d00000f55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055888_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf00bb00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf00bb00ff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xa0cU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00bb00ff000fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056791_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056790_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127680___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf0f055ccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055888_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                                                >> 2U)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127730___O) 
                                                                                >> 3U)))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f000ee00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056808_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f055ccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055954_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                                                >> 2U)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127732___O) 
                                                                                >> 3U))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xbbbbf0ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012023_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127682___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_)))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f3f0f5ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127745___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha271a2f2__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x10U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127743___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha271a2f2__0))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x70U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012015_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x1101ff0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012929_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056783_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0fff1100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7884ece4__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056780_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056779_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___056540_ = (1U & (IData)(
                                                         (0xef000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056529_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056528_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009691_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xefeeeeef00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x4f44U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xf0f000eeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011093_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3b8e8d7c__0))))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011092_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012929_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xf0f000eeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011130_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011128_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac971038__0)))))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011129_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056272_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xc0000000aULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127745___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127743___O) 
                                                                                >> 1U))))))))))))))))));
    wasmetal_core__DOT___068162_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068159_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128240___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___068247_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068244_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128240___O)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___068300_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068297_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128241___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___068354_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068351_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128241___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    vlSelf->wasmetal_core__DOT___061032_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h34f2d08e__0))))));
    vlSelf->wasmetal_core__DOT___060943_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h31aacdc1__0))))));
    vlSelf->wasmetal_core__DOT___060867_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3fcf358e__0))))));
    vlSelf->wasmetal_core__DOT___061113_ = (1U & (0xf0f5533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4ce8c3b1__0))))));
    wasmetal_core__DOT___127746___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
           & (IData)(wasmetal_core__DOT___024978_));
    vlSelf->wasmetal_core__DOT___057154_ = (1U & (IData)(
                                                         (0xf00ee00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___010077_)
                                                                          ? 
                                                                         (0x31U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((0xfdd0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056057_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127721___O)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O))))))))))))))))
                                                                          : 
                                                                         (0xff0eU 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((IData)(
                                                                                (0xccaaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056057_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                                                >> 2U))))))))) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & (((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010085_)
                                                                                 ? 
                                                                                (0xf0f3f0f5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012443_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012442_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012440_))))))
                                                                                 : 
                                                                                (0xcdccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012443_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012441_))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x4f00U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O))))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f000000ddULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057139_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xccaaf0f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056237_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127685___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                                                >> 2U))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xd0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O))))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccfff0fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057143_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127735___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025912_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___025881_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127823___O) 
                     >> 1U)));
    vlSelf->wasmetal_core__DOT___127776___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025415_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127776___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127799___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT___068167_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068162_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068161_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065813_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067148_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068152_)))))))))))));
    vlSelf->wasmetal_core__DOT___068252_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068246_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065909_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067189_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068237_)))))))))))));
    vlSelf->wasmetal_core__DOT___068305_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068300_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068299_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065943_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067303_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068290_)))))))))))));
    vlSelf->wasmetal_core__DOT___068359_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068354_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068353_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066088_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067333_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068344_)))))))))))));
    vlSelf->wasmetal_core__DOT___061056_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___061034_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061032_)))));
    vlSelf->wasmetal_core__DOT___060967_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___060948_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060943_)))));
    vlSelf->wasmetal_core__DOT___060897_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___060872_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___060867_)))));
    vlSelf->wasmetal_core__DOT___061135_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___061115_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061113_)))));
    wasmetal_core__DOT___127746___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127746___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025913_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127823___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT___127776___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025416_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127776___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127799___O) 
                     >> 3U)));
    wasmetal_core__DOT___127746___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127746___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___025914_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127823___O) 
                     >> 3U)));
    vlSelf->wasmetal_core__DOT____Vcellout___127746___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
           ^ (((IData)(wasmetal_core__DOT___127746___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127746___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127746___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024978_)))));
    vlSelf->wasmetal_core__DOT___024983_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127746___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___012884_ = (1U & (IData)((0x7fff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127746___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h238f5c0e__0))))));
    wasmetal_core__DOT___012515_ = (1U & (4U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127746___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010077_))));
    vlSelf->wasmetal_core__DOT___057377_ = (1U & (IData)(
                                                         (0xf0f0f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057372_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___011740_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___010092_)) 
                                                                            & (IData)(
                                                                                (0xff5757ff03030303ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012497_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012663_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012662_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012661_))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___011074_)
                                                                              ? (IData)(
                                                                                (0x8a0000cfcfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012662_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012694_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012663_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x7fff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127746___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h238f5c0e__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127744___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))))))
                                                                              : 
                                                                             (1U 
                                                                              >> (IData)(vlSelf->wasmetal_core__DOT___012694_))))))))))));
    vlSelf->wasmetal_core__DOT___012768_ = (1U & (IData)(
                                                         (0xff00ff00ff007000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057461_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xf0f0ccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010972_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (((~ (IData)(vlSelf->wasmetal_core__DOT___010092_)) 
                                                                            & (IData)(
                                                                                (0xff5757ff03030303ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012497_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012862_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012861_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012661_))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___012861_)
                                                                              ? 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___011074_)
                                                                               ? (IData)(
                                                                                (0x8808aa0aaa0aULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012885_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___012884_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012862_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012883_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x7fff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127744___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h238f5c0e__0)))))))))))))
                                                                               : 
                                                                              (0x2fU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012885_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012883_)))))
                                                                              : 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___011074_)
                                                                               ? 
                                                                              (0xdddU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012885_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___012884_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012862_)))))
                                                                               : 
                                                                              (7U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012885_))))))))))))));
    vlSelf->wasmetal_core__DOT___012470_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___009681_)) 
                                                  & (IData)(
                                                            (0x40cc40cc40ccf0ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___012471_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012499_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011074_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & (((1U 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O))
                                                                             ? 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___009693_)
                                                                              ? 
                                                                             (0xf1U 
                                                                              >> 
                                                                              (((IData)(wasmetal_core__DOT___012515_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___012512_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012511_))))
                                                                              : 
                                                                             (2U 
                                                                              >> (IData)(wasmetal_core__DOT___012515_)))
                                                                             : 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___009693_)
                                                                              ? 
                                                                             (0xf1U 
                                                                              >> 
                                                                              (((IData)(wasmetal_core__DOT___012516_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___012514_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012513_))))
                                                                              : 
                                                                             (2U 
                                                                              >> (IData)(wasmetal_core__DOT___012516_)))) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012497_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___012496_))))))))));
}
