#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__8(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__8\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___002594_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048745_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9eae91ba__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___002595_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d))))));
    vlSelf->wasmetal_core__DOT___002555_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048534_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h76527ded__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8df5578a__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___002556_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d))))));
    vlSelf->wasmetal_core__DOT___003135_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048023_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048022_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048021_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048020_)))))))));
    vlSelf->wasmetal_core__DOT___003221_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048135_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048136_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048138_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048137_)))))))));
    vlSelf->wasmetal_core__DOT___004771_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048038_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048039_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048035_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048034_)))))))));
    vlSelf->wasmetal_core__DOT___004697_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048153_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048152_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048151_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048150_)))))))));
    vlSelf->wasmetal_core__DOT___048628_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff000b0bffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048626_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he5858a3c__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005496_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005497_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b55__05d)))))))));
    if (vlSelf->wasmetal_core__DOT__simd_phase) {
        vlSelf->wasmetal_core__DOT___048148_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b55__05d)));
        vlSelf->wasmetal_core__DOT___005427_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b56__05d)));
        vlSelf->wasmetal_core__DOT___005428_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b57__05d)));
        vlSelf->wasmetal_core__DOT___048208_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b59__05d)));
    } else if (vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) {
        vlSelf->wasmetal_core__DOT___048148_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005497_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005496_)))));
        vlSelf->wasmetal_core__DOT___005427_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005437_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005436_)))));
        vlSelf->wasmetal_core__DOT___005428_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005447_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005446_)))));
        vlSelf->wasmetal_core__DOT___048208_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005400_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005399_)))));
    } else {
        vlSelf->wasmetal_core__DOT___048148_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_he5858a3c__0))));
        vlSelf->wasmetal_core__DOT___005427_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc3acb233__0))));
        vlSelf->wasmetal_core__DOT___005428_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hcea60642__0))));
        vlSelf->wasmetal_core__DOT___048208_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9462500e__0))));
    }
    vlSelf->wasmetal_core__DOT___048611_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff000b0bffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048609_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc3acb233__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005436_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005437_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___004475_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048031_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048030_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048029_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048028_)))))))));
    vlSelf->wasmetal_core__DOT___048616_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff000b0bffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048614_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcea60642__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005446_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005447_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b57__05d)))))))));
    vlSelf->wasmetal_core__DOT___048599_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048597_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005389_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005390_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005387_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005388_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b58__05d)))))))));
    vlSelf->__VdfgTmp_h5dfa9ecf__0 = (((IData)(vlSelf->wasmetal_core__DOT___005388_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005387_));
    vlSelf->wasmetal_core__DOT___048604_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff000b0bffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048602_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9462500e__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005399_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005400_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___048658_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048656_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005409_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005410_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005407_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005408_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b60__05d)))))))));
    vlSelf->__VdfgTmp_hb5adad38__0 = (((IData)(vlSelf->wasmetal_core__DOT___005408_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005407_));
    vlSelf->wasmetal_core__DOT___048653_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048651_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005419_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005420_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005417_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005418_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b61__05d)))))))));
    vlSelf->__VdfgTmp_h65f01eca__0 = (((IData)(vlSelf->wasmetal_core__DOT___005418_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005417_));
    vlSelf->__VdfgTmp_he9d835d5__0 = ((2U & ((0xe0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___047990_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047989_)))) 
                                             << 1U)) 
                                      | (1U & (0xeU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb85239a7__0)))));
    vlSelf->wasmetal_core__DOT___004327_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048157_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048156_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048155_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048154_)))))))));
    vlSelf->wasmetal_core__DOT___048668_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048666_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005456_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005457_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005454_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005455_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b62__05d)))))))));
    vlSelf->__VdfgTmp_hd81cbf50__0 = (((IData)(vlSelf->wasmetal_core__DOT___005455_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005454_));
    vlSelf->wasmetal_core__DOT___004401_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048012_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048013_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048015_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048014_)))))))));
    vlSelf->wasmetal_core__DOT___003134_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048022_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048023_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha59547bb__0))))))));
    vlSelf->wasmetal_core__DOT___005553_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha59547bb__0))));
    vlSelf->wasmetal_core__DOT___003133_ = (1U & (IData)(
                                                         (0xeeee0000fff0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048021_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048020_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha8427a44__0))))))));
    vlSelf->wasmetal_core__DOT___005554_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha8427a44__0))));
    vlSelf->wasmetal_core__DOT___005651_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09328eec__0))));
    vlSelf->__VdfgTmp_h534a5d27__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048136_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048135_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h09328eec__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048138_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048137_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hf92587e4__0))))))))));
    vlSelf->wasmetal_core__DOT___005652_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf92587e4__0))));
    vlSelf->wasmetal_core__DOT___005659_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8dbe6334__0))));
    vlSelf->__VdfgTmp_hd09f2908__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048039_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048038_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h8dbe6334__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048035_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048034_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h59e987ab__0))))))))));
    vlSelf->wasmetal_core__DOT___005660_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h59e987ab__0))));
    vlSelf->wasmetal_core__DOT___004549_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048067_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048066_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048065_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048064_)))))))));
    vlSelf->wasmetal_core__DOT___005647_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7d4fca25__0))));
    vlSelf->__VdfgTmp_hfcbc0180__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048152_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048153_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h7d4fca25__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048151_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048150_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hd1b03413__0))))))))));
    vlSelf->wasmetal_core__DOT___005648_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd1b03413__0))));
    vlSelf->wasmetal_core__DOT___003733_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048196_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048195_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048194_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048193_)))))))));
    vlSelf->wasmetal_core__DOT___048635_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048633_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005466_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005467_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005464_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005465_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b52__05d)))))))));
    vlSelf->__VdfgTmp_h63c99640__0 = (((IData)(vlSelf->wasmetal_core__DOT___005465_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005464_));
    vlSelf->wasmetal_core__DOT___005117_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048071_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048070_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048069_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048068_)))))))));
    vlSelf->__VdfgTmp_hc2abfe6d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005496_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005497_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048071_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048070_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048069_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048068_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_he5858a3c__0))))))))));
    vlSelf->wasmetal_core__DOT___005557_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82d77f97__0))));
    vlSelf->__VdfgTmp_h627c070d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048030_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048031_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h82d77f97__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048029_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048028_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h6e7f092f__0))))))))));
    vlSelf->wasmetal_core__DOT___005558_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6e7f092f__0))));
    vlSelf->wasmetal_core__DOT___048640_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048638_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005476_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005477_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005474_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005475_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b53__05d)))))))));
    vlSelf->__VdfgTmp_h5779821b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005475_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005474_));
    vlSelf->wasmetal_core__DOT___048623_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048621_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005486_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005487_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005484_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005485_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b54__05d)))))))));
    vlSelf->__VdfgTmp_hd852066e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005485_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005484_));
    vlSelf->wasmetal_core__DOT___005049_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048176_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048175_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048174_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048173_)))))))));
    vlSelf->__VdfgTmp_h04914456__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005436_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005437_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048176_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048175_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048174_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048173_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hc3acb233__0))))))))));
    vlSelf->wasmetal_core__DOT___005321_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048245_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048244_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048243_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048242_)))))))));
    vlSelf->__VdfgTmp_hea3adbd3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005446_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005447_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048245_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048244_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048243_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048242_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hcea60642__0))))))))));
    vlSelf->wasmetal_core__DOT___005541_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf0176237__0))));
    vlSelf->__VdfgTmp_h4ff79496__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048156_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048157_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hf0176237__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048155_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048154_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_ha7dc0a46__0))))))))));
    vlSelf->wasmetal_core__DOT___005542_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha7dc0a46__0))));
    vlSelf->wasmetal_core__DOT___003585_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048230_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048231_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048233_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048232_)))))))));
    vlSelf->wasmetal_core__DOT___004913_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048178_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048177_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048180_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048179_)))))))));
    vlSelf->wasmetal_core__DOT___004981_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048259_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048258_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048257_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048256_)))))))));
    vlSelf->__VdfgTmp_h6305c07b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005399_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005400_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048259_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048258_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048257_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048256_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h9462500e__0))))))))));
    vlSelf->wasmetal_core__DOT___005549_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbacded4f__0))));
    vlSelf->__VdfgTmp_h3bba44d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048013_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048012_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hbacded4f__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048015_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048014_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h2937d10d__0))))))))));
    vlSelf->wasmetal_core__DOT___005550_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2937d10d__0))));
    vlSelf->wasmetal_core__DOT___004845_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048184_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048183_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048182_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048181_)))))))));
    vlSelf->wasmetal_core__DOT___003437_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048197_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048198_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048200_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048199_)))))))));
    vlSelf->wasmetal_core__DOT___005565_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb7a72eea__0))));
    vlSelf->__VdfgTmp_hb5c2181f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048066_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048067_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hb7a72eea__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048065_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048064_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h158a449d__0))))))))));
    vlSelf->wasmetal_core__DOT___005566_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h158a449d__0))));
    vlSelf->wasmetal_core__DOT___005253_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048239_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048238_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048241_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048240_)))))))));
    vlSelf->wasmetal_core__DOT___005572_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048004_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048003_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048007_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048006_)))))))));
    vlSelf->__VdfgTmp_h92d236ac__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___047989_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047990_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048004_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048003_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048007_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048006_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hb85239a7__0))))))))));
    vlSelf->wasmetal_core__DOT___005185_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048172_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048171_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048170_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048169_)))))))));
    vlSelf->wasmetal_core__DOT___003511_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048263_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048262_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048261_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048260_)))))))));
    vlSelf->wasmetal_core__DOT___005533_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h601dd350__0))));
    vlSelf->__VdfgTmp_hbe250e1d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048195_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048196_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h601dd350__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048194_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048193_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h2f983ac6__0))))))))));
    vlSelf->wasmetal_core__DOT___005534_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2f983ac6__0))));
    vlSelf->wasmetal_core__DOT___004105_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048185_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048186_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048188_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048187_)))))))));
    vlSelf->wasmetal_core__DOT___005529_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hff8a2099__0))));
    vlSelf->__VdfgTmp_h74bfec90__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048231_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048230_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hff8a2099__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048233_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048232_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h2712d491__0))))))))));
    vlSelf->wasmetal_core__DOT___005530_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2712d491__0))));
    vlSelf->wasmetal_core__DOT___004179_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048234_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048235_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048237_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048236_)))))))));
    vlSelf->wasmetal_core__DOT___005504_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h52266111__0))));
    vlSelf->__VdfgTmp_h5d126061__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048198_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048197_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h52266111__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048200_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048199_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h7f6ab5bd__0))))))))));
    vlSelf->wasmetal_core__DOT___005505_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7f6ab5bd__0))));
    vlSelf->wasmetal_core__DOT___004623_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048190_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048189_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048191_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048192_)))))))));
    vlSelf->wasmetal_core__DOT___005508_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcde84ebb__0))));
    vlSelf->__VdfgTmp_h07f42939__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048262_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048263_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hcde84ebb__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048261_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048260_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hd5a2b04d__0))))))))));
    vlSelf->wasmetal_core__DOT___005509_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd5a2b04d__0))));
    vlSelf->wasmetal_core__DOT___005517_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0adea875__0))));
    vlSelf->__VdfgTmp_h1f83dfd6__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048186_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048185_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h0adea875__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048188_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048187_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h2566b586__0))))))))));
    vlSelf->wasmetal_core__DOT___005518_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2566b586__0))));
    vlSelf->wasmetal_core__DOT___003659_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048696_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048695_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048694_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048693_)))))))));
    vlSelf->wasmetal_core__DOT___005561_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h79860539__0))));
    vlSelf->__VdfgTmp_h1f7a3fb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048235_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048234_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h79860539__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048237_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048236_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hf0dacca2__0))))))))));
    vlSelf->wasmetal_core__DOT___005562_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf0dacca2__0))));
    vlSelf->wasmetal_core__DOT___003957_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048011_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048010_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048009_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048008_)))))))));
    vlSelf->wasmetal_core__DOT___005521_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5978f26f__0))));
    vlSelf->__VdfgTmp_hcbae1cfc__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048190_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048189_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h5978f26f__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048192_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048191_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hbd8e6335__0))))))))));
    vlSelf->wasmetal_core__DOT___005522_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd8e6335__0))));
    vlSelf->wasmetal_core__DOT___005525_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha13bce2f__0))));
    vlSelf->__VdfgTmp_had67ef57__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048695_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048696_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_ha13bce2f__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048694_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048693_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h33498483__0))))))))));
    vlSelf->wasmetal_core__DOT___005526_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h33498483__0))));
    vlSelf->wasmetal_core__DOT___004253_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048075_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048074_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048073_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048072_)))))))));
    vlSelf->wasmetal_core__DOT___005655_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h71a6f88b__0))));
    vlSelf->__VdfgTmp_h2852ec0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048010_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048011_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h71a6f88b__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048009_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048008_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hb9ea03dd__0))))))))));
    vlSelf->wasmetal_core__DOT___005656_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb9ea03dd__0))));
    vlSelf->wasmetal_core__DOT___004031_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048016_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048017_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048019_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048018_)))))))));
    vlSelf->wasmetal_core__DOT___005537_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h177129ae__0))));
    vlSelf->__VdfgTmp_h1fced7c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048074_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048075_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h177129ae__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048073_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048072_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h4a9c07e1__0))))))))));
    vlSelf->wasmetal_core__DOT___005538_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4a9c07e1__0))));
    vlSelf->wasmetal_core__DOT___005545_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h31225405__0))));
    vlSelf->__VdfgTmp_h5d95a729__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048017_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048016_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h31225405__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048019_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048018_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hf93df92c__0))))))))));
    vlSelf->wasmetal_core__DOT___005546_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf93df92c__0))));
    vlSelf->wasmetal_core__DOT___003815_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048139_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048140_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048142_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048141_)))))))));
    vlSelf->__VdfgTmp_he16d2f4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048140_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___048139_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h70d2167a__0))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048142_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048141_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h64e10f56__0))))))))));
    vlSelf->__VdfgTmp_hde5a6edf__0 = ((2U & ((0xe0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h70d2167a__0))) 
                                             << 1U)) 
                                      | (1U & (0xeU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h64e10f56__0)))));
    vlSelf->wasmetal_core__DOT___003889_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048043_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048042_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048041_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048040_)))))))));
    vlSelf->wasmetal_core__DOT___003369_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048060_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048059_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048058_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048057_)))))))));
    vlSelf->wasmetal_core__DOT___003301_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048047_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048046_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048045_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048044_)))))))));
    vlSelf->wasmetal_core__DOT___030687_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048391_))));
    vlSelf->wasmetal_core__DOT___048392_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048391_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003147_)))));
    if (vlSelf->wasmetal_core__DOT___003030_) {
        vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003030_)));
        vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)));
        vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003030_)));
    } else {
        vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)));
        vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003030_)));
        vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)));
    }
    vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003030_)) 
                 | (~ (IData)(vlSelf->wasmetal_core__DOT___003034_))));
    vlSelf->wasmetal_core__DOT___005723_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003030_)))));
    vlSelf->__VdfgTmp_hefabe8e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003034_));
    vlSelf->__VdfgTmp_hc058618d__0 = (((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003030_));
    vlSelf->__VdfgTmp_h360595f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003028_));
    vlSelf->wasmetal_core__DOT____Vcellinp___128723___S 
        = (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
            << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003028_));
    vlSelf->wasmetal_core__DOT____Vcellinp___128725___S 
        = (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
            << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003028_))));
    vlSelf->__VdfgTmp_hb9f44c2b__0 = (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003028_)));
    vlSelf->wasmetal_core__DOT___042570_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003028_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003032_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003029_)))))));
    vlSelf->wasmetal_core__DOT___070601_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070600_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003029_))));
    vlSelf->__VdfgTmp_h2de6a63c__0 = (((IData)(vlSelf->wasmetal_core__DOT___003032_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003029_));
    vlSelf->wasmetal_core__DOT___053428_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051571_))));
    vlSelf->wasmetal_core__DOT___053922_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051571_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053427_))));
    vlSelf->wasmetal_core__DOT___036749_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036781_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134151___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h83e5aafb__0))));
    vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___028285_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___028220_));
    vlSelf->wasmetal_core__DOT___053092_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053091_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053090_))));
    vlSelf->wasmetal_core__DOT___064899_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064897_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054047_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___064733_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064730_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___064465_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064462_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & vlSelf->insn_imm[0U]) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___052651_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052645_))));
    vlSelf->wasmetal_core__DOT___063463_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063471_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063479_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063449_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063447_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___062602_))));
    vlSelf->wasmetal_core__DOT___071912_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_z 
                                                               >> 2U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (0xfU 
                                                                    & vlSelf->insn_z)) 
                                                                  << 4U)) 
                                                              | ((0xcU 
                                                                  & (vlSelf->insn_z 
                                                                     >> 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he0cbb0dc__0)))))));
    vlSelf->wasmetal_core__DOT___071911_ = (1U & (IData)(
                                                         (0x1010000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (0xfU 
                                                                 & vlSelf->insn_z)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_z 
                                                                  >> 1U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_z 
                                                                     >> 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_z 
                                                                        >> 5U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_heaa2bcd7__0))))))));
    vlSelf->wasmetal_core__DOT___071910_ = (1U & (IData)(
                                                         (0x1010000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (0xfU 
                                                                 & vlSelf->insn_z)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & vlSelf->insn_z) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_z 
                                                                     >> 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_z 
                                                                        >> 5U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hed859ce1__0))))))));
    vlSelf->wasmetal_core__DOT___051184_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051176_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h295e0579__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h36e63769__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbcd45513__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051148_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051144_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h964144cd__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc4635290__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h73f4a931__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051168_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051152_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h738a13de__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc7f628da__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he2a57136__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050995_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050987_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8b69f170__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h947ab6b4__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h71547b26__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051094_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051086_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6286ac7f__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h29fa0da7__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc66bf11b__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050894_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050886_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1dd2dede__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcb35a5f1__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3885fdb9__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050248_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050232_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b83__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b82__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b81__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b80__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b91__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b90__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b89__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b88__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b95__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b94__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b93__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b92__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___050208_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050200_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b175__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b174__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b173__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b172__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b167__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b166__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b165__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b164__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b163__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b162__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b161__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b160__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___050228_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050224_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b211__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b210__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b209__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b208__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b219__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b218__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b217__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b216__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b223__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b222__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b221__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b220__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___049988_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049972_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b83__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b82__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b81__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b80__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b91__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b90__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b89__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b88__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b95__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b94__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b93__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b92__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___050008_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049992_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b175__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b174__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b173__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b172__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b167__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b166__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b165__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b164__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b163__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b162__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b161__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b160__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___050028_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050012_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b211__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b210__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b209__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b208__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b219__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b218__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b217__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b216__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b223__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b222__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b221__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b220__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___050322_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050314_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h980fd1a4__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h12f13bc4__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3ca396d5__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051082_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051074_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb13e555e__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4fc63e3e__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5b3781b6__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050192_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050174_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b6__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b4__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b11__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b9__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b8__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b15__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b14__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b13__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02evalid__05b12__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___049968_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049934_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b6__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b4__05d)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b11__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b9__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b8__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b15__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b14__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b13__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__element_sizes__02evalid__05b12__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___049411_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h295e0579__0))))));
    vlSelf->wasmetal_core__DOT___049407_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2b062dd4__0))))));
    vlSelf->wasmetal_core__DOT___049415_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8dc4790b__0))))));
    vlSelf->wasmetal_core__DOT___048531_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4f25bbf3__0))))));
    vlSelf->wasmetal_core__DOT___049908_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc4635290__0))))));
    vlSelf->wasmetal_core__DOT___051599_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb256bb9f__0))))));
    vlSelf->wasmetal_core__DOT___051666_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h738a13de__0))))));
    vlSelf->wasmetal_core__DOT___051670_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc793c4ac__0))))));
    vlSelf->wasmetal_core__DOT___051674_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hff3ab0b7__0))))));
    vlSelf->wasmetal_core__DOT___050682_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8b69f170__0))))));
    vlSelf->wasmetal_core__DOT___050673_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7982dd07__0))))));
    vlSelf->wasmetal_core__DOT___050669_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1157f8a3__0))))));
    vlSelf->wasmetal_core__DOT___050646_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h51560923__0))))));
    vlSelf->wasmetal_core__DOT___050618_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h29fa0da7__0))))));
    vlSelf->wasmetal_core__DOT___050614_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc0d4cc40__0))))));
    vlSelf->wasmetal_core__DOT___050597_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1dd2dede__0))))));
    vlSelf->wasmetal_core__DOT___050589_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7d1b01d9__0))))));
    vlSelf->wasmetal_core__DOT___050560_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h38f4df47__0))))));
    vlSelf->wasmetal_core__DOT___050575_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b83__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b82__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b81__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b80__05d)))))))));
    vlSelf->wasmetal_core__DOT___050571_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b103__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b102__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b101__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b100__05d)))))))));
    vlSelf->wasmetal_core__DOT___050491_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b115__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b114__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b113__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b112__05d)))))))));
    vlSelf->wasmetal_core__DOT___051447_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b139__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b138__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b137__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b136__05d)))))))));
    vlSelf->wasmetal_core__DOT___051455_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b167__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b166__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b165__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b164__05d)))))))));
    vlSelf->wasmetal_core__DOT___051451_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b179__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b178__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b177__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b176__05d)))))))));
    vlSelf->wasmetal_core__DOT___053464_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b211__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b210__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b209__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b208__05d)))))))));
    vlSelf->wasmetal_core__DOT___053460_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b231__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b230__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b229__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b228__05d)))))))));
    vlSelf->wasmetal_core__DOT___053456_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b243__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b242__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b241__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b240__05d)))))))));
    vlSelf->wasmetal_core__DOT___051482_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b83__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b82__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b81__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b80__05d)))))))));
    vlSelf->wasmetal_core__DOT___051478_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b103__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b102__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b101__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b100__05d)))))))));
    vlSelf->wasmetal_core__DOT___051472_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b115__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b114__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b113__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b112__05d)))))))));
    vlSelf->wasmetal_core__DOT___051400_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b139__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b138__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b137__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b136__05d)))))))));
    vlSelf->wasmetal_core__DOT___051465_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b167__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b166__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b165__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b164__05d)))))))));
    vlSelf->wasmetal_core__DOT___050567_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b179__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b178__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b177__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b176__05d)))))))));
    vlSelf->wasmetal_core__DOT___050593_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b211__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b210__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b209__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b208__05d)))))))));
    vlSelf->wasmetal_core__DOT___051392_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b231__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b230__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b229__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b228__05d)))))))));
    vlSelf->wasmetal_core__DOT___051388_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b243__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b242__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b241__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b240__05d)))))))));
    vlSelf->wasmetal_core__DOT___049399_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5760b542__0))))));
    vlSelf->wasmetal_core__DOT___050918_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7a6ef80c__0))))));
    vlSelf->wasmetal_core__DOT___051678_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he052d4e7__0))))));
    vlSelf->wasmetal_core__DOT___050759_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0a9f8029__0))))));
    vlSelf->wasmetal_core__DOT___050650_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5864b2ba__0))))));
    vlSelf->wasmetal_core__DOT___050606_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1968304e__0))))));
    vlSelf->wasmetal_core__DOT___051031_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8546e85d__0))))));
    vlSelf->wasmetal_core__DOT___051035_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h02a1ae9a__0))))));
    vlSelf->wasmetal_core__DOT___051039_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf05a0261__0))))));
    vlSelf->wasmetal_core__DOT___050738_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6727edf3__0))))));
    vlSelf->wasmetal_core__DOT___050728_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hefac84ff__0))))));
    vlSelf->wasmetal_core__DOT___050751_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_haf724a20__0))))));
    vlSelf->wasmetal_core__DOT___050579_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b75__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b74__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b73__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b72__05d)))))))));
    vlSelf->wasmetal_core__DOT___051023_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b151__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b150__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b149__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b148__05d)))))))));
    vlSelf->wasmetal_core__DOT___051847_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b203__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b202__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b201__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b200__05d)))))))));
    vlSelf->wasmetal_core__DOT___072231_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b75__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b74__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b73__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b72__05d)))))))));
    vlSelf->wasmetal_core__DOT___072223_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b151__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b150__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b149__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b148__05d)))))))));
    vlSelf->wasmetal_core__DOT___051384_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b203__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b202__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b201__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b200__05d)))))))));
    vlSelf->wasmetal_core__DOT___051027_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8c9e90c9__0))))));
    vlSelf->wasmetal_core__DOT___050742_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf782be94__0))))));
    vlSelf->wasmetal_core__DOT___053448_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___051878_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___049430_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___051442_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___072243_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___072239_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___053444_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___072247_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__memory_bounds__02ewords__02e0__02e0__ADDRARDADDR 
        = (0x803fU | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b7__05d) 
                       << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b6__05d) 
                                    << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                 << 0xbU) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                    << 0xaU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                       << 9U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                          << 8U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                             << 7U) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                               << 6U)))))))));
    vlSelf->__VdfgTmp_h8d479abc__0 = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b8__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___044479_));
    vlSelf->wasmetal_core__DOT___050942_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b30__05d))));
    vlSelf->wasmetal_core__DOT___044467_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070592_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x18U)) 
                                                                 | (3U 
                                                                    & (vlSelf->insn_x 
                                                                       >> 0x1aU))))))));
    vlSelf->wasmetal_core__DOT___044466_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070591_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x12U)) 
                                                                 | (3U 
                                                                    & (vlSelf->insn_x 
                                                                       >> 0x14U))))))));
    vlSelf->wasmetal_core__DOT___050961_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b23__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b19__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b18__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b17__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___044465_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070590_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xcU)) 
                                                                 | (3U 
                                                                    & (vlSelf->insn_x 
                                                                       >> 0xeU))))))));
    vlSelf->wasmetal_core__DOT___053985_ = (1U & (IData)(
                                                         (0xe0e0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053979_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050935_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x18U 
                                                                         >> 
                                                                         ((4U 
                                                                           & (vlSelf->insn_x 
                                                                              >> 0xcU)) 
                                                                          | ((2U 
                                                                              & (vlSelf->insn_y 
                                                                                >> 0xdU)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048519_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b12__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050933_)))))))));
    vlSelf->wasmetal_core__DOT___050940_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b27__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___044459_ = (1U & (IData)(
                                                         (0xcaffffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050957_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070589_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050935_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 9U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_x 
                                                                             >> 0xaU))))))))));
    vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031330_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___063000_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053511_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8ecdfd77__0))))));
    vlSelf->wasmetal_core__DOT___062979_ = (1U & (IData)(
                                                         (0xb0bbb0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052678_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052677_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8ecdfd77__0))))))));
    vlSelf->wasmetal_core__DOT___063365_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7e6b8024__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h56f16561__0))));
    vlSelf->wasmetal_core__DOT___063054_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5c8f7b91__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053572_))));
    vlSelf->wasmetal_core__DOT___053965_ = (1U & (IData)(
                                                         (0x110044000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053957_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050764_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048526_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b7__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___050766_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d))))))))))));
    vlSelf->wasmetal_core__DOT___053955_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052650_))));
    vlSelf->wasmetal_core__DOT___062966_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062964_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052650_))));
    vlSelf->wasmetal_core__DOT___052694_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050381_)))));
    vlSelf->wasmetal_core__DOT___062603_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052837_))));
    vlSelf->wasmetal_core__DOT___053991_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046221_))));
    vlSelf->__VdfgTmp_h8be24d75__0 = (((IData)(vlSelf->wasmetal_core__DOT___054807_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054808_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054809_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054810_))));
    vlSelf->__VdfgTmp_h1d87626c__0 = (((IData)(vlSelf->wasmetal_core__DOT___054815_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054816_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054818_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054820_))));
    vlSelf->__VdfgTmp_h401bf3cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___054987_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054988_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054989_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054990_))));
    vlSelf->__VdfgTmp_h1f51ea8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___054995_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054996_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054998_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___055000_))));
    vlSelf->__VdfgTmp_hebd182eb__0 = (((IData)(vlSelf->wasmetal_core__DOT___054948_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054949_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054950_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054951_))));
    vlSelf->__VdfgTmp_hee831718__0 = (((IData)(vlSelf->wasmetal_core__DOT___054956_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054957_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054958_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054959_))));
    vlSelf->__VdfgTmp_h2014cd64__0 = (((IData)(vlSelf->wasmetal_core__DOT___054899_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054898_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054900_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054901_))));
    vlSelf->__VdfgTmp_h4ffde934__0 = (((IData)(vlSelf->wasmetal_core__DOT___054906_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054907_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054908_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054909_))));
    vlSelf->__VdfgTmp_ha87b9f86__0 = (((IData)(vlSelf->wasmetal_core__DOT___054860_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054861_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054863_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054865_))));
    vlSelf->__VdfgTmp_h4ab1d453__0 = (((IData)(vlSelf->wasmetal_core__DOT___051493_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___051491_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051498_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___051496_))));
    vlSelf->__VdfgTmp_h84babf9f__0 = (((IData)(vlSelf->wasmetal_core__DOT___054767_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054768_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054769_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054770_))));
    vlSelf->__VdfgTmp_h3e487a94__0 = (((IData)(vlSelf->wasmetal_core__DOT___054775_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054777_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054779_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054781_))));
    vlSelf->__VdfgTmp_h2142849a__0 = (((IData)(vlSelf->wasmetal_core__DOT___054708_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054705_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054701_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054698_))));
    vlSelf->__VdfgTmp_h6ef442fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___054691_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054688_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054682_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054674_))));
    vlSelf->__VdfgTmp_hce1a9eab__0 = (((IData)(vlSelf->wasmetal_core__DOT___055033_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___055034_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055035_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___055036_))));
    vlSelf->__VdfgTmp_h703df812__0 = (((IData)(vlSelf->wasmetal_core__DOT___055041_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___055042_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055044_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___055046_))));
    vlSelf->__VdfgTmp_h384cc7f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___008048_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008123_));
    vlSelf->__VdfgTmp_he719985b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008198_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008273_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008349_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008424_))));
    vlSelf->__VdfgTmp_h9ea6e74c__0 = (((IData)(vlSelf->wasmetal_core__DOT___008032_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008107_));
    vlSelf->__VdfgTmp_hfa99a91b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008040_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008115_));
    vlSelf->__VdfgTmp_h9a7588ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___008056_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008131_));
    vlSelf->__VdfgTmp_hc06d6619__0 = (((IData)(vlSelf->wasmetal_core__DOT___008069_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008144_));
    vlSelf->__VdfgTmp_h90a7e66d__0 = (((IData)(vlSelf->wasmetal_core__DOT___008077_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008152_));
    vlSelf->__VdfgTmp_hd9d9e38d__0 = (((IData)(vlSelf->wasmetal_core__DOT___008085_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008160_));
    vlSelf->__VdfgTmp_hd4ed2ab6__0 = (((IData)(vlSelf->wasmetal_core__DOT___008182_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008257_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008333_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008408_))));
    vlSelf->__VdfgTmp_h4d3bb7ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___008341_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008416_));
    vlSelf->__VdfgTmp_hf10e2308__0 = (((IData)(vlSelf->wasmetal_core__DOT___008357_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008432_));
    vlSelf->__VdfgTmp_hb8ee9e15__0 = (((IData)(vlSelf->wasmetal_core__DOT___008370_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008445_));
    vlSelf->__VdfgTmp_h8de67bd6__0 = (((IData)(vlSelf->wasmetal_core__DOT___008378_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008453_));
    vlSelf->__VdfgTmp_hf366d942__0 = (((IData)(vlSelf->wasmetal_core__DOT___008235_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008310_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008386_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008461_))));
    vlSelf->__VdfgTmp_h78e7e4d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___008093_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008168_));
    vlSelf->__VdfgTmp_h92c59f9e__0 = (((IData)(vlSelf->wasmetal_core__DOT___008243_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008318_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008394_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008469_))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135196___B 
        = ((0x3ff80U & ((- (IData)((1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x555533330f0f00ffULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008168_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008469_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055036_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___055046_)))))))))))))) 
                        << 7U)) | ((0x40U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                << 1U) 
                                               | (1U 
                                                  & (IData)(
                                                            (0x555533330f0f00ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008160_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008461_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054990_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___055000_))))))))))) 
                                             << 6U)) 
                                   | ((0x20U & ((4U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (IData)(
                                                               (0x555533330f0f00ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008152_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008453_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054951_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054959_))))))))))) 
                                                << 5U)) 
                                      | ((0x10U & (
                                                   (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008144_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008445_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054901_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054909_))))))))))) 
                                                   << 4U)) 
                                         | ((8U & (
                                                   (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008131_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008432_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___051496_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054865_))))))))))) 
                                                   << 3U)) 
                                            | ((4U 
                                                & ((4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0x555533330f0f00ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008123_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008424_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054810_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054820_))))))))))) 
                                                   << 2U)) 
                                               | ((2U 
                                                   & ((4U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008115_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008416_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054770_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054781_))))))))))) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (4U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008107_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008408_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054698_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054674_)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034310_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128654___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034478_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___019786_ = (1U & (0xe000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053286_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053347_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053282_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052952_)))))));
    vlSelf->wasmetal_core__DOT___009544_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048430_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045693_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044230_)))));
    vlSelf->wasmetal_core__DOT__access_size__05b4__05d 
        = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___048430_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054465_))));
    vlSelf->wasmetal_core__DOT___054459_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048430_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (1ULL 
                                                                           >> 
                                                                           (vlSelf->insn_op 
                                                                            >> 0x1aU))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> 
                                                                      (3U 
                                                                       & (vlSelf->insn_op 
                                                                          >> 6U))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___044061_)))))))));
    vlSelf->wasmetal_core__DOT___053483_ = (1U & (IData)(
                                                         (0xffff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048430_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053482_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052647_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___044190_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___045725_)))))))));
    vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 9U) & (IData)(vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x200U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 9U) : (IData)(vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128483___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032895_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032894_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032893_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032892_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032859_)))));
    vlSelf->wasmetal_core__DOT___032863_ = ((IData)(vlSelf->wasmetal_core__DOT___032895_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d));
    vlSelf->wasmetal_core__DOT___067852_ = (1U & (IData)(
                                                         (0xc0f04000c0f0c0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b36__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067845_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((8U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___067843_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065141_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064872_)))))))));
    vlSelf->wasmetal_core__DOT___067654_ = (1U & (IData)(
                                                         (0xbfff3f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067650_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b33__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067649_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___067648_)))))))));
    vlSelf->wasmetal_core__DOT___065784_ = (1U & (IData)(
                                                         (0x88f8ffff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065772_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065771_)))))))));
    vlSelf->wasmetal_core__DOT___068531_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x80b000fU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b49__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      >> 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___066440_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___064666_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x70330000U 
                                                            >> 
                                                            ((0x18U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                 << 1U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068524_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b49__05d) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___068523_))))))))));
    vlSelf->wasmetal_core__DOT___069526_ = (1U & (IData)(
                                                         (0xfef00000f0f0f0fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069523_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069522_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b74__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065771_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___069879_ = (1U & (IData)(
                                                         (0xfef00000f0f0f0fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069876_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069875_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b90__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067136_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___069329_ = (1U & (IData)(
                                                         (0x5fcf00000f0f0f0fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069326_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b66__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064876_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xc5U 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                              | ((2U 
                                                                                & ((0x8000ffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heceac102__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019408_)))))))))))));
    vlSelf->wasmetal_core__DOT___070194_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xe00ee0000ffffULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b108__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___070186_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xffe0001fffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9ae21ada__0))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___068277_))))))))))));
    vlSelf->wasmetal_core__DOT___068883_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068881_))));
    vlSelf->wasmetal_core__DOT___068129_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e48eaa1__0))));
    vlSelf->wasmetal_core__DOT___065593_ = (1U & (IData)(
                                                         (0xffff444f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065590_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019393_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8acf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___065577_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065576_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x7f007f7fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___065545_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065544_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064081_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065543_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xafcf0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___065524_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf0f0ccaaU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065519_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064407_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064444_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065522_)))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (vlSelf->mem_rdata[0U] 
                                                                                >> 7U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___065584_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065586_)))))))));
    vlSelf->wasmetal_core__DOT___068215_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h28baf300__0))));
    vlSelf->wasmetal_core__DOT___068177_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he6f0d7f4__0))));
    vlSelf->wasmetal_core__DOT___065756_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065753_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x55330f00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 1U))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064817_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha9e0ea4b__0)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b10__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x11f00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 1U))) 
                                                                                << 4U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 2U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___069567_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0a030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b76__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h50efe2fe__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h051c8ed8__0)))))))));
    vlSelf->wasmetal_core__DOT___068263_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h051c8ed8__0))));
    vlSelf->wasmetal_core__DOT___068321_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc00cbbb6__0))));
    vlSelf->wasmetal_core__DOT___068453_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h482142a8__0))));
    vlSelf->wasmetal_core__DOT___066198_ = (1U & (IData)(
                                                         (0x153f151500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066179_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066178_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066177_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xcU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064978_)))))))));
    vlSelf->__VdfgTmp_hda165e4b__0 = ((2U & ((0xa3U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h0c18689a__0))) 
                                             << 1U)) 
                                      | (1U & (0xc5U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h866f258c__0)))));
    vlSelf->wasmetal_core__DOT___069660_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xa82aaaaaaaaaaaaaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT__load_vector__05b80__05d))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9b35e8c1__0))))));
    vlSelf->wasmetal_core__DOT___068491_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9b35e8c1__0))));
    vlSelf->wasmetal_core__DOT___068530_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6c009ef6__0))));
    vlSelf->wasmetal_core__DOT___068922_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he7e046c1__0))));
    vlSelf->wasmetal_core__DOT___069115_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1f61adb3__0))));
    vlSelf->wasmetal_core__DOT___068726_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdbe4c80a__0))));
    vlSelf->wasmetal_core__DOT___069020_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7b734092__0))));
    vlSelf->wasmetal_core__DOT___067799_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b35__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h37cccaef__0))))));
    vlSelf->wasmetal_core__DOT___070060_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b99__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h37cccaef__0))))));
    vlSelf->wasmetal_core__DOT___068629_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h205cfcf2__0))));
    vlSelf->wasmetal_core__DOT___070119_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b103__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___068001_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___068000_)))))));
    vlSelf->wasmetal_core__DOT___068826_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he61b9416__0))));
    vlSelf->wasmetal_core__DOT___069210_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf4f03bfc__0))));
    vlSelf->wasmetal_core__DOT___069182_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbbe8c33f__0))));
    vlSelf->wasmetal_core__DOT___067429_ = (1U & (IData)(
                                                         (0x33bf3f3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067425_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9bb3dbab__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h88dfb892__0)))))))))));
    vlSelf->wasmetal_core__DOT___070104_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b102__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4f29c7eb__0))))));
    vlSelf->wasmetal_core__DOT___068772_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he5ddd7d8__0))));
    vlSelf->wasmetal_core__DOT___068989_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1f0809ce__0))));
    vlSelf->wasmetal_core__DOT___068575_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h44e97a03__0))));
    vlSelf->wasmetal_core__DOT___070072_ = (1U & (IData)(
                                                         (0x5fcf00000f0f0f0fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067850_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b100__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h102f49bb__0))))))));
    vlSelf->wasmetal_core__DOT___068674_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h657da1af__0))));
    vlSelf->wasmetal_core__DOT___069920_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b92__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xf5cfU 
                                                                 >> 
                                                                 ((0xcU 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h33628a1f__0))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xfffe01ffffffffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                            << 5U) 
                                                                           | ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)))))))))))));
    vlSelf->wasmetal_core__DOT___069067_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h33628a1f__0))));
    vlSelf->wasmetal_core__DOT___068867_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4521a0c__0))));
    vlSelf->wasmetal_core__DOT___069483_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069478_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf05030f0f0f0f0fULL 
                                                                          >> 
                                                                          ((0x38U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                               << 2U)) 
                                                                           | ((4U 
                                                                               & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b72__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf103d5a5__0))))) 
                                                                                << 2U)) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h07d01a7e__0))))))))))));
    vlSelf->wasmetal_core__DOT___070135_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b104__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h220538c2__0))))));
    vlSelf->wasmetal_core__DOT___068054_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b40__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h220538c2__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128011___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027830_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027829_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027828_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027827_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027794_)))));
    vlSelf->wasmetal_core__DOT___027798_ = ((IData)(vlSelf->wasmetal_core__DOT___027830_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b7__05d));
    vlSelf->wasmetal_core__DOT___070017_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xafcf00000f0f0f0fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                           >> 2U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067629_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b97__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h4121b81d__0)))))))))));
    vlSelf->wasmetal_core__DOT___066461_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b17__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h42ebc2c2__0))))));
    vlSelf->wasmetal_core__DOT___069680_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b81__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h42ebc2c2__0))))));
    vlSelf->wasmetal_core__DOT___069853_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b89__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h91af3af4__0))))));
    vlSelf->wasmetal_core__DOT___069494_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf05030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b73__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h18a1d918__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h51979f8d__0)))))))));
    vlSelf->wasmetal_core__DOT___068121_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h51979f8d__0))));
    vlSelf->__VdfgTmp_hcf04e80b__0 = ((4U & ((0x53U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_hab510120__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h0afb0546__0));
    vlSelf->wasmetal_core__DOT___069942_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069936_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069935_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf050c0f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf050c0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b93__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5b846e26__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1f61adb3__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xb33U 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067363_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b93__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067362_))))))))))))));
    vlSelf->wasmetal_core__DOT___069781_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069769_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069768_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf050c0f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf050c0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b85__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha9829971__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdbe4c80a__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xb33U 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                              | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfef6b839__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b85__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4bfb58f6__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___069738_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069726_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069725_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf050c0f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b83__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_had7d0cfa__0))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h205cfcf2__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xb33U 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                              | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8a2bba7d__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b83__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h285454e8__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___069540_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf05030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b75__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4573e872__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9e5b6509__0)))))))));
    vlSelf->wasmetal_core__DOT___068206_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9e5b6509__0))));
    vlSelf->wasmetal_core__DOT___069812_ = (1U & (0xdfc00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b87__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdda09bd4__0))))));
    vlSelf->wasmetal_core__DOT___069631_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf05030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b79__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfdd57f0a__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_he90c68e8__0)))))))));
    vlSelf->wasmetal_core__DOT___068444_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he90c68e8__0))));
    vlSelf->wasmetal_core__DOT___069760_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069748_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069747_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069746_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdfc00000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b84__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he75eceef__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd785ede8__0)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf050c0f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf050c0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b84__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5b5a3019__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h657da1af__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064247_)))))))));
    vlSelf->wasmetal_core__DOT___069568_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf05030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b76__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3daad387__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h134a2a5b__0)))))))));
    vlSelf->wasmetal_core__DOT___068258_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h134a2a5b__0))));
    vlSelf->wasmetal_core__DOT___069839_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069831_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069830_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 0x16U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x2000000f3ffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b88__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h400b74e1__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___068053_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x1f100ffU 
                                                         >> 
                                                         ((0x10U 
                                                           & ((8U 
                                                               >> 
                                                               (3U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                   >> 2U))) 
                                                              << 4U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b40__05d) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h13c22a42__0))))))));
    vlSelf->wasmetal_core__DOT___066167_ = (1U & (0x40ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066158_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___064053_)) 
                                                             << 2U)) 
                                                         | ((IData)(vlSelf->wasmetal_core__DOT___065544_) 
                                                            << 1U))))));
    vlSelf->wasmetal_core__DOT___068367_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7e1e4a5__0))));
    vlSelf->wasmetal_core__DOT___067938_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xcfaf00000f0f0f0fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((8U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                           >> 2U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067925_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b38__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h78f256d8__0)))))))))));
    vlSelf->wasmetal_core__DOT___069803_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069790_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069789_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf050c0f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b86__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcb391db2__0))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he5ddd7d8__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xb33U 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                              | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha4f5f30b__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b86__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h97331d2b__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___068172_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h95565af9__0))));
    vlSelf->wasmetal_core__DOT___070038_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xcfaf00000f0f0f0fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                           >> 2U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067685_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b98__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hc656bac6__0)))))))))));
    vlSelf->wasmetal_core__DOT___067706_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xcfaf00000f0f0f0fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((8U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                           >> 2U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067685_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b34__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hc656bac6__0)))))))))));
    vlSelf->wasmetal_core__DOT___069716_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069704_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069703_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064976_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf050c0f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b82__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h744eac81__0))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h44e97a03__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xb33U 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                              | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h02ac2502__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b82__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h23f4485c__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___070016_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xafcf00000f0f0f0fULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                           >> 2U))) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067621_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b97__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h729278ac__0)))))))))));
    vlSelf->wasmetal_core__DOT___067640_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x2a3f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___067626_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067625_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              << 1U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xafcf00000f0f0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067621_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b33__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h729278ac__0))))))))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xafcf00000f0f0f0fULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                             >> 2U))) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067629_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b33__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h4121b81d__0))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064993_)))));
    vlSelf->wasmetal_core__DOT___070266_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070265_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hea3a75f9__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b113__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1dd3182a__0)))))))))));
    vlSelf->wasmetal_core__DOT___067065_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067042_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067041_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdfc00000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b25__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h91af3af4__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x19U))))))))));
    vlSelf->wasmetal_core__DOT___068923_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068918_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9b0680c9__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b57__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2428cf91__0))))))));
    vlSelf->wasmetal_core__DOT___070368_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070367_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9b0680c9__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b121__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2428cf91__0))))))));
    vlSelf->wasmetal_core__DOT___065688_ = (1U & (0x70000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065648_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065647_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 9U))))))));
    vlSelf->wasmetal_core__DOT___069404_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069392_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069391_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b69__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb2a5d28a__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h26de3b10__0))))))))))))));
    vlSelf->wasmetal_core__DOT___067863_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h26de3b10__0))));
    vlSelf->wasmetal_core__DOT___066758_ = (1U & (IData)(
                                                         (0xef00efef00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066745_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066744_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x4000cfff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b21__05d) 
                                                                                << 4U) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066741_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066740_))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x7033U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066351_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x5cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha0b0298a__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b21__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065248_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070316_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070315_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h96a0f125__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b117__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h744d834f__0))))))));
    vlSelf->wasmetal_core__DOT___068727_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068722_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h96a0f125__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b53__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h744d834f__0))))))));
    vlSelf->wasmetal_core__DOT___066052_ = (1U & (0x70000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066021_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066020_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0xdU))))))));
    vlSelf->wasmetal_core__DOT___070417_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070416_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hb159a4d2__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b125__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc3e51450__0))))))));
    vlSelf->wasmetal_core__DOT___069116_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069111_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hb159a4d2__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b61__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc3e51450__0))))))));
    vlSelf->wasmetal_core__DOT___067800_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067775_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067774_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x1f100ffU 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b35__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hba46d6b9__0)))))))))))));
    vlSelf->wasmetal_core__DOT___070061_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070056_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070055_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x1f100ffU 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b99__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hba46d6b9__0)))))))))))));
    vlSelf->wasmetal_core__DOT___066591_ = (1U & (IData)(
                                                         (0xef00efef00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066578_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066577_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x4000cfff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b19__05d) 
                                                                                << 4U) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066574_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066573_))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x7033U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066351_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h11c2cb19__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b19__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064945_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070290_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070289_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hded1dcfc__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b115__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdf86f0af__0))))))));
    vlSelf->wasmetal_core__DOT___068630_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068625_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hded1dcfc__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b51__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdf86f0af__0))))))));
    vlSelf->wasmetal_core__DOT___069901_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069892_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h729a2b0d__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b91__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he6a138a7__0)))))))))));
    vlSelf->wasmetal_core__DOT___067249_ = (1U & (IData)(
                                                         (0xef00efef00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067236_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067235_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x4000cfff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b27__05d) 
                                                                                << 4U) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067232_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ff00ff1fffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2e5f0189__0)))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x1000fcffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b27__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066351_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064964_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064944_))))))))))))))));
    vlSelf->wasmetal_core__DOT___069021_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069016_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h729a2b0d__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b59__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h25e3345e__0))))))));
    vlSelf->wasmetal_core__DOT___070392_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070391_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h729a2b0d__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b123__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h25e3345e__0))))))));
    vlSelf->wasmetal_core__DOT___065871_ = (1U & (0x70000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065843_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065842_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0xbU))))))));
    vlSelf->wasmetal_core__DOT___070340_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070339_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_had85000c__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b119__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc8a29b47__0))))))));
    vlSelf->wasmetal_core__DOT___068827_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068822_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_had85000c__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b55__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc8a29b47__0))))))));
    vlSelf->wasmetal_core__DOT___065504_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065473_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065472_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x20003fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___065470_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065469_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065468_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065467_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___069447_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf05030f0f0f0f0fULL 
                                                                 >> 
                                                                 ((0x38U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                      << 2U)) 
                                                                  | ((4U 
                                                                      & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b71__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he391eb62__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h7e9d016d__0)))))))));
    vlSelf->__VdfgTmp_hf139c1ac__0 = ((4U & ((0x53U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_he391eb62__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h7e9d016d__0));
    vlSelf->wasmetal_core__DOT___069990_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x33bf3f3f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069975_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                             >> 2U))) 
                                                                        << 4U)) 
                                                                    | ((8U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h8c50959a__0)) 
                                                                           << 3U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b95__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h009830e9__0)))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf050c0f0f0f0f0fULL 
                                                                   >> 
                                                                   ((0x38U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 2U)) 
                                                                    | ((4U 
                                                                        & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b95__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc6e14b62__0))))))) 
                                                                           << 2U)) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hf4f03bfc__0))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064247_)))));
    vlSelf->wasmetal_core__DOT___019391_ = (1U & (IData)(
                                                         (0xef00efef00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067524_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067523_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x4000cfff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b31__05d) 
                                                                                << 4U) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067520_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1ffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0ed876af__0)))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x200f3ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b31__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066351_) 
                                                                                << 3U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064128_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___070442_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070441_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8c50959a__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b127__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h009830e9__0)))))))))));
    vlSelf->wasmetal_core__DOT___066248_ = (1U & (0x70000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066219_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066218_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065570_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0xfU))))))));
    vlSelf->wasmetal_core__DOT___069379_ = (1U & (IData)(
                                                         (0x7f333f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069368_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069367_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b68__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfffe7fffffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                                                << 5U) 
                                                                                | ((0x1cU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (3U 
                                                                                & (~ 
                                                                                (1U 
                                                                                | (2U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                                                << 1U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___067835_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x1f100ffU 
                                                         >> 
                                                         ((0x10U 
                                                           & ((8U 
                                                               >> 
                                                               (3U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                   >> 2U))) 
                                                              << 4U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b36__05d) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h82ca3c22__0))))))));
    vlSelf->wasmetal_core__DOT___070073_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070070_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070069_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x1f100ffU 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b100__05d) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h82ca3c22__0)))))))))))));
    vlSelf->wasmetal_core__DOT___070136_ = (1U & (0x77070000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070132_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070131_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 7U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069262_)))))));
    vlSelf->wasmetal_core__DOT___070010_ = (1U & (0x4f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x700000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___070001_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070000_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___069999_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0x7fff500000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b96__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h62827519__0))))))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & vlSelf->mem_rdata[3U])))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((4U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O))
                                                                ? 
                                                               (0xff80afU 
                                                                >> 
                                                                ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b96__05d) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           >> 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___019406_))))))
                                                                : 
                                                               (0x80af00ffU 
                                                                >> 
                                                                ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b96__05d) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           >> 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___019407_)))))))))))));
    vlSelf->wasmetal_core__DOT___067589_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067573_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067572_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7fff500000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b32__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h62827519__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & vlSelf->mem_rdata[1U])))))))));
    vlSelf->wasmetal_core__DOT___069272_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069264_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x20000000fcffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b64__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 1U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 1U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h53aa4fbe__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___069970_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x33bf3f3f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069954_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                             >> 2U))) 
                                                                        << 4U)) 
                                                                    | ((8U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h9bb3dbab__0)) 
                                                                           << 3U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b94__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h88dfb892__0)))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf050c0f0f0f0f0fULL 
                                                                   >> 
                                                                   ((0x38U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 2U)) 
                                                                    | ((4U 
                                                                        & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b94__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5c1a0f86__0))))))) 
                                                                           << 2U)) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hbbe8c33f__0))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064247_)))));
    vlSelf->wasmetal_core__DOT___069183_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069178_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9bb3dbab__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b62__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4223b487__0))))))));
    vlSelf->wasmetal_core__DOT___070429_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9bb3dbab__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b126__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4223b487__0))))))));
    vlSelf->wasmetal_core__DOT___065398_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065366_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065365_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064249_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xc1dU 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((IData)(
                                                                                (0xaa330f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064789_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h23108600__0))))) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b6__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x7f7f7f7f7fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                                << 1U)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065359_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065361_))))))))))))));
    vlSelf->wasmetal_core__DOT___069429_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069418_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069417_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b70__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5f663eeb__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdcdbebf8__0))))))))))))));
    vlSelf->wasmetal_core__DOT___067920_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdcdbebf8__0))));
    vlSelf->wasmetal_core__DOT___070328_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070327_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h72f36192__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b118__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6b577092__0)))))))))));
    vlSelf->wasmetal_core__DOT___066882_ = (1U & (IData)(
                                                         (0xff00ff4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019393_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0x33bf3f3f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066819_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h72f36192__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b22__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6b577092__0)))))))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xbf00bfbfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066827_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0x5cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hedd7926b__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066826_)))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___064247_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaf0f0fccccccccULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066840_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b22__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xfef0f00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___066837_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b22__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066836_)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066838_))))))))))))))));
    vlSelf->wasmetal_core__DOT___069330_ = (1U & (IData)(
                                                         (0x454545cf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069319_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069318_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069317_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b66__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc656bac6__0))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb4147928__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064244_)))))))));
    vlSelf->wasmetal_core__DOT___070039_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x1f100ffU 
                                                         >> 
                                                         ((0x10U 
                                                           & ((4U 
                                                               >> 
                                                               (3U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                   >> 2U))) 
                                                              << 4U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b98__05d) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb47a572e__0))))))));
    vlSelf->wasmetal_core__DOT___067707_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x1f100ffU 
                                                         >> 
                                                         ((0x10U 
                                                           & ((8U 
                                                               >> 
                                                               (3U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                   >> 2U))) 
                                                              << 4U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b34__05d) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb47a572e__0))))))));
    vlSelf->wasmetal_core__DOT___070278_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070277_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he200cacd__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b114__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf114f092__0)))))))))));
    vlSelf->wasmetal_core__DOT___066514_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066491_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he200cacd__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf114f092__0)))))))))));
    vlSelf->wasmetal_core__DOT___068990_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068985_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h5ea85090__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b58__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h67fa8c87__0))))))));
    vlSelf->wasmetal_core__DOT___070380_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070379_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h5ea85090__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b122__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h67fa8c87__0))))))));
    vlSelf->wasmetal_core__DOT___069880_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069872_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h5ea85090__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b90__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_ha458d092__0)))))))))));
    vlSelf->wasmetal_core__DOT___067143_ = (1U & (IData)(
                                                         (0xff00ff4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019393_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019392_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067127_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067126_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067125_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067121_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaf0f0fccccccccULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067138_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b26__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xfef0f00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067135_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b26__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064710_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067134_)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067136_))))))))))))))));
    vlSelf->wasmetal_core__DOT___069527_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069517_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069516_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 8U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf05030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf05030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b74__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5ad13fe7__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h95565af9__0))))))))))))));
    vlSelf->wasmetal_core__DOT___065413_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065411_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 6U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065190_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065187_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 4U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065064_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065058_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 3U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___065303_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065301_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054059_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 5U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 9U) & (IData)(vlSelf->wasmetal_core__DOT___128052___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028117_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028084_)
                  : (vlSelf->insn_x >> 4U)));
    vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__1__KET__ 
        = ((~ (vlSelf->function_params >> 9U)) & (IData)(vlSelf->wasmetal_core__DOT___128316___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128467___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032703_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032702_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032701_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032700_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032667_)))));
    vlSelf->wasmetal_core__DOT___032671_ = ((IData)(vlSelf->wasmetal_core__DOT___032703_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134209___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037213_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037212_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037211_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037210_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037178_)))));
    vlSelf->wasmetal_core__DOT___037182_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037213_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h0e12a4a2__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127843___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026386_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026385_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026384_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026383_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026350_)))));
    vlSelf->wasmetal_core__DOT___026354_ = ((IData)(vlSelf->wasmetal_core__DOT___026386_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b7__05d));
    vlSelf->wasmetal_core__DOT___062330_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b66__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b66__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b66__05d)))))));
    vlSelf->wasmetal_core__DOT___069847_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b88__05d))));
    vlSelf->wasmetal_core__DOT___062392_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b88__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b88__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x17U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b88__05d)))))));
    vlSelf->wasmetal_core__DOT___069868_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b89__05d))));
    vlSelf->wasmetal_core__DOT___062394_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b89__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b89__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x18U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b89__05d)))))));
    vlSelf->wasmetal_core__DOT___069909_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b91__05d))));
    vlSelf->wasmetal_core__DOT___062399_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b91__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b91__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x1aU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b91__05d)))))));
    vlSelf->wasmetal_core__DOT___068596_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068593_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x10U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___068695_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068692_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x12U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT___068809_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b54__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0x15U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b64__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052640_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h50808fd0__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003161_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hb6d33cfc__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b72__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052745_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_he96756cd__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003753_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h09110191__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b80__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053131_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hbef8f541__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003977_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h0f7cbf8b__0)))))))))));
    vlSelf->wasmetal_core__DOT___068556_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b49__05d))));
    vlSelf->wasmetal_core__DOT___068545_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068543_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068542_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0xfU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b49__05d)))))))));
    vlSelf->wasmetal_core__DOT___062333_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b67__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b67__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b67__05d)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b70__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062340_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_had5b2ab5__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004421_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h37bfe82f__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b71__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052743_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hd2a6e22a__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004569_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h6d398ac8__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b78__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052794_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hce8127e9__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004643_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hd76f194b__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b90__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053141_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_heece1a14__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004951_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h360aedc6__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b92__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052740_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h2a05cb02__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004883_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h1aa0b795__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b93__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053143_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h5621a27e__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005291_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h30461973__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b103__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053176_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hc2746ec0__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004587_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hce07ecc6__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b96__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053149_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h0e59039e__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003179_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3cd3193e__0)))))))))));
    vlSelf->wasmetal_core__DOT___067586_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067585_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067584_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b76__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052790_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9946d772__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004125_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h18b22471__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b81__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053133_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h51c7c353__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004273_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hc280317b__0)))))))))));
    vlSelf->wasmetal_core__DOT___068887_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068885_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x16U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b77__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052792_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_ha028a74d__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004199_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3b77bad1__0)))))))))));
    vlSelf->wasmetal_core__DOT___068642_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068640_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x11U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT___068739_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068738_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___068839_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068838_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068837_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x15U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b55__05d)))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b65__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052642_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h51bf3013__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003241_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hcb1226e0__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b68__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052714_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h3be345de__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004495_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h252a6e11__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b99__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053157_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h51a38bc3__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h6e2b8153__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b102__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053173_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h2c3dfb0e__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9e847741__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b104__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053180_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_ha9ea3386__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h4c8e22c1__0))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b110__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053205_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_he9f02b45__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h8b084513__0))))))));
    vlSelf->wasmetal_core__DOT___062351_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b73__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b73__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 8U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b73__05d)))))));
    vlSelf->wasmetal_core__DOT___069510_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069506_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069505_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b73__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 7U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b73__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->wasmetal_core__DOT___069509_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 6U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 9U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b73__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT__value_aux__05b108__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053203_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h8294d615__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004143_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3a5851b5__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b109__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053201_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h563364ee__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___004217_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h8e96b5b6__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b116__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053234_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h57ccb970__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___003909_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h945f14c8__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b120__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053242_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hc01010d2__0)))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005069_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h9ff07be6__0)))))))))));
}
