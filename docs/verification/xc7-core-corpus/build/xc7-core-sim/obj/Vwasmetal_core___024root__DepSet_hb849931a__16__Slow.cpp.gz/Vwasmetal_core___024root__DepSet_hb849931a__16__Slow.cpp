#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__19(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__19\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___062411_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b95__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b95__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x1eU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b95__05d)))))));
    vlSelf->wasmetal_core__DOT___069987_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x1cU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (vlSelf->insn_y 
                                                                                >> 0x1fU)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b95__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069984_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b95__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b95__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (vlSelf->mem_rdata[2U] 
                                                                          >> 0x1fU)))))))));
    vlSelf->wasmetal_core__DOT___005266_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002797_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002796_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he1a2a265__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha991aa19__0)))))))));
    vlSelf->wasmetal_core__DOT___005265_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he1a2a265__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha991aa19__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002797_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002796_)))))));
    vlSelf->wasmetal_core__DOT___004926_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002839_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002838_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcf9144f2__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha0134e57__0)))))))));
    vlSelf->wasmetal_core__DOT___004925_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hcf9144f2__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha0134e57__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002839_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002838_)))))));
    vlSelf->wasmetal_core__DOT___004858_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002757_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002756_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h27cfb5f3__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd97a8939__0)))))))));
    vlSelf->wasmetal_core__DOT___004857_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h27cfb5f3__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd97a8939__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002757_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002756_)))))));
    vlSelf->wasmetal_core__DOT___005334_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002717_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002716_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4c59d32e__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd1570df5__0)))))))));
    vlSelf->wasmetal_core__DOT___005333_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4c59d32e__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd1570df5__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002717_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002716_)))))));
    vlSelf->wasmetal_core__DOT___003382_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002618_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002617_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8de0b505__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf66f4835__0)))))))));
    vlSelf->wasmetal_core__DOT___003381_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8de0b505__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf66f4835__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002618_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002617_)))))));
    vlSelf->wasmetal_core__DOT___003314_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002581_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002580_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he4198019__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h57a954cd__0)))))))));
    vlSelf->wasmetal_core__DOT___003313_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he4198019__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h57a954cd__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002581_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002580_)))))));
    vlSelf->wasmetal_core__DOT___005062_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002678_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002677_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h80bd54db__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6ae60ef8__0)))))))));
    vlSelf->wasmetal_core__DOT___005061_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h80bd54db__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h6ae60ef8__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002678_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002677_)))))));
    vlSelf->wasmetal_core__DOT___005130_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002960_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002959_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h572d5497__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1fbc0854__0)))))))));
    vlSelf->wasmetal_core__DOT___005129_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h572d5497__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1fbc0854__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002960_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002959_)))))));
    vlSelf->__VdfgTmp_h13f17749__0 = (((IData)(vlSelf->wasmetal_core__DOT___005275_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h6f7c691c__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005273_))));
    vlSelf->wasmetal_core__DOT___062486_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b125__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b125__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x1cU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b125__05d)))))));
    vlSelf->__VdfgTmp_h6b4c794b__0 = (((IData)(vlSelf->wasmetal_core__DOT___004935_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h9340bbb8__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004933_))));
    vlSelf->wasmetal_core__DOT___062477_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b122__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b122__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x19U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b122__05d)))))));
    vlSelf->wasmetal_core__DOT___052314_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h70f8ca0f__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b123__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052279_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h0589a813__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h70f8ca0f__0))))))));
    vlSelf->__VdfgTmp_h3d9b9896__0 = (((IData)(vlSelf->wasmetal_core__DOT___005003_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b123__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002873_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002872_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005001_))));
    vlSelf->wasmetal_core__DOT___052819_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004993_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005011_))));
    vlSelf->wasmetal_core__DOT___005400_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004994_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004993_)));
    vlSelf->__VdfgTmp_h928bb96c__0 = (((IData)(vlSelf->wasmetal_core__DOT___004993_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004994_));
    vlSelf->__VdfgTmp_h79077a59__0 = (((IData)(vlSelf->wasmetal_core__DOT___004867_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h4e57fd92__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004865_))));
    vlSelf->wasmetal_core__DOT___062483_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b124__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b124__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x1bU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b124__05d)))))));
    vlSelf->wasmetal_core__DOT___052313_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8783294b__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b121__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053244_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h04b492c5__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h8783294b__0))))))));
    vlSelf->__VdfgTmp_h630336df__0 = (((IData)(vlSelf->wasmetal_core__DOT___005343_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h22773bc1__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005341_))));
    vlSelf->__VdfgTmp_h1bb342d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___003391_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h75fb7e4c__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003389_))));
    vlSelf->wasmetal_core__DOT___062465_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b117__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b117__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x14U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b117__05d)))))));
    vlSelf->__VdfgTmp_h90194312__0 = (((IData)(vlSelf->wasmetal_core__DOT___003323_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hf100045e__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003321_))));
    vlSelf->wasmetal_core__DOT___062467_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b118__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b118__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x15U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b118__05d)))))));
    vlSelf->__VdfgTmp_he61be2d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___005071_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hbe2bd06c__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005069_))));
    vlSelf->wasmetal_core__DOT___062472_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b120__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b120__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x17U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b120__05d)))))));
    vlSelf->wasmetal_core__DOT___052305_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h533e26e9__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b119__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053240_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hed80111e__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h533e26e9__0))))))));
    vlSelf->__VdfgTmp_h3fce9550__0 = (((IData)(vlSelf->wasmetal_core__DOT___005139_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h20122d13__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005137_))));
    vlSelf->wasmetal_core__DOT___003542_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002380_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002379_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbd2d90ad__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h81ca9b0b__0)))))))));
    vlSelf->wasmetal_core__DOT___003107_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbd2d90ad__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h81ca9b0b__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002380_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002379_)))))));
    vlSelf->wasmetal_core__DOT___003468_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002458_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002457_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7b9c68be__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha79a258b__0)))))))));
    vlSelf->wasmetal_core__DOT___003105_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7b9c68be__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha79a258b__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002458_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002457_)))))));
    vlSelf->wasmetal_core__DOT___004728_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002026_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002025_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3348ca28__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h30008db5__0)))))))));
    vlSelf->wasmetal_core__DOT___004727_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3348ca28__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h30008db5__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002026_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002025_)))))));
    vlSelf->wasmetal_core__DOT___004506_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001278_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001277_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h924e7878__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h37ae4b02__0)))))))));
    vlSelf->wasmetal_core__DOT___003097_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h924e7878__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h37ae4b02__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001278_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001277_)))))));
    vlSelf->wasmetal_core__DOT___004358_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001703_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001702_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha95b5bdf__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h491d2757__0)))))))));
    vlSelf->wasmetal_core__DOT___003099_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha95b5bdf__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h491d2757__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001703_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001702_)))))));
    vlSelf->wasmetal_core__DOT___004432_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001768_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001767_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h14eebae7__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc4db00d9__0)))))))));
    vlSelf->wasmetal_core__DOT___003101_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h14eebae7__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc4db00d9__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001768_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001767_)))))));
    vlSelf->wasmetal_core__DOT___003764_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002543_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002542_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hea93726f__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h64d4eb6a__0)))))))));
    vlSelf->wasmetal_core__DOT___003109_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hea93726f__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h64d4eb6a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002543_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002542_)))))));
    vlSelf->wasmetal_core__DOT___004580_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002223_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002222_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h82193735__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h63e29ec3__0)))))))));
    vlSelf->wasmetal_core__DOT___003103_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h82193735__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h63e29ec3__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002223_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002222_)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b107__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___062440_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hd380d548__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_he04a0e99__0))))))));
    vlSelf->__VdfgTmp_h6d082533__0 = (((IData)(vlSelf->wasmetal_core__DOT___003551_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h8b2f01bd__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003549_))));
    vlSelf->wasmetal_core__DOT__value_aux__05b106__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053182_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h18ef2d35__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hd9174715__0))))))));
    vlSelf->__VdfgTmp_h39365f5c__0 = (((IData)(vlSelf->wasmetal_core__DOT___003477_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hd9daf5f7__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003475_))));
    vlSelf->wasmetal_core__DOT__value_aux__05b99__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053157_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h51a38bc3__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h6e2b8153__0))))))));
    vlSelf->__VdfgTmp_h887e5924__0 = (((IData)(vlSelf->wasmetal_core__DOT___004737_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h04a005a2__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004735_))));
    vlSelf->wasmetal_core__DOT___052325_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9014fa0f__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b100__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053169_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hb29d3d73__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9014fa0f__0))))))));
    vlSelf->__VdfgTmp_hf8739cbc__0 = (((IData)(vlSelf->wasmetal_core__DOT___004515_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h2b893d79__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004513_))));
    vlSelf->wasmetal_core__DOT__value_aux__05b101__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053167_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_he7b219d6__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h11abcf6d__0))))))));
    vlSelf->__VdfgTmp_h220272bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___004367_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h61430f62__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004365_))));
    vlSelf->wasmetal_core__DOT___052364_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9e847741__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b102__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053173_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h2c3dfb0e__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9e847741__0))))))));
    vlSelf->__VdfgTmp_h193e1c6c__0 = (((IData)(vlSelf->wasmetal_core__DOT___004441_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hf6cb6b1e__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004439_))));
    vlSelf->wasmetal_core__DOT___052365_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hae654b01__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b105__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052342_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h14a07dbf__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hae654b01__0))))))));
    vlSelf->__VdfgTmp_h94e7c39f__0 = (((IData)(vlSelf->wasmetal_core__DOT___003625_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b105__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002412_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002411_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003623_))));
    vlSelf->__VdfgTmp_hacafc5c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003616_));
    vlSelf->wasmetal_core__DOT___052338_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4c8e22c1__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b104__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053180_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_ha9ea3386__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h4c8e22c1__0))))))));
    vlSelf->__VdfgTmp_h8103cb90__0 = (((IData)(vlSelf->wasmetal_core__DOT___003773_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h93ad939a__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003771_))));
    vlSelf->wasmetal_core__DOT___052324_ = (1U & (IData)(
                                                         (0x8888f00000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052320_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003389_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003179_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h8889c5b6__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3cd3193e__0)))))))))));
    vlSelf->__VdfgTmp_h7b80a3df__0 = (((IData)(vlSelf->wasmetal_core__DOT___004589_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hd77c56a5__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004587_))));
    vlSelf->wasmetal_core__DOT___070126_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070122_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b103__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->cmd_data[3U] 
                                                                >> 6U)) 
                                                            | (1U 
                                                               & (0xf38f2779U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))));
    vlSelf->wasmetal_core__DOT___062430_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b103__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b103__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 6U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b103__05d)))))));
    vlSelf->wasmetal_core__DOT___004044_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002304_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002303_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1e17785c__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h57f74169__0)))))))));
    vlSelf->wasmetal_core__DOT___004043_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1e17785c__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h57f74169__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002304_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002303_)))))));
    vlSelf->wasmetal_core__DOT___003920_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002351_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002350_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5fa501f3__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9047b303__0)))))))));
    vlSelf->wasmetal_core__DOT___003919_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h5fa501f3__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h9047b303__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002351_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002350_)))))));
    vlSelf->wasmetal_core__DOT___003400_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002628_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002627_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcced7fa9__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4fd522f6__0)))))))));
    vlSelf->wasmetal_core__DOT___003399_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hcced7fa9__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h4fd522f6__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002628_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002627_)))))));
    vlSelf->wasmetal_core__DOT___003332_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002591_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002590_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb92015b3__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h725e6949__0)))))))));
    vlSelf->wasmetal_core__DOT___003331_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb92015b3__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h725e6949__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002591_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002590_)))))));
    vlSelf->wasmetal_core__DOT___004266_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002258_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002257_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h33748258__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8c8a9440__0)))))))));
    vlSelf->wasmetal_core__DOT___004265_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h33748258__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8c8a9440__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002258_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002257_)))))));
    vlSelf->wasmetal_core__DOT___051970_ = (1U & (IData)(
                                                         (0x8888f00000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051961_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004951_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005087_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h360aedc6__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8a29f22b__0)))))))))));
    vlSelf->__VdfgTmp_hec648199__0 = (((IData)(vlSelf->wasmetal_core__DOT___005361_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b89__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002699_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002698_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005359_))));
    vlSelf->wasmetal_core__DOT___069868_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b89__05d))));
    vlSelf->wasmetal_core__DOT___062394_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b89__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b89__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x18U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b89__05d)))))));
    vlSelf->wasmetal_core__DOT___048245_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005352_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005351_)));
    vlSelf->__VdfgTmp_h8511382f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005351_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005352_));
    vlSelf->__VdfgTmp_h6332189a__0 = (((IData)(vlSelf->wasmetal_core__DOT___004053_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h187cbe57__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004051_))));
    vlSelf->wasmetal_core__DOT___069713_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0xfU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x12U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b82__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069710_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b82__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b82__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x12U))))))))));
    vlSelf->wasmetal_core__DOT___052054_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdcdc0b33__0))));
    vlSelf->wasmetal_core__DOT__value_aux__05b83__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052071_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h587b33f1__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hdcdc0b33__0))))))));
    vlSelf->__VdfgTmp_hd87a9123__0 = (((IData)(vlSelf->wasmetal_core__DOT___003837_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b83__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001207_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___001206_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003835_))));
    vlSelf->wasmetal_core__DOT___048139_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003828_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003827_)));
    vlSelf->__VdfgTmp_hc135e20a__0 = (((IData)(vlSelf->wasmetal_core__DOT___003827_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003828_));
    vlSelf->__VdfgTmp_h98759836__0 = (((IData)(vlSelf->wasmetal_core__DOT___003929_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h0b6168e4__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003927_))));
    vlSelf->wasmetal_core__DOT___069757_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0xfU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x11U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x14U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b84__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069754_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b84__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b84__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x14U))))))))));
    vlSelf->__VdfgTmp_he8c28620__0 = (((IData)(vlSelf->wasmetal_core__DOT___003409_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h4c3dd507__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003407_))));
    vlSelf->wasmetal_core__DOT___062385_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b85__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b85__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x14U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b85__05d)))))));
    vlSelf->wasmetal_core__DOT___069778_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x10U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x12U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x15U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b85__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069775_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b85__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b85__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x15U))))))))));
    vlSelf->__VdfgTmp_h2b07b055__0 = (((IData)(vlSelf->wasmetal_core__DOT___003341_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h8b19f5ab__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003339_))));
    vlSelf->wasmetal_core__DOT___069800_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x11U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x13U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x16U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b86__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069797_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b86__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b86__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x16U))))))))));
    vlSelf->__VdfgTmp_h29035176__0 = (((IData)(vlSelf->wasmetal_core__DOT___004275_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h96657cd6__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004273_))));
    vlSelf->wasmetal_core__DOT___062372_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b81__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b81__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x10U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b81__05d)))))));
    vlSelf->wasmetal_core__DOT___069696_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069691_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069690_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b81__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 0xfU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b81__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->__VdfgTmp_h15796065__0 = (((IData)(vlSelf->wasmetal_core__DOT___005089_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b88__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002660_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002659_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005087_))));
    vlSelf->wasmetal_core__DOT___069847_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b88__05d))));
    vlSelf->wasmetal_core__DOT___062392_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b88__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b88__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x17U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b88__05d)))))));
    vlSelf->wasmetal_core__DOT___048176_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005080_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005079_)));
    vlSelf->__VdfgTmp_h3ac48b87__0 = (((IData)(vlSelf->wasmetal_core__DOT___005079_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005080_));
    vlSelf->wasmetal_core__DOT__value_aux__05b87__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052103_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h128bed99__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h106a7f5e__0))))))));
    vlSelf->__VdfgTmp_h29fb25ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___005157_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b87__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002942_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002941_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005155_))));
    vlSelf->wasmetal_core__DOT___048071_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005148_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005147_)));
    vlSelf->__VdfgTmp_h26cb2e9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005147_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005148_));
    vlSelf->wasmetal_core__DOT___003902_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002341_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002340_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3971fc45__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1553b034__0)))))))));
    vlSelf->wasmetal_core__DOT___003901_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3971fc45__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h1553b034__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002341_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002340_)))))));
    vlSelf->wasmetal_core__DOT___004136_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002103_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002102_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc2399f9e__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h27f51ffd__0)))))))));
    vlSelf->wasmetal_core__DOT___003117_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc2399f9e__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h27f51ffd__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002103_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002102_)))))));
    vlSelf->wasmetal_core__DOT___004210_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002140_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002139_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3ed820c7__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hade513e3__0)))))))));
    vlSelf->wasmetal_core__DOT___003119_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3ed820c7__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hade513e3__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002140_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002139_)))))));
    vlSelf->wasmetal_core__DOT___004654_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002177_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002176_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_haa9d6aae__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3bb332b8__0)))))))));
    vlSelf->wasmetal_core__DOT___003121_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_haa9d6aae__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3bb332b8__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002177_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002176_)))))));
    vlSelf->wasmetal_core__DOT___004062_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002314_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002313_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h70b5eab4__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h59732ad2__0)))))))));
    vlSelf->wasmetal_core__DOT___004061_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h70b5eab4__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h59732ad2__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002314_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002313_)))))));
    vlSelf->wasmetal_core__DOT___003846_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001225_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001224_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h94eb455b__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf50294ef__0)))))))));
    vlSelf->wasmetal_core__DOT___003845_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h94eb455b__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf50294ef__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001225_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001224_)))))));
    vlSelf->wasmetal_core__DOT___004284_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002268_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002267_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5528d6fa__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h490ddce5__0)))))))));
    vlSelf->wasmetal_core__DOT___003115_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h5528d6fa__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h490ddce5__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002268_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002267_)))))));
    vlSelf->wasmetal_core__DOT___052295_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052276_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052275_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbad05108__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd77c56a5__0)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf6cb6b1e__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2b893d79__0)))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h61430f62__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___003988_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002065_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002064_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h78e77464__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8b07b599__0)))))))));
    vlSelf->wasmetal_core__DOT___003113_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h78e77464__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8b07b599__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002065_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002064_)))))));
    vlSelf->wasmetal_core__DOT___003690_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002501_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002500_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb129d53d__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3e2e569c__0)))))))));
    vlSelf->wasmetal_core__DOT___003689_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb129d53d__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3e2e569c__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002501_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002500_)))))));
    vlSelf->__VdfgTmp_ha2c9478b__0 = (((IData)(vlSelf->wasmetal_core__DOT___003911_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h0b18d540__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003909_))));
    vlSelf->wasmetal_core__DOT___062462_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b116__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b116__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x13U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b116__05d)))))));
    vlSelf->__VdfgTmp_hbea96df5__0 = (((IData)(vlSelf->wasmetal_core__DOT___004145_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h95c9c2c5__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004143_))));
    vlSelf->wasmetal_core__DOT___062445_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b108__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b108__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0xbU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b108__05d)))))));
    vlSelf->__VdfgTmp_h01f51344__0 = (((IData)(vlSelf->wasmetal_core__DOT___004219_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h7c824381__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004217_))));
    vlSelf->wasmetal_core__DOT___062447_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b109__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b109__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0xcU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b109__05d)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b110__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053205_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_he9f02b45__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h8b084513__0))))))));
    vlSelf->__VdfgTmp_h7ca24d8b__0 = (((IData)(vlSelf->wasmetal_core__DOT___004663_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hbd2119cc__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004661_))));
    vlSelf->__VdfgTmp_hb807ebfb__0 = (((IData)(vlSelf->wasmetal_core__DOT___004071_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h2098039d__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004069_))));
    vlSelf->wasmetal_core__DOT___062458_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b114__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b114__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x11U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b114__05d)))))));
    vlSelf->__VdfgTmp_hed09e4ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___003855_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h00d09e7a__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003853_))));
    vlSelf->wasmetal_core__DOT___062460_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b115__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b115__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x12U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b115__05d)))))));
    vlSelf->__VdfgTmp_hf4fd0700__0 = (((IData)(vlSelf->wasmetal_core__DOT___004293_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h5f1be76b__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004291_))));
    vlSelf->wasmetal_core__DOT___062456_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b113__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b113__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x10U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b113__05d)))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b112__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053222_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h1836318f__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_h6806bd5e__0))))))));
    vlSelf->__VdfgTmp_hb2ba9050__0 = (((IData)(vlSelf->wasmetal_core__DOT___003997_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hbad05108__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003995_))));
    vlSelf->wasmetal_core__DOT__value_aux__05b111__05d 
        = (1U & (IData)((0xfff0fff033335555ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053224_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xc0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hcf8490b8__0)))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_he6df8ac0__0))))))));
    vlSelf->__VdfgTmp_he18e3e19__0 = (((IData)(vlSelf->wasmetal_core__DOT___003699_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hc7901b89__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003697_))));
    vlSelf->wasmetal_core__DOT___003970_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002055_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002054_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h81a5b0aa__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h51fb7abf__0)))))))));
    vlSelf->wasmetal_core__DOT___003969_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h81a5b0aa__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h51fb7abf__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002055_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002054_)))))));
    vlSelf->wasmetal_core__DOT___003450_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002448_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002447_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hde496412__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h97f578c1__0)))))))));
    vlSelf->wasmetal_core__DOT___003449_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hde496412__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h97f578c1__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002448_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002447_)))))));
    vlSelf->wasmetal_core__DOT___003524_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002370_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002369_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd368a607__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h05ad6ae6__0)))))))));
    vlSelf->wasmetal_core__DOT___003523_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd368a607__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h05ad6ae6__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002370_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002369_)))))));
    vlSelf->wasmetal_core__DOT___004118_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002093_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002092_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfbf79e7b__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb7be35e7__0)))))))));
    vlSelf->wasmetal_core__DOT___004117_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfbf79e7b__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb7be35e7__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002093_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002092_)))))));
    vlSelf->wasmetal_core__DOT___004192_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002130_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002129_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he0d5eea6__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h98cd7462__0)))))))));
    vlSelf->wasmetal_core__DOT___004191_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he0d5eea6__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h98cd7462__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002130_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002129_)))))));
    vlSelf->wasmetal_core__DOT___004636_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002167_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002166_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb62a6dc2__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfdc5949f__0)))))))));
    vlSelf->wasmetal_core__DOT___004635_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb62a6dc2__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfdc5949f__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002167_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002166_)))))));
    vlSelf->wasmetal_core__DOT___003746_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002533_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002532_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hab141f26__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7f4a56d5__0)))))))));
    vlSelf->wasmetal_core__DOT___003745_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hab141f26__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7f4a56d5__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002533_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002532_)))))));
    vlSelf->wasmetal_core__DOT___003672_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002491_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002490_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfe998686__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h395f448e__0)))))))));
    vlSelf->wasmetal_core__DOT___003671_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfe998686__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h395f448e__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002491_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002490_)))))));
    vlSelf->wasmetal_core__DOT___052084_ = (1U & (IData)(
                                                         (0xac00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052080_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052079_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052078_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052077_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_ha5352532__0)))))))))));
    vlSelf->__VdfgTmp_hf123ec52__0 = (((IData)(vlSelf->wasmetal_core__DOT___003979_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h56438591__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003977_))));
    vlSelf->wasmetal_core__DOT___062370_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b80__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b80__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0xfU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b80__05d)))))));
    vlSelf->__VdfgTmp_h2cf790ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___003459_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h2d07d754__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003457_))));
    vlSelf->wasmetal_core__DOT___062354_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b74__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b74__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 9U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b74__05d)))))));
    vlSelf->wasmetal_core__DOT___069534_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069530_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069529_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b74__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 8U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b74__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->wasmetal_core__DOT___069533_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 5U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 7U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xaU))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b74__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___051971_ = (1U & (IData)(
                                                         (0x8888f00000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051966_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004883_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005607_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h1aa0b795__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hbd6eb77c__0)))))))))));
    vlSelf->__VdfgTmp_h7482f819__0 = (((IData)(vlSelf->wasmetal_core__DOT___003533_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h6823128b__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003531_))));
    vlSelf->wasmetal_core__DOT___062357_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b75__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b75__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0xaU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b75__05d)))))));
    vlSelf->__VdfgTmp_hf7e0ef4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___004127_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h7e6d032b__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004125_))));
    vlSelf->wasmetal_core__DOT___062359_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b76__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b76__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0xbU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b76__05d)))))));
    vlSelf->wasmetal_core__DOT___069583_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069578_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069577_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b76__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 0xaU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b76__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->__VdfgTmp_h31491600__0 = (((IData)(vlSelf->wasmetal_core__DOT___004201_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h04cce861__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004199_))));
    vlSelf->wasmetal_core__DOT___069603_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069599_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069598_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b77__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 0xbU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b77__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->wasmetal_core__DOT___069602_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 8U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0xaU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xdU))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b77__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->__VdfgTmp_h19aa2548__0 = (((IData)(vlSelf->wasmetal_core__DOT___004645_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h9efd96c7__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004643_))));
    vlSelf->wasmetal_core__DOT___069626_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b78__05d))));
    vlSelf->wasmetal_core__DOT___062364_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b78__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b78__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0xdU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b78__05d)))))));
    vlSelf->__VdfgTmp_h2b63e99d__0 = (((IData)(vlSelf->wasmetal_core__DOT___003607_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b73__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002402_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002401_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003605_))));
    vlSelf->wasmetal_core__DOT___062351_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b73__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b73__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 8U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b73__05d)))))));
    vlSelf->wasmetal_core__DOT___069510_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x153f00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069506_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069505_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b73__05d) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & (vlSelf->cmd_data[2U] 
                                                                              >> 7U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b73__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051016_)))));
    vlSelf->wasmetal_core__DOT___069509_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 6U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 9U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b73__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___052828_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003597_))));
    vlSelf->wasmetal_core__DOT___048230_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003598_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___003597_)));
    vlSelf->__VdfgTmp_hc0be46f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___003597_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003598_));
    vlSelf->__VdfgTmp_h88d138aa__0 = (((IData)(vlSelf->wasmetal_core__DOT___003755_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hb156040c__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003753_))));
    vlSelf->wasmetal_core__DOT___062348_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b72__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b72__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 7U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b72__05d)))))));
    vlSelf->__VdfgTmp_he8484823__0 = (((IData)(vlSelf->wasmetal_core__DOT___003681_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_he10ebbb0__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003679_))));
    vlSelf->wasmetal_core__DOT___069646_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0xcU)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xfU))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b79__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069643_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b79__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b79__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0xfU))))))))));
    vlSelf->wasmetal_core__DOT___004562_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002213_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002212_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb257a383__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8934d805__0)))))))));
    vlSelf->wasmetal_core__DOT___004561_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hb257a383__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8934d805__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002213_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002212_)))))));
    vlSelf->wasmetal_core__DOT___052085_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052062_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052061_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052060_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h06d51d42__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h56438591__0)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0b6168e4__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h57451afb__0)))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed1d041c__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___004488_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001268_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001267_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h04880fd7__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8fe0413e__0)))))))));
    vlSelf->wasmetal_core__DOT___004487_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h04880fd7__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h8fe0413e__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001268_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001267_)))))));
    vlSelf->wasmetal_core__DOT___004340_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001693_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001692_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc20a91e7__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h772b8f1d__0)))))))));
    vlSelf->wasmetal_core__DOT___004339_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc20a91e7__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h772b8f1d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001693_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001692_)))))));
    vlSelf->wasmetal_core__DOT___004414_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001758_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001757_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h97006b3e__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7211f94c__0)))))))));
    vlSelf->wasmetal_core__DOT___004413_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h97006b3e__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7211f94c__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001758_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001757_)))))));
    vlSelf->wasmetal_core__DOT___003234_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001916_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001915_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h336c7598__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbdb7c255__0)))))))));
    vlSelf->wasmetal_core__DOT___003233_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h336c7598__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbdb7c255__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001916_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001915_)))))));
    vlSelf->wasmetal_core__DOT___003151_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001825_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___001824_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h302dd625__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha7aa500a__0)))))))));
    vlSelf->wasmetal_core__DOT___003150_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h302dd625__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_ha7aa500a__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001825_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___001824_)))))));
    vlSelf->__VdfgTmp_h41785ae8__0 = (((IData)(vlSelf->wasmetal_core__DOT___004571_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h18733fd3__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004569_))));
    vlSelf->wasmetal_core__DOT___069462_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b71__05d))));
    vlSelf->wasmetal_core__DOT___062345_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b71__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b71__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 6U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b71__05d)))))));
    vlSelf->__VdfgTmp_heecb7e70__0 = (((IData)(vlSelf->wasmetal_core__DOT___004793_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b66__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001973_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___001972_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004791_))));
    vlSelf->wasmetal_core__DOT___062330_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b66__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b66__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b66__05d)))))));
    vlSelf->wasmetal_core__DOT___048038_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004784_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004783_)));
    vlSelf->__VdfgTmp_h5877aba2__0 = (((IData)(vlSelf->wasmetal_core__DOT___004783_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004784_));
    vlSelf->__VdfgTmp_hd9d86825__0 = (((IData)(vlSelf->wasmetal_core__DOT___004719_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b67__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002008_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002007_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004717_))));
    vlSelf->wasmetal_core__DOT___062333_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b67__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b67__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b67__05d)))))));
    vlSelf->wasmetal_core__DOT___048153_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004710_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___004709_)));
    vlSelf->__VdfgTmp_hdb8b9d9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___004709_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004710_));
    vlSelf->__VdfgTmp_hfb5e3b7e__0 = (((IData)(vlSelf->wasmetal_core__DOT___004497_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h57451afb__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004495_))));
    vlSelf->wasmetal_core__DOT___062335_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b68__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b68__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 3U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b68__05d)))))));
    vlSelf->__VdfgTmp_h1d47507a__0 = (((IData)(vlSelf->wasmetal_core__DOT___004349_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hed1d041c__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004347_))));
    vlSelf->wasmetal_core__DOT___062338_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b69__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b69__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 4U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b69__05d)))))));
    vlSelf->__VdfgTmp_h9b6447c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___004423_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h06d51d42__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004421_))));
    vlSelf->wasmetal_core__DOT___069436_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b70__05d))));
    vlSelf->wasmetal_core__DOT___062343_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b70__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b70__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 5U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b70__05d)))))));
    vlSelf->__VdfgTmp_h5bb31d88__0 = (((IData)(vlSelf->wasmetal_core__DOT___003243_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h9a831d1c__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003241_))));
    vlSelf->wasmetal_core__DOT___062328_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b65__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b65__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & vlSelf->mem_rdata[2U]) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b65__05d)))))));
    vlSelf->__VdfgTmp_h7e49e6e6__0 = (((IData)(vlSelf->wasmetal_core__DOT___003163_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h3e0c1557__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003161_))));
    vlSelf->wasmetal_core__DOT___062325_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b64__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b64__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b64__05d)))))));
    vlSelf->wasmetal_core__DOT___052176_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h98b5e894__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052168_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6aba24e3__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b63__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052168_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6aba24e3__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h98b5e894__0))))))));
    vlSelf->__VdfgTmp_hee23ef9b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005645_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b63__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001177_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___001176_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005643_))));
    vlSelf->wasmetal_core__DOT___034342_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001330_))));
    vlSelf->__VdfgTmp_h965c3061__0 = (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005636_));
    vlSelf->wasmetal_core__DOT___005198_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___002921_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___002920_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5a3a45b7__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h21ed485e__0)))))))));
    vlSelf->wasmetal_core__DOT___005197_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h5a3a45b7__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h21ed485e__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___002921_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___002920_)))))));
    vlSelf->wasmetal_core__DOT___005582_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003145_) 
                                                    << 2U) 
                                                   | ((0xfffffffeU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                          & (((1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                               ? (IData)(vlSelf->wasmetal_core__DOT___003080_)
                                                               : (IData)(vlSelf->wasmetal_core__DOT___003079_)) 
                                                             << 1U))) 
                                                      | (1U 
                                                         & ((1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O))
                                                             ? 
                                                            (0xcaU 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_he6a8c031__0)))
                                                             : 
                                                            (0xe2U 
                                                             >> 
                                                             ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h61222d2d__0)))))))));
    vlSelf->wasmetal_core__DOT___005581_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000416_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                            ? 
                                                           (0xcaU 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_he6a8c031__0)))
                                                            : 
                                                           (0xe2U 
                                                            >> 
                                                            ((8U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                 << 3U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h61222d2d__0)))) 
                                                          << 1U)) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___003080_)
                                                             : (IData)(vlSelf->wasmetal_core__DOT___003079_)))))));
    vlSelf->wasmetal_core__DOT___052371_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052355_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052354_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052353_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc39d0419__0)))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcd3797e9__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xac00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052345_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052344_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052343_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052342_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h14a07dbf__0)))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8b2f01bd__0)))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd9daf5f7__0))))))))))))))));
    vlSelf->__VdfgTmp_h8b941ffe__0 = (((IData)(vlSelf->wasmetal_core__DOT___005207_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hbeaa94ef__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005205_))));
    vlSelf->wasmetal_core__DOT___062489_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b126__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b126__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x1dU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b126__05d)))))));
    vlSelf->__VdfgTmp_hd2cb6624__0 = (((IData)(vlSelf->wasmetal_core__DOT___005591_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_hb342b047__0)))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005589_))));
    vlSelf->wasmetal_core__DOT___062492_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b127__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b127__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x1eU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b127__05d)))))));
    vlSelf->wasmetal_core__DOT___069197_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b62__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0x1dU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___034341_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001169_))));
    vlSelf->wasmetal_core__DOT___005455_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005244_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001169_)));
    vlSelf->__VdfgTmp_hf266c674__0 = (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005244_));
    vlSelf->__VdfgTmp_h39540d35__0 = (((IData)(vlSelf->wasmetal_core__DOT___001165_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001164_));
    vlSelf->wasmetal_core__DOT___069132_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x1bU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b61__05d)))))))));
    vlSelf->wasmetal_core__DOT___034340_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001147_))));
    vlSelf->wasmetal_core__DOT___045151_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001330_)))))))));
    vlSelf->wasmetal_core__DOT___045175_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001330_)))))))));
    vlSelf->wasmetal_core__DOT___005418_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005312_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001147_)));
    vlSelf->__VdfgTmp_h26fdb0d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005312_));
    vlSelf->__VdfgTmp_hffec0e42__0 = (((IData)(vlSelf->wasmetal_core__DOT___001143_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001142_));
    vlSelf->__VdfgTmp_h14b4bf2b__0 = (((IData)(vlSelf->wasmetal_core__DOT___052189_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052188_));
    vlSelf->wasmetal_core__DOT___069083_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069081_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069080_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x1aU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___034339_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001125_))));
    vlSelf->wasmetal_core__DOT___052770_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001125_))));
    vlSelf->wasmetal_core__DOT___005408_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004904_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001125_)));
    vlSelf->__VdfgTmp_hc23ff14f__0 = (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004904_));
    vlSelf->__VdfgTmp_h15e8b450__0 = (((IData)(vlSelf->wasmetal_core__DOT___001121_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001120_));
    vlSelf->wasmetal_core__DOT___069053_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b59__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0x1aU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->__VdfgTmp_hbd97d07b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___004904_)));
    vlSelf->wasmetal_core__DOT___034337_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001103_))));
    vlSelf->__VdfgTmp_he56eea3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005040_));
    vlSelf->__VdfgTmp_h638471cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___001099_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001098_));
    vlSelf->wasmetal_core__DOT___069004_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b58__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0x19U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___034336_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001081_))));
    vlSelf->wasmetal_core__DOT___045150_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004972_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004904_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001103_)))))))));
    vlSelf->wasmetal_core__DOT___045174_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004904_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004972_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001081_)))))))));
    vlSelf->wasmetal_core__DOT___005388_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004972_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___001081_)));
    vlSelf->__VdfgTmp_h99cf87be__0 = (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004972_));
    vlSelf->__VdfgTmp_h82a219c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___001077_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001076_));
    vlSelf->wasmetal_core__DOT___068955_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b57__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0x18U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___034335_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001059_))));
    vlSelf->__VdfgTmp_hbd712dd8__0 = (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005380_));
    vlSelf->__VdfgTmp_h60872440__0 = (((IData)(vlSelf->wasmetal_core__DOT___001055_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001054_));
    vlSelf->wasmetal_core__DOT___068887_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068885_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x16U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b56__05d)))))))));
    vlSelf->__VdfgTmp_hfe9e3bd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005380_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___004972_)));
    vlSelf->wasmetal_core__DOT___034334_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001037_))));
    vlSelf->__VdfgTmp_hb3e18d1b__0 = (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001037_));
    vlSelf->__VdfgTmp_hd5ee5b41__0 = (((IData)(vlSelf->wasmetal_core__DOT___001037_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005108_));
    vlSelf->__VdfgTmp_h881dfff7__0 = (((IData)(vlSelf->wasmetal_core__DOT___001033_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001032_));
    vlSelf->wasmetal_core__DOT___068839_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068838_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068837_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x15U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b55__05d)))))))));
    vlSelf->wasmetal_core__DOT___034333_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001015_))));
    vlSelf->wasmetal_core__DOT___045172_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005380_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001037_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001015_)))))))));
    vlSelf->__VdfgTmp_ha04b46b6__0 = (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005176_));
    vlSelf->__VdfgTmp_h69848182__0 = (((IData)(vlSelf->wasmetal_core__DOT___001011_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001010_));
    vlSelf->__VdfgTmp_h23d702b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___052449_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052448_));
    vlSelf->wasmetal_core__DOT___068809_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b54__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0x15U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___034332_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000993_))));
    vlSelf->wasmetal_core__DOT___005485_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003360_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000993_)));
    vlSelf->__VdfgTmp_h59798d13__0 = (((IData)(vlSelf->wasmetal_core__DOT___000993_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003360_));
    vlSelf->__VdfgTmp_h426f01c6__0 = (((IData)(vlSelf->wasmetal_core__DOT___000989_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000988_));
    vlSelf->wasmetal_core__DOT___068739_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068738_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b53__05d)))))))));
    vlSelf->__VdfgTmp_h92d5757b__0 = (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003360_)));
    vlSelf->wasmetal_core__DOT___034331_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000981_))));
    vlSelf->wasmetal_core__DOT___005475_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003428_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000981_)));
    vlSelf->__VdfgTmp_h4b249985__0 = (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003428_));
    vlSelf->__VdfgTmp_ha7c65fb3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000977_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000976_));
    vlSelf->wasmetal_core__DOT___068695_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068692_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x12U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT___034330_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000926_))));
    vlSelf->wasmetal_core__DOT___045147_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003360_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000926_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000993_)))))))));
    vlSelf->wasmetal_core__DOT___045171_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003360_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000993_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000926_)))))))));
    vlSelf->wasmetal_core__DOT___005465_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___003948_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000926_)));
    vlSelf->__VdfgTmp_h5d0edfe8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000926_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003948_));
    vlSelf->__VdfgTmp_h3ff94b24__0 = (((IData)(vlSelf->wasmetal_core__DOT___001324_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001323_));
    vlSelf->wasmetal_core__DOT___052445_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hf33ae1e8__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052443_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6366d506__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b51__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052443_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6366d506__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf33ae1e8__0))))))));
    vlSelf->__VdfgTmp_h5f9a0992__0 = (((IData)(vlSelf->wasmetal_core__DOT___003885_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003884_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003883_))));
    vlSelf->wasmetal_core__DOT___034329_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000927_))));
    vlSelf->__VdfgTmp_hf825dcba__0 = (((IData)(vlSelf->wasmetal_core__DOT___000927_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003876_));
    vlSelf->wasmetal_core__DOT___052447_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hccc0d080__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052439_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hbe4c2cfb__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b50__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052439_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbe4c2cfb__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hccc0d080__0))))))));
    vlSelf->__VdfgTmp_h5172aa32__0 = (((IData)(vlSelf->wasmetal_core__DOT___004101_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004100_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004099_))));
    vlSelf->__VdfgTmp_h7b969d91__0 = (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003948_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003876_)));
    vlSelf->wasmetal_core__DOT___034328_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000897_))));
    vlSelf->wasmetal_core__DOT___052767_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000926_))));
    vlSelf->__VdfgTmp_hd7f74d59__0 = (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004092_));
    vlSelf->wasmetal_core__DOT___052446_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h39926e96__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052435_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h650b1858__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b49__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052435_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h650b1858__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h39926e96__0))))))));
    vlSelf->__VdfgTmp_h56fd8038__0 = (((IData)(vlSelf->wasmetal_core__DOT___004323_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004322_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004321_))));
    vlSelf->wasmetal_core__DOT___034326_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000896_))));
    vlSelf->wasmetal_core__DOT___052766_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000927_))));
    vlSelf->wasmetal_core__DOT___045146_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003876_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000927_)))))))));
    vlSelf->wasmetal_core__DOT___045170_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003876_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000927_)))))))));
    vlSelf->__VdfgTmp_hef5b3f20__0 = (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004314_));
    vlSelf->wasmetal_core__DOT___052450_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h58c7b8aa__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052431_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf5ca71c3__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b48__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052431_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf5ca71c3__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h58c7b8aa__0))))))));
    vlSelf->__VdfgTmp_hde7deab4__0 = (((IData)(vlSelf->wasmetal_core__DOT___004027_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004026_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004025_))));
    vlSelf->wasmetal_core__DOT___034325_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000873_))));
    vlSelf->__VdfgTmp_hfec86816__0 = (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004018_));
    vlSelf->wasmetal_core__DOT___052142_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h9b219d07__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052131_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h57e567b8__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b47__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052131_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h57e567b8__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9b219d07__0))))))));
    vlSelf->__VdfgTmp_hca53b37a__0 = (((IData)(vlSelf->wasmetal_core__DOT___003729_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003728_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003727_))));
    vlSelf->__VdfgTmp_h73e9a4a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___004018_)));
    vlSelf->wasmetal_core__DOT___034324_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000872_))));
    vlSelf->__VdfgTmp_h97b1be8c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003720_));
    vlSelf->wasmetal_core__DOT___052141_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h21caabb4__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052127_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc3ffba8a__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b46__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052127_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc3ffba8a__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h21caabb4__0))))))));
    vlSelf->__VdfgTmp_hfa0f79c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___004693_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004692_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004691_))));
    vlSelf->wasmetal_core__DOT___034323_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000849_))));
    vlSelf->wasmetal_core__DOT___045145_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004684_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004018_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000873_)))))))));
    vlSelf->wasmetal_core__DOT___045169_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003720_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004018_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004684_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000849_)))))))));
    vlSelf->__VdfgTmp_h2cbbdbef__0 = (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004684_));
    vlSelf->wasmetal_core__DOT___052264_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd35a9dc8__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052196_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_ha87e62b8__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b45__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052196_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha87e62b8__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd35a9dc8__0))))))));
    vlSelf->__VdfgTmp_h3fc388f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___004249_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004248_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004247_))));
    vlSelf->wasmetal_core__DOT___034322_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000848_))));
    vlSelf->__VdfgTmp_h1fd76cb3__0 = (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004240_));
    vlSelf->wasmetal_core__DOT___052263_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h31a231e1__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052261_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h807ad9d2__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b44__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052261_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h807ad9d2__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h31a231e1__0))))))));
    vlSelf->__VdfgTmp_ha15d8995__0 = (((IData)(vlSelf->wasmetal_core__DOT___004175_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004174_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004173_))));
    vlSelf->__VdfgTmp_ha17b8b2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___004684_)));
    vlSelf->wasmetal_core__DOT___034321_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000824_))));
    vlSelf->__VdfgTmp_h598b279f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004166_));
    vlSelf->wasmetal_core__DOT___052507_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hc1c0d33f__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052498_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h456da093__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b43__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052498_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h456da093__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc1c0d33f__0))))))));
    vlSelf->__VdfgTmp_he2dbc386__0 = (((IData)(vlSelf->wasmetal_core__DOT___003581_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003580_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003579_))));
    vlSelf->wasmetal_core__DOT___034320_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000825_))));
    vlSelf->wasmetal_core__DOT___045144_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000824_)))))))));
    vlSelf->wasmetal_core__DOT___045168_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004240_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004166_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000825_)))))))));
    vlSelf->__VdfgTmp_h8d1b60d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003572_));
    vlSelf->wasmetal_core__DOT___052506_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h01d0ee79__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052494_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc5f6f937__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b42__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052494_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc5f6f937__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h01d0ee79__0))))))));
    vlSelf->__VdfgTmp_haaa3ad0b__0 = (((IData)(vlSelf->wasmetal_core__DOT___003507_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003506_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003505_))));
    vlSelf->wasmetal_core__DOT___034319_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000796_))));
    vlSelf->__VdfgTmp_h38fb75d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___000796_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003498_));
    vlSelf->wasmetal_core__DOT___052138_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he23a6b26__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052135_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd28cbf2a__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b41__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052135_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd28cbf2a__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he23a6b26__0))))))));
    vlSelf->__VdfgTmp_h3ec183f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___003655_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003654_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003653_))));
    vlSelf->__VdfgTmp_had3e30f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003498_)));
    vlSelf->wasmetal_core__DOT___034318_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000795_))));
    vlSelf->__VdfgTmp_hfe166c9c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003646_));
    vlSelf->wasmetal_core__DOT___052137_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h07a3b670__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052112_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hb4397905__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b40__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052112_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb4397905__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h07a3b670__0))))))));
    vlSelf->__VdfgTmp_ha7c76017__0 = (((IData)(vlSelf->wasmetal_core__DOT___003803_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003802_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003801_))));
    vlSelf->wasmetal_core__DOT___034317_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000772_))));
    vlSelf->wasmetal_core__DOT___052764_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000849_)))))))));
    vlSelf->wasmetal_core__DOT___045143_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003498_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000796_)))))))));
    vlSelf->wasmetal_core__DOT___045167_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003498_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000796_)))))))));
    vlSelf->__VdfgTmp_h0ee6a0be__0 = (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003794_));
    vlSelf->wasmetal_core__DOT___052417_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he0dafd81__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052410_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hce8a559f__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b39__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052410_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hce8a559f__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he0dafd81__0))))))));
    vlSelf->__VdfgTmp_h97352ffe__0 = (((IData)(vlSelf->wasmetal_core__DOT___004619_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004618_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004617_))));
    vlSelf->wasmetal_core__DOT___034315_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000771_))));
    vlSelf->__VdfgTmp_h94bf9d34__0 = (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004610_));
    vlSelf->wasmetal_core__DOT___052416_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h2b977022__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052406_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc5320df5__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b38__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052406_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hc5320df5__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2b977022__0))))))));
    vlSelf->__VdfgTmp_h01ca3900__0 = (((IData)(vlSelf->wasmetal_core__DOT___004471_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004470_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004469_))));
    vlSelf->__VdfgTmp_hf21c6828__0 = (((IData)(vlSelf->wasmetal_core__DOT___004462_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003794_)));
    vlSelf->wasmetal_core__DOT___034314_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000747_))));
    vlSelf->__VdfgTmp_h58f52bdc__0 = (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004462_));
    vlSelf->wasmetal_core__DOT___052508_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd438e6c0__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052501_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd6e95fa8__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b37__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052501_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hd6e95fa8__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd438e6c0__0))))))));
    vlSelf->__VdfgTmp_h2bc911a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___004397_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004396_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004395_))));
    vlSelf->wasmetal_core__DOT___034313_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000748_))));
    vlSelf->wasmetal_core__DOT___045142_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004388_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004462_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000747_)))))))));
    vlSelf->wasmetal_core__DOT___045166_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004462_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004388_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000748_)))))))));
    vlSelf->__VdfgTmp_hcf95a844__0 = (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004388_));
    vlSelf->wasmetal_core__DOT___052505_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h50f5670e__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052490_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8fdaff69__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b36__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052490_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h8fdaff69__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h50f5670e__0))))))));
    vlSelf->__VdfgTmp_hc61dfdcc__0 = (((IData)(vlSelf->wasmetal_core__DOT___004545_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004544_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004543_))));
    vlSelf->wasmetal_core__DOT___034312_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000723_))));
    vlSelf->__VdfgTmp_h20a4ea67__0 = (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004536_));
    vlSelf->wasmetal_core__DOT___052190_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he2ad86dc__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052150_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hb26c7187__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b35__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052150_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb26c7187__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_he2ad86dc__0))))))));
    vlSelf->__VdfgTmp_h33ea4c85__0 = (((IData)(vlSelf->wasmetal_core__DOT___004767_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004766_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004765_))));
    vlSelf->__VdfgTmp_hc8d209ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___004388_)));
    vlSelf->wasmetal_core__DOT___034311_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000724_))));
    vlSelf->__VdfgTmp_hf98ad324__0 = (((IData)(vlSelf->wasmetal_core__DOT___000724_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004758_));
    vlSelf->wasmetal_core__DOT___052192_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h4cb51258__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052181_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf3a0142d__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b34__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052181_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf3a0142d__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h4cb51258__0))))))));
    vlSelf->__VdfgTmp_heeded769__0 = (((IData)(vlSelf->wasmetal_core__DOT___004841_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___004840_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___004839_))));
    vlSelf->wasmetal_core__DOT___034310_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000694_))));
    vlSelf->wasmetal_core__DOT___045141_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000724_)))))))));
    vlSelf->wasmetal_core__DOT___045165_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004536_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000724_)))))))));
    vlSelf->__VdfgTmp_h84433958__0 = (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004832_));
    vlSelf->wasmetal_core__DOT___052191_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h319b52f0__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052154_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h13262e9c__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b33__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052154_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h13262e9c__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h319b52f0__0))))))));
    vlSelf->__VdfgTmp_h2f17a8a4__0 = (((IData)(vlSelf->wasmetal_core__DOT___003297_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000698_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___000697_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003295_))));
    vlSelf->wasmetal_core__DOT___034309_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000693_))));
    vlSelf->__VdfgTmp_hd2ae5a25__0 = (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003288_));
    vlSelf->wasmetal_core__DOT___052418_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h0683198f__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052414_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1512c46f__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b32__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052414_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h1512c46f__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h0683198f__0))))))));
    vlSelf->__VdfgTmp_h51a3fd4e__0 = (((IData)(vlSelf->wasmetal_core__DOT___003217_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000674_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___000673_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___003215_))));
    vlSelf->__VdfgTmp_hdb6fbe09__0 = (((IData)(vlSelf->wasmetal_core__DOT___003208_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___003288_)));
    vlSelf->wasmetal_core__DOT___034308_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000665_))));
    vlSelf->wasmetal_core__DOT___052765_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000724_)))))))));
    vlSelf->__VdfgTmp_ha7f22436__0 = (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000665_));
    vlSelf->__VdfgTmp_h4bbfe337__0 = (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003208_));
    vlSelf->wasmetal_core__DOT___052235_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h7752095d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052230_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h149fa621__0)))))))))));
    vlSelf->wasmetal_core__DOT__value_aux__05b31__05d 
        = (1U & (IData)((0xff33330f0f5555ULL >> (((IData)(vlSelf->wasmetal_core__DOT___051019_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052581_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052230_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h149fa621__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h7752095d__0))))))));
    vlSelf->__VdfgTmp_hbfbeb842__0 = (((IData)(vlSelf->wasmetal_core__DOT___005627_) 
                                       << 3U) | ((4U 
                                                  & ((IData)(
                                                             (0xff555503f303f3ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000263_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000262_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000684_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___000683_)))))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___005625_))));
    vlSelf->wasmetal_core__DOT___052818_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005079_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005617_))));
    vlSelf->wasmetal_core__DOT___052583_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02ewide))));
    vlSelf->wasmetal_core__DOT___028485_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005618_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005617_))));
    vlSelf->wasmetal_core__DOT___048006_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005618_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___005617_)));
    vlSelf->__VdfgTmp_h3edf8090__0 = (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005618_));
    vlSelf->wasmetal_core__DOT___028972_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052234_))));
    vlSelf->wasmetal_core__DOT___067444_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 0x1dU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___028660_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052234_))));
    vlSelf->wasmetal_core__DOT___054035_ = (1U & (0xb00bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b30__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005618_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b31__05d))))));
    vlSelf->wasmetal_core__DOT___028484_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000658_))));
    vlSelf->wasmetal_core__DOT___048169_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005232_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000658_)));
    vlSelf->__VdfgTmp_h5c9b01b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005232_));
    vlSelf->__VdfgTmp_hb653ab3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000654_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000653_));
    vlSelf->wasmetal_core__DOT___028970_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052233_))));
    vlSelf->wasmetal_core__DOT___067396_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b29__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b29__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x1dU))))));
    vlSelf->wasmetal_core__DOT___028658_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052233_))));
    vlSelf->wasmetal_core__DOT___044537_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005617_)))))))));
    vlSelf->wasmetal_core__DOT___044549_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005617_)))))))));
    vlSelf->wasmetal_core__DOT___028482_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000636_))));
    vlSelf->wasmetal_core__DOT___048240_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005300_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000636_)));
    vlSelf->__VdfgTmp_hc454ae75__0 = (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005300_));
    vlSelf->__VdfgTmp_h3063303a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000632_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000631_));
    vlSelf->wasmetal_core__DOT___028969_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052232_))));
    vlSelf->__VdfgTmp_h7bad9dec__0 = (((IData)(vlSelf->wasmetal_core__DOT___052233_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052232_));
    vlSelf->wasmetal_core__DOT___067295_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b28__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b28__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x1cU))))));
    vlSelf->wasmetal_core__DOT___028657_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052232_))));
    vlSelf->__VdfgTmp_h4c543443__0 = (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000614_)));
    vlSelf->wasmetal_core__DOT___045139_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004892_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000636_)))))))));
    vlSelf->wasmetal_core__DOT___028481_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000614_))));
    vlSelf->wasmetal_core__DOT___048181_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004892_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000614_)));
    vlSelf->__VdfgTmp_hb30bed30__0 = (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004892_));
    vlSelf->__VdfgTmp_h69cbf44b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000610_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000609_));
    vlSelf->wasmetal_core__DOT___028968_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052567_))));
    vlSelf->wasmetal_core__DOT___067252_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b27__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b27__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[0U] 
                                                            >> 0x1bU))))));
    vlSelf->wasmetal_core__DOT___028656_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052567_))));
    vlSelf->wasmetal_core__DOT___054028_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b31__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005618_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005028_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b27__05d))))));
    vlSelf->wasmetal_core__DOT___028480_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000592_))));
    vlSelf->wasmetal_core__DOT___048256_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___005028_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000592_)));
    vlSelf->__VdfgTmp_hc7b7ff9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005028_));
    vlSelf->__VdfgTmp_h81d9a883__0 = (((IData)(vlSelf->wasmetal_core__DOT___000588_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000587_));
    vlSelf->wasmetal_core__DOT___028967_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052566_))));
    vlSelf->wasmetal_core__DOT___067142_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           >> 0x19U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___028655_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004960_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052566_))));
    vlSelf->wasmetal_core__DOT___051952_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005012_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004994_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004972_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004960_)))))))));
    vlSelf->wasmetal_core__DOT___044546_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004972_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004904_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000592_)))))))));
    vlSelf->wasmetal_core__DOT___044558_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___004904_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004972_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000565_)))))))));
    vlSelf->wasmetal_core__DOT___045443_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052566_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052232_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052567_)))))))));
    vlSelf->wasmetal_core__DOT___045455_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052232_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052567_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052566_)))))))));
    vlSelf->wasmetal_core__DOT___028479_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___004960_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000565_))));
    vlSelf->wasmetal_core__DOT___048179_ = ((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___004960_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___000565_)));
}
