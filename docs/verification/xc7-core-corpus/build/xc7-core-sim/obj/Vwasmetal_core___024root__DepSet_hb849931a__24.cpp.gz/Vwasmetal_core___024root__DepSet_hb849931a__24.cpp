#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__30(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__30\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006582_;
    wasmetal_core__DOT___006582_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015598_;
    wasmetal_core__DOT___015598_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015599_;
    wasmetal_core__DOT___015599_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015659_;
    wasmetal_core__DOT___015659_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015679_;
    wasmetal_core__DOT___015679_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015682_;
    wasmetal_core__DOT___015682_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015683_;
    wasmetal_core__DOT___015683_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015687_;
    wasmetal_core__DOT___015687_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015736_;
    wasmetal_core__DOT___015736_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015759_;
    wasmetal_core__DOT___015759_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015766_;
    wasmetal_core__DOT___015766_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015767_;
    wasmetal_core__DOT___015767_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015819_;
    wasmetal_core__DOT___015819_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015826_;
    wasmetal_core__DOT___015826_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015834_;
    wasmetal_core__DOT___015834_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015846_;
    wasmetal_core__DOT___015846_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015847_;
    wasmetal_core__DOT___015847_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015860_;
    wasmetal_core__DOT___015860_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015869_;
    wasmetal_core__DOT___015869_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015876_;
    wasmetal_core__DOT___015876_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015902_;
    wasmetal_core__DOT___015902_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015947_;
    wasmetal_core__DOT___015947_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015948_;
    wasmetal_core__DOT___015948_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015963_;
    wasmetal_core__DOT___015963_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015976_;
    wasmetal_core__DOT___015976_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015977_;
    wasmetal_core__DOT___015977_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015993_;
    wasmetal_core__DOT___015993_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016004_;
    wasmetal_core__DOT___016004_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016033_;
    wasmetal_core__DOT___016033_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016051_;
    wasmetal_core__DOT___016051_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016071_;
    wasmetal_core__DOT___016071_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016097_;
    wasmetal_core__DOT___016097_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016123_;
    wasmetal_core__DOT___016123_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017373_;
    wasmetal_core__DOT___017373_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043085_;
    wasmetal_core__DOT___043085_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051533_;
    wasmetal_core__DOT___051533_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053623_;
    wasmetal_core__DOT___053623_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058231_;
    wasmetal_core__DOT___058231_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058240_;
    wasmetal_core__DOT___058240_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058252_;
    wasmetal_core__DOT___058252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058272_;
    wasmetal_core__DOT___058272_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058273_;
    wasmetal_core__DOT___058273_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058278_;
    wasmetal_core__DOT___058278_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058281_;
    wasmetal_core__DOT___058281_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058285_;
    wasmetal_core__DOT___058285_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058289_;
    wasmetal_core__DOT___058289_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058311_;
    wasmetal_core__DOT___058311_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058318_;
    wasmetal_core__DOT___058318_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058327_;
    wasmetal_core__DOT___058327_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058340_;
    wasmetal_core__DOT___058340_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058768_;
    wasmetal_core__DOT___058768_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058774_;
    wasmetal_core__DOT___058774_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058814_;
    wasmetal_core__DOT___058814_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058818_;
    wasmetal_core__DOT___058818_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058908_;
    wasmetal_core__DOT___058908_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058915_;
    wasmetal_core__DOT___058915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058922_;
    wasmetal_core__DOT___058922_ = 0;
    CData/*2:0*/ wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0;
    wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hd06a07d0__0;
    __VdfgTmp_hd06a07d0__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc9f60877__0;
    __VdfgTmp_hc9f60877__0 = 0;
    CData/*5:0*/ __VdfgTmp_hf2bf1435__0;
    __VdfgTmp_hf2bf1435__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6b2d1b17__0;
    __VdfgTmp_h6b2d1b17__0 = 0;
    CData/*2:0*/ __VdfgTmp_hb26667c8__0;
    __VdfgTmp_hb26667c8__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5be2ea26__0;
    __VdfgTmp_h5be2ea26__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9c4bb670__0;
    __VdfgTmp_h9c4bb670__0 = 0;
    CData/*2:0*/ __VdfgTmp_h7e4803dd__0;
    __VdfgTmp_h7e4803dd__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf54ed2ea__0;
    __VdfgTmp_hf54ed2ea__0 = 0;
    CData/*3:0*/ __VdfgTmp_h5e2f8bee__0;
    __VdfgTmp_h5e2f8bee__0 = 0;
    CData/*3:0*/ __VdfgTmp_h19b58510__0;
    __VdfgTmp_h19b58510__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2fff67d0__0;
    __VdfgTmp_h2fff67d0__0 = 0;
    CData/*1:0*/ __VdfgTmp_he0d9cd96__0;
    __VdfgTmp_he0d9cd96__0 = 0;
    CData/*1:0*/ __VdfgTmp_he6226459__0;
    __VdfgTmp_he6226459__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1a57c023__0;
    __VdfgTmp_h1a57c023__0 = 0;
    CData/*1:0*/ __VdfgTmp_hdf3675f5__0;
    __VdfgTmp_hdf3675f5__0 = 0;
    CData/*3:0*/ __VdfgTmp_h61bc6a8d__0;
    __VdfgTmp_h61bc6a8d__0 = 0;
    CData/*3:0*/ __VdfgTmp_hc7c22dbd__0;
    __VdfgTmp_hc7c22dbd__0 = 0;
    CData/*1:0*/ __VdfgTmp_h5abf1189__0;
    __VdfgTmp_h5abf1189__0 = 0;
    CData/*3:0*/ __VdfgTmp_h816ad3b7__0;
    __VdfgTmp_h816ad3b7__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha292b77c__0;
    __VdfgTmp_ha292b77c__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___005687_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d)))));
    vlSelf->wasmetal_core__DOT___018504_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048704_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9e4ff193__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d 
        = (1U & (0x4fcfcfcU >> (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                 << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___048704_) 
                                               << 2U) 
                                              | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)))))));
    vlSelf->__VdfgTmp_h97610f75__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051264_));
    vlSelf->wasmetal_core__DOT___036647_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051264_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d))));
    wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b26__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___053008_ = (1U & (IData)(
                                                         (0x8f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052918_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052917_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052916_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052914_)))))))));
    vlSelf->wasmetal_core__DOT___063412_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00bb00ff000f00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___063394_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050467_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063007_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (0xdf0f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063403_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xe000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063372_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063401_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063400_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063399_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050449_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009544_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___063433_ = (1U & (0x5fcf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063431_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x4000ffffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___063418_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063428_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063403_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xbfffffff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063401_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063426_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063372_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063399_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053568_)))))))))))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063392_)))))));
    vlSelf->wasmetal_core__DOT___019800_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053752_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053514_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052658_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053621_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053501_)))))))));
    vlSelf->wasmetal_core__DOT___053622_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xf35100000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053618_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053617_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->mem_ready) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___053616_)))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053619_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052656_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053501_))))));
    vlSelf->wasmetal_core__DOT___019784_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053516_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1000000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___053510_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053509_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___052712_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053506_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053505_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053504_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xd000U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xd000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053481_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053261_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053480_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053479_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053478_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h66357502__0)))))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053491_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x7fffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053489_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053488_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052695_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053487_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053436_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053016_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052853_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053435_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053434_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052907_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050450_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052896_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052880_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052886_)))))))))))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007871_))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053502_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053501_)))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053247_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053016_)))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___053363_))))))))))));
    wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023794_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d));
    vlSelf->wasmetal_core__DOT___023799_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5b8de47f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d))));
    vlSelf->wasmetal_core__DOT___023798_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d))));
    wasmetal_core__DOT___058908_ = (1U & (1U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5b8de47f__0))))));
    wasmetal_core__DOT___058768_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058760_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058759_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127624___O) 
                                                             << 2U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127623___O) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058758_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)))))))))));
    vlSelf->wasmetal_core__DOT___023797_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d))));
    vlSelf->wasmetal_core__DOT___058876_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058873_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___058912_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058758_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058761_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h43f5f2ec__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0)))))))));
    wasmetal_core__DOT___058774_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127624___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha55183ab__0))))));
    vlSelf->wasmetal_core__DOT___005977_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127526___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xff03fe02ff03aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h5ab387cb__0))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h5ab387cb__0))))));
    vlSelf->wasmetal_core__DOT___006038_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127526___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006065_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h9fc18e31__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9fc18e31__0)))))));
    vlSelf->wasmetal_core__DOT___006039_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127526___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xff03fe02ff03aaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5b8459c4__0))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5b8459c4__0))))));
    vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__0__KET__ 
        = ((0x5cU >> (IData)(vlSelf->__VdfgTmp_h3b955ce1__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___023305_));
    vlSelf->wasmetal_core__DOT___049341_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd339b1da__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h647f0add__0))))));
    vlSelf->__VdfgTmp_h07e5b5ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___005678_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005677_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d 
        = (1U & (IData)((0x111f111f111fffffULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005677_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005678_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005680_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005683_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hd339b1da__0))))))));
    vlSelf->wasmetal_core__DOT___058087_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005677_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005678_))));
    vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036010_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128790___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128776___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035869_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h7cb02621__0)))) {
        vlSelf->wasmetal_core__DOT___035873_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d;
        vlSelf->wasmetal_core__DOT___035729_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d;
    } else {
        vlSelf->wasmetal_core__DOT___035873_ = vlSelf->wasmetal_core__DOT___128790___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___035729_ = vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036959_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__1__KET__)
                  : (9U >> (IData)(vlSelf->__VdfgTmp_hc2af737a__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128776___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128776___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128776___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035725_)))));
    vlSelf->__VdfgTmp_h1a6a5523__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015607_));
    __VdfgTmp_h6b2d1b17__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015828_)));
    __VdfgTmp_h5e2f8bee__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015656_))));
    wasmetal_core__DOT___015759_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___015606_)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___015634_));
    __VdfgTmp_h19b58510__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015763_))));
    vlSelf->__VdfgTmp_h5ba5065d__0 = (((IData)(vlSelf->wasmetal_core__DOT___051535_) 
                                       << 1U) | (1U 
                                                 & (0x80U 
                                                    >> 
                                                    ((4U 
                                                      & ((0xf0d5U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h59f45271__0)) 
                                                         << 2U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_h540d21cf__0)))));
    vlSelf->wasmetal_core__DOT___017325_ = (1U & (0x2b00d4ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051535_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xf0d5U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h59f45271__0)) 
                                                          << 3U)) 
                                                      | ((6U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058677_))))));
    vlSelf->wasmetal_core__DOT___058269_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x55550f0f00ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015645_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015812_)))))))));
    vlSelf->wasmetal_core__DOT___015730_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h63c4ff94__0))))))));
    vlSelf->wasmetal_core__DOT___058221_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xf0f5555333300ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc84aef23__0)))))));
    vlSelf->wasmetal_core__DOT___058226_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015654_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015651_)))))));
    vlSelf->wasmetal_core__DOT___058245_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015651_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___015606_)))));
    vlSelf->__VdfgTmp_h6d3ce6b7__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___015763_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___015613_));
    wasmetal_core__DOT___015876_ = (1U & (0x503U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h9a784e39__0)))));
    if (vlSelf->wasmetal_core__DOT___015613_) {
        vlSelf->wasmetal_core__DOT___016003_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015681_))))));
        wasmetal_core__DOT___015846_ = (1U & (0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h46ff4218__0)))));
        vlSelf->wasmetal_core__DOT___016044_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2c2f1e15__0)))));
        vlSelf->wasmetal_core__DOT___015772_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hdeec5a49__0)))));
        wasmetal_core__DOT___015947_ = (1U & (0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hb34385bd__0)))));
        vlSelf->wasmetal_core__DOT___015981_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015636_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015635_))));
        vlSelf->wasmetal_core__DOT___058222_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___015651_)));
        if (vlSelf->wasmetal_core__DOT___013549_) {
            vlSelf->wasmetal_core__DOT___015602_ = 
                (1U & (0x23U >> (IData)(vlSelf->__VdfgTmp_h7d202e30__0)));
            vlSelf->wasmetal_core__DOT___015604_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___015612_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015611_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___015610_)))));
        } else {
            vlSelf->wasmetal_core__DOT___015602_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___015622_)));
            vlSelf->wasmetal_core__DOT___015604_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___015612_)));
        }
        vlSelf->wasmetal_core__DOT___015735_ = (1U 
                                                & (0x2333U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h12d5b185__0)))));
        wasmetal_core__DOT___015736_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015621_)) 
                                              & (0xfdfU 
                                                 >> (IData)(vlSelf->__VdfgTmp_h12c4c12e__0))));
        vlSelf->wasmetal_core__DOT___015737_ = (1U 
                                                & (0x23U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015747_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006651_)))));
        vlSelf->wasmetal_core__DOT___015738_ = vlSelf->wasmetal_core__DOT___015614_;
        vlSelf->wasmetal_core__DOT___015686_ = vlSelf->wasmetal_core__DOT___015725_;
        vlSelf->wasmetal_core__DOT___015839_ = vlSelf->wasmetal_core__DOT___015724_;
        wasmetal_core__DOT___015687_ = vlSelf->wasmetal_core__DOT___015719_;
        vlSelf->wasmetal_core__DOT___015867_ = vlSelf->wasmetal_core__DOT___015718_;
        vlSelf->wasmetal_core__DOT___015688_ = vlSelf->wasmetal_core__DOT___015710_;
        vlSelf->wasmetal_core__DOT___015868_ = vlSelf->wasmetal_core__DOT___015709_;
        vlSelf->wasmetal_core__DOT___015689_ = vlSelf->wasmetal_core__DOT___015698_;
        wasmetal_core__DOT___015869_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015697_));
        vlSelf->wasmetal_core__DOT___015910_ = wasmetal_core__DOT___015759_;
        vlSelf->wasmetal_core__DOT___015897_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___015606_)) 
                                                & (IData)(vlSelf->wasmetal_core__DOT___015762_));
        vlSelf->wasmetal_core__DOT___016019_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015656_))))));
        vlSelf->wasmetal_core__DOT___016045_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(__VdfgTmp_h19b58510__0)));
        vlSelf->wasmetal_core__DOT___015821_ = (1U 
                                                & (0xc0afU 
                                                   >> (IData)(__VdfgTmp_h19b58510__0)));
    } else {
        vlSelf->wasmetal_core__DOT___016003_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015676_))))));
        wasmetal_core__DOT___015846_ = (1U & (0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___015672_))))));
        vlSelf->wasmetal_core__DOT___016044_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015673_))))));
        vlSelf->wasmetal_core__DOT___015772_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015674_))))));
        wasmetal_core__DOT___015947_ = (1U & (0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___015666_))))));
        vlSelf->wasmetal_core__DOT___015981_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015637_))
                                                    : 
                                                   (7U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb584f1fd__0))));
        vlSelf->wasmetal_core__DOT___058222_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___015654_));
        if (vlSelf->wasmetal_core__DOT___013549_) {
            vlSelf->wasmetal_core__DOT___015602_ = 
                (1U & (0x203U >> (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015621_) 
                                              << 2U) 
                                             | (IData)(vlSelf->__VdfgTmp_h514789fb__0)))));
            wasmetal_core__DOT___015869_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015781_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfacd537a__0))));
        } else {
            vlSelf->wasmetal_core__DOT___015602_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___015621_)));
            wasmetal_core__DOT___015869_ = (1U & (1U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___015781_)));
        }
        vlSelf->wasmetal_core__DOT___015735_ = (1U 
                                                & (0x2333U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7d202e30__0))));
        wasmetal_core__DOT___015736_ = (1U & (0x23U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015750_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___013466_)))));
        vlSelf->wasmetal_core__DOT___015737_ = (1U 
                                                & (0xe0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015612_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc4d25f20__0)))));
        vlSelf->wasmetal_core__DOT___015604_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___015614_));
        vlSelf->wasmetal_core__DOT___015738_ = vlSelf->wasmetal_core__DOT___015725_;
        vlSelf->wasmetal_core__DOT___015686_ = vlSelf->wasmetal_core__DOT___015724_;
        vlSelf->wasmetal_core__DOT___015839_ = vlSelf->wasmetal_core__DOT___015719_;
        wasmetal_core__DOT___015687_ = vlSelf->wasmetal_core__DOT___015718_;
        vlSelf->wasmetal_core__DOT___015867_ = vlSelf->wasmetal_core__DOT___015710_;
        vlSelf->wasmetal_core__DOT___015688_ = vlSelf->wasmetal_core__DOT___015709_;
        vlSelf->wasmetal_core__DOT___015868_ = vlSelf->wasmetal_core__DOT___015698_;
        vlSelf->wasmetal_core__DOT___015689_ = vlSelf->wasmetal_core__DOT___015697_;
        vlSelf->wasmetal_core__DOT___015910_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___015606_)) 
                                                & (IData)(vlSelf->wasmetal_core__DOT___015633_));
        vlSelf->wasmetal_core__DOT___015897_ = wasmetal_core__DOT___015759_;
        vlSelf->wasmetal_core__DOT___016019_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(__VdfgTmp_h19b58510__0)));
        vlSelf->wasmetal_core__DOT___016045_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(__VdfgTmp_h5e2f8bee__0)));
        vlSelf->wasmetal_core__DOT___015821_ = (1U 
                                                & (0xafcfU 
                                                   >> (IData)(__VdfgTmp_h5e2f8bee__0)));
    }
    vlSelf->__VdfgTmp_hffe7d15f__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h31f6f19a__0)))));
    __VdfgTmp_hf2bf1435__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h31f6f19a__0)))));
    vlSelf->wasmetal_core__DOT___058243_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015654_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h31f6f19a__0))))))));
    vlSelf->wasmetal_core__DOT___016018_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdeec5a49__0))))))));
    vlSelf->wasmetal_core__DOT___015992_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x55550f0f00ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015678_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015677_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015676_)))))))));
    wasmetal_core__DOT___015847_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                    & (IData)((0xf0f5555333300ffULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hccfff196__0)))))));
    vlSelf->wasmetal_core__DOT___016043_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h46ff4218__0))))))));
    vlSelf->wasmetal_core__DOT___015771_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h20099147__0))))))));
    vlSelf->wasmetal_core__DOT___016020_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff55550f0f3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015765_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015665_)))))))));
    vlSelf->wasmetal_core__DOT___015994_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h10a18780__0))))))));
    vlSelf->wasmetal_core__DOT___015848_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xf0f333300ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb34385bd__0))))))));
    vlSelf->wasmetal_core__DOT___058244_ = (1U & (IData)(
                                                         (0xff00aaaaf0f0ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc84aef23__0)))))));
    vlSelf->wasmetal_core__DOT___015818_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x333355550f0f00ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2c2f1e15__0))))))));
    vlSelf->wasmetal_core__DOT___016116_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x55550f0f00ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015671_)))))))));
    wasmetal_core__DOT___015948_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                    & (IData)((0xff555533330f0fULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb73d1e0b__0))))))));
    vlSelf->wasmetal_core__DOT___015926_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h46ff4218__0))))))));
    vlSelf->wasmetal_core__DOT___015928_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfcfb0a06__0))))))));
    vlSelf->wasmetal_core__DOT___015909_ = (1U & (IData)(
                                                         (0xfff8f800000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015635_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb584f1fd__0)))))));
    vlSelf->wasmetal_core__DOT___015896_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015635_))))));
    vlSelf->wasmetal_core__DOT___058246_ = (1U & (IData)(
                                                         (0xccccf0f0ff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015635_)))))))));
    vlSelf->wasmetal_core__DOT___015605_ = ((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___015613_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___015634_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___015633_)));
    vlSelf->wasmetal_core__DOT___015943_ = ((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___015613_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___015762_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___015634_)));
    vlSelf->__VdfgTmp_hf420cd01__0 = (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015681_));
    wasmetal_core__DOT___015834_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015671_))))));
    wasmetal_core__DOT___015679_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015677_))))));
    wasmetal_core__DOT___015902_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015667_))))));
    wasmetal_core__DOT___015766_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_hfcfb0a06__0)))));
    wasmetal_core__DOT___015767_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015665_))))));
    vlSelf->wasmetal_core__DOT___015603_ = (1U & (IData)(
                                                         (0xa0a0f0f00cc00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015747_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015750_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8523194f__0))))))));
    wasmetal_core__DOT___015682_ = (1U & (0xff100000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h83a6d262__0))));
    wasmetal_core__DOT___015683_ = (1U & (IData)((0xf3f5f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he3b69f57__0)))));
    vlSelf->wasmetal_core__DOT___015684_ = (1U & (IData)(
                                                         (0xf3f5f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h9cde2904__0)))));
    wasmetal_core__DOT___015659_ = ((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013508_));
    vlSelf->wasmetal_core__DOT___016021_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                   >> 1U) 
                                                  & (IData)(
                                                            (0x7000000000000ULL 
                                                             >> 
                                                             ((0x30U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O))))))))));
    vlSelf->__VdfgTmp_h1a0326f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005686_));
    wasmetal_core__DOT___015860_ = (1U & (IData)((0x550f33ffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___015656_)))))))));
    vlSelf->wasmetal_core__DOT___015597_ = (1U & (IData)(
                                                         (0xbfff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051510_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048132_)))))))));
    vlSelf->wasmetal_core__DOT___015596_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005686_))));
    vlSelf->wasmetal_core__DOT___015594_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005686_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d 
        = (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___005688_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005686_)))));
    vlSelf->__VdfgTmp_hfa042eae__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hd339b1da__0))));
    vlSelf->wasmetal_core__DOT___017936_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018504_))));
    vlSelf->wasmetal_core__DOT___017193_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018504_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___058529_ = (1U & (1U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 1U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d))))));
    vlSelf->wasmetal_core__DOT___043072_ = (1U & (IData)(
                                                         (0x5757577f01010115ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xf0d5U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h59f45271__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h540d21cf__0))))))));
    vlSelf->wasmetal_core__DOT___017196_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048704_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127568___O) 
                                                               >> 2U))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf0d5U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h59f45271__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d))))));
    vlSelf->wasmetal_core__DOT___043076_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___005686_)
                                                    ? (IData)(
                                                              (0x700000000070ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb5be14c3__0)))
                                                    : (IData)(
                                                              (0x3300000000700000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb5be14c3__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___005686_)
                                                    ? (IData)(
                                                              (0x7000088888fULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb5be14c3__0)))
                                                    : (IData)(
                                                              (0xcc00000000070000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hb5be14c3__0))))));
    vlSelf->wasmetal_core__DOT___006589_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)
                                                   ? (IData)(
                                                             (0xfff03330aaa02220ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005689_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005688_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005687_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005686_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d))))))))
                                                   : 
                                                  (0x80U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005689_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005688_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005687_))))));
    vlSelf->wasmetal_core__DOT___005679_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005689_)) 
                                                  & (IData)(
                                                            (0xfc54f000f000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005688_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005687_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005686_))))))))));
    vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d 
        = (1U & (0xf8U >> (((IData)(vlSelf->wasmetal_core__DOT___005689_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d)))));
    vlSelf->wasmetal_core__DOT___036961_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036647_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7cb02621__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128868___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b27__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b26__05d) 
                        << 2U) | ((2U & ((0x1eU >> (IData)(vlSelf->__VdfgTmp_h963234d4__0)) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b24__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128868___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036416_)))));
    vlSelf->wasmetal_core__DOT___036420_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b27__05d) 
                                            & (IData)(wasmetal_core__DOT___128868___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___019805_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053254_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053008_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052862_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h554fca93__0))))))));
    vlSelf->wasmetal_core__DOT___053102_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053008_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053007_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053006_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051217_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053005_)))))));
    vlSelf->wasmetal_core__DOT___046424_ = (1U & (IData)(
                                                         (0x88880f0f00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063433_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf33ffffffffff55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h56fc5986__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063408_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053343_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)))))))))));
    wasmetal_core__DOT___053623_ = (1U & (IData)((0xdf00000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053506_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053622_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053502_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053621_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___053572_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127590___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023795_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023794_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023793_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023792_)))) 
           ^ (((IData)(wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127590___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023728_)))));
    vlSelf->wasmetal_core__DOT___023732_ = ((IData)(vlSelf->wasmetal_core__DOT___023795_)
                                             ? (IData)(wasmetal_core__DOT___127590___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d));
    vlSelf->wasmetal_core__DOT___058910_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058909_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058908_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h6b40bfd0__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hdd48e33a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hd2dd278c__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h85736cb0__0)))))))))));
    vlSelf->wasmetal_core__DOT___058783_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058767_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058766_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127620___O)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfc74bd0d__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127623___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___058784_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058774_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058773_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127622___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127619___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hde857550__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0)))))))))));
    vlSelf->wasmetal_core__DOT___006122_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006039_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006232_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005977_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___023202_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127519___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023243_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___006583_ = (1U & (IData)(
                                                         (0xeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005682_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005681_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005680_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005683_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h07e5b5ff__0))))))));
    vlSelf->wasmetal_core__DOT___058086_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135064___B 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
            << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d));
    vlSelf->wasmetal_core__DOT___058089_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058087_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049341_))));
    vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036011_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b6__05d));
    if (vlSelf->wasmetal_core__DOT___036647_) {
        vlSelf->wasmetal_core__DOT___128791___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d;
        vlSelf->wasmetal_core__DOT___128777___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128791___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___035873_;
        vlSelf->wasmetal_core__DOT___128777___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___035729_;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___134180___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036960_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036959_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036958_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036957_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036944_)))));
    vlSelf->wasmetal_core__DOT___036948_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036960_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134180___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7cb02621__0))));
    vlSelf->wasmetal_core__DOT___058267_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1a6a5523__0))));
    vlSelf->wasmetal_core__DOT___015949_ = (1U & (0x3f0050U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h6b2d1b17__0)))));
    vlSelf->wasmetal_core__DOT___017300_ = ((IData)(vlSelf->wasmetal_core__DOT___017325_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___015828_)
                                                ? (IData)(
                                                          (0xfcff0000aaffULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hca71c93a__0)))
                                                : (IData)(
                                                          (0xffff0300ffff5500ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hca71c93a__0)))));
    vlSelf->wasmetal_core__DOT___015982_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xf0f5555333300ffULL 
                                                       >> (IData)(__VdfgTmp_hf2bf1435__0))));
    vlSelf->wasmetal_core__DOT___058276_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058243_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058245_)))));
    vlSelf->__VdfgTmp_hf69e15ee__0 = (((IData)(wasmetal_core__DOT___015847_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015846_));
    vlSelf->__VdfgTmp_h0dbc0f0f__0 = (((IData)(wasmetal_core__DOT___015846_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015847_));
    vlSelf->__VdfgTmp_hcaafbee5__0 = (((IData)(vlSelf->wasmetal_core__DOT___016043_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016044_));
    vlSelf->__VdfgTmp_h70395930__0 = (((IData)(vlSelf->wasmetal_core__DOT___016044_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016043_));
    vlSelf->wasmetal_core__DOT___016122_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015771_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015772_))));
    vlSelf->wasmetal_core__DOT___015953_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___015948_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___015947_))));
    vlSelf->__VdfgTmp_h0d424198__0 = (((IData)(wasmetal_core__DOT___015947_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015948_));
    vlSelf->__VdfgTmp_ha6796979__0 = (((IData)(vlSelf->wasmetal_core__DOT___058244_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058246_));
    vlSelf->wasmetal_core__DOT___058224_ = (1U & (0xeef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xf0f0aaaaccccff00ULL 
                                                                   >> (IData)(__VdfgTmp_hf2bf1435__0))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058222_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015606_))))));
    vlSelf->__VdfgTmp_ha298e6e0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058222_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___015878_)))));
    vlSelf->wasmetal_core__DOT___058286_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015943_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015735_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___015606_)))));
    vlSelf->__VdfgTmp_hc102c9b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___015603_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015602_));
    vlSelf->__VdfgTmp_hd3573026__0 = (((IData)(wasmetal_core__DOT___015736_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015735_));
    vlSelf->__VdfgTmp_h7f4536ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015736_));
    vlSelf->__VdfgTmp_he2a347e4__0 = (((IData)(wasmetal_core__DOT___015687_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015686_));
    vlSelf->__VdfgTmp_h12dd4af8__0 = (((IData)(vlSelf->wasmetal_core__DOT___015867_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015839_));
    vlSelf->__VdfgTmp_hc3174423__0 = (((IData)(vlSelf->wasmetal_core__DOT___015688_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015687_));
    vlSelf->__VdfgTmp_h29141d8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015689_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015688_));
    vlSelf->__VdfgTmp_h7369d2e1__0 = ((2U & ((IData)(
                                                     (0xf0f335500000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                              << 3U) 
                                                             | (((IData)(wasmetal_core__DOT___015869_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h649aadfd__0))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                ? (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h20099147__0))))
                                                : (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015678_))))))));
    vlSelf->__VdfgTmp_h766529e2__0 = (((IData)(wasmetal_core__DOT___015869_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015868_));
    vlSelf->wasmetal_core__DOT___016030_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___015683_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___015682_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015689_)))))));
    vlSelf->__VdfgTmp_ha302ee77__0 = (((IData)(wasmetal_core__DOT___015683_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015682_));
    vlSelf->wasmetal_core__DOT___015816_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff00ff0f55553333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015684_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hccfff196__0)))))));
    vlSelf->__VdfgTmp_h36951d10__0 = ((((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                        & (IData)((0xfff0fff0ffff1111ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015684_) 
                                                        << 4U) 
                                                       | (((IData)(wasmetal_core__DOT___015683_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___015682_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hf420cd01__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                     ? 
                                                    (0x503U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3f94b345__0))))
                                                     : (IData)(wasmetal_core__DOT___015679_))));
    vlSelf->wasmetal_core__DOT___016046_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x55553333ff00ff0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___015659_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h10a18780__0))))))));
    vlSelf->wasmetal_core__DOT___015950_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0xff00ff0f33335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___015659_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd1c7c886__0))))))));
    vlSelf->wasmetal_core__DOT___015831_ = (1U & (0xcdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___015659_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015658_))))));
    if (vlSelf->wasmetal_core__DOT___015606_) {
        vlSelf->wasmetal_core__DOT___058268_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015876_));
        vlSelf->wasmetal_core__DOT___015983_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015645_))))));
        vlSelf->wasmetal_core__DOT___015991_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015834_));
        vlSelf->wasmetal_core__DOT___015817_ = wasmetal_core__DOT___015679_;
        vlSelf->wasmetal_core__DOT___016017_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hb73d1e0b__0)))));
        vlSelf->wasmetal_core__DOT___015849_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015766_));
        vlSelf->wasmetal_core__DOT___016115_ = wasmetal_core__DOT___015767_;
        vlSelf->wasmetal_core__DOT___015925_ = wasmetal_core__DOT___015902_;
        vlSelf->wasmetal_core__DOT___016029_ = (1U 
                                                & (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015684_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015681_))))));
        wasmetal_core__DOT___015977_ = (1U & (0xeU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_ha302ee77__0))));
        wasmetal_core__DOT___015993_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015831_));
        wasmetal_core__DOT___015819_ = (1U & (0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h10a18780__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___058268_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015636_))))));
        vlSelf->wasmetal_core__DOT___015983_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015876_));
        vlSelf->wasmetal_core__DOT___015991_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015672_))))));
        vlSelf->wasmetal_core__DOT___015817_ = wasmetal_core__DOT___015834_;
        vlSelf->wasmetal_core__DOT___016017_ = (1U 
                                                & (IData)(wasmetal_core__DOT___015902_));
        vlSelf->wasmetal_core__DOT___015849_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015657_))))));
        vlSelf->wasmetal_core__DOT___016115_ = wasmetal_core__DOT___015766_;
        vlSelf->wasmetal_core__DOT___015925_ = wasmetal_core__DOT___015767_;
        vlSelf->wasmetal_core__DOT___016029_ = (1U 
                                                & (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h3f94b345__0)))));
        wasmetal_core__DOT___015977_ = (1U & (0xf1U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015684_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hf420cd01__0)))));
        wasmetal_core__DOT___015993_ = (1U & (0x35U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd1c7c886__0)))));
        wasmetal_core__DOT___015819_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015831_));
    }
    vlSelf->__VdfgTmp_h6c8cc102__0 = ((2U & ((0x3050000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1a0326f2__0))))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                         & (IData)(
                                                   (0xff33330f0f5555ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015656_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___015763_))))))))));
    vlSelf->wasmetal_core__DOT___015969_ = (IData)(
                                                   ((0xcU 
                                                     == 
                                                     (0xcU 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O))) 
                                                    & (IData)(wasmetal_core__DOT___015860_)));
    vlSelf->wasmetal_core__DOT___015851_ = (IData)(
                                                   ((4U 
                                                     == 
                                                     (0xcU 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O))) 
                                                    & (IData)(wasmetal_core__DOT___015860_)));
    vlSelf->wasmetal_core__DOT___015927_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                >> 2U)) 
                                            & (IData)(wasmetal_core__DOT___015860_));
    vlSelf->wasmetal_core__DOT___058326_ = (1U & (IData)(
                                                         (0x3a00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6d3ce6b7__0))))))));
    vlSelf->wasmetal_core__DOT___058260_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058226_)))));
    vlSelf->wasmetal_core__DOT___015995_ = ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            & (IData)(
                                                      (0x3f005000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_h6b2d1b17__0)))))));
    vlSelf->wasmetal_core__DOT___016132_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            & (IData)(
                                                      (0x33330f0f00ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                                                  << 2U) 
                                                                 | (((IData)(wasmetal_core__DOT___015736_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015839_)))))))));
    vlSelf->wasmetal_core__DOT___016125_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            & (IData)(
                                                      (0x33330f0f00ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015603_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015602_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___015686_)))))))));
    vlSelf->__VdfgTmp_h2acad42a__0 = ((2U & ((IData)(
                                                     (0xf0fff1100000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015605_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015981_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___015602_)))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                ? (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015603_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015686_)))))
                                                : (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___015687_))))))));
    vlSelf->wasmetal_core__DOT___016072_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015943_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058246_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015735_)))))))));
    vlSelf->wasmetal_core__DOT___016063_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058221_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015981_))))));
    vlSelf->__VdfgTmp_h2eec3533__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                       << 2U) | ((2U 
                                                  & (((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                       ? 
                                                      (0x503U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h63c4ff94__0))))
                                                       : 
                                                      (0x503U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___015648_)))))) 
                                                     << 1U)) 
                                                 | ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    & (IData)(
                                                              (0x5555333300ff0f0fULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_hffe7d15f__0))))));
    vlSelf->wasmetal_core__DOT___058253_ = (1U & (0x30a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6d3ce6b7__0))))));
    vlSelf->__VdfgTmp_h2900ee3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (0xcaU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1a0326f2__0)))))));
    vlSelf->wasmetal_core__DOT___015840_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015839_))))));
    vlSelf->wasmetal_core__DOT___015806_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015686_))))));
    if (vlSelf->wasmetal_core__DOT___015607_) {
        vlSelf->wasmetal_core__DOT___015850_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015867_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015868_))));
        vlSelf->wasmetal_core__DOT___016062_ = (1U 
                                                & (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015605_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015602_))))));
        vlSelf->wasmetal_core__DOT___015732_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hd3573026__0)))));
        vlSelf->wasmetal_core__DOT___015820_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc3174423__0))));
        wasmetal_core__DOT___016071_ = (1U & (0x503U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h7f4536ab__0)))));
        wasmetal_core__DOT___058240_ = (1U & (0x503U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hc102c9b5__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___015850_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(wasmetal_core__DOT___015869_))
                                                    : 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h649aadfd__0)))));
        vlSelf->wasmetal_core__DOT___016062_ = (1U 
                                                & (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015603_))))));
        vlSelf->wasmetal_core__DOT___015732_ = (1U 
                                                & (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015737_))))));
        vlSelf->wasmetal_core__DOT___015820_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015689_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_ha302ee77__0)))));
        wasmetal_core__DOT___016071_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015840_));
        wasmetal_core__DOT___058240_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015806_));
    }
    vlSelf->__VdfgTmp_h75158e97__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d));
    vlSelf->__VdfgTmp_h8e7aae2a__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h647f0add__0))));
    vlSelf->wasmetal_core__DOT___019014_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058528_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017936_))));
    vlSelf->__VdfgTmp_hf6eff41b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017193_));
    vlSelf->wasmetal_core__DOT___018505_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x10000000U 
                                                        >> 
                                                        ((0x10U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                             << 4U)) 
                                                         | ((8U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
                                                            | ((4U 
                                                                & ((8U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)) 
                                                                   << 2U)) 
                                                               | ((2U 
                                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___058528_)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058529_))));
    vlSelf->wasmetal_core__DOT___058531_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058529_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058528_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___043068_ = ((IData)(vlSelf->wasmetal_core__DOT___043076_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___043075_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___043074_)
                                                  ? 
                                                 ((~ (IData)(vlSelf->wasmetal_core__DOT___043073_)) 
                                                  & (IData)(vlSelf->wasmetal_core__DOT___043069_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___043070_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___043071_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___043072_));
    vlSelf->wasmetal_core__DOT___017411_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043073_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043075_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043074_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043076_))))));
    vlSelf->wasmetal_core__DOT___058093_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006589_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d))));
    wasmetal_core__DOT___006582_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___006589_)) 
                                    & ((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                       & (IData)((0xfffffffffffffffeULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005677_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005678_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005682_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005681_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h647f0add__0)))))))));
    vlSelf->wasmetal_core__DOT___005666_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005683_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005679_))
                                                   : (IData)(
                                                             (0xf0f0f0f0f0f0f01ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005682_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005681_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005680_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005679_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h07e5b5ff__0)))))))));
    vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hcbf9eea7__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058087_));
    vlSelf->__VdfgTmp_h3056fe7c__0 = ((8U & ((0x10U 
                                              >> (IData)(vlSelf->__VdfgTmp_h963234d4__0)) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128868___O) 
                                                 >> 1U)))));
    vlSelf->__VdfgTmp_h5ac6c849__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058478_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128868___O)))));
    vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036420_));
    vlSelf->wasmetal_core__DOT___019806_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053103_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053101_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h554fca93__0))))));
    vlSelf->wasmetal_core__DOT___019801_ = (1U & (IData)(
                                                         (0x7f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053516_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___053623_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053250_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053247_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053017_)))))))));
    wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023797_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023732_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d));
    wasmetal_core__DOT___058915_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058912_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058911_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058910_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7a46858f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h263b1cf5__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he93f6ca8__0)))))))))));
    wasmetal_core__DOT___058814_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058784_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058783_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058782_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> 
                                                                 ((2U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127620___O) 
                                                                      >> 2U)) 
                                                                  | (1U 
                                                                     & (4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_had5b18f3__0))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> 
                                                                    ((2U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127621___O) 
                                                                         >> 1U)) 
                                                                     | (1U 
                                                                        & (4U 
                                                                           >> (IData)(vlSelf->__VdfgTmp_hcf1816fa__0))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (8U 
                                                                     >> 
                                                                     ((2U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127624___O) 
                                                                          >> 1U)) 
                                                                      | (1U 
                                                                         & (4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5b8de47f__0))))))))))))));
    wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023181_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h11374272__0 = (((IData)(vlSelf->wasmetal_core__DOT___006583_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005679_));
    vlSelf->wasmetal_core__DOT___040073_ = (1U & (0xeaeaea2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005679_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058086_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128801___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036012_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036011_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036010_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036003_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035936_)))));
    vlSelf->wasmetal_core__DOT___035957_ = ((IData)(vlSelf->wasmetal_core__DOT___036012_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128801___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b7__05d));
    vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036961_)
            ? (IData)(vlSelf->wasmetal_core__DOT___036948_)
            : (IData)(vlSelf->wasmetal_core__DOT___036647_));
    vlSelf->__VdfgTmp_hee741df9__0 = (((IData)(vlSelf->wasmetal_core__DOT___058267_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015596_)));
    vlSelf->__VdfgTmp_h14009f5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___015910_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015909_));
    vlSelf->wasmetal_core__DOT___015731_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015896_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015897_))));
    vlSelf->__VdfgTmp_hbb3c60ea__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016020_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___016019_))));
    vlSelf->wasmetal_core__DOT___058262_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016019_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016020_)))));
    vlSelf->wasmetal_core__DOT___015964_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015821_))));
    vlSelf->wasmetal_core__DOT___043121_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017300_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017298_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017297_)))));
    vlSelf->wasmetal_core__DOT___043103_ = (1U & (IData)(
                                                         (0xffffffffff404040ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017298_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017300_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017325_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057798_)))))))));
    vlSelf->wasmetal_core__DOT___017206_ = ((IData)(vlSelf->wasmetal_core__DOT___017300_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___017299_) 
                                               & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017298_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017297_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h182596d5__0)))))));
    vlSelf->wasmetal_core__DOT___058238_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0f335500000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha298e6e0__0)))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___015613_)
                                                          ? 
                                                         (0x503U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___015812_)))))
                                                          : 
                                                         (0x305U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___015645_))))))))));
    vlSelf->__VdfgTmp_h7f6f5bfd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015992_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015991_));
    vlSelf->wasmetal_core__DOT___058331_ = (1U & (IData)(
                                                         (0xeeee0000fff0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016020_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016019_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016017_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016018_)))))))));
    vlSelf->__VdfgTmp_hf1a5f561__0 = (((IData)(vlSelf->wasmetal_core__DOT___016018_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016017_));
    vlSelf->__VdfgTmp_h5b5b6b1b__0 = (((IData)(vlSelf->wasmetal_core__DOT___015849_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015848_));
    vlSelf->wasmetal_core__DOT___058283_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016116_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016115_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015772_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015771_)))))))));
    vlSelf->wasmetal_core__DOT___058230_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016115_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___016116_)))));
    vlSelf->wasmetal_core__DOT___015931_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015926_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015925_))));
    vlSelf->__VdfgTmp_h86126eef__0 = (((IData)(vlSelf->wasmetal_core__DOT___015925_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015926_));
    vlSelf->__VdfgTmp_h4f78e4d3__0 = ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                        & (IData)((0xfff0fff055553333ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015897_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015896_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd3573026__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___015606_)
                                                     ? 
                                                    (0x305U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015839_)))))
                                                     : 
                                                    (0x305U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015867_))))))));
    vlSelf->__VdfgTmp_h1811098d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd3573026__0));
    vlSelf->__VdfgTmp_h9a38454b__0 = ((2U & ((0x3500U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_ha6796979__0)))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                ? (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015943_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015735_)))))
                                                : (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h7f4536ab__0)))))));
    vlSelf->wasmetal_core__DOT___015978_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015603_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he2a347e4__0))))))));
    __VdfgTmp_hb26667c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___015688_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_he2a347e4__0));
    vlSelf->wasmetal_core__DOT___016007_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h12dd4af8__0))))))));
    wasmetal_core__DOT___016051_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                    & (IData)((0xff555533330f0fULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015868_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h12dd4af8__0))))))));
    __VdfgTmp_hdf3675f5__0 = ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                & (IData)((0xff00ff5533330f0fULL 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015605_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc102c9b5__0)))))))) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                ? (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he2a347e4__0))))
                                                : (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h29141d8d__0)))))));
    wasmetal_core__DOT___015976_ = (1U & (0x5300U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h29141d8d__0)))));
    __VdfgTmp_h7e4803dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h766529e2__0));
    __VdfgTmp_h5abf1189__0 = (((IData)(vlSelf->wasmetal_core__DOT___016030_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016029_));
    __VdfgTmp_he6226459__0 = (((IData)(vlSelf->wasmetal_core__DOT___016029_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016030_));
    wasmetal_core__DOT___015826_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___015817_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015816_))));
    __VdfgTmp_h816ad3b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                               << 3U) | ((4U & ((4U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___058267_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___015594_))) 
                                                << 2U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT___016045_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___016046_))));
    __VdfgTmp_ha292b77c__0 = (((IData)(vlSelf->wasmetal_core__DOT___016046_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016045_));
    wasmetal_core__DOT___058272_ = (1U & (0xfc00aaU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016045_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016046_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___058267_)))))));
    wasmetal_core__DOT___015599_ = (1U & (IData)((0xeeee0000fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015950_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015949_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h0d424198__0))))))));
    vlSelf->wasmetal_core__DOT___015954_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015950_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015949_))));
    vlSelf->__VdfgTmp_h45982c59__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h6c8cc102__0)));
    wasmetal_core__DOT___058231_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6c8cc102__0))));
    __VdfgTmp_hc9f60877__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015969_));
    vlSelf->wasmetal_core__DOT___058317_ = (1U & (0xe000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015927_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015928_)))))));
    vlSelf->wasmetal_core__DOT___015932_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015927_))));
    if (vlSelf->wasmetal_core__DOT___015594_) {
        vlSelf->wasmetal_core__DOT___015979_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015983_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___015982_))));
        vlSelf->wasmetal_core__DOT___058335_ = (1U 
                                                & (0xf0e0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h70395930__0)))));
        if (vlSelf->wasmetal_core__DOT___015596_) {
            wasmetal_core__DOT___058281_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h36951d10__0)));
            wasmetal_core__DOT___058278_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)));
        } else {
            wasmetal_core__DOT___058281_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015954_));
            wasmetal_core__DOT___058278_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015932_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___015979_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015981_))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015605_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015602_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___015606_))))));
        vlSelf->wasmetal_core__DOT___058335_ = (1U 
                                                & (0xf0e0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_ha292b77c__0)))));
        wasmetal_core__DOT___058281_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015596_)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___015953_)));
        wasmetal_core__DOT___058278_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015596_)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___015931_)));
    }
    vlSelf->wasmetal_core__DOT___058363_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058326_))));
    vlSelf->wasmetal_core__DOT___058254_ = (1U & (0xf011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xfefefefe000000ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015983_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015982_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058222_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h1a6a5523__0))))))) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2acad42a__0)))));
    vlSelf->wasmetal_core__DOT___058364_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x4000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h2900ee3d__0)))))));
    wasmetal_core__DOT___016097_ = (1U & (1U >> ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                   & (IData)(
                                                             (0xfff0fff055553333ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015910_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015909_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hc102c9b5__0)))))))) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                        ? (IData)(vlSelf->wasmetal_core__DOT___015806_)
                                                        : 
                                                       (0x503U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hc3174423__0)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h75158e97__0))));
    vlSelf->wasmetal_core__DOT___036952_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfa042eae__0))));
    vlSelf->wasmetal_core__DOT___018507_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058531_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                         >> 1U)))));
    wasmetal_core__DOT___017373_ = ((IData)(vlSelf->wasmetal_core__DOT___017412_) 
                                    & (IData)((0xefff1000000000ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017411_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017410_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017409_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017408_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017407_)))))))));
    vlSelf->wasmetal_core__DOT___017803_ = (1U & (0xf0f000ddU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b2__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b3__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02emajorExc_Z)))))));
    vlSelf->wasmetal_core__DOT___036292_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005686_)) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128846___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005686_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                          << 1U)))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0)))) {
        wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d;
        wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d;
    } else {
        wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128791___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128777___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___036951_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfa042eae__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0))));
    vlSelf->wasmetal_core__DOT___036962_ = (1U & (0xb4U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h97610f75__0))));
    wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0 = ((4U 
                                                   & ((~ 
                                                       (6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfa042eae__0))) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((~ 
                                                          (6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (~ (IData)(vlSelf->wasmetal_core__DOT___036647_)))));
    vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b29__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023798_)
            ? (IData)(wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d));
    wasmetal_core__DOT___058922_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058917_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058916_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058915_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hf2c31503__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0)))))))))));
    wasmetal_core__DOT___058818_ = (1U & (IData)((0xb00000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058814_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058813_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058812_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___005882_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127527___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023182_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023181_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023243_) 
                                   << 1U) | (1U & (0x5cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3b955ce1__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023305_)))));
    vlSelf->wasmetal_core__DOT___023246_ = ((IData)(vlSelf->wasmetal_core__DOT___023182_) 
                                            & (IData)(wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036013_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035957_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b8__05d));
    vlSelf->wasmetal_core__DOT___058365_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hee741df9__0))))));
    vlSelf->wasmetal_core__DOT___058294_ = (1U & ((~ 
                                                   (0x40U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hee741df9__0))) 
                                                  & (IData)(
                                                            (0x1111ffff000fffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016046_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016045_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h70395930__0)))))))));
    vlSelf->wasmetal_core__DOT___058336_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x80U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hee741df9__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015597_))));
    vlSelf->wasmetal_core__DOT___058239_ = (1U & (0xf011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xaaaaccccf0f0ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9a784e39__0))))))) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h14009f5a__0)))));
    wasmetal_core__DOT___058285_ = (1U & (IData)((0xccccaaaaf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015731_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xaaaaccccff00f0f0ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hffe7d15f__0))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058226_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___015730_)))))))));
    __VdfgTmp_h5be2ea26__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015731_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015730_)));
    vlSelf->__VdfgTmp_h9b99f784__0 = ((2U & ((0x1000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h2900ee3d__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___058262_));
    vlSelf->wasmetal_core__DOT___058322_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015964_))));
    wasmetal_core__DOT___043085_ = ((IData)(vlSelf->wasmetal_core__DOT___043121_)
                                     ? ((IData)(vlSelf->wasmetal_core__DOT___043120_)
                                         ? ((IData)(vlSelf->wasmetal_core__DOT___043119_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___017201_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___043118_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___043117_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___043116_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___043115_)
                                                     ? 
                                                    ((1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb820c59b__0)))
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043125_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043124_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043123_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043122_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___017375_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___017269_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___017371_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___017372_)
                                                              ? 
                                                             ((~ (IData)(vlSelf->wasmetal_core__DOT___017412_)) 
                                                              & (IData)(vlSelf->wasmetal_core__DOT___043095_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043104_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043105_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043106_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043107_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043108_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043109_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043110_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043111_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043112_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___043096_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___043097_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___043098_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___043099_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___043100_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___043101_))
                                         : (IData)(vlSelf->wasmetal_core__DOT___043102_))
                                     : (IData)(vlSelf->wasmetal_core__DOT___043103_));
    __VdfgTmp_hc7c22dbd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_h7f6f5bfd__0)));
    vlSelf->__VdfgTmp_h9d948fd9__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf1a5f561__0)));
    __VdfgTmp_h2fff67d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015851_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h5b5b6b1b__0));
    vlSelf->wasmetal_core__DOT___058297_ = ((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                            & (IData)(
                                                      (0xeeee0000fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015927_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015928_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h86126eef__0))))))));
    wasmetal_core__DOT___058340_ = (1U & (IData)((0xeeee0000fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015928_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015927_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h86126eef__0))))))));
    vlSelf->wasmetal_core__DOT___058264_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058260_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xeU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2eec3533__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4f78e4d3__0))))));
    wasmetal_core__DOT___016123_ = (1U & (1U >> ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                   & (IData)(
                                                             (0x555533330f0f00ffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                                      << 3U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h1811098d__0))))))) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                        ? 
                                                       (0x503U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h12dd4af8__0))))
                                                        : 
                                                       (0x503U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h766529e2__0)))))))));
    __VdfgTmp_h1a57c023__0 = ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                & (IData)((0xff00ff5533330f0fULL 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015943_) 
                                                      << 3U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h1811098d__0))))))) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___015840_)
                                                : (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015868_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015867_))))))));
    wasmetal_core__DOT___016033_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                    & (IData)((0xff555533330f0fULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                          << 3U) 
                                                         | (IData)(__VdfgTmp_hb26667c8__0)))))));
    wasmetal_core__DOT___015598_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                    & (IData)((0x555533330f0f00ffULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015689_) 
                                                          << 3U) 
                                                         | (IData)(__VdfgTmp_hb26667c8__0)))))));
    __VdfgTmp_h9c4bb670__0 = ((2U & ((0xacU >> (IData)(__VdfgTmp_h7e4803dd__0)) 
                                     << 1U)) | (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h12dd4af8__0)))));
    wasmetal_core__DOT___016004_ = (1U & (0x5300U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            << 3U) 
                                           | (IData)(__VdfgTmp_h7e4803dd__0))));
    __VdfgTmp_he0d9cd96__0 = (((IData)(wasmetal_core__DOT___015977_) 
                               << 1U) | (IData)(wasmetal_core__DOT___015976_));
    vlSelf->wasmetal_core__DOT___058305_ = (1U & (0x5500fcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015817_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015816_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015820_)))))));
    wasmetal_core__DOT___058273_ = (1U & (IData)((0xeeee0000fff00000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016043_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016044_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_he6226459__0))))))));
    vlSelf->wasmetal_core__DOT___058361_ = (1U & (IData)(
                                                         (0xfef0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h816ad3b7__0))))));
    vlSelf->wasmetal_core__DOT___058315_ = (1U & (IData)(
                                                         (0xfef000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h816ad3b7__0))))));
    vlSelf->wasmetal_core__DOT___058354_ = (1U & ((1U 
                                                   & (0x40U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hee741df9__0)))
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (0xe000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hcaafbee5__0))))
                                                    : 
                                                   (0xe000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_ha292b77c__0)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b57__05d 
        = (1U & (0x4000bfffU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___015954_)))))));
    vlSelf->wasmetal_core__DOT___058356_ = (1U & (IData)(
                                                         (0xee0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015954_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0d424198__0))))))));
    vlSelf->__VdfgTmp_h1ac41acf__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015954_)));
    wasmetal_core__DOT___058327_ = (1U & (IData)((0xeeee0000fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015994_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___015993_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015991_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___015992_)))))))));
    __VdfgTmp_h61bc6a8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015994_) 
                                           << 1U) | (IData)(wasmetal_core__DOT___015993_))));
    wasmetal_core__DOT___058252_ = (1U & (0xe0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___015993_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___015994_)))));
    wasmetal_core__DOT___015963_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___015818_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___015819_))));
    __VdfgTmp_hf54ed2ea__0 = (((IData)(wasmetal_core__DOT___015819_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015818_));
    vlSelf->wasmetal_core__DOT___058362_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xe000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h45982c59__0))))));
    vlSelf->wasmetal_core__DOT___058349_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xe00U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h45982c59__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058283_)))));
    __VdfgTmp_hd06a07d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___058230_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058231_));
    vlSelf->__VdfgTmp_hac8f2958__0 = (((IData)(wasmetal_core__DOT___058231_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058230_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b60__05d 
        = (1U & (0x807fU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                         << 2U) | (IData)(__VdfgTmp_hc9f60877__0)))));
    wasmetal_core__DOT___058289_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                           ? (0x1111000fU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015848_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015849_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0dbc0f0f__0)))))
                                           : (1U >> (IData)(vlSelf->wasmetal_core__DOT___015969_))));
    vlSelf->wasmetal_core__DOT___016450_ = (1U & (IData)(
                                                         (0xf0f01111ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058289_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccccaaaaf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058286_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058244_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058243_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058246_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016132_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___015850_))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b56__05d 
        = (1U & (0x4000bfffU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___015932_)))))));
    vlSelf->wasmetal_core__DOT___058355_ = (1U & (IData)(
                                                         (0xee0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015932_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h86126eef__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b61__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058363_))));
    vlSelf->wasmetal_core__DOT___058324_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___016132_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016132_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___015850_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0dbc0f0f__0))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015848_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___015849_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b28__05d 
        = (1U & (0x55c0aa3fU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015969_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___058324_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b62__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058364_))));
    vlSelf->wasmetal_core__DOT___058249_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xffaa0fccU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058245_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058244_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___058243_)))))) 
                                                             << 2U)) 
                                                         | (((IData)(wasmetal_core__DOT___016071_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___016072_)))))));
    vlSelf->wasmetal_core__DOT___058091_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006589_)))));
    vlSelf->wasmetal_core__DOT___040074_ = (1U & (IData)(
                                                         (0x2aea2a2aeaeaeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006583_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___049343_ = (1U & (IData)(
                                                         (0xf0004400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h75158e97__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049341_)))))))));
    vlSelf->wasmetal_core__DOT___036009_ = (1U & (0xbb0bbbbU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b54__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048948_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b53__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b52__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d)))))));
    vlSelf->__VdfgTmp_h7b6a46b3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d));
    vlSelf->__VdfgTmp_he488fa83__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp___135065___A 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
            << 0x12U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                          << 0x11U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d) 
                                        << 0x10U) | 
                                       (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                         << 0xfU) | 
                                        (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d) 
                                          << 0xeU) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                             << 0xdU) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                << 0xcU) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d) 
                                                   << 0xbU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d) 
                                                      << 0xaU) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d) 
                                                         << 9U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d) 
                                                            << 8U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d) 
                                                               << 7U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                                  << 6U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___017195_ = (((IData)(vlSelf->wasmetal_core__DOT___017375_) 
                                             & ((IData)(vlSelf->wasmetal_core__DOT___017374_) 
                                                & (IData)(
                                                          (0x8000000000000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___017373_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017372_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017371_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017370_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hb820c59b__0))))))))) 
                                            & (((IData)(vlSelf->wasmetal_core__DOT___017342_) 
                                                & (IData)(
                                                          (0x1001000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017341_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017340_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017339_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017338_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h6cc9accb__0)))))))) 
                                               & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017203_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___017234_) 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT___017233_) 
                                                                            & (IData)(
                                                                                (0x9009000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017232_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017231_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5fa4cdd4__0))))))) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017201_))))))))));
    wasmetal_core__DOT___051533_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U)) 
                                                            | (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                  >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___017519_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                         >> 3U)))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hfa042eae__0)))) {
        wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d;
        wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d;
    } else {
        wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036962_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0))));
    vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b30__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127591___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023799_) 
             << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023798_) 
                        << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023797_))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___023799_)
                 ? (IData)(wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023732_)))));
    vlSelf->wasmetal_core__DOT___058928_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058924_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058923_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058922_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h87705c6a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h8ddb6508__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h276f18a3__0)))))))))));
    vlSelf->wasmetal_core__DOT___058929_ = (1U & ((IData)(
                                                          (0x1000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___058862_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058861_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058860_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___006204_))) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___003806_))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (4U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___006144_))))))))))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___017453_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017452_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017451_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058840_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058839_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058838_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005928_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003811_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006178_))))))))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((8U 
                                                                               >> 
                                                                               ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058824_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058823_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058822_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005889_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006065_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xb00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___058818_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058817_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058816_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005802_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006238_))))))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058752_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058751_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058750_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127629___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h87705c6a__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127627___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hff1f1b74__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127628___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd093a298__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058724_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058723_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058722_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127630___O)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127629___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h276f18a3__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127625___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___005849_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127527___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb31c73a1__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h397c5a04__0)))));
    vlSelf->wasmetal_core__DOT___005783_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127527___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h444b75da__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h399a9b9d__0)))));
    vlSelf->wasmetal_core__DOT___005782_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127527___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf53bec91__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hf53bec91__0)))))));
    vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023183_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023246_));
    vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036014_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b9__05d));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b63__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058365_))));
    vlSelf->wasmetal_core__DOT___058306_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___058240_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058239_))))));
    vlSelf->wasmetal_core__DOT___058241_ = (1U & (0xffaa0c0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___058240_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058239_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058238_)))))));
    vlSelf->wasmetal_core__DOT___058303_ = (1U & (IData)(
                                                         (0xafcf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015732_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h5be2ea26__0)))))));
    vlSelf->wasmetal_core__DOT___058232_ = (1U & ((~ 
                                                   (0x5030000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xaaaaccccff00f0f0ULL 
                                                                           >> (IData)(vlSelf->__VdfgTmp_hffe7d15f__0))) 
                                                                  << 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___058226_))))))) 
                                                  & (IData)(
                                                            (0xff00ff00ffafffcfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015732_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 3U) 
                                                                    | (IData)(__VdfgTmp_h5be2ea26__0))))))));
    vlSelf->wasmetal_core__DOT___058360_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9b99f784__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b59__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058322_)))));
    vlSelf->wasmetal_core__DOT___017197_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043068_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017411_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___043085_)))));
    vlSelf->wasmetal_core__DOT___058353_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016021_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (0xe000U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h9d948fd9__0))
                                                    : 
                                                   (0xe000U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hbb3c60ea__0)))));
    vlSelf->__VdfgTmp_he58e0004__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                       << 3U) | (IData)(__VdfgTmp_h2fff67d0__0));
    vlSelf->wasmetal_core__DOT___058341_ = (1U & (IData)(
                                                         (0xfff1ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058340_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___016051_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)))))))))));
    vlSelf->wasmetal_core__DOT___058518_ = (1U & (0xfefU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058340_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___016051_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015594_)))))));
    vlSelf->wasmetal_core__DOT___058321_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                            ? (IData)(wasmetal_core__DOT___016123_)
                                                            : 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___016122_)
                                                             : 
                                                            (1U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___016116_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___016115_))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xe000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h45982c59__0)))))));
    vlSelf->wasmetal_core__DOT___016448_ = (1U & (IData)(
                                                         (0xff00f0f011111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058285_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___016123_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058283_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xe00U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h45982c59__0)))))))))));
    vlSelf->wasmetal_core__DOT___058334_ = (1U & (0xf10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___016033_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_he6226459__0))))));
    vlSelf->wasmetal_core__DOT___058342_ = (1U & (IData)(
                                                         (0xfff1ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___015599_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___015598_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h36951d10__0)))))))))));
    vlSelf->wasmetal_core__DOT___016441_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                     & (IData)(
                                                               (0xeeee0000fff0ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015949_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015950_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h0d424198__0)))))))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                          ? 
                                                         (0xe0U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016063_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___016062_))))
                                                          : 
                                                         ((IData)(wasmetal_core__DOT___015598_)
                                                           ? 
                                                          (2U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                           : 
                                                          (0xe00U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h36951d10__0))))))))));
    vlSelf->wasmetal_core__DOT___058225_ = (1U & ((~ (IData)(
                                                             (0x1111fff000000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016062_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016063_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___058224_))))))))) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffefULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___015599_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___015598_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((1U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h36951d10__0)) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___015594_))))))))));
    vlSelf->wasmetal_core__DOT___058296_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                   ? 
                                                  (0xe0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9a38454b__0)))
                                                   : 
                                                  ((IData)(wasmetal_core__DOT___016051_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                    : 
                                                   (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)))))));
    vlSelf->__VdfgTmp_hf599dae9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058297_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___058296_)))));
    vlSelf->wasmetal_core__DOT___058302_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h9c4bb670__0)))));
    vlSelf->wasmetal_core__DOT___058233_ = ((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                            & (IData)(
                                                      (0x55553333fff0fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015772_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015771_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h9c4bb670__0))))))));
    vlSelf->__VdfgTmp_ha2f7036a__0 = (((IData)(wasmetal_core__DOT___016004_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016003_));
    if (vlSelf->wasmetal_core__DOT___015596_) {
        wasmetal_core__DOT___058318_ = (1U & (1U >> (IData)(__VdfgTmp_hdf3675f5__0)));
        wasmetal_core__DOT___058311_ = (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2acad42a__0)));
        if (vlSelf->wasmetal_core__DOT___015594_) {
            vlSelf->wasmetal_core__DOT___058351_ = 
                (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_hf69e15ee__0))));
            vlSelf->wasmetal_core__DOT___058248_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___015850_)));
            vlSelf->wasmetal_core__DOT___058323_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___016125_)));
            vlSelf->wasmetal_core__DOT___058242_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___015820_)));
        } else {
            vlSelf->wasmetal_core__DOT___058351_ = 
                (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h5b5b6b1b__0))));
            vlSelf->wasmetal_core__DOT___058248_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hf69e15ee__0)));
            vlSelf->wasmetal_core__DOT___058323_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___016125_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015820_))));
            vlSelf->wasmetal_core__DOT___058242_ = 
                (1U & (IData)(wasmetal_core__DOT___015826_));
        }
        vlSelf->wasmetal_core__DOT___058308_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016072_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___016071_))));
        vlSelf->wasmetal_core__DOT___058314_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016097_));
        vlSelf->wasmetal_core__DOT___058316_ = (1U 
                                                & (1U 
                                                   >> (IData)(__VdfgTmp_h1a57c023__0)));
        vlSelf->wasmetal_core__DOT___058295_ = (1U 
                                                & (0xe0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & (((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                             ? 
                                                            (0xeU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h14009f5a__0)))
                                                             : 
                                                            (0x53U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc102c9b5__0))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0xe0U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058268_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___058269_)))))))));
        vlSelf->wasmetal_core__DOT___058312_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4f78e4d3__0)));
    } else {
        if (vlSelf->wasmetal_core__DOT___015594_) {
            wasmetal_core__DOT___058318_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h36951d10__0)));
            wasmetal_core__DOT___058311_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___015976_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___015977_))));
            vlSelf->wasmetal_core__DOT___058314_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h5abf1189__0)));
            vlSelf->wasmetal_core__DOT___058248_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h2fff67d0__0)));
            vlSelf->wasmetal_core__DOT___058316_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)));
            vlSelf->wasmetal_core__DOT___058323_ = 
                (1U & (IData)(wasmetal_core__DOT___015826_));
            vlSelf->wasmetal_core__DOT___058242_ = 
                (1U & (1U >> (IData)(__VdfgTmp_hf54ed2ea__0)));
            vlSelf->wasmetal_core__DOT___058312_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_ha2f7036a__0)));
        } else {
            wasmetal_core__DOT___058318_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015953_));
            wasmetal_core__DOT___058311_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7f6f5bfd__0)));
            vlSelf->wasmetal_core__DOT___058314_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hcaafbee5__0)));
            vlSelf->wasmetal_core__DOT___058248_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___015851_)));
            vlSelf->wasmetal_core__DOT___058316_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___015931_));
            vlSelf->wasmetal_core__DOT___058323_ = 
                (1U & (IData)(wasmetal_core__DOT___015963_));
            vlSelf->wasmetal_core__DOT___058242_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___015821_)));
            vlSelf->wasmetal_core__DOT___058312_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hf1a5f561__0)));
        }
        vlSelf->wasmetal_core__DOT___058351_ = (1U 
                                                & (8U 
                                                   >> (IData)(__VdfgTmp_hc9f60877__0)));
        vlSelf->wasmetal_core__DOT___058308_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015850_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h0dbc0f0f__0)))));
        vlSelf->wasmetal_core__DOT___058295_ = (1U 
                                                & ((IData)(wasmetal_core__DOT___016033_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                    : 
                                                   (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h5abf1189__0))))));
    }
    vlSelf->__VdfgTmp_hfb1d3885__0 = (((IData)(vlSelf->wasmetal_core__DOT___016003_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016004_));
    vlSelf->wasmetal_core__DOT___058255_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015992_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015991_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_he0d9cd96__0))))))));
    vlSelf->wasmetal_core__DOT___058346_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___058272_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058273_)))));
    vlSelf->wasmetal_core__DOT___058275_ = (1U & (IData)(
                                                         (0xaaaaff0003030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___016097_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___058273_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___058272_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfff01111U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & ((0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha298e6e0__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058269_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058268_)))))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b55__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058361_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b47__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058354_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b49__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058356_))));
    vlSelf->wasmetal_core__DOT___058319_ = (1U & (0xff00bfbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___058318_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1ac41acf__0)))));
    vlSelf->wasmetal_core__DOT___058348_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058281_))));
    vlSelf->wasmetal_core__DOT___016447_ = (1U & (IData)(
                                                         (0xf0f01111ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058281_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f000eeU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058221_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058224_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015981_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015607_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_hdf3675f5__0))))))));
    vlSelf->wasmetal_core__DOT___058328_ = (1U & (IData)(
                                                         (0x1f1f00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058327_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058326_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015978_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                               << 2U) 
                                                                              | (IData)(__VdfgTmp_he0d9cd96__0))))))))))));
    vlSelf->wasmetal_core__DOT___058352_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015995_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (0xe000U 
                                                    >> (IData)(__VdfgTmp_hc7c22dbd__0))
                                                    : 
                                                   (0xe000U 
                                                    >> (IData)(__VdfgTmp_h61bc6a8d__0)))));
    vlSelf->wasmetal_core__DOT___016451_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___015995_)
                                                         ? 
                                                        (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                         : 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                          ? 
                                                         (0xe0U 
                                                          >> (IData)(__VdfgTmp_hc7c22dbd__0))
                                                          : 
                                                         (0xe0U 
                                                          >> (IData)(__VdfgTmp_h61bc6a8d__0)))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      & (IData)(
                                                                (0xff00fff0f0fefeULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015979_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015978_) 
                                                                            << 2U) 
                                                                           | (IData)(__VdfgTmp_he0d9cd96__0)))))))))));
    vlSelf->wasmetal_core__DOT___016442_ = (1U & (0xff001f1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___058311_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___058252_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058253_)))))));
    vlSelf->__VdfgTmp_h240228f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___058253_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058252_));
    vlSelf->__VdfgTmp_hf1c161b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015964_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___015963_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (1U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015816_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___015817_))))))));
    vlSelf->__VdfgTmp_hb564d990__0 = (((IData)(vlSelf->wasmetal_core__DOT___015821_) 
                                       << 2U) | (IData)(__VdfgTmp_hf54ed2ea__0));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b58__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058362_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b42__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058349_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b50__05d 
        = (1U & (0xe0001fffU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                << 2U) 
                                               | (IData)(__VdfgTmp_hd06a07d0__0))))));
    vlSelf->__VdfgTmp_hbec899f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hd06a07d0__0)));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b44__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058351_))));
    vlSelf->__VdfgTmp_h3c71f500__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016450_));
    vlSelf->wasmetal_core__DOT___016460_ = (1U & (IData)(
                                                         (0x7fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058364_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058363_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058355_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015969_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015596_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b48__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058355_))));
    vlSelf->wasmetal_core__DOT___058347_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058278_))));
    vlSelf->wasmetal_core__DOT___058279_ = (1U & (IData)(
                                                         (0xf0f01111ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058278_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f0ccaaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058276_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha6796979__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_h1a57c023__0))))))));
    vlSelf->__VdfgTmp_h86dfc376__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058315_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058314_))));
    vlSelf->wasmetal_core__DOT___040084_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128789___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___040099_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128789___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___040103_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128789___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___040100_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128789___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___040076_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128790___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___040101_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b58__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128790___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___040098_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b59__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128790___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___040080_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b60__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128790___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase 
        = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049343_))));
    vlSelf->wasmetal_core__DOT___036007_ = (1U & (IData)(
                                                         (0xffff753000008acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b53__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b53__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___071561_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058086_)))))))));
    vlSelf->wasmetal_core__DOT___058090_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7b6a46b3__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h11374272__0))));
    vlSelf->wasmetal_core__DOT___017156_ = (1U & ((~ 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b3__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005670_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                      ? 
                                                     (0x7f5f3f0fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006583_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005679_) 
                                                           << 3U) 
                                                          | (((IData)(wasmetal_core__DOT___006582_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_he488fa83__0)))))
                                                      : 
                                                     (0xb333U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___006583_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005679_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___006582_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xdf2f20dU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0))))))))));
    vlSelf->__VdfgTmp_hc204a2d8__0 = ((4U & ((9U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___017194_))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017196_)));
    vlSelf->wasmetal_core__DOT___057697_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051533_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057695_))));
    vlSelf->wasmetal_core__DOT___036315_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017519_))));
    vlSelf->wasmetal_core__DOT___013209_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___051533_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___057693_ = (1U & (0xe0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                               >> 1U))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___013621_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___057689_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017519_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128791___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0))) 
                   << 3U)) | (IData)(wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0)) 
           ^ (((IData)(wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128791___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035873_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0)))) {
        vlSelf->wasmetal_core__DOT___035864_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d;
        vlSelf->wasmetal_core__DOT___035721_ = wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__;
    } else {
        vlSelf->wasmetal_core__DOT___035864_ = wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___035721_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d;
    }
    vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036951_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hfa042eae__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128777___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0)) 
                   << 3U)) | (IData)(wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0)) 
           ^ (((IData)(wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128777___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035729_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128869___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b28__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036420_)))));
    vlSelf->wasmetal_core__DOT___036490_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b31__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___018280_ = (1U & (IData)(
                                                         (0xfff08880fff0fff0ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058929_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058928_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058927_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058884_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058883_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058882_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x153f000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058876_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058875_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058758_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x700000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058872_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058871_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058870_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd48e33a__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he93f6ca8__0)))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x700000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058868_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058867_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058866_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a46858f__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h87705c6a__0)))))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058907_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058906_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058905_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058894_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058893_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058892_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2b50f7e1__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h61354930__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h324d1ed5__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc2de3b41__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023184_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035960_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b10__05d));
    vlSelf->__VdfgTmp_hf5238d18__0 = (((IData)(vlSelf->wasmetal_core__DOT___058305_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058306_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b54__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058360_))));
    vlSelf->wasmetal_core__DOT___058696_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf3f2f333U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___017195_)))))))))));
    if ((1U & (8U >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)))) {
        vlSelf->wasmetal_core__DOT___058688_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___017193_)));
        vlSelf->wasmetal_core__DOT___018273_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___017193_)));
    } else {
        vlSelf->wasmetal_core__DOT___058688_ = (1U 
                                                & (IData)(
                                                          (0x5d5d5ddd5d5d5d5fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf6eff41b__0))))))));
        vlSelf->wasmetal_core__DOT___018273_ = (1U 
                                                & (IData)(
                                                          (0x7777777f55575555ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf6eff41b__0))))))));
    }
    vlSelf->wasmetal_core__DOT___058687_ = ((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                            & (IData)(
                                                      (0x55570100ULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((8U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                            << 5U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))))));
    vlSelf->wasmetal_core__DOT___018272_ = ((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                            & (IData)(
                                                      (0x222a2223ULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((8U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                            << 5U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b46__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058353_))));
    vlSelf->wasmetal_core__DOT___058358_ = (1U & (IData)(
                                                         (0xfef0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he58e0004__0))))));
    vlSelf->wasmetal_core__DOT___058309_ = (1U & (IData)(
                                                         (0xfef000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he58e0004__0))))));
    vlSelf->__VdfgTmp_h0d8c930c__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058248_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b32__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058341_))));
    vlSelf->wasmetal_core__DOT___016429_ = (1U & (IData)(
                                                         (0xeeeef0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058518_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h9a38454b__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058276_)))))))));
    vlSelf->__VdfgTmp_h20c89172__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058321_));
    vlSelf->__VdfgTmp_h8d5d3612__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016448_));
    vlSelf->wasmetal_core__DOT___016444_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058315_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058317_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058314_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058316_)))))));
    vlSelf->__VdfgTmp_h6df53282__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058317_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058316_))));
    vlSelf->__VdfgTmp_h37243dd3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058295_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058294_))));
    vlSelf->wasmetal_core__DOT___058337_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058336_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058335_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058334_))))));
    vlSelf->wasmetal_core__DOT___058338_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058336_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058334_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058335_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b33__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058342_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b17__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016441_))));
    vlSelf->__VdfgTmp_hba6f19f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058225_));
    vlSelf->__VdfgTmp_heb95d931__0 = ((2U & ((0xe00U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hac8f2958__0)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfff100000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058303_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058302_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___016122_))))))))));
    vlSelf->wasmetal_core__DOT___058343_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058233_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hac8f2958__0))))));
    vlSelf->wasmetal_core__DOT___058234_ = (1U & (IData)(
                                                         (0xff00ff000000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058233_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058232_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hac8f2958__0))))))));
    vlSelf->wasmetal_core__DOT___016452_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___016021_)
                                                         ? 
                                                        (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                         : 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                          ? 
                                                         (0xe0U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h9d948fd9__0))
                                                          : 
                                                         (0xe0U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hbb3c60ea__0)))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                          ? 
                                                         (0xe0U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & (((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                                    ? 
                                                                   (0xeU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015897_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___015896_))))
                                                                    : 
                                                                   (0x53U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hd3573026__0))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (0xe0U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h2eec3533__0))))))
                                                          : 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___016007_)
                                                           ? 
                                                          (2U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                           : 
                                                          (0xe00U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_ha2f7036a__0))))))))));
    vlSelf->wasmetal_core__DOT___058332_ = (1U & (IData)(
                                                         (0x11ff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058331_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x4000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2900ee3d__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016007_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hfb1d3885__0))))))))))));
    vlSelf->wasmetal_core__DOT___058265_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016018_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016017_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfb1d3885__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b39__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058346_))));
    vlSelf->__VdfgTmp_he7bb7b74__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058275_));
    vlSelf->__VdfgTmp_h6712d737__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058319_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b41__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058348_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b9__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016447_))));
    vlSelf->__VdfgTmp_h7041ac57__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058328_));
    vlSelf->wasmetal_core__DOT___058521_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058354_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058353_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058352_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058351_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b45__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058352_))));
    vlSelf->__VdfgTmp_hbca2c4ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016451_));
    vlSelf->__VdfgTmp_he60f6eaf__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016442_));
    vlSelf->wasmetal_core__DOT___058359_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h240228f9__0)))));
    vlSelf->wasmetal_core__DOT___058344_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058255_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h240228f9__0))))));
    vlSelf->__VdfgTmp_hc888fbf4__0 = (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h240228f9__0));
    vlSelf->wasmetal_core__DOT___016431_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x88888888000fffffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015969_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015964_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058324_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___058323_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058321_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058319_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b27__05d 
        = (1U & (0x3ca5U >> (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058323_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058322_))))));
    vlSelf->wasmetal_core__DOT___058350_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf1c161b0__0)))));
    vlSelf->wasmetal_core__DOT___016449_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015597_)
                                                   ? 
                                                  (2U 
                                                   >> 
                                                   (1U 
                                                    & (IData)(
                                                              (0xccccf0f000ff00aaULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016125_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058239_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058238_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___015820_))))))))))
                                                   : 
                                                  (0xaacc0f0fU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf1c161b0__0))));
    vlSelf->wasmetal_core__DOT___058357_ = (1U & (IData)(
                                                         (0xee0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb564d990__0)))))));
    vlSelf->wasmetal_core__DOT___058307_ = (1U & (IData)(
                                                         (0xee000f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb564d990__0)))))));
    vlSelf->__VdfgTmp_h787befb5__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058242_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b3__05d 
        = (1U & (0x53acU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058242_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058241_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b40__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058347_))));
    vlSelf->wasmetal_core__DOT___016433_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058279_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058275_))));
    vlSelf->__VdfgTmp_h2a4257a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058279_));
    vlSelf->wasmetal_core__DOT___020523_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp))));
    vlSelf->wasmetal_core__DOT___072257_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048947_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase)))));
    vlSelf->wasmetal_core__DOT___040093_ = (1U & (IData)(
                                                         (0xfbfbfbfbfb080808ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128793___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___040095_ = (1U & (IData)(
                                                         (0xfbfbfbfbfb080808ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128794___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___040094_ = (1U & (IData)(
                                                         (0xfbfbfbfbfb080808ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering_normalCase) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128794___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02einValid) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052586_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___058092_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058090_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h75158e97__0)))))));
    vlSelf->wasmetal_core__DOT___058689_ = (1U & (0x1fU 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc204a2d8__0))));
    vlSelf->wasmetal_core__DOT___013204_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057697_))));
    vlSelf->__VdfgTmp_h8fcc0329__0 = (((IData)(vlSelf->wasmetal_core__DOT___013209_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013206_));
    vlSelf->__VdfgTmp_h917221d1__0 = (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015658_));
    vlSelf->wasmetal_core__DOT___057692_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057689_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)))));
    vlSelf->wasmetal_core__DOT___057698_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057689_))));
    vlSelf->wasmetal_core__DOT___040102_ = (1U & (IData)(
                                                         (0xeaea2a2aea2aea2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128791___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049343_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02eentering) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___128792___DOT__CO__BRA__0__KET__ 
        = ((1U >> (IData)(vlSelf->__VdfgTmp_h647f0add__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___035864_));
    vlSelf->wasmetal_core__DOT___036940_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036952_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___134181___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036952_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036951_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036962_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036961_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036948_)))));
    vlSelf->wasmetal_core__DOT___048951_ = (1U & (1U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128776___O) 
                                                       << 1U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                             << 1U)) 
                                                         | (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                               >> 2U)))))));
    vlSelf->__VdfgTmp_h78bec42d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058491_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128869___O) 
                                                          >> 1U)))));
    vlSelf->__VdfgTmp_h59bf4fdc__0 = (((IData)(vlSelf->wasmetal_core__DOT___016492_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128869___O) 
                                                    >> 3U)));
    vlSelf->wasmetal_core__DOT___128884___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b32__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036490_));
    vlSelf->wasmetal_core__DOT___060363_ = (1U & (IData)(
                                                         (0xff0a3303ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127587___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127604___O))))))))));
    vlSelf->wasmetal_core__DOT___059464_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                            & (IData)(
                                                      (0xff00ff3fff5fffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___018281_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127592___O))))))))));
    vlSelf->wasmetal_core__DOT___059543_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005745_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127592___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___059671_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006085_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_ha15895e4__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127593___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___060239_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127599___O) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O)))))))))))));
    vlSelf->wasmetal_core__DOT___019042_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127599___O)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127616___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___060305_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127600___O) 
                                                                                >> 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___060339_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127586___O) 
                                                                                >> 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___060397_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127587___O) 
                                                                                >> 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127604___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___019179_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127587___O) 
                                                                                >> 2U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127604___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___060417_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127588___O) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127605___O)))))))))))));
    vlSelf->wasmetal_core__DOT___019187_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff0a3303ff0fff0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127588___O)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127605___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___059574_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005875_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127592___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___059602_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006092_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha7391b06__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127593___O)))))))))))));
    vlSelf->wasmetal_core__DOT___059725_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003810_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2bc5853c__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127594___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___059777_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006400_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hff1f1b74__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127594___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___059805_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003807_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd093a298__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127595___O)))))))))))));
    vlSelf->wasmetal_core__DOT___059829_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003811_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd665514e__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127595___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___059890_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003805_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9141ccce__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127595___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___059918_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003806_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h87705c6a__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127596___O)))))))))))));
    vlSelf->wasmetal_core__DOT___060103_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005989_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127597___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___060468_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058550_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060464_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127588___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___060283_ = (1U & (IData)(
                                                         (0xff0a3303ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127600___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O))))))))));
    vlSelf->wasmetal_core__DOT___060291_ = (1U & (IData)(
                                                         (0xff0a3303ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127600___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___060317_ = (1U & (IData)(
                                                         (0xff0a3303ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127600___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127617___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___060323_ = (1U & (IData)(
                                                         (0xff0a3303ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127586___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O))))))))));
    vlSelf->wasmetal_core__DOT___060328_ = (1U & (IData)(
                                                         (0xff0a3303ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127586___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127603___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___060210_ = (1U & (IData)(
                                                         (0xfcfaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005711_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hfcfdf45d__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127598___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___059318_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005928_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127585___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___059381_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005716_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127585___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___059424_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005935_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127585___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___059679_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005982_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h79e73f20__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127593___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___059700_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003809_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hec73a4f8__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127594___O)))))))))))));
    vlSelf->wasmetal_core__DOT___059943_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005855_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf2c31503__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127596___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___060057_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006022_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127597___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___060082_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006099_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127597___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___060129_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006171_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2307c8f1__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127598___O)))))))))))));
    vlSelf->wasmetal_core__DOT___060153_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006144_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf7bb201a__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127598___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___059505_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                            & (IData)(
                                                      (0xff00ff3fff5fffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___018334_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3a9f8450__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127592___O) 
                                                                          >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___059753_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006204_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he6c218f0__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127594___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___059858_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003808_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3ada9ffa__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127595___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___059974_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005770_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8ddb6508__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127596___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___060001_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005868_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h276f18a3__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127596___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___060033_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006106_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127597___O)))))))))))));
    vlSelf->wasmetal_core__DOT___060594_ = (1U & (IData)(
                                                         (0xf0fff1100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127590___O) 
                                                                                >> 3U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058931_)))))))));
    vlSelf->wasmetal_core__DOT___060189_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfcfaf0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018279_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___018278_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006215_))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h43b7a5ac__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127598___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___060621_ = (1U & (IData)(
                                                         (0xf0fcf0faULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___018280_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060487_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hab870e45__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127591___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023185_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128802___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035961_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035960_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036014_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036013_)))) 
           ^ (((IData)(wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128802___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035957_)))));
    vlSelf->wasmetal_core__DOT___035905_ = ((IData)(vlSelf->wasmetal_core__DOT___035961_)
                                             ? (IData)(wasmetal_core__DOT___128802___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b11__05d));
    vlSelf->__VdfgTmp_hb63e733c__0 = (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058688_));
    vlSelf->wasmetal_core__DOT___059568_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059596_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059719_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059771_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059799_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059823_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059884_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059312_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059375_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059418_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059673_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059694_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059746_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059851_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059967_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059994_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___060026_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___060182_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->__VdfgTmp_hef0df0fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018273_));
    vlSelf->__VdfgTmp_h385650d9__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___018273_));
    vlSelf->wasmetal_core__DOT___060301_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058687_))));
    vlSelf->wasmetal_core__DOT___060335_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058687_))));
    vlSelf->wasmetal_core__DOT___059667_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013654_))))));
    vlSelf->wasmetal_core__DOT___019166_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013739_)))))));
    vlSelf->wasmetal_core__DOT___060646_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058687_))));
    vlSelf->wasmetal_core__DOT___019032_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013770_)))))));
    vlSelf->wasmetal_core__DOT___019046_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013771_)))))));
    vlSelf->wasmetal_core__DOT___059644_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013648_))))));
    vlSelf->wasmetal_core__DOT___019092_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013797_)))))));
    vlSelf->wasmetal_core__DOT___019106_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013796_)))))));
    vlSelf->wasmetal_core__DOT___019116_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013785_)))))));
    vlSelf->wasmetal_core__DOT___019138_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013787_)))))));
    vlSelf->wasmetal_core__DOT___019157_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013786_)))))));
    vlSelf->wasmetal_core__DOT___019004_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013805_)))))));
    vlSelf->wasmetal_core__DOT___017183_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013672_))))));
    vlSelf->__VdfgTmp_he45ddc74__0 = (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017186_));
    vlSelf->wasmetal_core__DOT___059911_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019167_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060462_ = (1U & (IData)(
                                                         (0xeee00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))))));
    vlSelf->wasmetal_core__DOT___060578_ = (1U & (IData)(
                                                         (0x45cf4545ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)))))))))));
    vlSelf->wasmetal_core__DOT___060300_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060334_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019033_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019047_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013771_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019093_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019107_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019117_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013785_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019139_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019158_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019005_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060272_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013795_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060374_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060389_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060404_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014037_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060412_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060428_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013778_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060442_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014245_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___059936_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060050_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
}
