#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__21(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__21\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___013839_;
    wasmetal_core__DOT___013839_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017856_;
    wasmetal_core__DOT___017856_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017868_;
    wasmetal_core__DOT___017868_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017870_;
    wasmetal_core__DOT___017870_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017881_;
    wasmetal_core__DOT___017881_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___029044_;
    wasmetal_core__DOT___029044_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044911_;
    wasmetal_core__DOT___044911_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045332_;
    wasmetal_core__DOT___045332_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045341_;
    wasmetal_core__DOT___045341_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045344_;
    wasmetal_core__DOT___045344_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045353_;
    wasmetal_core__DOT___045353_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045366_;
    wasmetal_core__DOT___045366_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045375_;
    wasmetal_core__DOT___045375_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045378_;
    wasmetal_core__DOT___045378_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045387_;
    wasmetal_core__DOT___045387_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045400_;
    wasmetal_core__DOT___045400_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045409_;
    wasmetal_core__DOT___045409_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045412_;
    wasmetal_core__DOT___045412_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045421_;
    wasmetal_core__DOT___045421_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045907_;
    wasmetal_core__DOT___045907_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045918_;
    wasmetal_core__DOT___045918_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045927_;
    wasmetal_core__DOT___045927_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045930_;
    wasmetal_core__DOT___045930_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045939_;
    wasmetal_core__DOT___045939_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059177_;
    wasmetal_core__DOT___059177_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059184_;
    wasmetal_core__DOT___059184_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070582_;
    wasmetal_core__DOT___070582_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070583_;
    wasmetal_core__DOT___070583_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070585_;
    wasmetal_core__DOT___070585_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127485___O;
    wasmetal_core__DOT____Vcellout___127485___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127614___O;
    wasmetal_core__DOT____Vcellout___127614___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127857___CO;
    wasmetal_core__DOT____Vcellout___127857___CO = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127873___O;
    wasmetal_core__DOT____Vcellout___127873___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128065___O;
    wasmetal_core__DOT____Vcellout___128065___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128065___CO;
    wasmetal_core__DOT____Vcellout___128065___CO = 0;
    CData/*0:0*/ wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127891___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127891___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127891___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127891___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127892___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127892___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127892___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127892___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127892___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127892___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127908___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127908___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127908___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127908___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127925___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127925___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127925___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127925___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127942___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127942___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127942___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127942___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127943___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127943___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127943___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127943___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128119___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128119___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128119___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128119___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135442___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___135442___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hcd9ab9ab__0;
    __VdfgTmp_hcd9ab9ab__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0996db4e__0;
    __VdfgTmp_h0996db4e__0 = 0;
    CData/*4:0*/ __VdfgTmp_hf9553abf__0;
    __VdfgTmp_hf9553abf__0 = 0;
    CData/*5:0*/ __VdfgTmp_hb5812008__0;
    __VdfgTmp_hb5812008__0 = 0;
    CData/*1:0*/ __VdfgTmp_he5f9d86a__0;
    __VdfgTmp_he5f9d86a__0 = 0;
    // Body
    __VdfgTmp_h0996db4e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___002636_));
    vlSelf->wasmetal_core__DOT___013764_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002631_)))))))));
    vlSelf->wasmetal_core__DOT___013763_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002630_))))));
    vlSelf->wasmetal_core__DOT___013813_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002629_))))));
    vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013687_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023592_));
    vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029074_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029039_)
            : (IData)(vlSelf->wasmetal_core__DOT___000613_));
    wasmetal_core__DOT___045366_ = (1U & (0xbfabbbaaU 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O) 
                                                  << 2U)) 
                                              | ((8U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b62__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b63__05d) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___CO) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___045378_ = (1U & (0x41000041U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b63__05d) 
                                               << 4U) 
                                              | ((0xcU 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b62__05d) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___CO) 
                                                          >> 3U)))))));
    wasmetal_core__DOT___045375_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128109___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b59__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b61__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b60__05d)))))))));
    wasmetal_core__DOT___045387_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b61__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128110___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b60__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128109___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___071283_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071282_))));
    wasmetal_core__DOT___045341_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052504_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h14b4bf2b__0))))))));
    wasmetal_core__DOT___045353_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052504_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052189_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052188_)))))))));
    wasmetal_core__DOT___045332_ = (1U & (0xbfabbbaaU 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                  << 2U)) 
                                              | ((8U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052175_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052176_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___CO) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___045344_ = (1U & (0x41000041U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___052176_) 
                                               << 4U) 
                                              | ((0xcU 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052175_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___CO) 
                                                          >> 3U)))))));
    wasmetal_core__DOT___127891___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026689_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127891___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d));
    vlSelf->wasmetal_core__DOT___070727_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054388_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1cU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___070722_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054382_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x19U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d)))))));
    wasmetal_core__DOT___127942___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027159_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127942___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d));
    wasmetal_core__DOT____Vcellout___127873___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___026586_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___026585_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___026583_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026582_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026515_)))));
    vlSelf->wasmetal_core__DOT___026520_ = ((IData)(vlSelf->wasmetal_core__DOT___026586_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127873___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___005617_));
    vlSelf->wasmetal_core__DOT___070830_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054387_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1cU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___070825_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054381_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x19U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d)))))));
    wasmetal_core__DOT___127925___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026959_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127925___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d));
    wasmetal_core__DOT___045927_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052567_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h7bad9dec__0))))))));
    wasmetal_core__DOT___045939_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052233_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052232_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052567_)))))))));
    wasmetal_core__DOT___045409_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbd97d07b__0)))))));
    wasmetal_core__DOT___045421_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005312_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___004904_)))))))));
    vlSelf->wasmetal_core__DOT___045861_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 4U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___005618_))))))));
    vlSelf->wasmetal_core__DOT___045885_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005232_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005618_)))))))));
    vlSelf->wasmetal_core__DOT___045881_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004960_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005028_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004892_)))))))));
    vlSelf->wasmetal_core__DOT___045905_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005028_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004960_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004892_)))))))));
    wasmetal_core__DOT___045918_ = (1U & (0xbfabbbaaU 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                  << 2U)) 
                                              | ((8U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052234_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052235_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___CO) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___045930_ = (1U & (0x41000041U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___052235_) 
                                               << 4U) 
                                              | ((0xcU 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052234_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___CO) 
                                                          >> 3U)))))));
    __VdfgTmp_hcd9ab9ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___005636_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___CO) 
                                               >> 3U)));
    wasmetal_core__DOT___127908___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h4bc445dd__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127908___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___135441___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___135441___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___135441___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___135441___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034532_)))));
    vlSelf->wasmetal_core__DOT___046632_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___135441___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128670___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034479_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034478_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034477_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034476_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034532_)))));
    vlSelf->wasmetal_core__DOT___034536_ = ((IData)(vlSelf->wasmetal_core__DOT___034479_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128670___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030114_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128238___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d));
    wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030242_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128252___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d));
    wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127958___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027357_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027356_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027354_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027353_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027287_)))));
    vlSelf->wasmetal_core__DOT___027292_ = ((IData)(vlSelf->wasmetal_core__DOT___027357_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127958___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b31__05d));
    vlSelf->wasmetal_core__DOT___023208_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2914f84f__0))));
    vlSelf->wasmetal_core__DOT___023207_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd5e33f95__0))));
    vlSelf->wasmetal_core__DOT___023206_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006215_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h584814f6__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h584814f6__0)))));
    vlSelf->wasmetal_core__DOT___023205_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5b56c921__0))));
    wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022473_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127441___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___059071_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016290_)
                                                   ? (IData)(
                                                             (0xbfffffffULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9cc49427__0)))
                                                   : (IData)(
                                                             (0xffffffff40000000ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9cc49427__0)))));
    wasmetal_core__DOT___017881_ = ((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___014094_));
    __VdfgTmp_hf9553abf__0 = ((0x10U & ((8U >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                        << 4U)) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017848_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017847_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017846_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___017830_ = (1U 
                                                & ((~ (IData)(
                                                              (0x30a000000000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((8U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                                             << 2U)) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h179d57be__0)))))))) 
                                                   & (0x11fff0ffU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                        << 4U) 
                                                       | ((8U 
                                                           & ((8U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                              << 3U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014094_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(
                                                                            (0xf0f335500000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057782_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h563e3bc4__0))))))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (0x305U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013638_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___013637_)))))))))))));
        vlSelf->wasmetal_core__DOT___017832_ = (1U 
                                                & ((1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)))
                                                    ? 
                                                   (0x11f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014198_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((IData)(
                                                                       (0x33550f0f00000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                             << 4U) 
                                                                            | ((8U 
                                                                                & ((0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                                                << 3U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___057782_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013687_)))))))) 
                                                               << 1U)) 
                                                           | (1U 
                                                              & (IData)(
                                                                        (0x335500000f0fULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7c6f7838__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013638_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h563e3bc4__0))))))))))))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (1U 
                                                     & (IData)(
                                                               (0xfaa330000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                        << 3U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hc1104829__0))))))))));
        vlSelf->wasmetal_core__DOT___017833_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___017849_)
                                                    ? 
                                                   (0xccf05555U 
                                                    >> (IData)(__VdfgTmp_hf9553abf__0))
                                                    : 
                                                   (0x330faaaaU 
                                                    >> (IData)(__VdfgTmp_hf9553abf__0))));
    } else {
        vlSelf->wasmetal_core__DOT___017830_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013687_)));
        vlSelf->wasmetal_core__DOT___017832_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___002472_)));
        vlSelf->wasmetal_core__DOT___017833_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___017849_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___002193_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___002193_))));
    }
    vlSelf->wasmetal_core__DOT___057781_ = (1U & (0xcc55f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017847_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___017848_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017846_)))))));
    vlSelf->wasmetal_core__DOT___057858_ = (1U & (0xff8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057857_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057856_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017848_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013909_)))))));
    vlSelf->wasmetal_core__DOT___017838_ = (1U & (IData)(
                                                         (0xf55330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7f08cefc__0)))))));
    vlSelf->wasmetal_core__DOT___057806_ = (1U & (0x5fcfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057805_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff00ccccf0f0aaaaULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014231_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7f08cefc__0)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff33330f0f5555ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014224_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014234_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014233_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014232_)))))))))))))));
    wasmetal_core__DOT___017868_ = ((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                    & (IData)((0xff0fff55ff33ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7f08cefc__0)))))));
    if (vlSelf->wasmetal_core__DOT___013909_) {
        if (vlSelf->wasmetal_core__DOT___014263_) {
            vlSelf->wasmetal_core__DOT___057843_ = 
                (1U & (IData)((0xf000aa00cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014289_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h7f08cefc__0)))))));
            vlSelf->wasmetal_core__DOT___057846_ = 
                (1U & (IData)((0xf0005500cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014300_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc1104829__0)))))));
        } else {
            vlSelf->wasmetal_core__DOT___057843_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014289_)));
            vlSelf->wasmetal_core__DOT___057846_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014300_)));
        }
    } else {
        vlSelf->wasmetal_core__DOT___057843_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014289_)));
        vlSelf->wasmetal_core__DOT___057846_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014300_)));
    }
    __VdfgTmp_hb5812008__0 = (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___017908_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017907_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017906_))))));
    vlSelf->wasmetal_core__DOT___057790_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017909_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf3f500000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017908_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017906_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___017907_))))))))))));
    wasmetal_core__DOT___017870_ = ((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                    & (IData)((0xff0fffaaff33ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013641_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013640_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc1104829__0)))))));
    vlSelf->__VdfgTmp_h103cd5d4__0 = (((IData)(vlSelf->wasmetal_core__DOT___017829_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017828_));
    vlSelf->wasmetal_core__DOT___057871_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017883_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017884_)))));
    vlSelf->wasmetal_core__DOT___057876_ = (1U & (0xff8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057874_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057873_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017819_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013909_)))))));
    vlSelf->wasmetal_core__DOT___017859_ = (1U & (IData)(
                                                         (0xf8ffffff0700ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057877_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057874_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057873_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017819_)))))))));
    vlSelf->__VdfgTmp_h2b8ef9eb__0 = (((IData)(vlSelf->wasmetal_core__DOT___016289_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057884_));
    wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022712_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127459___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022695_));
    vlSelf->wasmetal_core__DOT___058907_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058901_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058900_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h9141ccce__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3ada9ffa__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023753_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023688_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d));
    wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d) {
        wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d;
        vlSelf->wasmetal_core__DOT___023890_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d;
    } else {
        wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023890_ = wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__;
    }
    wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                  >> 2U) | (IData)(vlSelf->wasmetal_core__DOT___134185___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022629_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127451___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022629_));
    wasmetal_core__DOT___059177_ = (1U & (IData)((0x700000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059170_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059169_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059168_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d) 
                                                                   << 1U) 
                                                                  | (1U 
                                                                     & (4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_h6a2fda60__0))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h4dc2cdc8__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022798_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022765_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h183d05b4__0))));
    wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d) {
        wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d;
        vlSelf->wasmetal_core__DOT___022880_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d;
    } else {
        wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022880_ = wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034313_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128119___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028867_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128119___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000635_));
    wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028112_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128049___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 0x1dU)));
    wasmetal_core__DOT____Vcellout___127857___CO = 
        ((((IData)(vlSelf->wasmetal_core__DOT___026478_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127857___DOT__CO__BRA__2__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b31__05d)) 
          << 3U) | (IData)(vlSelf->wasmetal_core__DOT___127857___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127857___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026478_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026477_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026475_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026474_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127857___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026440_)));
    wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___010972_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003808_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013814_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h0996db4e__0))))))));
    wasmetal_core__DOT___013839_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h0996db4e__0))))))));
    vlSelf->wasmetal_core__DOT___013742_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013813_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127578___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127579___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___002633_)))))));
    vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013656_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029075_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000635_));
    vlSelf->wasmetal_core__DOT___045355_ = ((IData)(wasmetal_core__DOT___045378_)
                                             ? ((IData)(wasmetal_core__DOT___045387_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045386_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045385_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045384_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045383_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045382_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045381_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045380_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045379_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045377_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045365_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045367_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045368_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045369_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045370_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045371_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045372_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045373_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045374_))
                                                 : (IData)(wasmetal_core__DOT___045375_))
                                             : (IData)(wasmetal_core__DOT___045366_));
    vlSelf->wasmetal_core__DOT___071284_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071283_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___045321_ = ((IData)(wasmetal_core__DOT___045344_)
                                             ? ((IData)(wasmetal_core__DOT___045353_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045352_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045351_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045350_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045349_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045348_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045347_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045346_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045345_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045343_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045331_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045333_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045334_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045335_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045336_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045337_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045338_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045339_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045340_))
                                                 : (IData)(wasmetal_core__DOT___045341_))
                                             : (IData)(wasmetal_core__DOT___045332_));
    wasmetal_core__DOT___127891___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026690_)
            ? (IData)(wasmetal_core__DOT___127891___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d));
    vlSelf->wasmetal_core__DOT___070729_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054386_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070727_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1bU)))))))))));
    vlSelf->wasmetal_core__DOT___070728_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070727_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054386_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1bU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___070724_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054380_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070722_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x18U)))))))))));
    vlSelf->wasmetal_core__DOT___070723_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070722_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054380_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x18U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d)))))))));
    wasmetal_core__DOT___127942___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027160_)
            ? (IData)(wasmetal_core__DOT___127942___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d));
    vlSelf->wasmetal_core__DOT___045479_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071373_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___127873___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071372_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071371_))))))));
    vlSelf->wasmetal_core__DOT___045503_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071373_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071372_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071371_)))))))));
    vlSelf->wasmetal_core__DOT___045499_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071370_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071369_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071368_)))))))));
    vlSelf->wasmetal_core__DOT___045523_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071370_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071369_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071368_)))))))));
    vlSelf->wasmetal_core__DOT___045275_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071436_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___127873___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071435_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071434_))))))));
    vlSelf->wasmetal_core__DOT___045299_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071436_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071435_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071434_)))))))));
    vlSelf->wasmetal_core__DOT___045295_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071433_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071432_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071431_)))))))));
    vlSelf->wasmetal_core__DOT___045319_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071433_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127872___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071432_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127873___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071431_)))))))));
    vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026492_) 
           & (IData)(vlSelf->wasmetal_core__DOT___026520_));
    vlSelf->wasmetal_core__DOT___070832_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054385_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070830_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1bU)))))))))));
    vlSelf->wasmetal_core__DOT___070831_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070830_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1bU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___070827_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054379_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070825_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x18U)))))))))));
    vlSelf->wasmetal_core__DOT___070826_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070825_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054379_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x18U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d)))))))));
    wasmetal_core__DOT___127925___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026960_)
            ? (IData)(wasmetal_core__DOT___127925___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d));
    wasmetal_core__DOT___045907_ = ((IData)(wasmetal_core__DOT___045930_)
                                     ? ((IData)(wasmetal_core__DOT___045939_)
                                         ? ((IData)(vlSelf->wasmetal_core__DOT___045938_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045937_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045936_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045935_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045934_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045933_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045932_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045931_)
                                                       ? 
                                                      ((~ (IData)(vlSelf->wasmetal_core__DOT___045929_)) 
                                                       & (IData)(vlSelf->wasmetal_core__DOT___045917_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045919_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045920_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045921_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045922_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045923_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045924_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045925_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045926_))
                                         : (IData)(wasmetal_core__DOT___045927_))
                                     : (IData)(wasmetal_core__DOT___045918_));
    wasmetal_core__DOT___045400_ = (1U & (0xbfabbbaaU 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                  << 2U)) 
                                              | ((8U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_hcd9ab9ab__0))))));
    wasmetal_core__DOT___045412_ = (1U & (0x41000041U 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                  << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___005244_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                        >> 1U)) 
                                                    | (IData)(__VdfgTmp_hcd9ab9ab__0))))));
    wasmetal_core__DOT___127908___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h9dd568d9__0)))
            ? (IData)(wasmetal_core__DOT___127908___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d));
    vlSelf->wasmetal_core__DOT___030249_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135441___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d))))));
    vlSelf->wasmetal_core__DOT___030248_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135441___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d))))));
    vlSelf->wasmetal_core__DOT___030247_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135441___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))))));
    vlSelf->wasmetal_core__DOT___030246_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135441___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))))));
    vlSelf->wasmetal_core__DOT___135442___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___046632_));
    vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034480_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034536_));
    vlSelf->wasmetal_core__DOT____Vcellout___128238___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030117_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030116_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030114_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030113_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___030116_)
                 ? (IData)(wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128238___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128238___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030080_)))));
    wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030244_)
            ? (IData)(wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d));
    wasmetal_core__DOT____Vcellout___128065___CO = 
        ((((IData)(vlSelf->wasmetal_core__DOT___028309_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128065___DOT__CO__BRA__2__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028244_)) 
          << 3U) | (IData)(wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0));
    wasmetal_core__DOT____Vcellout___128065___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028309_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028308_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028306_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028305_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128065___DOT____VdfgTmp_h3cda4b7d__0) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___028271_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127974___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
           ^ (((IData)(wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127974___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027418_)))));
    vlSelf->wasmetal_core__DOT___027422_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127957___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127974___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027358_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027292_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b32__05d));
    wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022474_) 
           & (IData)(wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h3ee80f1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___016258_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017830_));
    vlSelf->__VdfgTmp_h378f1a2c__0 = (((IData)(vlSelf->wasmetal_core__DOT___017886_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017885_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017884_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017883_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017882_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___017881_))))));
    vlSelf->wasmetal_core__DOT___057865_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017885_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___017881_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017882_)))));
    vlSelf->wasmetal_core__DOT___057799_ = (1U & (IData)(
                                                         (0x11110f0fff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdff3685b__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017838_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017839_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017840_)))))))));
    vlSelf->wasmetal_core__DOT___017811_ = (1U & (0x90U 
                                                  >> 
                                                  ((4U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___017821_)
                                                          ? 
                                                         (0xaf00cfU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h4cbcef22__0))
                                                          : 
                                                         (0xff50ff30U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h4cbcef22__0)))
                                                         : 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___017821_)
                                                          ? 
                                                         (2U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___013652_))
                                                          : 
                                                         (1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___013652_)))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xefU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hedae78d9__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057806_)))));
    vlSelf->wasmetal_core__DOT___057812_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017871_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017867_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017868_)))));
    vlSelf->wasmetal_core__DOT___043053_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006941_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057838_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006947_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057843_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057852_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057835_)))))))));
    vlSelf->wasmetal_core__DOT___017861_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006947_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057852_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057838_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057835_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006941_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057843_)))))))));
    vlSelf->wasmetal_core__DOT___017863_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017910_)
                                                   ? 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___017909_)) 
                                                   & (IData)(
                                                             (0xff0aff0cffffffffULL 
                                                              >> (IData)(__VdfgTmp_hb5812008__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017909_) 
                                                   | (IData)(
                                                             (0xf500f300000000ULL 
                                                              >> (IData)(__VdfgTmp_hb5812008__0))))));
    vlSelf->__VdfgTmp_h0aec0439__0 = (((IData)(vlSelf->wasmetal_core__DOT___017872_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017871_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___017870_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017869_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___017868_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___017867_))))));
    vlSelf->wasmetal_core__DOT___057817_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017872_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017869_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017870_)))));
    vlSelf->wasmetal_core__DOT___043052_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006943_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006942_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057890_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057897_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057846_)))))))));
    vlSelf->wasmetal_core__DOT___017860_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016288_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057890_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006942_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057897_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006943_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057846_)))))))));
    wasmetal_core__DOT___070582_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___017888_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057871_))));
    vlSelf->wasmetal_core__DOT___070580_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059071_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2b8ef9eb__0))));
    wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022696_)
            ? (IData)(wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022696_));
    vlSelf->wasmetal_core__DOT____Vcellout___127630___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127630___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024013_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d) {
        vlSelf->wasmetal_core__DOT___024017_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024017_ = wasmetal_core__DOT___127630___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023890_;
    }
    vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023754_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d));
    wasmetal_core__DOT____Vcellout___127614___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127614___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127614___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023886_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___134185___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                       >> 3U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                   >> 2U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                   >> 1U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134185___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___036988_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                     >> 3U) 
                                                    | (IData)(wasmetal_core__DOT___134185___DOT__CO__BRA__2__KET__)));
    wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022630_)
            ? (IData)(wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022630_));
    vlSelf->wasmetal_core__DOT____Vcellout___127493___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127493___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022939_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d) {
        vlSelf->wasmetal_core__DOT___022943_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d;
        vlSelf->wasmetal_core__DOT___127486___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022943_ = wasmetal_core__DOT___127493___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127486___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022880_;
    }
    vlSelf->wasmetal_core__DOT___059187_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059178_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059177_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059176_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h57318413__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7e209046__0))))))))))))));
    vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022799_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h1eb7369a__0))));
    wasmetal_core__DOT____Vcellout___127485___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127485___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127485___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022876_)))));
    vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034314_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128119___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028869_)
            ? (IData)(wasmetal_core__DOT___128119___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000657_));
    vlSelf->wasmetal_core__DOT____Vcellout___128049___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028115_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028114_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028112_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028111_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___028114_)
                       ? (IData)(wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__)
                       : (vlSelf->insn_x >> 0x1eU)) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128049___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___028078_)))));
    wasmetal_core__DOT___044911_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127857___CO) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127857___O) 
                                                          << 2U)) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127857___O)) 
                                                         | ((6U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127857___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127856___O) 
                                                                  >> 3U)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128554___O 
        = (((8U & ((~ (0xfef0U >> (IData)(vlSelf->__VdfgTmp_h2133c371__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010972_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128554___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033438_)))));
    vlSelf->wasmetal_core__DOT___033443_ = ((~ (0xfef0U 
                                                >> (IData)(vlSelf->__VdfgTmp_h2133c371__0))) 
                                            & (IData)(wasmetal_core__DOT___128554___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003811_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___013825_ = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127580___O))
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                & (IData)(wasmetal_core__DOT___013839_))
                                             : (IData)(wasmetal_core__DOT___013839_));
    vlSelf->__VdfgTmp_he2ae9361__0 = (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013672_));
    vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013652_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029077_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000657_));
    vlSelf->wasmetal_core__DOT___045047_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071284_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___045023_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071284_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054162_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054166_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071282_))))));
    vlSelf->__VdfgTmp_h19b7a9a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___045321_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052577_));
    vlSelf->wasmetal_core__DOT___052705_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045321_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h568bee24__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127891___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026691_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026690_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026689_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026688_)))) 
           ^ (((IData)(wasmetal_core__DOT___127891___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127891___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127891___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026622_)))));
    vlSelf->wasmetal_core__DOT___026626_ = ((IData)(vlSelf->wasmetal_core__DOT___026691_)
                                             ? (IData)(wasmetal_core__DOT___127891___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d));
    vlSelf->wasmetal_core__DOT___045231_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070728_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054384_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1aU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___045207_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070729_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054388_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1cU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054384_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070728_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1aU))))))))))))));
    vlSelf->wasmetal_core__DOT___045251_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070723_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___045227_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070724_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054382_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x19U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054378_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070723_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127942___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027161_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027160_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027159_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027158_)))) 
           ^ (((IData)(wasmetal_core__DOT___127942___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127942___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127942___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027092_)))));
    vlSelf->wasmetal_core__DOT___027096_ = ((IData)(vlSelf->wasmetal_core__DOT___027161_)
                                             ? (IData)(wasmetal_core__DOT___127942___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b35__05d));
    vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026493_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___044959_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070831_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054383_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1aU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___044935_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070832_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054387_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1cU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054383_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070831_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1aU))))))))))))));
    vlSelf->wasmetal_core__DOT___044979_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070826_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054377_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___044955_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070827_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054381_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x19U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054377_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070826_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127925___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026961_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026960_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026959_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026958_)))) 
           ^ (((IData)(wasmetal_core__DOT___127925___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127925___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127925___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026892_)))));
    vlSelf->wasmetal_core__DOT___026896_ = ((IData)(vlSelf->wasmetal_core__DOT___026961_)
                                             ? (IData)(wasmetal_core__DOT___127925___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d));
    vlSelf->wasmetal_core__DOT___054021_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___045907_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045423_))));
    vlSelf->wasmetal_core__DOT___045389_ = ((IData)(wasmetal_core__DOT___045412_)
                                             ? ((IData)(wasmetal_core__DOT___045421_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045420_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045419_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045418_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045417_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045416_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045415_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045414_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045413_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045411_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045399_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045401_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045402_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045403_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045404_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045405_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045406_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045407_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045408_))
                                                 : (IData)(wasmetal_core__DOT___045409_))
                                             : (IData)(wasmetal_core__DOT___045400_));
    vlSelf->wasmetal_core__DOT____Vcellout___127908___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hb0eafd09__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h9dd568d9__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h4bc445dd__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h80fb591c__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127908___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127908___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127908___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026757_)))));
    vlSelf->wasmetal_core__DOT___026761_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb0eafd09__0)))
                                             ? (IData)(wasmetal_core__DOT___127908___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d));
    vlSelf->wasmetal_core__DOT___135442___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135442___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034481_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128252___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030245_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030244_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030242_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030241_)))) 
           ^ (((IData)(wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128252___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128252___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030176_)))));
    vlSelf->wasmetal_core__DOT___030181_ = ((IData)(vlSelf->wasmetal_core__DOT___030245_)
                                             ? (IData)(wasmetal_core__DOT___128252___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d));
    vlSelf->wasmetal_core__DOT___063288_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___CO) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128065___CO)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___CO) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063264_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128065___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063270_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128065___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063276_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128065___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063282_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128065___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->__VdfgTmp_h4ddf67d8__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d)))));
    vlSelf->__VdfgTmp_h3d4d4e87__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O) 
                                             >> 2U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d)))));
    vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027422_));
    vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027359_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b33__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127441___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022475_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022474_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022473_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022472_)))) 
           ^ (((IData)(wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127441___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127441___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022528_)))));
    vlSelf->wasmetal_core__DOT___022532_ = ((IData)(vlSelf->wasmetal_core__DOT___022475_) 
                                            & (IData)(wasmetal_core__DOT___127441___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___017858_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017888_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017887_)
                                                    ? (IData)(
                                                              (0xb0bbULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h378f1a2c__0)))
                                                    : (IData)(
                                                              (0xf0ff4044ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h378f1a2c__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017887_)
                                                    ? (IData)(
                                                              (0xbbbb00000b00ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h378f1a2c__0)))
                                                    : (IData)(
                                                              (0xffff44440f000400ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h378f1a2c__0))))));
    wasmetal_core__DOT___070585_ = (1U & (0x90U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017833_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h3ee80f1f__0))));
    vlSelf->wasmetal_core__DOT___070587_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016255_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057799_))));
    vlSelf->wasmetal_core__DOT___043056_ = (1U & (IData)(
                                                         (0x8fff888f8f8f8888ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xefU 
                                                                >> (IData)(vlSelf->__VdfgTmp_hedae78d9__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017821_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057806_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057771_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017811_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017910_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___057790_))))))))))));
    vlSelf->wasmetal_core__DOT___043062_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017863_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017811_))));
    wasmetal_core__DOT___017856_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017874_)
                                           ? ((1U & 
                                               (0xefU 
                                                >> (IData)(vlSelf->__VdfgTmp_h8599270c__0)))
                                               ? (IData)(
                                                         (0xb0bbULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0aec0439__0)))
                                               : (IData)(
                                                         (0xf0ff4044ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0aec0439__0))))
                                           : ((1U & 
                                               (0xefU 
                                                >> (IData)(vlSelf->__VdfgTmp_h8599270c__0)))
                                               ? (IData)(
                                                         (0xbbbb00000b00ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0aec0439__0)))
                                               : (IData)(
                                                         (0xffff44440f000400ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h0aec0439__0))))));
    wasmetal_core__DOT___070583_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___017874_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057817_))));
    vlSelf->wasmetal_core__DOT___043059_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070580_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057923_)))));
    vlSelf->wasmetal_core__DOT___043051_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___016290_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057893_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h2b8ef9eb__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057923_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070580_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___016297_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127459___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022697_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022696_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022712_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022711_)))) 
           ^ (((IData)(wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127459___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127459___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___022705_ = ((IData)(vlSelf->wasmetal_core__DOT___022697_)
                                             ? (IData)(wasmetal_core__DOT___127459___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___022697_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d) {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024017_;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023755_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d));
    vlSelf->__VdfgTmp_hea953bdf__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127614___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005989_));
    vlSelf->__VdfgTmp_h8fda36d2__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127614___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006099_));
    vlSelf->__VdfgTmp_h9c2e8d35__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127614___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006022_));
    vlSelf->__VdfgTmp_hc450b1a0__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127614___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006106_));
    vlSelf->wasmetal_core__DOT___022639_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022643_)
                                                   ? (IData)(wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___022643_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127451___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022643_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022630_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022629_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022628_)))) 
           ^ (((IData)(wasmetal_core__DOT___127451___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127451___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127451___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022635_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d) {
        vlSelf->wasmetal_core__DOT___127494___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d;
        wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127494___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022943_;
        wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127486___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022800_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h747f7a26__0))));
    vlSelf->__VdfgTmp_h0ecf04e3__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127485___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005989_));
    vlSelf->__VdfgTmp_h3e9bda10__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127485___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006099_));
    vlSelf->__VdfgTmp_h601f88f8__0 = ((2U & (IData)(wasmetal_core__DOT____Vcellout___127485___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006022_));
    vlSelf->__VdfgTmp_h36468d91__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127485___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006106_));
    vlSelf->wasmetal_core__DOT____Vcellout___128655___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034315_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034314_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034313_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034312_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034375_)))));
    vlSelf->wasmetal_core__DOT___034379_ = ((IData)(vlSelf->wasmetal_core__DOT___034315_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___028836_ = ((IData)(vlSelf->wasmetal_core__DOT___028870_)
                                             ? (IData)(wasmetal_core__DOT___128119___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128119___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028870_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028869_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028867_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028866_)))) 
           ^ (((IData)(wasmetal_core__DOT___128119___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128119___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128119___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028831_)))));
    vlSelf->wasmetal_core__DOT___044897_ = (1U & ((IData)(wasmetal_core__DOT___044911_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044910_)
                                                    ? 
                                                   ((1U 
                                                     & (8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcfac9f06__0)))
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044908_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044907_)
                                                       ? 
                                                      (~ (IData)(vlSelf->wasmetal_core__DOT___044906_))
                                                       : 
                                                      (~ (IData)(vlSelf->wasmetal_core__DOT___044907_)))
                                                      : 
                                                     (~ (IData)(vlSelf->wasmetal_core__DOT___044908_)))
                                                     : 
                                                    (4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hcfac9f06__0)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044910_)))
                                                   : 
                                                  (~ (IData)(wasmetal_core__DOT___044911_))));
    vlSelf->wasmetal_core__DOT___057372_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___057236_ = (1U & (0x3fafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff33330f0f5555ULL 
                                                                         >> 
                                                                         ((0x20U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                              << 5U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054929_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0ccccff00aaaaULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                               << 5U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O))))))))))))))));
    vlSelf->wasmetal_core__DOT___057670_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0ccaa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (0xfef0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O) 
                                                                                >> 2U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d))))))))))));
    vlSelf->wasmetal_core__DOT___128555___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033443_));
    vlSelf->wasmetal_core__DOT____Vcellout___127564___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003807_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003805_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023471_)))));
    vlSelf->wasmetal_core__DOT___023475_ = ((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127564___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127581___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013635_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013652_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h62ff3be8__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023592_)))));
    vlSelf->wasmetal_core__DOT___023596_ = ((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127581___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___029044_ = ((IData)(vlSelf->wasmetal_core__DOT___029078_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128137___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029078_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029077_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029075_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029074_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128137___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029039_)))));
    vlSelf->wasmetal_core__DOT___062990_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052578_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h19b7a9a0__0)))))));
    vlSelf->wasmetal_core__DOT___052917_ = (1U & (IData)(
                                                         (0xbfbfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h19b7a9a0__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052864_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1a7964bb__0))))))));
    vlSelf->wasmetal_core__DOT___052712_ = (1U & (0x7f7f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052700_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h19b7a9a0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050380_)))))));
    vlSelf->wasmetal_core__DOT___052711_ = (1U & (IData)(
                                                         (0x7f7f7f7f7f7f7fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052679_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052706_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052705_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050364_)))))))));
    vlSelf->wasmetal_core__DOT___071293_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071292_))));
    vlSelf->wasmetal_core__DOT___071288_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071287_))));
    wasmetal_core__DOT___127892___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026692_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026626_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d));
    vlSelf->wasmetal_core__DOT___054390_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127942___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054396_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127942___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054392_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127942___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054394_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127942___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    wasmetal_core__DOT___127943___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027162_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027096_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d));
    vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026494_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___054389_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127925___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054395_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127925___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054391_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127925___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054393_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127925___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026962_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026896_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d));
    vlSelf->wasmetal_core__DOT___054036_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054035_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054034_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054033_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x4100004100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054021_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b7__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004596_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b3__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004744_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b6__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004448_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x1001000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054019_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054018_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b23__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005164_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b22__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003348_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b21__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003416_))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054012_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054011_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054010_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xb00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054001_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054000_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053999_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b2__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004818_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003190_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b0__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x1001000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054006_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054005_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b13__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004226_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b12__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004152_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b10__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003484_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (6U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b15__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003706_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___052681_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045389_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045355_))));
    vlSelf->wasmetal_core__DOT___045862_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdb6fbe09__0)))))));
    vlSelf->wasmetal_core__DOT___045886_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003208_)))))))));
    vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h45ac64ad__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026761_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d));
    wasmetal_core__DOT___135442___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135442___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034482_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030246_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030181_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d));
    vlSelf->wasmetal_core__DOT___063291_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063288_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063287_)))))));
    vlSelf->wasmetal_core__DOT___063267_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063264_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063263_)))))));
    vlSelf->wasmetal_core__DOT___063273_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063270_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063269_)))))));
    vlSelf->wasmetal_core__DOT___063279_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063276_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063275_)))))));
    vlSelf->wasmetal_core__DOT___063285_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063282_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063281_)))))));
    vlSelf->wasmetal_core__DOT___044866_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4ddf67d8__0)))))))))));
    vlSelf->wasmetal_core__DOT___044890_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4ddf67d8__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127974___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d))))))));
    vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027360_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b34__05d));
    vlSelf->__VdfgTmp_he6ade5b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                    >> 3U)));
    vlSelf->__VdfgTmp_he6a1153d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_he5c4f457__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O)));
    vlSelf->wasmetal_core__DOT___023204_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022472_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O))))));
    vlSelf->wasmetal_core__DOT___023201_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022474_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___023200_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___022475_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                            >> 3U))))));
    __VdfgTmp_he5f9d86a__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022476_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022532_));
    vlSelf->wasmetal_core__DOT___043060_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017859_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017858_))));
    vlSelf->wasmetal_core__DOT___043054_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017887_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057865_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070582_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057877_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017858_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057876_)))))))));
    vlSelf->wasmetal_core__DOT___043063_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070585_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h103cd5d4__0))));
    vlSelf->wasmetal_core__DOT___043057_ = (1U & (IData)(
                                                         (0xffff40ff40ff4040ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017849_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h3ee80f1f__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057781_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017829_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___070585_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017828_)))))))));
    vlSelf->__VdfgTmp_hb36cd122__0 = ((2U & ((IData)(
                                                     (0xf8ffffff0700ULL 
                                                      >> 
                                                      ((0x20U 
                                                        & ((0xefU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6ef172e0__0)) 
                                                           << 5U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___057857_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014263_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057856_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013909_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___017848_)))))))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___017856_));
    vlSelf->wasmetal_core__DOT___043055_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xefU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8599270c__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057812_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070583_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xefU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h6ef172e0__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(wasmetal_core__DOT___017856_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057858_)))))))));
    vlSelf->wasmetal_core__DOT___043036_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___043040_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O))))))))));
    vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022698_)
            ? (IData)(vlSelf->wasmetal_core__DOT___022705_)
            : (IData)(vlSelf->wasmetal_core__DOT___022698_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d) {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127596___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023756_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023755_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023754_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023753_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023688_)))));
    vlSelf->wasmetal_core__DOT___023693_ = ((IData)(vlSelf->wasmetal_core__DOT___023756_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127596___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d));
    vlSelf->wasmetal_core__DOT___058722_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127630___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0))))));
    vlSelf->wasmetal_core__DOT___023760_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d))));
    vlSelf->wasmetal_core__DOT___058741_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127630___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0))))));
    vlSelf->wasmetal_core__DOT___023759_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d))));
    vlSelf->wasmetal_core__DOT___023758_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d))));
    vlSelf->wasmetal_core__DOT___058884_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h276f18a3__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d))))));
    vlSelf->wasmetal_core__DOT___058921_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0))))));
    vlSelf->wasmetal_core__DOT___058723_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058708_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058707_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058706_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127626___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h79e73f20__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127630___O) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT___023757_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc450b1a0__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___127452___O 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)
                 ? (IData)(vlSelf->wasmetal_core__DOT___022639_)
                 : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022639_)));
    vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                 | (IData)(vlSelf->wasmetal_core__DOT___036988_)));
    vlSelf->wasmetal_core__DOT___016473_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058528_))))));
    vlSelf->wasmetal_core__DOT___036393_ = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128860___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O)) 
                   << 3U)) | ((4U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                         >> 3U)) << 2U)) 
                              | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                            >> 2U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       >> 1U)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128860___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ 
                                                 ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                  >> 1U)) 
                                                << 1U))))));
    vlSelf->__VdfgTmp_h29bb7b8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                    >> 3U)));
    vlSelf->__VdfgTmp_h7b6ee7cc__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                    >> 2U)));
    wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127494___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127474___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022801_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022800_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022799_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022798_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022765_)))));
    vlSelf->wasmetal_core__DOT___022770_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022801_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___127474___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcc8c0380__0))));
    vlSelf->wasmetal_core__DOT___022805_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0))))));
    vlSelf->wasmetal_core__DOT___059179_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0ecf04e3__0))))));
    vlSelf->wasmetal_core__DOT___022804_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0))))));
    wasmetal_core__DOT___059184_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h3e9bda10__0))))));
    vlSelf->wasmetal_core__DOT___022803_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0))))));
    vlSelf->wasmetal_core__DOT___059182_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h36468d91__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d))))));
    vlSelf->wasmetal_core__DOT___059126_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127493___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h36468d91__0))))));
    vlSelf->wasmetal_core__DOT___022802_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h36468d91__0))))));
    vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034317_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034379_));
    vlSelf->wasmetal_core__DOT____Vcellout___128120___O 
        = ((1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___CO) 
                  >> 3U)) ^ ((0x3ffffffeU & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128083___CO) 
                                              >> 2U) 
                                             & ((IData)(vlSelf->wasmetal_core__DOT___028836_) 
                                                << 1U))) 
                             | (IData)(vlSelf->wasmetal_core__DOT___028836_)));
    vlSelf->__VdfgTmp_h57a1bcce__0 = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128898___Q) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___044897_));
    vlSelf->wasmetal_core__DOT___062970_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128896___Q) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044897_))));
    vlSelf->wasmetal_core__DOT___053592_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044897_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053429_))));
    vlSelf->wasmetal_core__DOT___053430_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044897_)))));
    wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128555___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___050098_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127564___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003811_))));
    vlSelf->wasmetal_core__DOT___050094_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127564___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003808_))));
    vlSelf->__VdfgTmp_h27384d82__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127564___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003807_));
    vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006400_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023475_));
    vlSelf->__VdfgTmp_hb00ae252__0 = (((IData)(vlSelf->wasmetal_core__DOT___013656_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127581___O) 
                                                    >> 1U)));
    vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__0__KET__ 
        = ((0xeU >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___023596_));
    vlSelf->wasmetal_core__DOT____Vcellout___128138___O 
        = ((1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___CO) 
                  >> 3U)) ^ ((0x3ffffffeU & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128128___CO) 
                                              >> 2U) 
                                             & ((IData)(wasmetal_core__DOT___029044_) 
                                                << 1U))) 
                             | (IData)(wasmetal_core__DOT___029044_)));
    vlSelf->wasmetal_core__DOT___071294_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071293_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___071289_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071288_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054178_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d)))))))));
    wasmetal_core__DOT___127892___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026693_)
            ? (IData)(wasmetal_core__DOT___127892___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d));
    vlSelf->wasmetal_core__DOT___070732_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054394_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1fU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d)))))));
    wasmetal_core__DOT___127943___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027163_)
            ? (IData)(wasmetal_core__DOT___127943___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d));
    vlSelf->wasmetal_core__DOT___127874___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___070835_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054393_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1fU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026963_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d));
    vlSelf->wasmetal_core__DOT___054187_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054036_))));
    vlSelf->wasmetal_core__DOT___053095_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052681_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052645_))));
    vlSelf->wasmetal_core__DOT___052683_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052681_))));
    vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hd87e5f33__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___135442___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___135442___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___135442___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___135442___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046632_)))));
    vlSelf->wasmetal_core__DOT___046636_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d)) 
                                            & (IData)(wasmetal_core__DOT___135442___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128671___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034483_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034482_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034481_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034480_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034536_)))));
    vlSelf->wasmetal_core__DOT___034540_ = ((IData)(vlSelf->wasmetal_core__DOT___034483_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030247_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0));
    wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127959___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027361_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027360_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027359_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027358_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027292_)))));
    vlSelf->wasmetal_core__DOT___027296_ = ((IData)(vlSelf->wasmetal_core__DOT___027361_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127959___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b35__05d));
    vlSelf->__VdfgTmp_h098b01ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_he5f9d86a__0)));
    vlSelf->__VdfgTmp_h1ea78a97__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_he5f9d86a__0)))));
    vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022477_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022699_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022699_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d) {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d;
        vlSelf->wasmetal_core__DOT___023895_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023895_ = vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023757_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023693_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d));
    vlSelf->wasmetal_core__DOT___006829_ = (1U & (0xbf000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___017895_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016296_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O))))));
    vlSelf->wasmetal_core__DOT___048705_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                  >> 1U) | (IData)(vlSelf->wasmetal_core__DOT___134186___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___051511_ = (1U & (IData)(
                                                         (0xb000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h29bb7b8d__0))))))));
    vlSelf->__VdfgTmp_h04da727f__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127452___O) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h29bb7b8d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127494___O 
        = ((4U | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)) 
                         << 1U)) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d))))) 
           ^ (((IData)(wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127494___DOT__CO__BRA__2__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127494___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022943_)))));
    vlSelf->wasmetal_core__DOT___059186_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059184_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059183_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4b2bd90e__0)))))))))));
    vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022802_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022770_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h36468d91__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127486___O 
        = (((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)) 
                   << 2U)) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d)) 
                                     << 1U)) | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)
                 ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d)
                 : (IData)(wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127486___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127486___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022880_)))));
    vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034318_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___019791_ = (1U & (IData)(
                                                         (0xf3a2a2a200000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052688_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052999_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053592_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048483_)))))))));
    vlSelf->wasmetal_core__DOT___019788_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053429_))));
    vlSelf->wasmetal_core__DOT___019790_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053428_))));
    vlSelf->wasmetal_core__DOT___039572_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051570_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b96__05d)))))));
    vlSelf->wasmetal_core__DOT___039632_ = (1U & (0xaea2aeaeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051572_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051568_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill)))))));
    vlSelf->wasmetal_core__DOT___039755_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039629_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039633_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039634_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039635_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039636_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039637_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039638_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039639_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039640_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039663_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039652_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___039651_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039650_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039649_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___040059_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___039641_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039648_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039646_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039645_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___039644_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039643_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039653_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039654_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___039655_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039668_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039662_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039670_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT___039672_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039664_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___040056_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039656_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___039642_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT___039683_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b33__05d)))))));
    vlSelf->wasmetal_core__DOT___039671_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___039669_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000724_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b35__05d)))))));
    vlSelf->wasmetal_core__DOT___039661_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT___039657_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___039667_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b38__05d)))))));
    vlSelf->wasmetal_core__DOT___039659_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b39__05d)))))));
    vlSelf->wasmetal_core__DOT___039666_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___039660_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b41__05d)))))));
    vlSelf->wasmetal_core__DOT___039673_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000796_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b42__05d)))))));
    vlSelf->wasmetal_core__DOT___039674_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___039675_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b44__05d)))))));
    vlSelf->wasmetal_core__DOT___039689_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b45__05d)))))));
    vlSelf->wasmetal_core__DOT___039682_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___039691_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b47__05d)))))));
    vlSelf->wasmetal_core__DOT___039698_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b48__05d)))))));
    vlSelf->wasmetal_core__DOT___039684_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT___040055_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b50__05d)))))));
    vlSelf->wasmetal_core__DOT___039676_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000927_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT___039665_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000926_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___039681_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b53__05d)))))));
    vlSelf->wasmetal_core__DOT___039692_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000993_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b54__05d)))))));
    vlSelf->wasmetal_core__DOT___039690_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b55__05d)))))));
    vlSelf->wasmetal_core__DOT___039685_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001037_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b56__05d)))))));
    vlSelf->wasmetal_core__DOT___039688_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b57__05d)))))));
    vlSelf->wasmetal_core__DOT___039677_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b58__05d)))))));
    vlSelf->wasmetal_core__DOT___039687_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b59__05d)))))));
    vlSelf->wasmetal_core__DOT___039679_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b60__05d)))))));
    vlSelf->wasmetal_core__DOT___039686_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___039693_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b62__05d)))))));
    vlSelf->wasmetal_core__DOT___039694_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___039695_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003150_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b64__05d)))))));
    vlSelf->wasmetal_core__DOT___039696_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003233_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b65__05d)))))));
    vlSelf->wasmetal_core__DOT___039697_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004783_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b66__05d)))))));
    vlSelf->wasmetal_core__DOT___039678_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004709_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b67__05d)))))));
    vlSelf->wasmetal_core__DOT___039680_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004487_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b68__05d)))))));
    vlSelf->wasmetal_core__DOT___039700_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004339_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b69__05d)))))));
    vlSelf->wasmetal_core__DOT___039701_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004413_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b70__05d)))))));
    vlSelf->wasmetal_core__DOT___039702_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004561_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b71__05d)))))));
    vlSelf->wasmetal_core__DOT___039703_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003745_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b72__05d)))))));
    vlSelf->wasmetal_core__DOT___039704_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003597_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b73__05d)))))));
    vlSelf->wasmetal_core__DOT___039705_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003449_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b74__05d)))))));
    vlSelf->wasmetal_core__DOT___039706_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003523_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b75__05d)))))));
    vlSelf->wasmetal_core__DOT___039707_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004117_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b76__05d)))))));
    vlSelf->wasmetal_core__DOT___039727_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004191_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b77__05d)))))));
    vlSelf->wasmetal_core__DOT___039719_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004635_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b78__05d)))))));
    vlSelf->wasmetal_core__DOT___039718_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003671_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b79__05d)))))));
    vlSelf->wasmetal_core__DOT___039717_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003969_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b80__05d)))))));
    vlSelf->wasmetal_core__DOT___039716_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004265_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b81__05d)))))));
    vlSelf->wasmetal_core__DOT___039699_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004043_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b82__05d)))))));
    vlSelf->wasmetal_core__DOT___039708_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003827_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b83__05d)))))));
    vlSelf->wasmetal_core__DOT___039715_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003919_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b84__05d)))))));
    vlSelf->wasmetal_core__DOT___039713_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003399_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b85__05d)))))));
    vlSelf->wasmetal_core__DOT___039712_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003331_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b86__05d)))))));
    vlSelf->wasmetal_core__DOT___039711_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005147_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b87__05d)))))));
    vlSelf->wasmetal_core__DOT___039710_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005079_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b88__05d)))))));
    vlSelf->wasmetal_core__DOT___039720_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005351_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b89__05d)))))));
    vlSelf->wasmetal_core__DOT___039742_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004943_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b90__05d)))))));
    vlSelf->wasmetal_core__DOT___039731_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005011_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b91__05d)))))));
    vlSelf->wasmetal_core__DOT___039730_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004875_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b92__05d)))))));
    vlSelf->wasmetal_core__DOT___039728_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b93__05d)))))));
    vlSelf->wasmetal_core__DOT___040050_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005215_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b94__05d)))))));
    vlSelf->wasmetal_core__DOT___039721_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005599_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b95__05d)))))));
    vlSelf->wasmetal_core__DOT___039709_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b96__05d)))))));
    vlSelf->wasmetal_core__DOT___039725_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b97__05d)))))));
    vlSelf->wasmetal_core__DOT___039729_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b98__05d)))))));
    vlSelf->wasmetal_core__DOT___039724_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004727_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b99__05d)))))));
    vlSelf->wasmetal_core__DOT___039723_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003097_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b100__05d)))))));
    vlSelf->wasmetal_core__DOT___039732_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b101__05d)))))));
    vlSelf->wasmetal_core__DOT___039733_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b102__05d)))))));
    vlSelf->wasmetal_core__DOT___039734_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b103__05d)))))));
    vlSelf->wasmetal_core__DOT___039752_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003109_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b104__05d)))))));
    vlSelf->wasmetal_core__DOT___039746_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b105__05d)))))));
    vlSelf->wasmetal_core__DOT___039745_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003105_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b106__05d)))))));
    vlSelf->wasmetal_core__DOT___039744_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b107__05d)))))));
    vlSelf->wasmetal_core__DOT___039743_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b108__05d)))))));
    vlSelf->wasmetal_core__DOT___039726_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b109__05d)))))));
    vlSelf->wasmetal_core__DOT___039735_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b110__05d)))))));
    vlSelf->wasmetal_core__DOT___039722_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003689_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b111__05d)))))));
    vlSelf->wasmetal_core__DOT___039740_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b112__05d)))))));
    vlSelf->wasmetal_core__DOT___039739_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b113__05d)))))));
    vlSelf->wasmetal_core__DOT___039738_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004061_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b114__05d)))))));
    vlSelf->wasmetal_core__DOT___039737_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003845_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b115__05d)))))));
    vlSelf->wasmetal_core__DOT___039747_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b116__05d)))))));
    vlSelf->wasmetal_core__DOT___039748_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b117__05d)))))));
    vlSelf->wasmetal_core__DOT___039749_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b118__05d)))))));
    vlSelf->wasmetal_core__DOT___039759_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005129_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b119__05d)))))));
    vlSelf->wasmetal_core__DOT___039757_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005061_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b120__05d)))))));
    vlSelf->wasmetal_core__DOT___039756_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005333_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b121__05d)))))));
    vlSelf->wasmetal_core__DOT___039754_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004925_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b122__05d)))))));
    vlSelf->wasmetal_core__DOT___039753_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004993_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b123__05d)))))));
    vlSelf->wasmetal_core__DOT___040047_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004857_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b124__05d)))))));
    vlSelf->wasmetal_core__DOT___039750_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005265_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b125__05d)))))));
    vlSelf->wasmetal_core__DOT___039736_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005197_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b126__05d)))))));
    vlSelf->wasmetal_core__DOT___039751_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005581_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b127__05d)))))));
    vlSelf->wasmetal_core__DOT___040104_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053923_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x1cU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___039592_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053924_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039564_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053925_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039571_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053926_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039569_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053927_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & vlSelf->insn_y) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039568_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053928_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039567_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053929_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039566_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053930_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039573_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053931_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039574_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053932_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 5U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___039591_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053933_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 6U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039585_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053934_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 7U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039584_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053935_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 8U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039583_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053936_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 9U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039582_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053937_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039570_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053938_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xbU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039575_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053939_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xcU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039565_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053940_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039580_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053941_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xeU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039579_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053942_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xfU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039578_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053943_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x10U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039577_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053944_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x11U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039586_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053945_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x12U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039587_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053946_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039588_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053947_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x14U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039597_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053948_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x15U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039595_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053949_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039594_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053950_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x17U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039593_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053951_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x18U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039576_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053952_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x19U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039581_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053953_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039589_ = (1U & (IData)(
                                                         (0xaea2aea2a2a2aeaeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053954_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x1bU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039627_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128482___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039601_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128482___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039600_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128482___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039599_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128482___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___039603_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128483___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039604_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128483___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039619_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128483___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039615_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128483___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___039614_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128484___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___039613_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128484___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___039612_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128484___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___039602_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128484___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___039605_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128485___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___039598_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128485___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___039610_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128485___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___039609_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128485___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___039608_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128486___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___039607_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128486___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___039616_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128486___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___039620_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128486___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___039611_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128487___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___039617_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128487___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___039606_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128487___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___039618_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128487___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___039621_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128488___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___039622_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128488___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___039623_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128488___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___039624_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128488___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___039625_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128489___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___039626_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128489___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___039630_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128489___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___039628_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053428_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128489___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053430_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b31__05d)))))))));
    wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d)) 
           & (IData)(wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006204_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013705_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___045028_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071294_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___045004_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071294_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054186_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054189_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071292_))))));
    vlSelf->wasmetal_core__DOT___045027_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071289_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___045003_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071289_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054174_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                   << 1U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054178_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071287_))))));
    wasmetal_core__DOT___127892___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026694_)
            ? (IData)(wasmetal_core__DOT___127892___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d));
    vlSelf->wasmetal_core__DOT___070734_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054392_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070732_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1eU)))))))))));
    vlSelf->wasmetal_core__DOT___070733_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070732_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054392_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1eU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT___127943___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027164_)
            ? (IData)(wasmetal_core__DOT___127943___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127874___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026495_) 
             & (IData)(vlSelf->wasmetal_core__DOT___127874___DOT__CO__BRA__2__KET__)) 
            << 3U) | (IData)(vlSelf->wasmetal_core__DOT___127874___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127874___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026495_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026494_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026493_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026492_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127874___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026520_)));
    vlSelf->wasmetal_core__DOT___070837_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054391_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070835_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1eU)))))))))));
    vlSelf->wasmetal_core__DOT___070836_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070835_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054391_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1eU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026964_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127926___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d));
    vlSelf->wasmetal_core__DOT___053103_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053098_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053097_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053096_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053095_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h461b3fd9__0))))))));
    vlSelf->wasmetal_core__DOT___052689_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052684_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052683_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h461b3fd9__0)))));
    vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h218f194f__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127909___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d));
    vlSelf->wasmetal_core__DOT___030253_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135442___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d))))));
    vlSelf->wasmetal_core__DOT___030252_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135442___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d))))));
    vlSelf->wasmetal_core__DOT___030251_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135442___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d))))));
    vlSelf->wasmetal_core__DOT___030250_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135442___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d))))));
    vlSelf->wasmetal_core__DOT___135428___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___046636_));
    vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034484_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034540_));
    vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030248_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128253___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127975___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
           ^ (((IData)(wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127975___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027422_)))));
    vlSelf->wasmetal_core__DOT___027427_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127958___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127975___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063294_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128368___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128456___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063296_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128368___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128456___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063298_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127959___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128368___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128456___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___127960___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027362_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027296_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b36__05d));
    vlSelf->wasmetal_core__DOT___023203_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                   ? (IData)(
                                                             (0xf0c0f0d1f0c05555ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h1ea78a97__0)))
                                                   : 
                                                  (0xfcfdU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h098b01ee__0))));
    vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022478_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127442___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022700_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127460___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___022700_));
    vlSelf->wasmetal_core__DOT____Vcellout___127631___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024017_)))));
    vlSelf->wasmetal_core__DOT___024022_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___127631___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023758_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127597___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127615___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127615___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023890_)))));
    vlSelf->wasmetal_core__DOT___058425_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016297_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006829_))));
    vlSelf->wasmetal_core__DOT___016219_ = (1U & (IData)(
                                                         (0xa0a0f0f00cc00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006930_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006933_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006944_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006931_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___006940_)))))))));
    if (vlSelf->wasmetal_core__DOT___006829_) {
        if (vlSelf->wasmetal_core__DOT___006900_) {
            vlSelf->wasmetal_core__DOT___016190_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006932_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hb02141c6__0))));
            vlSelf->wasmetal_core__DOT___016191_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006918_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006916_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006917_)))));
            vlSelf->wasmetal_core__DOT___006889_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006919_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006915_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006914_)))));
            vlSelf->wasmetal_core__DOT___016192_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006898_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006896_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006897_)))));
            vlSelf->wasmetal_core__DOT___006890_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006899_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006895_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___006894_)))));
        } else {
            vlSelf->wasmetal_core__DOT___016190_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006932_)));
            vlSelf->wasmetal_core__DOT___016191_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006918_)));
            vlSelf->wasmetal_core__DOT___006889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006919_)));
            vlSelf->wasmetal_core__DOT___016192_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006898_)));
            vlSelf->wasmetal_core__DOT___006890_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006899_)));
        }
        vlSelf->wasmetal_core__DOT___006888_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006933_)) 
                                                   & (0xdU 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha11b0f77__0))));
    } else {
        if (vlSelf->wasmetal_core__DOT___006900_) {
            vlSelf->wasmetal_core__DOT___016190_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006919_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hf64b2678__0))));
            vlSelf->wasmetal_core__DOT___016191_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___016206_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h63494727__0))));
            vlSelf->wasmetal_core__DOT___006889_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006918_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h4068d69c__0))));
            vlSelf->wasmetal_core__DOT___016192_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___016197_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h42a31070__0))));
            vlSelf->wasmetal_core__DOT___006890_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___006898_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h3bcc9f30__0))));
        } else {
            vlSelf->wasmetal_core__DOT___016190_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006919_)));
            vlSelf->wasmetal_core__DOT___016191_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___016206_)));
            vlSelf->wasmetal_core__DOT___006889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006918_)));
            vlSelf->wasmetal_core__DOT___016192_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___016197_)));
            vlSelf->wasmetal_core__DOT___006890_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___006898_)));
        }
        vlSelf->wasmetal_core__DOT___006888_ = (1U 
                                                & (0xefU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006932_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hb02141c6__0)))));
    }
    vlSelf->wasmetal_core__DOT___016188_ = (1U & (0xff10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8599270c__0))));
    vlSelf->wasmetal_core__DOT___006887_ = (1U & (0xff100000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6ef172e0__0))));
    vlSelf->wasmetal_core__DOT___058424_ = ((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)
                                                ? (0xf05cc00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he163c644__0))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___003811_))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___016256_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (0xf05cc00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h690a20a1__0))));
        vlSelf->wasmetal_core__DOT___016232_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (0xf05cc00U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he163c644__0))));
        vlSelf->wasmetal_core__DOT___016376_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (0xf053300U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9c807cdf__0))));
    } else {
        vlSelf->wasmetal_core__DOT___016256_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___003806_))));
        vlSelf->wasmetal_core__DOT___016232_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___003811_))));
        vlSelf->wasmetal_core__DOT___016376_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___006829_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    }
    vlSelf->wasmetal_core__DOT___016233_ = (1U & (0xff100000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedae78d9__0))));
    vlSelf->wasmetal_core__DOT___016257_ = ((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)
                                                ? (0xf053300U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h9c807cdf__0))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    vlSelf->wasmetal_core__DOT___016375_ = ((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn)
                                                ? (0xf05cc00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h690a20a1__0))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___003806_))));
    vlSelf->__VdfgTmp_h934029c5__0 = (((IData)(vlSelf->wasmetal_core__DOT___006829_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006900_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006622_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051557_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_haa0d8025__0)))));
    vlSelf->wasmetal_core__DOT___048950_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005663_))));
    vlSelf->wasmetal_core__DOT___017896_ = (1U & (0xf0d5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048705_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7b6ee7cc__0)))));
    vlSelf->wasmetal_core__DOT___006821_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051510_))));
    vlSelf->wasmetal_core__DOT___058470_ = (1U & (0x1000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051510_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x4fU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)))))))));
    vlSelf->__VdfgTmp_h363b6dc6__0 = ((4U & ((0x4fU 
                                              >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h96af251d__0));
    vlSelf->wasmetal_core__DOT___016377_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x4fU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))))));
    vlSelf->wasmetal_core__DOT___006819_ = (1U & (0xb000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127451___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04da727f__0))));
    vlSelf->wasmetal_core__DOT___006820_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (0x4fU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h04da727f__0))))));
    vlSelf->wasmetal_core__DOT___006818_ = (1U & (0xb000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04da727f__0))));
    vlSelf->wasmetal_core__DOT___006891_ = (1U & (0xb000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h04da727f__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127634___O 
        = ((6U | (1U & (0x4fU >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)))) 
           ^ (0xeU & ((- (IData)((1U & (~ (0x4fU >> (IData)(vlSelf->__VdfgTmp_h04da727f__0)))))) 
                      << 1U)));
    vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022803_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127475___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h601f88f8__0))));
    vlSelf->__VdfgTmp_h7695852b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127486___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006215_));
    vlSelf->__VdfgTmp_h5f0989ee__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127486___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006144_));
    vlSelf->__VdfgTmp_hd540c232__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127486___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034319_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128555___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128555___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128555___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033443_)))));
    vlSelf->wasmetal_core__DOT___033447_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)) 
                                            & (IData)(wasmetal_core__DOT___128555___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003810_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127565___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013692_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127582___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127892___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026695_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026694_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026693_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026692_)))) 
           ^ (((IData)(wasmetal_core__DOT___127892___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127892___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127892___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026626_)))));
    vlSelf->wasmetal_core__DOT___026630_ = ((IData)(vlSelf->wasmetal_core__DOT___026695_)
                                             ? (IData)(wasmetal_core__DOT___127892___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d));
    vlSelf->wasmetal_core__DOT___045232_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070733_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1dU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___045208_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070734_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054394_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1fU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054390_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070733_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1dU))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127943___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027165_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027164_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027163_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027162_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127943___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127943___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127943___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027096_)))));
}
