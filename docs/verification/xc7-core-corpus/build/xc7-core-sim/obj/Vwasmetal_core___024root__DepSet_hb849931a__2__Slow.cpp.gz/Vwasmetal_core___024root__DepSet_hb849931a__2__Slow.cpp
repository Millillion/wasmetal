#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__1(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__1\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___000197_;
    wasmetal_core__DOT___000197_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___000198_;
    wasmetal_core__DOT___000198_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___000199_;
    wasmetal_core__DOT___000199_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___000207_;
    wasmetal_core__DOT___000207_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___000242_;
    wasmetal_core__DOT___000242_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___000246_;
    wasmetal_core__DOT___000246_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___000290_;
    wasmetal_core__DOT___000290_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___000294_;
    wasmetal_core__DOT___000294_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___000298_;
    wasmetal_core__DOT___000298_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___000333_;
    wasmetal_core__DOT___000333_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___000337_;
    wasmetal_core__DOT___000337_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043972_;
    wasmetal_core__DOT___043972_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043973_;
    wasmetal_core__DOT___043973_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043978_;
    wasmetal_core__DOT___043978_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043986_;
    wasmetal_core__DOT___043986_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043987_;
    wasmetal_core__DOT___043987_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043992_;
    wasmetal_core__DOT___043992_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044000_;
    wasmetal_core__DOT___044000_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044001_;
    wasmetal_core__DOT___044001_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044006_;
    wasmetal_core__DOT___044006_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044014_;
    wasmetal_core__DOT___044014_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044015_;
    wasmetal_core__DOT___044015_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044020_;
    wasmetal_core__DOT___044020_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044659_;
    wasmetal_core__DOT___044659_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048299_;
    wasmetal_core__DOT___048299_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048572_;
    wasmetal_core__DOT___048572_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049444_;
    wasmetal_core__DOT___049444_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049584_;
    wasmetal_core__DOT___049584_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049591_;
    wasmetal_core__DOT___049591_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049596_;
    wasmetal_core__DOT___049596_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049678_;
    wasmetal_core__DOT___049678_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___049727_;
    wasmetal_core__DOT___049727_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052958_;
    wasmetal_core__DOT___052958_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052968_;
    wasmetal_core__DOT___052968_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052976_;
    wasmetal_core__DOT___052976_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052982_;
    wasmetal_core__DOT___052982_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052983_;
    wasmetal_core__DOT___052983_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053398_;
    wasmetal_core__DOT___053398_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053399_;
    wasmetal_core__DOT___053399_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053400_;
    wasmetal_core__DOT___053400_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053401_;
    wasmetal_core__DOT___053401_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053402_;
    wasmetal_core__DOT___053402_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070928_;
    wasmetal_core__DOT___070928_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070929_;
    wasmetal_core__DOT___070929_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070930_;
    wasmetal_core__DOT___070930_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070931_;
    wasmetal_core__DOT___070931_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070932_;
    wasmetal_core__DOT___070932_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071477_;
    wasmetal_core__DOT___071477_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128026___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128026___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128266___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128266___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128793___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128793___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h225c4799__0;
    __VdfgTmp_h225c4799__0 = 0;
    CData/*1:0*/ __VdfgTmp_hcd919103__0;
    __VdfgTmp_hcd919103__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___032676_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d))));
    vlSelf->wasmetal_core__DOT___035119_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b40__05d))));
    vlSelf->__VdfgTmp_h0817f177__0 = ((2U & (vlSelf->function_params 
                                             >> 0x13U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x14U)));
    vlSelf->wasmetal_core__DOT___035118_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b39__05d))));
    vlSelf->wasmetal_core__DOT___032675_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d))));
    vlSelf->wasmetal_core__DOT___035116_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b38__05d))));
    vlSelf->wasmetal_core__DOT___032705_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d))));
    vlSelf->wasmetal_core__DOT___035115_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b37__05d))));
    vlSelf->__VdfgTmp_h1274aae9__0 = ((2U & (vlSelf->function_params 
                                             >> 0x12U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x13U)));
    vlSelf->wasmetal_core__DOT___035114_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b36__05d))));
    vlSelf->wasmetal_core__DOT___032704_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d))));
    vlSelf->wasmetal_core__DOT___071532_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___035113_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b35__05d))));
    vlSelf->wasmetal_core__DOT___032703_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d))));
    vlSelf->wasmetal_core__DOT___035112_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b34__05d))));
    vlSelf->__VdfgTmp_h148285ae__0 = ((2U & (vlSelf->function_params 
                                             >> 0x11U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x12U)));
    vlSelf->__VdfgTmp_h835050f4__0 = (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b0__05d));
    vlSelf->wasmetal_core__DOT___032702_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d))));
    vlSelf->wasmetal_core__DOT___035111_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b33__05d))));
    vlSelf->__VdfgTmp_h49b76e08__0 = (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b2__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b3__05d));
    vlSelf->wasmetal_core__DOT___035110_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b33__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b32__05d))));
    vlSelf->wasmetal_core__DOT___032701_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d))));
    vlSelf->wasmetal_core__DOT___064085_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b20__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b21__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b23__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b22__05d))))));
    vlSelf->__VdfgTmp_h0dd4dc97__0 = ((2U & (vlSelf->function_params 
                                             >> 0x10U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x11U)));
    vlSelf->wasmetal_core__DOT___035109_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b31__05d))));
    vlSelf->wasmetal_core__DOT___065552_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b6__05d))));
    vlSelf->wasmetal_core__DOT___032700_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d))));
    vlSelf->wasmetal_core__DOT___026286_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b3__05d))));
    vlSelf->wasmetal_core__DOT___035108_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b30__05d))));
    vlSelf->wasmetal_core__DOT___032699_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d))));
    vlSelf->wasmetal_core__DOT___063361_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__bulk_table))));
    vlSelf->wasmetal_core__DOT___035107_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b29__05d))));
    vlSelf->__VdfgTmp_h5f5f5b59__0 = ((2U & (vlSelf->function_params 
                                             >> 0xfU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x10U)));
    vlSelf->wasmetal_core__DOT___032696_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d))));
    vlSelf->wasmetal_core__DOT___026190_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d))));
    vlSelf->wasmetal_core__DOT___035105_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b28__05d))));
    vlSelf->wasmetal_core__DOT___032685_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->function_params) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d))));
    vlSelf->wasmetal_core__DOT___035104_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b27__05d))));
    vlSelf->wasmetal_core__DOT___032674_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d))));
    vlSelf->__VdfgTmp_h54e5e4c4__0 = ((2U & (vlSelf->function_params 
                                             >> 0xeU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0xfU)));
    vlSelf->wasmetal_core__DOT___035103_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b26__05d))));
    vlSelf->wasmetal_core__DOT___063360_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__bulk_table))));
    vlSelf->wasmetal_core__DOT___035102_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b25__05d))));
    vlSelf->__VdfgTmp_h558b9029__0 = ((2U & (vlSelf->function_params 
                                             >> 0xdU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0xeU)));
    vlSelf->wasmetal_core__DOT___035101_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b24__05d))));
    vlSelf->wasmetal_core__DOT___064083_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b24__05d))));
    vlSelf->wasmetal_core__DOT___064084_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b26__05d))));
    vlSelf->wasmetal_core__DOT___035100_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b23__05d))));
    vlSelf->wasmetal_core__DOT___064089_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b8__05d))));
    vlSelf->wasmetal_core__DOT___064090_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b10__05d))));
    vlSelf->wasmetal_core__DOT___026382_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 3U)))));
    vlSelf->__VdfgTmp_h629179e3__0 = ((2U & (vlSelf->function_params 
                                             >> 0xcU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0xdU)));
    vlSelf->wasmetal_core__DOT___035099_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b22__05d))));
    vlSelf->wasmetal_core__DOT___063357_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_unit__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__bulk_table))));
    vlSelf->wasmetal_core__DOT___035098_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b21__05d))));
    wasmetal_core__DOT___071477_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d))));
    vlSelf->__VdfgTmp_h638a3747__0 = ((2U & (vlSelf->function_params 
                                             >> 0xbU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0xcU)));
    vlSelf->wasmetal_core__DOT___035097_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b20__05d))));
    vlSelf->wasmetal_core__DOT___035096_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b19__05d))));
    vlSelf->__VdfgTmp_h68654253__0 = ((2U & (vlSelf->function_params 
                                             >> 0xaU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0xbU)));
    vlSelf->wasmetal_core__DOT___035094_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b18__05d))));
    vlSelf->__VdfgTmp_h6978beee__0 = ((2U & (vlSelf->function_params 
                                             >> 9U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0xaU)));
    vlSelf->wasmetal_core__DOT___035093_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b17__05d))));
    vlSelf->wasmetal_core__DOT___035092_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b16__05d))));
    vlSelf->__VdfgTmp_h14007945__0 = ((2U & (vlSelf->function_params 
                                             >> 8U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 9U)));
    vlSelf->wasmetal_core__DOT___035091_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b15__05d))));
    vlSelf->__VdfgTmp_h13ef8f89__0 = ((2U & (vlSelf->function_params 
                                             >> 7U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 8U)));
    vlSelf->wasmetal_core__DOT___035090_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b14__05d))));
    vlSelf->wasmetal_core__DOT___035089_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b13__05d))));
    vlSelf->__VdfgTmp_h0e12a4a2__0 = ((2U & (vlSelf->function_params 
                                             >> 6U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 7U)));
    vlSelf->wasmetal_core__DOT___035088_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b12__05d))));
    vlSelf->__VdfgTmp_h0d1b5516__0 = ((2U & (vlSelf->function_params 
                                             >> 5U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 6U)));
    vlSelf->wasmetal_core__DOT___035087_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b11__05d))));
    vlSelf->wasmetal_core__DOT___035086_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b10__05d))));
    vlSelf->__VdfgTmp_h5afc8767__0 = ((2U & (vlSelf->function_params 
                                             >> 4U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 5U)));
    vlSelf->wasmetal_core__DOT___035085_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b9__05d))));
    vlSelf->__VdfgTmp_h5b0f43f4__0 = ((2U & (vlSelf->function_params 
                                             >> 3U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 4U)));
    vlSelf->wasmetal_core__DOT___026283_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b2__05d))));
    vlSelf->wasmetal_core__DOT___035147_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b8__05d))));
    vlSelf->wasmetal_core__DOT___035146_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b7__05d))));
    vlSelf->wasmetal_core__DOT___026187_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d))));
    vlSelf->__VdfgTmp_h60140cd4__0 = ((2U & (vlSelf->function_params 
                                             >> 2U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 3U)));
    vlSelf->wasmetal_core__DOT___019355_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d))));
    vlSelf->wasmetal_core__DOT___035145_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b6__05d))));
    vlSelf->__VdfgTmp_h61cb7e30__0 = ((2U & (vlSelf->function_params 
                                             >> 1U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 2U)));
    vlSelf->wasmetal_core__DOT___035144_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b5__05d))));
    vlSelf->__VdfgTmp_h2cd56cce__0 = ((2U & vlSelf->function_params) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___035139_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b4__05d))));
    vlSelf->wasmetal_core__DOT___026379_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___035128_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b3__05d))));
    vlSelf->wasmetal_core__DOT___035117_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b2__05d))));
    vlSelf->wasmetal_core__DOT___035106_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b1__05d))));
    vlSelf->wasmetal_core__DOT___035084_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b63__05d))));
    vlSelf->wasmetal_core__DOT___026272_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b1__05d))));
    vlSelf->__VdfgTmp_hff2c11ba__0 = (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b0__05d));
    vlSelf->wasmetal_core__DOT___026176_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d))));
    vlSelf->wasmetal_core__DOT___026368_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 1U)))));
    vlSelf->__VdfgTmp_h1a8ff62f__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xdU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0xeU)));
    vlSelf->__VdfgTmp_h19a3d105__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xeU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0xfU)));
    vlSelf->__VdfgTmp_h134dac5a__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xfU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x10U)));
    vlSelf->__VdfgTmp_h3c4e434c__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x11U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x12U)));
    vlSelf->__VdfgTmp_h3d708201__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x12U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x13U)));
    vlSelf->__VdfgTmp_h2660b6cc__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x13U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x14U)));
    vlSelf->__VdfgTmp_h273da3c5__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x14U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x15U)));
    vlSelf->__VdfgTmp_he4692376__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x17U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x18U)));
    vlSelf->__VdfgTmp_h3a2be217__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x19U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x1aU)));
    vlSelf->__VdfgTmp_h26a9e557__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1eU)) 
                                      | (vlSelf->insn_y 
                                         >> 0x1fU));
    vlSelf->__VdfgTmp_h16f85c0c__0 = ((2U & (vlSelf->insn_x 
                                             >> 9U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0xaU)));
    vlSelf->__VdfgTmp_hedbed4ea__0 = ((2U & (vlSelf->insn_x 
                                             >> 7U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 8U)));
    vlSelf->__VdfgTmp_he08305af__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x15U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x16U)));
    vlSelf->__VdfgTmp_h272aca04__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1cU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x1dU)));
    vlSelf->__VdfgTmp_heb8306fa__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x18U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x19U)));
    vlSelf->__VdfgTmp_h265c757d__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1dU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x1eU)));
    vlSelf->__VdfgTmp_he580b887__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x16U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x17U)));
    vlSelf->__VdfgTmp_he366744c__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x10U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x11U)));
    vlSelf->__VdfgTmp_he16c95bc__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1aU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x1bU)));
    vlSelf->__VdfgTmp_he081d797__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1bU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0x1cU)));
    vlSelf->__VdfgTmp_heb713746__0 = ((2U & (vlSelf->insn_x 
                                             >> 8U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 9U)));
    vlSelf->__VdfgTmp_h10bdd4bc__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xbU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0xcU)));
    vlSelf->__VdfgTmp_h1fc2f2ef__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xcU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0xdU)));
    vlSelf->__VdfgTmp_h1585cf87__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xaU)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 0xbU)));
    vlSelf->__VdfgTmp_h94eb0193__0 = ((2U & (vlSelf->insn_y 
                                             >> 0x12U)) 
                                      | (1U & (vlSelf->insn_x 
                                               >> 0x13U)));
    vlSelf->wasmetal_core__DOT___026261_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_source__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d))));
    vlSelf->wasmetal_core__DOT___026165_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d))));
    vlSelf->wasmetal_core__DOT___026357_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & vlSelf->insn_x))));
    vlSelf->__VdfgTmp_ha330fec4__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d));
    vlSelf->wasmetal_core__DOT___044145_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b21__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b17__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___044144_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b14__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___044149_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b45__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b44__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___044148_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b39__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b38__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b37__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b34__05d)))))))));
    vlSelf->wasmetal_core__DOT___044142_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b63__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b62__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b61__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b60__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b59__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b58__05d)))))))));
    vlSelf->wasmetal_core__DOT___044150_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b50__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b49__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b48__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b47__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b46__05d)))))))));
    vlSelf->__VdfgTmp_hba5a1633__0 = (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b32__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp___128343___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b31__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b30__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b29__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b28__05d))));
    vlSelf->wasmetal_core__DOT___053337_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b26__05d))));
    vlSelf->__VdfgTmp_h347304aa__0 = (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b23__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b22__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp___128334___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b55__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b54__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b53__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b52__05d))));
    vlSelf->wasmetal_core__DOT___128498___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___044131_ = (1U & (0xfffffffeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b9__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b8__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b7__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b6__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___070934_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___070921_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b18__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b20__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b20__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b16__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b16__05d))))))))))));
    vlSelf->wasmetal_core__DOT___070924_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b29__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b25__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b23__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b23__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b22__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b22__05d))))))))))));
    wasmetal_core__DOT___070931_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b0__05d))));
    wasmetal_core__DOT___070932_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b4__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b4__05d))));
    wasmetal_core__DOT___070929_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b24__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b24__05d))));
    wasmetal_core__DOT___070930_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b26__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b26__05d))));
    wasmetal_core__DOT___070928_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b15__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b15__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b14__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b14__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b11__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___128509___DOT____VdfgTmp_h9d2c3928__0 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d)) 
                 & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___128534___DOT____VdfgTmp_h9d2c3928__0 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b1__05d)) 
                 & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->__VdfgTmp_hc1ba27eb__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d));
    __VdfgTmp_hcd919103__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d));
    vlSelf->__VdfgTmp_ha01e8f2f__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d));
    vlSelf->__VdfgTmp_h8cb32961__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d));
    vlSelf->wasmetal_core__DOT___054679_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_x 
                                                       >> 7U)) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 5U)))));
    vlSelf->wasmetal_core__DOT___043130_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 2U))) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & vlSelf->insn_op))));
    vlSelf->wasmetal_core__DOT___048500_ = (1U & (0x1000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(
                                                               (1ULL 
                                                                >> 
                                                                (0x3fU 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0x14U)))) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> 
                                                           (7U 
                                                            & (vlSelf->insn_x 
                                                               >> 9U))) 
                                                          << 3U)) 
                                                      | ((6U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x11U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_x 
                                                               >> 8U)))))));
    vlSelf->wasmetal_core__DOT___048499_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_x 
                                                            >> 6U))) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (vlSelf->insn_x 
                                                         >> 4U)))));
    vlSelf->wasmetal_core__DOT____VdfgTmp_hc50f84f8__0 
        = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
            << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    if (vlSelf->wasmetal_core__DOT__sp__05b1__05d) {
        vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b0__05d;
        wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b1__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b1__05d;
        wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b0__05d;
    }
    vlSelf->wasmetal_core__DOT___048426_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (1ULL 
                                                                        >> 
                                                                        (0x3fU 
                                                                         & (vlSelf->insn_y 
                                                                            >> 0xeU)))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (1ULL 
                                                                           >> 
                                                                           (vlSelf->insn_y 
                                                                            >> 0x1aU))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (1ULL 
                                                                              >> 
                                                                              (0x3fU 
                                                                               & (vlSelf->insn_y 
                                                                                >> 2U)))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (0x3fU 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x14U)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((4U 
                                                                              & (vlSelf->insn_y 
                                                                                >> 6U)) 
                                                                             | (3U 
                                                                                & vlSelf->insn_y))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xfffffffeU 
                                                                             >> 
                                                                             (0x1fU 
                                                                              & (vlSelf->insn_y 
                                                                                >> 9U))))))))))));
    vlSelf->__VdfgTmp_h1a7964bb__0 = (((IData)(vlSelf->insn_valid) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d));
    vlSelf->__VdfgTmp_h17c4848e__0 = (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d));
    vlSelf->wasmetal_core__DOT___070576_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 6U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (3U 
                                                          & (vlSelf->insn_op 
                                                             >> 8U)))))));
    vlSelf->wasmetal_core__DOT___048111_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d))));
    vlSelf->__VdfgTmp_hb5e2654e__0 = (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d));
    vlSelf->wasmetal_core__DOT___048346_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 6U))) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (vlSelf->insn_op 
                                                         >> 4U)))));
    vlSelf->wasmetal_core__DOT___000375_ = (1U & (0x100U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | ((6U 
                                                       & (vlSelf->insn_op 
                                                          >> 5U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 4U))))));
    vlSelf->wasmetal_core__DOT___048302_ = (1U & (0x100U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (7U 
                                                      & (vlSelf->insn_op 
                                                         >> 5U)))));
    vlSelf->__VdfgTmp_ha3f5bbbb__0 = ((2U & ((IData)(
                                                     (1ULL 
                                                      >> 
                                                      (vlSelf->insn_op 
                                                       >> 0x1aU))) 
                                             << 1U)) 
                                      | (1U & (0xeU 
                                               >> (3U 
                                                   & (vlSelf->insn_op 
                                                      >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___001241_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & vlSelf->insn_op) 
                                                      | ((2U 
                                                          & (vlSelf->insn_op 
                                                             >> 2U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___002988_ = (1U & (0x1000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 4U)) 
                                                      | ((2U 
                                                          & (vlSelf->insn_op 
                                                             >> 6U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 4U)))))));
    vlSelf->wasmetal_core__DOT___000366_ = (1U & (0x100U 
                                                  >> 
                                                  ((0xcU 
                                                    & (vlSelf->insn_op 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (vlSelf->insn_op 
                                                         >> 2U)))));
    vlSelf->__VdfgTmp_h682c3842__0 = ((8U & (vlSelf->insn_op 
                                             >> 4U)) 
                                      | ((4U & (vlSelf->insn_op 
                                                >> 2U)) 
                                         | (3U & (vlSelf->insn_op 
                                                  >> 5U))));
    vlSelf->wasmetal_core__DOT___002994_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 4U)) 
                                                      | ((2U 
                                                          & (vlSelf->insn_op 
                                                             >> 3U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 7U)))))));
    vlSelf->wasmetal_core__DOT___001231_ = (1U & (IData)(
                                                         ((0x10U 
                                                           == 
                                                           (0x11U 
                                                            & vlSelf->insn_op)) 
                                                          & (1ULL 
                                                             >> 
                                                             ((0x20U 
                                                               & (vlSelf->insn_op 
                                                                  << 4U)) 
                                                              | ((0x1cU 
                                                                  & (vlSelf->insn_op 
                                                                     >> 3U)) 
                                                                 | (3U 
                                                                    & (vlSelf->insn_op 
                                                                       >> 2U))))))));
    vlSelf->wasmetal_core__DOT___000158_ = (1U & (0xbfffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))))));
    vlSelf->__VdfgTmp_h97facc1b__0 = ((0xcU & (vlSelf->insn_op 
                                               << 1U)) 
                                      | ((2U & (vlSelf->insn_op 
                                                >> 2U)) 
                                         | (1U & vlSelf->insn_op)));
    vlSelf->wasmetal_core__DOT___047786_ = (1U & (0x1000U 
                                                  >> 
                                                  ((0xeU 
                                                    & (vlSelf->insn_op 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___047783_ = (1U & (0x1000U 
                                                  >> 
                                                  ((8U 
                                                    & vlSelf->insn_op) 
                                                   | ((6U 
                                                       & (vlSelf->insn_op 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___001240_ = (1U & (0x100U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       << 1U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & vlSelf->insn_op) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 3U)))))));
    vlSelf->__VdfgTmp_h3fee6eff__0 = ((8U & (vlSelf->insn_op 
                                             << 3U)) 
                                      | ((6U & vlSelf->insn_op) 
                                         | (1U & (vlSelf->insn_op 
                                                  >> 3U))));
    vlSelf->__VdfgTmp_h20102633__0 = ((2U & vlSelf->insn_op) 
                                      | (1U & (vlSelf->insn_op 
                                               >> 2U)));
    vlSelf->wasmetal_core__DOT___044249_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (0xfU 
                                                         & (vlSelf->insn_x 
                                                            >> 0xfU))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (vlSelf->insn_x 
                                                          >> 0x12U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0xeU))))));
    vlSelf->wasmetal_core__DOT___044243_ = (1U & (0xefU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (7U 
                                                         & (vlSelf->insn_x 
                                                            >> 9U))) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xcU)))));
    vlSelf->wasmetal_core__DOT___048289_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b14__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b13__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b12__05d))))));
    vlSelf->wasmetal_core__DOT___048290_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b24__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___048288_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b23__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b19__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b18__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b17__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___053407_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b18__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b20__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b20__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b16__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b16__05d))))))))))));
    vlSelf->wasmetal_core__DOT___053410_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b29__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b25__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b23__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b23__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b22__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b22__05d))))))))))));
    vlSelf->wasmetal_core__DOT___053404_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b27__05d)))))))));
    wasmetal_core__DOT___053398_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b15__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b15__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b14__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b14__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b11__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b11__05d)))))))));
    wasmetal_core__DOT___053399_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b24__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b24__05d))));
    wasmetal_core__DOT___053400_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b26__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b26__05d))));
    wasmetal_core__DOT___053401_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b0__05d))));
    wasmetal_core__DOT___053402_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b4__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b4__05d))));
    vlSelf->wasmetal_core__DOT___135386___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (vlSelf->insn_op >> 1U)) | (4U 
                                                >> 
                                                (3U 
                                                 & vlSelf->insn_op))));
    vlSelf->__VdfgTmp_h3fefcec1__0 = ((8U & (vlSelf->insn_op 
                                             << 3U)) 
                                      | ((4U & (vlSelf->insn_op 
                                                << 1U)) 
                                         | (3U & (vlSelf->insn_op 
                                                  >> 2U))));
    vlSelf->__VdfgTmp_h8e88a732__0 = ((0x20U & (vlSelf->insn_op 
                                                >> 9U)) 
                                      | ((0x10U & (vlSelf->insn_op 
                                                   >> 0xbU)) 
                                         | ((8U & (vlSelf->insn_op 
                                                   >> 6U)) 
                                            | ((4U 
                                                & (vlSelf->insn_op 
                                                   >> 8U)) 
                                               | ((2U 
                                                   & (vlSelf->insn_op 
                                                      >> 0xaU)) 
                                                  | (1U 
                                                     & (vlSelf->insn_op 
                                                        >> 8U)))))));
    if (vlSelf->wasmetal_core__DOT__sp__05b2__05d) {
        vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b2__05d;
        vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b2__05d;
        vlSelf->wasmetal_core__DOT___128593___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128490___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b2__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b1__05d;
        vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128593___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b2__05d;
        vlSelf->wasmetal_core__DOT___128490___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___044001_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b18__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b21__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b19__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b22__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b20__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b23__05d)))))))));
    wasmetal_core__DOT___044000_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b12__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b13__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b14__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b15__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b16__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b17__05d)))))))));
    wasmetal_core__DOT___044006_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b11__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b6__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b7__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b8__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b9__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b10__05d)))))))));
    wasmetal_core__DOT___044015_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b20__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b21__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b19__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b22__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b18__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b23__05d)))))))));
    wasmetal_core__DOT___044014_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b12__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b13__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b14__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b15__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b16__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b17__05d)))))))));
    wasmetal_core__DOT___044020_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b11__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b6__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b7__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b8__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b9__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b10__05d)))))))));
    wasmetal_core__DOT___043973_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b18__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b20__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b23__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b22__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b19__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b21__05d)))))))));
    wasmetal_core__DOT___043972_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b12__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b13__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b14__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b15__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b16__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b17__05d)))))))));
    wasmetal_core__DOT___043978_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b11__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b6__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b7__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b8__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b9__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b10__05d)))))))));
    wasmetal_core__DOT___043987_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b21__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b20__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b22__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b23__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b19__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b18__05d)))))))));
    wasmetal_core__DOT___043986_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b12__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b13__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b14__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b15__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b16__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b17__05d)))))))));
    wasmetal_core__DOT___043992_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b11__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b6__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b7__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b8__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b9__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b10__05d)))))))));
    wasmetal_core__DOT___000197_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b16__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b18__05d))));
    wasmetal_core__DOT___000198_ = (1U & (0x9009U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b18__05d) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b20__05d) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b14__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b16__05d))))));
    wasmetal_core__DOT___000199_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b17__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b19__05d))));
    wasmetal_core__DOT___000207_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b23__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b25__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b21__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b23__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b20__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___000212_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___000213_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b28__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b25__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___000214_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b7__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b9__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___000279_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___000283_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b25__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b27__05d)))))))));
    wasmetal_core__DOT___000290_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b9__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b11__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b7__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b9__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b1__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b3__05d)))))))));
    wasmetal_core__DOT___000294_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b12__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b14__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b4__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b6__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b3__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b5__05d)))))))));
    wasmetal_core__DOT___000298_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b16__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b18__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b15__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b17__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b5__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___000302_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b6__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___000306_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b21__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b23__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b17__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___000321_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___000325_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b28__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___000329_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b2__05d)))))))));
    wasmetal_core__DOT___000333_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b10__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b12__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b7__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b9__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b2__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b4__05d)))))))));
    wasmetal_core__DOT___000337_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b23__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b25__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b21__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b23__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b20__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___000344_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b8__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b10__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___000348_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___000230_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___000234_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b28__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___000238_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b2__05d)))))))));
    wasmetal_core__DOT___000242_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b10__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b12__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b7__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b9__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b2__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b4__05d)))))))));
    wasmetal_core__DOT___000246_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b23__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b25__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b21__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b23__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b20__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___000254_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b8__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b10__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___000258_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___000371_ = (1U & (1U 
                                                  >> 
                                                  ((0xcU 
                                                    & (vlSelf->insn_op 
                                                       >> 0xeU)) 
                                                   | (3U 
                                                      & (vlSelf->insn_op 
                                                         >> 0x12U)))));
    vlSelf->__VdfgTmp_h2780d718__0 = ((2U & (vlSelf->insn_op 
                                             << 1U)) 
                                      | (1U & (vlSelf->insn_op 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT____VdfgTmp_h1702059a__0 
        = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d)) 
                  << 1U)) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->__VdfgTmp_h7a4c1007__0 = ((2U & (vlSelf->insn_op 
                                             >> 1U)) 
                                      | (1U & (vlSelf->insn_op 
                                               >> 3U)));
    vlSelf->__VdfgTmp_h3ca161df__0 = ((2U & (vlSelf->insn_op 
                                             >> 3U)) 
                                      | (1U & (vlSelf->insn_op 
                                               >> 5U)));
    vlSelf->__VdfgTmp_h17767d6e__0 = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b0__05d));
    vlSelf->wasmetal_core__DOT___000378_ = (1U & (0x1000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 3U)) 
                                                      | (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 6U))))));
    vlSelf->wasmetal_core__DOT___044624_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)))))))));
    vlSelf->__VdfgTmp_hbb12d5bf__0 = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp___128284___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128287___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d))));
    vlSelf->wasmetal_core__DOT___044625_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___044627_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___045705_ = (1U & (0x1fU 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 0x12U))) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (vlSelf->insn_op 
                                                         >> 0x10U)))));
    vlSelf->wasmetal_core__DOT___070610_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_op 
                                                       >> 5U)) 
                                                   | ((2U 
                                                       & (vlSelf->insn_op 
                                                          >> 4U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 6U))))));
    vlSelf->wasmetal_core__DOT___043959_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___043964_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b12__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b10__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___043961_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___043960_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b20__05d)))))))));
    __VdfgTmp_h225c4799__0 = ((2U & (vlSelf->insn_op 
                                     >> 9U)) | (1U 
                                                & (vlSelf->insn_op 
                                                   >> 0xbU)));
    vlSelf->__VdfgTmp_hf3a49853__0 = ((8U & (vlSelf->insn_op 
                                             >> 0x11U)) 
                                      | ((4U & (vlSelf->insn_op 
                                                >> 0x13U)) 
                                         | ((2U & (vlSelf->insn_op 
                                                   >> 0x15U)) 
                                            | (1U & 
                                               (vlSelf->insn_op 
                                                >> 0x17U)))));
    vlSelf->__VdfgTmp_h752c22b4__0 = ((2U & (vlSelf->insn_op 
                                             >> 6U)) 
                                      | (1U & (vlSelf->insn_op 
                                               >> 5U)));
    vlSelf->wasmetal_core__DOT___054455_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0xdU)) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 0xfU)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128230___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d)))) 
           ^ (1U | ((((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d)
                       ? (IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d)
                       : (IData)(vlSelf->wasmetal_core__DOT___128230___DOT__CO__BRA__1__KET__)) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128230___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128814___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                & (IData)(vlSelf->wasmetal_core__DOT___128814___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128814___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___036780_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036619_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf9e7c209__0))));
    vlSelf->wasmetal_core__DOT___036779_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf9e7c209__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h586b57d5__0))));
    vlSelf->wasmetal_core__DOT___071471_ = (1U & (IData)(
                                                         (0xfeffffff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02ebusy) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2f7c3620__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___036777_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h586b57d5__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h364ba349__0))));
    vlSelf->wasmetal_core__DOT___053749_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_he3290929__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053742_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b10__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___036776_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h364ba349__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd2526c88__0))));
    wasmetal_core__DOT___052958_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052957_) 
                                                    << 5U) 
                                                   | ((0x18U 
                                                       & (vlSelf->mem_rdata[0U] 
                                                          >> 0xaU)) 
                                                      | (7U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 2U)))))));
    wasmetal_core__DOT___052968_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052967_) 
                                                    << 5U) 
                                                   | ((0x18U 
                                                       & (vlSelf->mem_rdata[1U] 
                                                          >> 0x19U)) 
                                                      | (7U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 1U)))))));
    wasmetal_core__DOT___052982_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052964_) 
                                                    << 5U) 
                                                   | ((0x18U 
                                                       & (vlSelf->mem_rdata[2U] 
                                                          >> 9U)) 
                                                      | (7U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 1U)))))));
    wasmetal_core__DOT___052976_ = (1U & (IData)((0x4000000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->mem_rdata[3U] 
                                                            >> 2U))) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052974_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052973_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (1ULL 
                                                                         >> 
                                                                         ((0x30U 
                                                                           & (vlSelf->mem_rdata[2U] 
                                                                              >> 0x16U)) 
                                                                          | ((0xcU 
                                                                              & (vlSelf->mem_rdata[2U] 
                                                                                >> 8U)) 
                                                                             | (3U 
                                                                                & (vlSelf->mem_rdata[2U] 
                                                                                >> 4U)))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((1U 
                                                                    >> 
                                                                    (3U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xcU))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (vlSelf->mem_rdata[3U] 
                                                                     >> 1U))))))))));
    wasmetal_core__DOT___052983_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052963_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052962_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052961_) 
                                                          << 3U) 
                                                         | ((6U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 0x16U)) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0x11U)))))))));
    vlSelf->wasmetal_core__DOT___038805_ = (1U & ((IData)(
                                                          (1ULL 
                                                           >> 
                                                           (vlSelf->cmd_index 
                                                            >> 0x1aU))) 
                                                  & ((IData)(
                                                             (1ULL 
                                                              >> 
                                                              (0x3fU 
                                                               & (vlSelf->cmd_index 
                                                                  >> 0x14U)))) 
                                                     & ((IData)(
                                                                (1ULL 
                                                                 >> 
                                                                 (0x3fU 
                                                                  & (vlSelf->cmd_index 
                                                                     >> 0xeU)))) 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT___045803_)) 
                                                           & (4U 
                                                              >> 
                                                              ((2U 
                                                                & ((1U 
                                                                    >> 
                                                                    (0x1fU 
                                                                     & (vlSelf->cmd_index 
                                                                        >> 9U))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (vlSelf->cmd_index 
                                                                     >> 8U)))))))));
    vlSelf->wasmetal_core__DOT___045596_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___045609_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045608_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045607_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045606_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045605_)
                                                       ? 
                                                      ((~ (IData)(vlSelf->wasmetal_core__DOT___045604_)) 
                                                       & (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b1__05d))
                                                       : 
                                                      (~ (IData)(vlSelf->wasmetal_core__DOT___045605_)))
                                                      : 
                                                     (~ (IData)(vlSelf->wasmetal_core__DOT___045606_)))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___045607_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___045608_)))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___045609_))));
    vlSelf->wasmetal_core__DOT___036775_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd2526c88__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h93f91ca8__0))));
    wasmetal_core__DOT___128793___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128793___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___063389_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (0xfU 
                                                                 & (vlSelf->function_locals 
                                                                    >> 5U))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063385_) 
                                                               << 4U) 
                                                              | (0xfU 
                                                                 & (vlSelf->function_locals 
                                                                    >> 9U)))))));
    vlSelf->wasmetal_core__DOT___036774_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h93f91ca8__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4835143f__0))));
    vlSelf->wasmetal_core__DOT___128720___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128720___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___044731_ = (1U & ((1U 
                                                   & (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->function_params 
                                                               >> 0x1aU))))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(
                                                              (1ULL 
                                                               >> 
                                                               (0x3fU 
                                                                & (vlSelf->function_params 
                                                                   >> 0x14U)))))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (0x3fU 
                                                                 & (vlSelf->function_params 
                                                                    >> 0xeU)))))
                                                     ? 
                                                    ((1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h26309c84__0)))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(
                                                                 (1ULL 
                                                                  >> 
                                                                  (0x3fU 
                                                                   & (vlSelf->function_params 
                                                                      >> 2U)))))
                                                       ? 
                                                      (~ 
                                                       (1U 
                                                        >> 
                                                        (3U 
                                                         & vlSelf->function_params)))
                                                       : 
                                                      (~ (IData)(
                                                                 (1ULL 
                                                                  >> 
                                                                  (0x3fU 
                                                                   & (vlSelf->function_params 
                                                                      >> 2U))))))
                                                      : 
                                                     (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h26309c84__0)))
                                                     : 
                                                    (~ (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (0x3fU 
                                                                 & (vlSelf->function_params 
                                                                    >> 0xeU))))))
                                                    : 
                                                   (~ (IData)(
                                                              (1ULL 
                                                               >> 
                                                               (0x3fU 
                                                                & (vlSelf->function_params 
                                                                   >> 0x14U))))))
                                                   : 
                                                  (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->function_params 
                                                               >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___036773_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4835143f__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf6334cf8__0))));
    vlSelf->wasmetal_core__DOT___036772_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf6334cf8__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2b80e318__0))));
    vlSelf->wasmetal_core__DOT___036771_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2b80e318__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h17547017__0))));
    vlSelf->wasmetal_core__DOT___036770_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17547017__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hed077be7__0))));
    vlSelf->wasmetal_core__DOT___049543_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048570_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048545_))));
    wasmetal_core__DOT___049444_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048295_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048539_))));
    vlSelf->wasmetal_core__DOT___036769_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hed077be7__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1872cc15__0))));
    wasmetal_core__DOT___044659_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044682_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___044691_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___044690_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044689_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044688_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044687_)
                                                      ? 
                                                     ((1U 
                                                       & (IData)(
                                                                 (1ULL 
                                                                  >> 
                                                                  (0x3fU 
                                                                   & (IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x16U))))))
                                                       ? 
                                                      ((1U 
                                                        & (IData)(
                                                                  (1ULL 
                                                                   >> 
                                                                   (0x3fU 
                                                                    & (IData)(
                                                                              (vlSelf->cmd_aux 
                                                                               >> 0x10U))))))
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044684_)
                                                         ? 
                                                        ((1U 
                                                          & (IData)(
                                                                    (1ULL 
                                                                     >> 
                                                                     (0x3fU 
                                                                      & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 4U))))))
                                                          ? 
                                                         (~ 
                                                          (1U 
                                                           >> 
                                                           (0xfU 
                                                            & (IData)(vlSelf->cmd_aux))))
                                                          : 
                                                         (~ (IData)(
                                                                    (1ULL 
                                                                     >> 
                                                                     (0x3fU 
                                                                      & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 4U)))))))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044672_))
                                                        : 
                                                       (~ (IData)(
                                                                  (1ULL 
                                                                   >> 
                                                                   (0x3fU 
                                                                    & (IData)(
                                                                              (vlSelf->cmd_aux 
                                                                               >> 0x10U)))))))
                                                       : 
                                                      (~ (IData)(
                                                                 (1ULL 
                                                                  >> 
                                                                  (0x3fU 
                                                                   & (IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x16U)))))))
                                                      : 
                                                     (~ (IData)(vlSelf->wasmetal_core__DOT___044687_)))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044688_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044689_)))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044690_)))
                                               : (~ (IData)(vlSelf->wasmetal_core__DOT___044691_)))
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___044682_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128179___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d) 
             << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                        << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d) 
                & (IData)(vlSelf->wasmetal_core__DOT___128179___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128179___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___036768_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1872cc15__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9473bd37__0))));
    wasmetal_core__DOT___128026___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_z >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128026___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128266___DOT__CO__BRA__2__KET__ 
        = (1U & ((4U & vlSelf->mem_rdata[0U]) ? (vlSelf->mem_rdata[0U] 
                                                 >> 2U)
                  : (IData)(vlSelf->wasmetal_core__DOT___128266___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___044273_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128431___DI))))));
    vlSelf->wasmetal_core__DOT___036766_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9473bd37__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfd696a08__0))));
    vlSelf->wasmetal_core__DOT___128002___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128002___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128034___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128034___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128155___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128155___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___036765_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfd696a08__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb0a19382__0))));
    vlSelf->wasmetal_core__DOT___053305_ = (1U & (IData)(
                                                         (0x9009000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053297_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053296_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b2__05d)))))))));
    vlSelf->__VdfgTmp_hf72c75d5__0 = (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0))));
    vlSelf->wasmetal_core__DOT___128188___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128188___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128205___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128205___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128370___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128370___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___053295_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053290_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b13__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b13__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b9__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___053294_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053293_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b7__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b7__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b6__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___053304_ = (1U & (IData)(
                                                         (0x9000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053301_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053300_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053299_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x9009000000009009ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b12__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b12__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b10__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b8__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b8__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___045956_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b12__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h950b0747__0))))))));
    vlSelf->wasmetal_core__DOT___045960_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he45fe6bb__0))))))));
    vlSelf->wasmetal_core__DOT___036764_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0a19382__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h959d8796__0))));
    vlSelf->wasmetal_core__DOT___128418___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128418___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___036763_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h959d8796__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6d2d9567__0))));
    vlSelf->wasmetal_core__DOT___036762_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6d2d9567__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h291433ac__0))));
    vlSelf->wasmetal_core__DOT___036761_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h291433ac__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd028268__0))));
    vlSelf->wasmetal_core__DOT___044708_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 6U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 8U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha938949d__0))))))));
    vlSelf->wasmetal_core__DOT___044712_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0x12U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0x14U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd225b533__0))))))));
    vlSelf->wasmetal_core__DOT___036760_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbd028268__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6265db41__0))));
    vlSelf->wasmetal_core__DOT___036759_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6265db41__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7b2f5a0d__0))));
    vlSelf->wasmetal_core__DOT___051236_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->cmd_kind)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h73f978ac__0))))));
    vlSelf->wasmetal_core__DOT___050385_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h73f978ac__0)) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (IData)(vlSelf->cmd_kind)))));
    vlSelf->wasmetal_core__DOT___036758_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7b2f5a0d__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h86617c98__0))));
    vlSelf->wasmetal_core__DOT___044212_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052942_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128422___DI))))));
    vlSelf->wasmetal_core__DOT___044213_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha5b552f8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128423___DI))))));
    vlSelf->wasmetal_core__DOT___052936_ = (1U & (IData)(
                                                         (0x9009000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052932_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052931_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___052925_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052921_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b13__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b13__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b9__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___052926_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052924_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b7__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b7__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b6__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___052935_ = (1U & (IData)(
                                                         (0x9000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052930_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052929_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052928_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x9009000000009009ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b12__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b12__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b10__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b8__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b8__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___036757_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h86617c98__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h20c332a4__0))));
    vlSelf->wasmetal_core__DOT___036787_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h20c332a4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1c8d20fd__0))));
    vlSelf->wasmetal_core__DOT___036786_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1c8d20fd__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5736dc67__0))));
    vlSelf->wasmetal_core__DOT___053312_ = (1U & (IData)(
                                                         (0x4100004100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053310_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b89__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b86__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 0x15U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b87__05d) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x17U)))))))))))));
    vlSelf->wasmetal_core__DOT___052994_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052991_))));
    vlSelf->wasmetal_core__DOT___063375_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052991_))));
    vlSelf->wasmetal_core__DOT___036785_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5736dc67__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h13987860__0))));
    vlSelf->wasmetal_core__DOT___036784_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h13987860__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_haa7ff968__0))));
    vlSelf->wasmetal_core__DOT___044203_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052944_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5a9aeb48__0))));
    vlSelf->wasmetal_core__DOT___044211_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b9__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052944_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b8__05d)))));
    vlSelf->wasmetal_core__DOT___052949_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044210_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128423___DI)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128422___DI)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052944_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x1000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___044209_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___044214_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052942_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha5b552f8__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5a9aeb48__0))))))))))))));
    vlSelf->wasmetal_core__DOT___036783_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_haa7ff968__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h85ffa972__0))));
    vlSelf->wasmetal_core__DOT___036782_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h85ffa972__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h83e5aafb__0))));
    vlSelf->wasmetal_core__DOT___036781_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h83e5aafb__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcb9fc16c__0))));
    vlSelf->wasmetal_core__DOT___036778_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcb9fc16c__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8befad22__0))));
    vlSelf->wasmetal_core__DOT___049550_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048570_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048575_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048570_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048571_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048570_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048541_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048567_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048545_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0))))));
    vlSelf->wasmetal_core__DOT___049347_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0))))));
    vlSelf->wasmetal_core__DOT___049345_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0))))));
    vlSelf->wasmetal_core__DOT___048510_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___049390_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048545_))));
    vlSelf->wasmetal_core__DOT___049392_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___049003_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048962_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048546_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048545_))));
    vlSelf->wasmetal_core__DOT___048298_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    vlSelf->wasmetal_core__DOT___048536_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h46faf1d8__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc3285b0a__0))))));
    wasmetal_core__DOT___049584_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048295_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    wasmetal_core__DOT___048572_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048295_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    wasmetal_core__DOT___048299_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048295_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (1U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    wasmetal_core__DOT___049727_ = (1U & (8U >> ((2U 
                                                  & ((8U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    wasmetal_core__DOT___049678_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048539_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0))))));
    wasmetal_core__DOT___049596_ = (1U & (8U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf7906078__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0))))));
    wasmetal_core__DOT___049591_ = (1U & (8U >> ((2U 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf7906078__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0))))));
    vlSelf->wasmetal_core__DOT___048511_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    vlSelf->wasmetal_core__DOT___048542_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048539_))));
    vlSelf->wasmetal_core__DOT___049942_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    vlSelf->wasmetal_core__DOT___049424_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    vlSelf->wasmetal_core__DOT___049421_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    vlSelf->wasmetal_core__DOT___049914_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048539_))));
    vlSelf->wasmetal_core__DOT___050082_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    vlSelf->wasmetal_core__DOT___049611_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a8db87d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7906078__0))))));
    vlSelf->wasmetal_core__DOT___045577_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b23__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b25__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h17166267__0))))))));
    vlSelf->wasmetal_core__DOT___128274___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128274___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___065584_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065583_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b4__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__load_width__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___065585_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b3__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065583_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__load_width__05b4__05d)))));
    vlSelf->wasmetal_core__DOT___128222___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128222___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___029914_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d));
    vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032866_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___044271_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070607_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_he965b193__0)))))));
    vlSelf->wasmetal_core__DOT___044263_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he965b193__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___070607_)))));
    vlSelf->wasmetal_core__DOT___045573_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b11__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b13__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he965b193__0))))))));
    vlSelf->wasmetal_core__DOT___053733_ = (1U & (IData)(
                                                         (0xffff3c3fffff23ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)))))))))));
    vlSelf->wasmetal_core__DOT___127994___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128938___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___127994___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_he557a56d__0 = (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h673d32f0__0))));
    vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___029745_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d));
    vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___029382_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b0__05d));
    vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___027801_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b0__05d));
    vlSelf->wasmetal_core__DOT___052004_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052003_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___052675_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052025_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b77__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b76__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b67__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b66__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b65__05d)))))))));
    vlSelf->wasmetal_core__DOT___052011_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052010_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052009_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052008_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b99__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b98__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b97__05d)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b109__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b108__05d)))))))));
    vlSelf->wasmetal_core__DOT___128255___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128255___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045581_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032218_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032217_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032215_)))));
    vlSelf->wasmetal_core__DOT___052019_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052017_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052016_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b35__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6b18dcfd__0))))))));
    vlSelf->wasmetal_core__DOT___052024_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b59__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b58__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b43__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b42__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb8b9c084__0))))))));
    vlSelf->wasmetal_core__DOT___037208_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036716_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h08c26bfc__0))));
    vlSelf->wasmetal_core__DOT___044716_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032695_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032698_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032697_)))));
    vlSelf->wasmetal_core__DOT___061607_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061598_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x17U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 8U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x11U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 2U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x17U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 8U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x11U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 2U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x17U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 8U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x11U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 2U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061608_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061602_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x18U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 9U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x12U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 3U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x18U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 9U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x12U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 3U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x18U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 9U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x12U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 3U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061619_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061616_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x19U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0xaU)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x13U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 4U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x19U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xaU)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x13U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 4U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x19U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0xaU)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x13U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 4U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___037207_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h08c26bfc__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09206f3f__0))));
    vlSelf->wasmetal_core__DOT___128050___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_x >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128050___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___029221_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d));
    vlSelf->wasmetal_core__DOT___128018___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128018___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045590_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032214_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032213_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032212_)))));
    vlSelf->wasmetal_core__DOT___044280_ = (1U & ((1U 
                                                   & (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_y 
                                                               >> 0x1aU))))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(
                                                              (1ULL 
                                                               >> 
                                                               (0x3fU 
                                                                & (vlSelf->insn_y 
                                                                   >> 0x14U)))))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (0x3fU 
                                                                 & (vlSelf->insn_y 
                                                                    >> 0xeU)))))
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044291_) 
                                                     | (0xfffffffeU 
                                                        >> 
                                                        (0x1fU 
                                                         & (vlSelf->insn_y 
                                                            >> 9U))))
                                                     : 
                                                    (~ (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (0x3fU 
                                                                 & (vlSelf->insn_y 
                                                                    >> 0xeU))))))
                                                    : 
                                                   (~ (IData)(
                                                              (1ULL 
                                                               >> 
                                                               (0x3fU 
                                                                & (vlSelf->insn_y 
                                                                   >> 0x14U))))))
                                                   : 
                                                  (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_y 
                                                               >> 0x1aU))))));
    vlSelf->__VdfgTmp_h8c4cb679__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                             << 2U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                               >> 1U)));
    vlSelf->__VdfgTmp_h8d2606de__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                             << 3U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___067580_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___052867_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032694_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___032693_))));
    vlSelf->wasmetal_core__DOT___037205_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h09206f3f__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbc309d1b__0))));
    vlSelf->wasmetal_core__DOT___045589_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032211_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032210_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032209_)))));
    vlSelf->__VdfgTmp_hd461afd0__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02erunning) 
                                       << 1U) | (1U 
                                                 & (0x8000U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI))));
    vlSelf->__VdfgTmp_hcd6b7a1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___032208_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032207_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___032206_)));
    vlSelf->wasmetal_core__DOT___037204_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbc309d1b__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4312483e__0))));
    vlSelf->wasmetal_core__DOT___061593_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061588_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x15U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 6U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0xfU)) 
                                                                                | (1U 
                                                                                & vlSelf->insn_imm[2U])))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x15U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 6U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xfU)) 
                                                                                | (1U 
                                                                                & vlSelf->insn_imm[1U])))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x15U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 6U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0xfU)) 
                                                                                | (1U 
                                                                                & vlSelf->insn_imm[0U])))))))))))))))));
    vlSelf->wasmetal_core__DOT___061594_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x16U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 7U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x10U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 1U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x16U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 7U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x10U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 1U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x16U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 7U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x10U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 1U))))))))))))))))));
    vlSelf->__VdfgTmp_h42a8fe82__0 = (((IData)(vlSelf->wasmetal_core__DOT___032691_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032690_));
    vlSelf->__VdfgTmp_h0fa5f18f__0 = ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                             << 3U)) 
                                      | (4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                               << 1U)));
    vlSelf->__VdfgTmp_hf35ae7d9__0 = ((2U & ((8U >> 
                                              (3U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                >> 2U))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                               >> 1U)));
    vlSelf->__VdfgTmp_hab6fcc6c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                      | (1U & (8U >> 
                                               (3U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                   >> 2U)))));
    vlSelf->wasmetal_core__DOT___009522_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___045587_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032204_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032203_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032202_)))));
    vlSelf->wasmetal_core__DOT___037203_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4312483e__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4679be83__0))));
    vlSelf->wasmetal_core__DOT___045586_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032201_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032200_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032199_)))));
    vlSelf->wasmetal_core__DOT___037202_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4679be83__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h137eceb9__0))));
    vlSelf->wasmetal_core__DOT___044723_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032686_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032688_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032687_)))));
    vlSelf->wasmetal_core__DOT___128314___DOT__CO__BRA__2__KET__ 
        = ((~ (vlSelf->function_params >> 2U)) & (IData)(vlSelf->wasmetal_core__DOT___128314___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045585_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032198_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032197_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032196_)))));
    vlSelf->wasmetal_core__DOT___128632___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128632___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___037201_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h137eceb9__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h590821b5__0))));
    vlSelf->wasmetal_core__DOT___042520_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035143_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035142_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b63__05d)))));
    vlSelf->__VdfgTmp_he13e3256__0 = (((IData)(vlSelf->wasmetal_core__DOT___032195_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032225_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___032224_)));
    vlSelf->wasmetal_core__DOT___042519_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035138_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035140_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035141_)))));
    vlSelf->wasmetal_core__DOT___044722_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032682_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032684_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032683_)))));
    vlSelf->wasmetal_core__DOT___042517_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035135_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035136_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035137_)))));
    vlSelf->wasmetal_core__DOT___042516_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035132_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035133_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035134_)))));
    vlSelf->wasmetal_core__DOT___037200_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h590821b5__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5a255a66__0))));
    vlSelf->wasmetal_core__DOT___045583_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032223_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032222_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032221_)))));
    vlSelf->wasmetal_core__DOT___042515_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035130_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035131_)))));
    vlSelf->wasmetal_core__DOT___037199_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a255a66__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbc3091a9__0))));
    vlSelf->wasmetal_core__DOT___045582_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032220_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032219_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032216_)))));
    vlSelf->wasmetal_core__DOT___042514_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035125_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035126_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035127_)))));
    vlSelf->wasmetal_core__DOT___044721_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032679_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032680_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032681_)))));
    vlSelf->wasmetal_core__DOT___045568_ = (1U & (0x2b22U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbf5bedf6__0)))));
    vlSelf->__VdfgTmp_h58222fb0__0 = ((2U & ((9U >> (IData)(vlSelf->__VdfgTmp_hbf5bedf6__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___032194_));
    vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032194_) 
           | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___042513_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035122_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035123_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035124_)))));
    vlSelf->wasmetal_core__DOT___037198_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbc3091a9__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h092cd911__0))));
    vlSelf->__VdfgTmp_haf0d31b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___032678_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032677_));
    vlSelf->wasmetal_core__DOT___042512_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035119_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035120_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035121_)))));
    vlSelf->wasmetal_core__DOT___037197_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h092cd911__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0817f177__0))));
    vlSelf->wasmetal_core__DOT___042511_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035115_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035116_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035118_)))));
    vlSelf->wasmetal_core__DOT___037196_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0817f177__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1274aae9__0))));
    vlSelf->wasmetal_core__DOT___044719_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032704_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032675_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032705_)))));
    vlSelf->wasmetal_core__DOT___042510_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035112_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035113_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035114_)))));
    vlSelf->wasmetal_core__DOT___037194_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1274aae9__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h148285ae__0))));
    vlSelf->wasmetal_core__DOT___065559_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h49b76e08__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h835050f4__0))))));
    vlSelf->wasmetal_core__DOT___044718_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032701_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032703_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032702_)))));
    vlSelf->wasmetal_core__DOT___037193_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h148285ae__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0dd4dc97__0))));
    vlSelf->wasmetal_core__DOT___042509_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035109_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035110_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035111_)))));
    vlSelf->wasmetal_core__DOT___065563_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065552_))));
    vlSelf->wasmetal_core__DOT___065553_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065552_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b4__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b5__05d)))));
    vlSelf->wasmetal_core__DOT___052868_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032700_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___032699_))));
    vlSelf->wasmetal_core__DOT___037192_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0dd4dc97__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5f5f5b59__0))));
    vlSelf->wasmetal_core__DOT___042508_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035105_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035107_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035108_)))));
    vlSelf->__VdfgTmp_h74a82ee2__0 = (((IData)(vlSelf->wasmetal_core__DOT___032685_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032674_));
    vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032674_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___037191_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5f5f5b59__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54e5e4c4__0))));
    vlSelf->wasmetal_core__DOT___042528_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035102_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035103_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035104_)))));
    vlSelf->wasmetal_core__DOT___037190_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h54e5e4c4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h558b9029__0))));
    vlSelf->wasmetal_core__DOT___064086_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064083_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b31__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b29__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___064091_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064090_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064089_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___037189_ = (1U & (0x87U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h558b9029__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h629179e3__0))));
    vlSelf->wasmetal_core__DOT___042527_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035099_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035100_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035101_)))));
    vlSelf->wasmetal_core__DOT___071478_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071477_))));
    vlSelf->wasmetal_core__DOT___037188_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h629179e3__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h638a3747__0))));
    vlSelf->wasmetal_core__DOT___042526_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035096_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035097_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035098_)))));
    vlSelf->wasmetal_core__DOT___037187_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h638a3747__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h68654253__0))));
    vlSelf->wasmetal_core__DOT___037186_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h68654253__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6978beee__0))));
    vlSelf->wasmetal_core__DOT___042525_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035093_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035094_)))));
    vlSelf->wasmetal_core__DOT___037185_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6978beee__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h14007945__0))));
    vlSelf->wasmetal_core__DOT___037215_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h14007945__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h13ef8f89__0))));
    vlSelf->wasmetal_core__DOT___042524_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035089_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035090_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035091_)))));
    vlSelf->wasmetal_core__DOT___037214_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h13ef8f89__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e12a4a2__0))));
    vlSelf->wasmetal_core__DOT___037213_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0e12a4a2__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0d1b5516__0))));
    vlSelf->wasmetal_core__DOT___042523_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035086_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035087_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035088_)))));
    vlSelf->wasmetal_core__DOT___037212_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0d1b5516__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5afc8767__0))));
    vlSelf->wasmetal_core__DOT___037211_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5afc8767__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5b0f43f4__0))));
    vlSelf->wasmetal_core__DOT___042522_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035146_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035147_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035085_)))));
    vlSelf->wasmetal_core__DOT___037210_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5b0f43f4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h60140cd4__0))));
    vlSelf->wasmetal_core__DOT___037209_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h60140cd4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h61cb7e30__0))));
    vlSelf->wasmetal_core__DOT___037206_ = (1U & (0x87U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h61cb7e30__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2cd56cce__0))));
    vlSelf->wasmetal_core__DOT___037195_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2cd56cce__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2d9d1f69__0))));
    vlSelf->wasmetal_core__DOT___042521_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035139_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035144_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035145_)))));
    vlSelf->wasmetal_core__DOT___042518_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035106_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035117_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___035128_)))));
    vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035084_) 
           | (IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b63__05d));
    vlSelf->wasmetal_core__DOT___042507_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hff2c11ba__0))))));
    vlSelf->wasmetal_core__DOT___042483_ = (1U & (0x2b22U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hff2c11ba__0)))));
    vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___026261_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b0__05d));
    vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___026165_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d));
    vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___026357_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fp__05b0__05d));
    vlSelf->wasmetal_core__DOT___071486_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0))))));
    vlSelf->wasmetal_core__DOT___071482_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0))))));
    vlSelf->wasmetal_core__DOT___071473_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0))))));
    vlSelf->wasmetal_core__DOT___070571_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d))));
    vlSelf->wasmetal_core__DOT___044147_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hba5a1633__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128343___DI))))));
    vlSelf->wasmetal_core__DOT___044146_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053337_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b25__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b24__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h347304aa__0))))));
    vlSelf->wasmetal_core__DOT___044151_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128334___DI)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b56__05d)))));
    vlSelf->wasmetal_core__DOT___128498___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128498___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___053343_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044142_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044148_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___044149_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___044145_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x40000000U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___044150_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044144_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128343___DI)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128334___DI)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128330___DI)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053337_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b24__05d)))))))) 
                                                                             << 2U)) 
                                                                         | ((2U 
                                                                             & ((IData)(
                                                                                (0x100000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hba5a1633__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b57__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b56__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h347304aa__0))))))) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___044131_)))))))))))));
    vlSelf->wasmetal_core__DOT___044143_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044131_))));
    vlSelf->wasmetal_core__DOT___070936_ = (1U & (IData)(
                                                         (0x9009000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070932_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___070931_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___070935_ = (1U & (IData)(
                                                         (0x9000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070930_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___070929_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070928_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x9009000000009009ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b12__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b12__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b10__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b8__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b8__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128615___O 
        = ((1U | ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d)) 
                         << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d)) 
                                           << 2U)) 
                                    | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d)) 
                                             << 1U))))) 
           ^ (3U | (((IData)(vlSelf->wasmetal_core__DOT___128509___DOT____VdfgTmp_h9d2c3928__0) 
                     << 3U) | (4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d)) 
                                     << 2U)))));
    vlSelf->wasmetal_core__DOT___033042_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128509___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128567___O 
        = ((1U | ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b2__05d)) 
                         << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b1__05d)) 
                                           << 2U)) 
                                    | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                             << 1U))))) 
           ^ (3U | (((IData)(vlSelf->wasmetal_core__DOT___128534___DOT____VdfgTmp_h9d2c3928__0) 
                     << 3U) | (4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                     << 2U)))));
    vlSelf->wasmetal_core__DOT___128568___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b2__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128534___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___071521_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(__VdfgTmp_hcd919103__0))))));
    vlSelf->wasmetal_core__DOT___071516_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071477_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(__VdfgTmp_hcd919103__0))))));
    vlSelf->wasmetal_core__DOT___071514_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(__VdfgTmp_hcd919103__0))))));
    vlSelf->wasmetal_core__DOT___071499_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(__VdfgTmp_hcd919103__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0))))));
    vlSelf->wasmetal_core__DOT___071493_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(__VdfgTmp_hcd919103__0)) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___071477_))));
    vlSelf->wasmetal_core__DOT___071491_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(__VdfgTmp_hcd919103__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0))))));
    vlSelf->wasmetal_core__DOT___048947_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(__VdfgTmp_hcd919103__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc1ba27eb__0))));
    vlSelf->wasmetal_core__DOT___044248_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048499_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (vlSelf->insn_x 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___062982_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0))))));
    vlSelf->__VdfgTmp_h13477f5c__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->insn_valid));
    vlSelf->wasmetal_core__DOT___052992_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0))))));
    vlSelf->wasmetal_core__DOT___052864_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0))))));
    vlSelf->wasmetal_core__DOT___051013_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0))))));
    vlSelf->wasmetal_core__DOT___070577_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070576_))));
    vlSelf->wasmetal_core__DOT___070578_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070576_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 6U)))));
    vlSelf->wasmetal_core__DOT___052856_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048111_))));
    vlSelf->wasmetal_core__DOT___019394_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d)))));
    vlSelf->wasmetal_core__DOT___052652_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0))))));
    vlSelf->wasmetal_core__DOT___053004_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048111_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0))))));
    vlSelf->wasmetal_core__DOT___048517_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0))))));
    vlSelf->wasmetal_core__DOT___052993_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0))))));
    vlSelf->wasmetal_core__DOT___051015_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0))))));
    vlSelf->wasmetal_core__DOT___048109_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___048480_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0))))));
    vlSelf->wasmetal_core__DOT___048478_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0))))));
    vlSelf->__VdfgTmp_h6c590b04__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___048111_));
    vlSelf->wasmetal_core__DOT___044234_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 2U))))));
    vlSelf->__VdfgTmp_h6253e4f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___001241_) 
                                       << 1U) | (1U 
                                                 & (0x4000U 
                                                    >> 
                                                    (0xfU 
                                                     & (vlSelf->insn_op 
                                                        >> 4U)))));
    vlSelf->wasmetal_core__DOT___070626_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002988_))));
    vlSelf->wasmetal_core__DOT___048447_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000366_))));
    vlSelf->wasmetal_core__DOT___045654_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_op 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 7U))))));
    vlSelf->__VdfgTmp_h5f7c118b__0 = (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                       << 1U) | (1U 
                                                 & (0x1000U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h682c3842__0))));
    vlSelf->wasmetal_core__DOT___045676_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (vlSelf->insn_op 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___070624_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002994_))));
    vlSelf->wasmetal_core__DOT___045673_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002994_))));
    vlSelf->wasmetal_core__DOT___042539_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (1ULL 
                                                                 >> 
                                                                 (vlSelf->insn_op 
                                                                  >> 0x1aU)))))));
    vlSelf->wasmetal_core__DOT___003042_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___003043_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___003044_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___003045_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___042590_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xeU 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 0x18U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___003014_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->wasmetal_core__DOT___003013_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000158_))));
    vlSelf->__VdfgTmp_h71254871__0 = ((4U & (vlSelf->insn_op 
                                             >> 1U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h20102633__0));
    vlSelf->wasmetal_core__DOT___002984_ = (1U & (0x100U 
                                                  >> 
                                                  ((8U 
                                                    & vlSelf->insn_op) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h20102633__0)))));
    vlSelf->wasmetal_core__DOT___054680_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (1ULL 
                                                                        >> 
                                                                        (0x3fU 
                                                                         & (vlSelf->insn_x 
                                                                            >> 0x14U)))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & (vlSelf->insn_x 
                                                                       >> 6U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x17U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_x 
                                                                        >> 0x11U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0xdU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___044243_)))))))));
    vlSelf->__VdfgTmp_h2d79cdd9__0 = ((2U & (vlSelf->insn_x 
                                             >> 7U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___044243_));
    vlSelf->wasmetal_core__DOT___048293_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x100000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___048288_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b22__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b11__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b10__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b9__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b8__05d)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048290_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048289_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b29__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b28__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b27__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b26__05d))))))))))));
    vlSelf->wasmetal_core__DOT___053405_ = (1U & (IData)(
                                                         (0x9000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___053400_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___053399_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___053398_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x9009000000009009ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b12__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b12__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b10__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b8__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b8__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___053406_ = (1U & (IData)(
                                                         (0x9009000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___053402_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___053401_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___048303_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x1000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0))))));
    vlSelf->__VdfgTmp_h87f36829__0 = ((2U & ((0x100U 
                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000366_));
    vlSelf->wasmetal_core__DOT___000368_ = (1U & (IData)(
                                                         ((0U 
                                                           == 
                                                           (0x3000U 
                                                            & vlSelf->insn_op)) 
                                                          & (1ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h8e88a732__0)))));
    vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___043997_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b27__05d) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b26__05d) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b28__05d) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b25__05d) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b24__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b29__05d)))))))) 
                                            & ((IData)(wasmetal_core__DOT___044001_) 
                                               & ((IData)(wasmetal_core__DOT___044000_) 
                                                  & ((~ (IData)(wasmetal_core__DOT___044006_)) 
                                                     & (~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b11__05d))))));
    vlSelf->wasmetal_core__DOT___044011_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b25__05d) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b24__05d) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b29__05d) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b28__05d) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b27__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b26__05d)))))))) 
                                            & ((IData)(wasmetal_core__DOT___044015_) 
                                               & ((IData)(wasmetal_core__DOT___044014_) 
                                                  & ((~ (IData)(wasmetal_core__DOT___044020_)) 
                                                     & (~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b11__05d))))));
    vlSelf->wasmetal_core__DOT___043969_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b25__05d) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b24__05d) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b29__05d) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b28__05d) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b27__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b26__05d)))))))) 
                                            & ((IData)(wasmetal_core__DOT___043973_) 
                                               & ((IData)(wasmetal_core__DOT___043972_) 
                                                  & ((~ (IData)(wasmetal_core__DOT___043978_)) 
                                                     & (~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b11__05d))))));
    vlSelf->wasmetal_core__DOT___043983_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b24__05d) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b27__05d) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b28__05d) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b26__05d) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b25__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b29__05d)))))))) 
                                            & ((IData)(wasmetal_core__DOT___043987_) 
                                               & ((IData)(wasmetal_core__DOT___043986_) 
                                                  & ((~ (IData)(wasmetal_core__DOT___043992_)) 
                                                     & (~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b11__05d))))));
    vlSelf->wasmetal_core__DOT___000188_ = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b27__05d)
                                              ? ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b29__05d) 
                                                 & (IData)(wasmetal_core__DOT___000207_))
                                              : ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b29__05d)) 
                                                 & (IData)(wasmetal_core__DOT___000207_))) 
                                            & ((IData)(
                                                       (0x9009000000009009ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b10__05d) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b12__05d) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b6__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b8__05d) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b2__05d) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b4__05d)))))))) 
                                               & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___000199_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___000198_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___000197_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((9U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b19__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b21__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((9U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b15__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b17__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x9009U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b11__05d) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b9__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b2__05d__02eread_row__05b8__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b10__05d)))))))))))))));
    vlSelf->wasmetal_core__DOT___000269_ = ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b11__05d)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d) 
                                                & (IData)(wasmetal_core__DOT___000290_))
                                             : ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d)) 
                                                & (IData)(wasmetal_core__DOT___000290_)));
    vlSelf->wasmetal_core__DOT___000270_ = ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b13__05d)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b15__05d) 
                                                & (IData)(wasmetal_core__DOT___000294_))
                                             : ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b15__05d)) 
                                                & (IData)(wasmetal_core__DOT___000294_)));
    vlSelf->wasmetal_core__DOT___000271_ = ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b19__05d)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b21__05d) 
                                                & (IData)(wasmetal_core__DOT___000298_))
                                             : ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b21__05d)) 
                                                & (IData)(wasmetal_core__DOT___000298_)));
    vlSelf->wasmetal_core__DOT___000311_ = ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b11__05d)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d) 
                                                & (IData)(wasmetal_core__DOT___000333_))
                                             : ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d)) 
                                                & (IData)(wasmetal_core__DOT___000333_)));
    vlSelf->wasmetal_core__DOT___000312_ = ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b27__05d)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b29__05d) 
                                                & (IData)(wasmetal_core__DOT___000337_))
                                             : ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b29__05d)) 
                                                & (IData)(wasmetal_core__DOT___000337_)));
    vlSelf->wasmetal_core__DOT___000220_ = ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b11__05d)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d) 
                                                & (IData)(wasmetal_core__DOT___000242_))
                                             : ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d)) 
                                                & (IData)(wasmetal_core__DOT___000242_)));
    vlSelf->wasmetal_core__DOT___000221_ = ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b27__05d)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b29__05d) 
                                                & (IData)(wasmetal_core__DOT___000246_))
                                             : ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b29__05d)) 
                                                & (IData)(wasmetal_core__DOT___000246_)));
    vlSelf->wasmetal_core__DOT___135236___DOT__CO__BRA__0__KET__ 
        = (1U & ((4U >> (IData)(vlSelf->__VdfgTmp_h2780d718__0)) 
                 | (vlSelf->insn_op >> 1U)));
    vlSelf->__VdfgTmp_ha8374813__0 = ((8U & (vlSelf->insn_op 
                                             << 1U)) 
                                      | ((4U & (vlSelf->insn_op 
                                                >> 1U)) 
                                         | (IData)(vlSelf->__VdfgTmp_h2780d718__0)));
    vlSelf->wasmetal_core__DOT___001230_ = (1U & (0x1000U 
                                                  >> 
                                                  ((0xcU 
                                                    & vlSelf->insn_op) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2780d718__0))));
    vlSelf->wasmetal_core__DOT___135390___DOT__CO__BRA__0__KET__ 
        = (1U & (5U >> (IData)(vlSelf->__VdfgTmp_h2780d718__0)));
    vlSelf->wasmetal_core__DOT___044066_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7a4c1007__0))))));
    vlSelf->wasmetal_core__DOT___044086_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7a4c1007__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048346_))));
    vlSelf->wasmetal_core__DOT___002985_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7a4c1007__0)))));
    vlSelf->wasmetal_core__DOT___044231_ = (1U & (0xffff80ffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 6U))) 
                                                          << 3U)) 
                                                      | ((6U 
                                                          & (vlSelf->insn_op 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000375_))))));
    vlSelf->wasmetal_core__DOT___048329_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (3U 
                                                          & (vlSelf->insn_op 
                                                             >> 6U)))))));
    vlSelf->wasmetal_core__DOT___048336_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 6U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0))))));
    vlSelf->wasmetal_core__DOT___007028_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 6U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0))))));
    vlSelf->wasmetal_core__DOT___001234_ = (1U & (0x100U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 3U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 5U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3ca161df__0)))));
    vlSelf->__VdfgTmp_h695ce273__0 = ((0xcU & (vlSelf->insn_op 
                                               >> 4U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h3ca161df__0));
    vlSelf->wasmetal_core__DOT___044162_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7a4c1007__0))))));
    vlSelf->wasmetal_core__DOT___070615_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000378_))));
    vlSelf->wasmetal_core__DOT___044703_ = (1U & (0x7150U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->function_params 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (vlSelf->function_params 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbb12d5bf__0)))));
    vlSelf->wasmetal_core__DOT___135298___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044624_)
                  ? (~ (1U >> (IData)(vlSelf->__VdfgTmp_hbb12d5bf__0)))
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___044624_))));
    vlSelf->wasmetal_core__DOT___048272_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___DI))));
    vlSelf->wasmetal_core__DOT___044626_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___DI))))));
    vlSelf->__VdfgTmp_h58bd40ba__0 = (((IData)(wasmetal_core__DOT___128593___DOT__CO__BRA__1__KET__) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___000248_ = ((IData)(vlSelf->wasmetal_core__DOT___043961_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___043960_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___043959_) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___043964_)) 
                                                     & (~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d))))));
    vlSelf->wasmetal_core__DOT___001233_ = (1U & (IData)(
                                                         ((0x100U 
                                                           == 
                                                           (0x1100U 
                                                            & vlSelf->insn_op)) 
                                                          & (1ULL 
                                                             >> 
                                                             ((0x20U 
                                                               & (vlSelf->insn_op 
                                                                  >> 8U)) 
                                                              | ((0x10U 
                                                                  & (vlSelf->insn_op 
                                                                     >> 0xaU)) 
                                                                 | ((8U 
                                                                     & (vlSelf->insn_op 
                                                                        >> 0xcU)) 
                                                                    | ((4U 
                                                                        & (vlSelf->insn_op 
                                                                           >> 7U)) 
                                                                       | (IData)(__VdfgTmp_h225c4799__0)))))))));
    vlSelf->wasmetal_core__DOT___054454_ = (1U & (1U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 9U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 0xbU)) 
                                                      | (IData)(__VdfgTmp_h225c4799__0)))));
    vlSelf->wasmetal_core__DOT___048515_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha3f5bbbb__0))));
    vlSelf->wasmetal_core__DOT___048276_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_op 
                                                               >> 0xeU)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (1ULL 
                                                                           >> 
                                                                           (vlSelf->insn_op 
                                                                            >> 0x1aU))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & (vlSelf->insn_op 
                                                                          >> 0x10U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x8000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_op 
                                                                           >> 0x11U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (3U 
                                                                              & (vlSelf->insn_op 
                                                                                >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___000354_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha3f5bbbb__0)))));
    vlSelf->wasmetal_core__DOT___000356_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (1ULL 
                                                                        >> 
                                                                        (vlSelf->insn_op 
                                                                         >> 0x1aU))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_op 
                                                                  >> 0xcU)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & (vlSelf->insn_op 
                                                                          >> 0x12U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x8000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_op 
                                                                           >> 0x10U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (3U 
                                                                              & (vlSelf->insn_op 
                                                                                >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___044063_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xeU 
                                                         >> 
                                                         (3U 
                                                          & (vlSelf->insn_op 
                                                             >> 0x18U)))))));
    vlSelf->__VdfgTmp_hc705d0d5__0 = ((2U & ((0x8000U 
                                              >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                             << 1U)) 
                                      | (1U & (0xeU 
                                               >> (3U 
                                                   & (vlSelf->insn_op 
                                                      >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___047780_ = (1U & (0x1000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 4U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h752c22b4__0)))));
    vlSelf->__VdfgTmp_he33f1ed5__0 = ((2U & ((0x1000U 
                                              >> (0xfU 
                                                  & (vlSelf->insn_op 
                                                     >> 0x10U))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054455_));
    vlSelf->wasmetal_core__DOT___070621_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 0x10U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054455_)))));
    vlSelf->wasmetal_core__DOT___044062_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054455_))));
    vlSelf->wasmetal_core__DOT___044170_ = (1U & (0xf400U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 0x12U))) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & (vlSelf->insn_op 
                                                          >> 0xfU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054455_)))));
    vlSelf->wasmetal_core__DOT___044174_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054455_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 0xeU)) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & (vlSelf->insn_op 
                                                                  >> 0x12U))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 0x11U)))))));
    vlSelf->wasmetal_core__DOT___052985_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052984_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___052983_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___052982_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052970_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052969_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___052968_) 
                                                                                << 3U) 
                                                                                | ((6U 
                                                                                & (vlSelf->mem_rdata[2U] 
                                                                                >> 0x15U)) 
                                                                                | (1U 
                                                                                & (vlSelf->mem_rdata[2U] 
                                                                                >> 0x10U)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052978_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052977_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___052976_) 
                                                                                << 3U) 
                                                                                | ((6U 
                                                                                & (vlSelf->mem_rdata[1U] 
                                                                                >> 0x15U)) 
                                                                                | (1U 
                                                                                & (vlSelf->mem_rdata[1U] 
                                                                                >> 0x10U)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052960_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052959_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___052958_) 
                                                                                << 3U) 
                                                                                | ((6U 
                                                                                & (vlSelf->mem_rdata[3U] 
                                                                                >> 0x15U)) 
                                                                                | (1U 
                                                                                & (vlSelf->mem_rdata[3U] 
                                                                                >> 0x10U)))))))))))))))));
    vlSelf->wasmetal_core__DOT___051227_ = (1U & (0x1400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___038805_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & (IData)(vlSelf->cmd_kind)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->cmd_kind) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128793___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128793___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128793___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035884_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d)
                                             : (IData)(wasmetal_core__DOT___128793___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063392_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063391_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063389_) 
                                                                  << 3U) 
                                                                 | (vlSelf->function_locals 
                                                                    >> 0x1dU)))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128720___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128720___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128720___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035215_ = ((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128720___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___049544_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128026___O 
        = (((0xeU & vlSelf->insn_z) | (1U & (~ vlSelf->insn_z))) 
           ^ (((IData)(wasmetal_core__DOT___128026___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128026___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & (vlSelf->insn_z 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___027954_ = ((vlSelf->insn_z 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128026___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128266___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 3U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 2U)) << 2U)) 
                              | ((2U & ((~ (vlSelf->mem_rdata[0U] 
                                            >> 1U)) 
                                        << 1U)) | (1U 
                                                   & vlSelf->mem_rdata[0U])))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128266___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128266___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & (vlSelf->mem_rdata[0U] 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT___030489_ = (1U & ((8U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 3U)
                                                   : (IData)(wasmetal_core__DOT___128266___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128002___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128002___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128002___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027729_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128002___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128034___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128034___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128034___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028019_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128034___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128155___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128155___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128155___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029310_ = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128155___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128188___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128188___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128188___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029672_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b3__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128188___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128205___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128205___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128205___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029841_ = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b3__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128205___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128370___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128370___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128370___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___031611_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128370___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___053308_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x9000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053305_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053304_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053303_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((9U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b5__05d))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b1__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b1__05d)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x9009000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___053295_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053294_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b21__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b21__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b17__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b17__05d))))))))))));
    vlSelf->wasmetal_core__DOT___045941_ = ((IData)(vlSelf->wasmetal_core__DOT___045964_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045973_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045972_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045971_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045970_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045969_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045968_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045967_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045966_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045965_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045963_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045951_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045953_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045954_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045955_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045956_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045957_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045958_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045959_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045960_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045961_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045952_));
    vlSelf->wasmetal_core__DOT____Vcellout___128418___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128418___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128418___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032092_ = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128418___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063418_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051236_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d))));
    vlSelf->wasmetal_core__DOT___063013_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050385_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___050467_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050385_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___044659_))));
    vlSelf->wasmetal_core__DOT___050438_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___044659_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050385_))));
    vlSelf->wasmetal_core__DOT___052939_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x9000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052936_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052935_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052934_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((9U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b5__05d))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b1__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b1__05d)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x9009000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___052926_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___052925_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b21__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b21__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b17__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b17__05d))))))))))));
    vlSelf->wasmetal_core__DOT___053330_ = (1U & (IData)(
                                                         (0x9009000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053312_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053311_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b79__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_y 
                                                                        >> 0xdU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b78__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0xeU))))))))));
    vlSelf->wasmetal_core__DOT___044200_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044214_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044213_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044212_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044211_) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___044203_))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044212_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044213_)))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044214_))));
    vlSelf->wasmetal_core__DOT___063379_ = (1U & (IData)(
                                                         (0x5500cc000f0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052949_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052954_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->mem_fault)))))))));
    vlSelf->wasmetal_core__DOT___049551_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___050090_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___051231_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___050133_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___049548_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___049547_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___049546_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___051249_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___051248_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___050294_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050296_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050280_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050285_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___049445_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___049446_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___049593_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___050495_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___049585_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___051263_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___051260_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___051279_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___051262_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___051261_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051302_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___051259_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___051257_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___051256_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050909_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___051255_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050156_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___050134_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___049443_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___049442_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___049441_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___050305_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050298_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___050297_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___048576_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___048574_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___049058_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___049391_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___049393_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050306_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050304_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050299_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___051247_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___049350_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___049349_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___049389_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___049348_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___049346_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___051241_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___051242_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___050157_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___050902_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051238_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___051237_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___050747_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___049004_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___048963_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___048692_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___048301_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___048682_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___050503_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049727_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___050502_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048567_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___050497_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049347_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___050496_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049345_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___051258_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049550_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049829_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049543_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049828_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048575_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049826_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048571_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049827_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048510_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049824_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049390_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049773_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049392_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049774_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049003_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049730_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048962_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049728_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048546_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049729_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048298_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___050786_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048536_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___049727_))));
    vlSelf->wasmetal_core__DOT___049681_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___051254_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___049682_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___049680_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___049679_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___049929_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___049930_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___050163_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051250_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___051251_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___050328_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050267_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050295_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050270_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050293_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___050271_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___050290_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___050292_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___050288_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___050289_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050287_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___050286_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___050284_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___050283_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___050282_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___050281_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___049604_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050071_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___049605_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___049862_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___049597_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___049920_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___050070_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___050037_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___051275_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___050036_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___051273_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___050473_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___050087_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___050474_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___050472_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___050393_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___050477_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___051123_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050903_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050072_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___049592_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___050563_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___049591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___051216_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___051215_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
}
