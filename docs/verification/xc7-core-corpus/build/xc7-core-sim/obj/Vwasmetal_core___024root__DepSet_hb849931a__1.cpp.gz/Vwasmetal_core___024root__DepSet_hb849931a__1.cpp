#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__1(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__1\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___044659_;
    wasmetal_core__DOT___044659_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052958_;
    wasmetal_core__DOT___052958_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052968_;
    wasmetal_core__DOT___052968_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052976_;
    wasmetal_core__DOT___052976_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052982_;
    wasmetal_core__DOT___052982_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052983_;
    wasmetal_core__DOT___052983_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064364_;
    wasmetal_core__DOT___064364_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064365_;
    wasmetal_core__DOT___064365_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064369_;
    wasmetal_core__DOT___064369_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064410_;
    wasmetal_core__DOT___064410_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064414_;
    wasmetal_core__DOT___064414_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064415_;
    wasmetal_core__DOT___064415_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064420_;
    wasmetal_core__DOT___064420_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064421_;
    wasmetal_core__DOT___064421_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064424_;
    wasmetal_core__DOT___064424_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064425_;
    wasmetal_core__DOT___064425_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065223_;
    wasmetal_core__DOT___065223_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065380_;
    wasmetal_core__DOT___065380_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065485_;
    wasmetal_core__DOT___065485_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065509_;
    wasmetal_core__DOT___065509_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065649_;
    wasmetal_core__DOT___065649_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065743_;
    wasmetal_core__DOT___065743_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065761_;
    wasmetal_core__DOT___065761_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065844_;
    wasmetal_core__DOT___065844_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065956_;
    wasmetal_core__DOT___065956_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066027_;
    wasmetal_core__DOT___066027_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066180_;
    wasmetal_core__DOT___066180_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066225_;
    wasmetal_core__DOT___066225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066336_;
    wasmetal_core__DOT___066336_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066434_;
    wasmetal_core__DOT___066434_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066500_;
    wasmetal_core__DOT___066500_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066581_;
    wasmetal_core__DOT___066581_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069655_;
    wasmetal_core__DOT___069655_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128026___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128026___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128266___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128266___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h225c4799__0;
    __VdfgTmp_h225c4799__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___070610_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_op 
                                                       >> 5U)) 
                                                   | ((2U 
                                                       & (vlSelf->insn_op 
                                                          >> 4U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 6U))))));
    __VdfgTmp_h225c4799__0 = ((2U & (vlSelf->insn_op 
                                     >> 9U)) | (1U 
                                                & (vlSelf->insn_op 
                                                   >> 0xbU)));
    vlSelf->__VdfgTmp_hf3a49853__0 = ((8U & (vlSelf->insn_op 
                                             >> 0x11U)) 
                                      | ((4U & (vlSelf->insn_op 
                                                >> 0x13U)) 
                                         | ((2U & (vlSelf->insn_op 
                                                   >> 0x15U)) 
                                            | (1U & 
                                               (vlSelf->insn_op 
                                                >> 0x17U)))));
    vlSelf->__VdfgTmp_h752c22b4__0 = ((2U & (vlSelf->insn_op 
                                             >> 6U)) 
                                      | (1U & (vlSelf->insn_op 
                                               >> 5U)));
    vlSelf->wasmetal_core__DOT___054455_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 0xdU)) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 0xfU)))));
    vlSelf->wasmetal_core__DOT___036780_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036619_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf9e7c209__0))));
    vlSelf->wasmetal_core__DOT___069281_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069276_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b64__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069310_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069307_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069306_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b65__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069338_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069334_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069333_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b66__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & vlSelf->cmd_data[2U]) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069361_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069358_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069357_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b67__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069386_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069383_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069382_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b68__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069412_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069409_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069408_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b69__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 3U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069438_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069433_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069432_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b70__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 4U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069463_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069459_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069458_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b71__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 5U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069491_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069487_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069486_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b72__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 6U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069557_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069554_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069553_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b75__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 9U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069628_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069623_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069622_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b78__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0xcU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069673_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069669_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069668_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b80__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0xeU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069848_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069843_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069842_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b88__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x16U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069869_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069864_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069863_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b89__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x17U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069889_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069884_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069883_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b90__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x18U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069910_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069905_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069904_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b91__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x19U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069930_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069925_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069924_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b92__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x1aU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___069951_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069946_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069945_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b93__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x1bU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___070011_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070007_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070006_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b96__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___036779_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf9e7c209__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h586b57d5__0))));
    vlSelf->wasmetal_core__DOT___036777_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h586b57d5__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h364ba349__0))));
    vlSelf->wasmetal_core__DOT___070365_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068912_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___063420_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063376_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h13477f5c__0))));
    vlSelf->wasmetal_core__DOT___036776_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h364ba349__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd2526c88__0))));
    vlSelf->wasmetal_core__DOT___070377_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068979_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___070389_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069010_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0x1bU))))));
    vlSelf->wasmetal_core__DOT___070337_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066943_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067563_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0x15U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x16U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___070439_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069211_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[1U] 
                                                         >> 0x1fU)))));
    wasmetal_core__DOT___052958_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052957_) 
                                                    << 5U) 
                                                   | ((0x18U 
                                                       & (vlSelf->mem_rdata[0U] 
                                                          >> 0xaU)) 
                                                      | (7U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 2U)))))));
    wasmetal_core__DOT___052968_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052967_) 
                                                    << 5U) 
                                                   | ((0x18U 
                                                       & (vlSelf->mem_rdata[1U] 
                                                          >> 0x19U)) 
                                                      | (7U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 1U)))))));
    wasmetal_core__DOT___052982_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052964_) 
                                                    << 5U) 
                                                   | ((0x18U 
                                                       & (vlSelf->mem_rdata[2U] 
                                                          >> 9U)) 
                                                      | (7U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 1U)))))));
    wasmetal_core__DOT___052976_ = (1U & (IData)((0x4000000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->mem_rdata[3U] 
                                                            >> 2U))) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052974_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052973_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (1ULL 
                                                                         >> 
                                                                         ((0x30U 
                                                                           & (vlSelf->mem_rdata[2U] 
                                                                              >> 0x16U)) 
                                                                          | ((0xcU 
                                                                              & (vlSelf->mem_rdata[2U] 
                                                                                >> 8U)) 
                                                                             | (3U 
                                                                                & (vlSelf->mem_rdata[2U] 
                                                                                >> 4U)))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((1U 
                                                                    >> 
                                                                    (3U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xcU))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (vlSelf->mem_rdata[3U] 
                                                                     >> 1U))))))))));
    wasmetal_core__DOT___052983_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052963_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052962_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052961_) 
                                                          << 3U) 
                                                         | ((6U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 0x16U)) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0x11U)))))))));
    vlSelf->wasmetal_core__DOT___038805_ = (1U & ((IData)(
                                                          (1ULL 
                                                           >> 
                                                           (vlSelf->cmd_index 
                                                            >> 0x1aU))) 
                                                  & ((IData)(
                                                             (1ULL 
                                                              >> 
                                                              (0x3fU 
                                                               & (vlSelf->cmd_index 
                                                                  >> 0x14U)))) 
                                                     & ((IData)(
                                                                (1ULL 
                                                                 >> 
                                                                 (0x3fU 
                                                                  & (vlSelf->cmd_index 
                                                                     >> 0xeU)))) 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT___045803_)) 
                                                           & (4U 
                                                              >> 
                                                              ((2U 
                                                                & ((1U 
                                                                    >> 
                                                                    (0x1fU 
                                                                     & (vlSelf->cmd_index 
                                                                        >> 9U))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (vlSelf->cmd_index 
                                                                     >> 8U)))))))));
    vlSelf->wasmetal_core__DOT___070287_ = (1U & (0x7770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066556_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067563_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0x11U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x12U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___036775_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd2526c88__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h93f91ca8__0))));
    vlSelf->wasmetal_core__DOT___063431_ = (1U & (IData)(
                                                         (0x11fff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063379_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbbbbfffff0ff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053257_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___045525_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__copy_next__05b3__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___045941_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063375_)))))))));
    vlSelf->wasmetal_core__DOT___063382_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063379_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d)))));
    vlSelf->wasmetal_core__DOT___052587_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045744_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->busy))));
    vlSelf->wasmetal_core__DOT___063389_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (0xfU 
                                                                 & (vlSelf->function_locals 
                                                                    >> 5U))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063385_) 
                                                               << 4U) 
                                                              | (0xfU 
                                                                 & (vlSelf->function_locals 
                                                                    >> 9U)))))));
    vlSelf->wasmetal_core__DOT___036774_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h93f91ca8__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4835143f__0))));
    vlSelf->wasmetal_core__DOT___065590_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065582_))));
    vlSelf->wasmetal_core__DOT___019392_ = (1U & (0xf800U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065582_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065587_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xeU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065584_))))));
    vlSelf->wasmetal_core__DOT___044731_ = (1U & ((1U 
                                                   & (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->function_params 
                                                               >> 0x1aU))))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(
                                                              (1ULL 
                                                               >> 
                                                               (0x3fU 
                                                                & (vlSelf->function_params 
                                                                   >> 0x14U)))))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (0x3fU 
                                                                 & (vlSelf->function_params 
                                                                    >> 0xeU)))))
                                                     ? 
                                                    ((1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h26309c84__0)))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(
                                                                 (1ULL 
                                                                  >> 
                                                                  (0x3fU 
                                                                   & (vlSelf->function_params 
                                                                      >> 2U)))))
                                                       ? 
                                                      (~ 
                                                       (1U 
                                                        >> 
                                                        (3U 
                                                         & vlSelf->function_params)))
                                                       : 
                                                      (~ (IData)(
                                                                 (1ULL 
                                                                  >> 
                                                                  (0x3fU 
                                                                   & (vlSelf->function_params 
                                                                      >> 2U))))))
                                                      : 
                                                     (4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h26309c84__0)))
                                                     : 
                                                    (~ (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (0x3fU 
                                                                 & (vlSelf->function_params 
                                                                    >> 0xeU))))))
                                                    : 
                                                   (~ (IData)(
                                                              (1ULL 
                                                               >> 
                                                               (0x3fU 
                                                                & (vlSelf->function_params 
                                                                   >> 0x14U))))))
                                                   : 
                                                  (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->function_params 
                                                               >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___069721_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066556_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069653_))));
    vlSelf->wasmetal_core__DOT___069764_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066724_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069653_))));
    vlSelf->wasmetal_core__DOT___069808_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066943_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069653_))));
    wasmetal_core__DOT___069655_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___066375_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___069653_))));
    vlSelf->wasmetal_core__DOT___036773_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4835143f__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf6334cf8__0))));
    vlSelf->wasmetal_core__DOT___070130_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 8U))))));
    vlSelf->wasmetal_core__DOT___070203_ = (1U & (0x7707U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xbU)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0xcU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___070218_ = (1U & (0x7707U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 0xcU)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0xdU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___070144_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 9U))))));
    vlSelf->wasmetal_core__DOT___070171_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0xbU))))));
    vlSelf->wasmetal_core__DOT___070158_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0xaU))))));
    vlSelf->wasmetal_core__DOT___070232_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[1U] 
                                                            >> 0xfU))))));
    vlSelf->wasmetal_core__DOT___036772_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf6334cf8__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2b80e318__0))));
    vlSelf->wasmetal_core__DOT___036771_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2b80e318__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h17547017__0))));
    vlSelf->wasmetal_core__DOT___036770_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17547017__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hed077be7__0))));
    vlSelf->wasmetal_core__DOT___036769_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hed077be7__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1872cc15__0))));
    wasmetal_core__DOT___044659_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044682_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___044691_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___044690_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044689_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044688_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044687_)
                                                      ? 
                                                     ((1U 
                                                       & (IData)(
                                                                 (1ULL 
                                                                  >> 
                                                                  (0x3fU 
                                                                   & (IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x16U))))))
                                                       ? 
                                                      ((1U 
                                                        & (IData)(
                                                                  (1ULL 
                                                                   >> 
                                                                   (0x3fU 
                                                                    & (IData)(
                                                                              (vlSelf->cmd_aux 
                                                                               >> 0x10U))))))
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044684_)
                                                         ? 
                                                        ((1U 
                                                          & (IData)(
                                                                    (1ULL 
                                                                     >> 
                                                                     (0x3fU 
                                                                      & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 4U))))))
                                                          ? 
                                                         (~ 
                                                          (1U 
                                                           >> 
                                                           (0xfU 
                                                            & (IData)(vlSelf->cmd_aux))))
                                                          : 
                                                         (~ (IData)(
                                                                    (1ULL 
                                                                     >> 
                                                                     (0x3fU 
                                                                      & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 4U)))))))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044672_))
                                                        : 
                                                       (~ (IData)(
                                                                  (1ULL 
                                                                   >> 
                                                                   (0x3fU 
                                                                    & (IData)(
                                                                              (vlSelf->cmd_aux 
                                                                               >> 0x10U)))))))
                                                       : 
                                                      (~ (IData)(
                                                                 (1ULL 
                                                                  >> 
                                                                  (0x3fU 
                                                                   & (IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x16U)))))))
                                                      : 
                                                     (~ (IData)(vlSelf->wasmetal_core__DOT___044687_)))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044688_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044689_)))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044690_)))
                                               : (~ (IData)(vlSelf->wasmetal_core__DOT___044691_)))
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___044682_))));
    vlSelf->wasmetal_core__DOT___036768_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1872cc15__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9473bd37__0))));
    vlSelf->wasmetal_core__DOT___069285_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065647_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___069497_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065647_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 6U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 7U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___066457_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066456_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065647_))));
    vlSelf->wasmetal_core__DOT___067042_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067039_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065647_))));
    vlSelf->wasmetal_core__DOT___069342_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065842_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___069543_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065842_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 8U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 9U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___067216_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065842_))));
    wasmetal_core__DOT___128026___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_z >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128026___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128266___DOT__CO__BRA__2__KET__ 
        = (1U & ((4U & vlSelf->mem_rdata[0U]) ? (vlSelf->mem_rdata[0U] 
                                                 >> 2U)
                  : (IData)(vlSelf->wasmetal_core__DOT___128266___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___069264_ = (1U & (0xbb0bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065572_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067560_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069260_)))))));
    vlSelf->wasmetal_core__DOT___069474_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065572_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 8U)))))));
    vlSelf->wasmetal_core__DOT___066996_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065572_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7eff58ec__0))));
    vlSelf->wasmetal_core__DOT___070191_ = (1U & (IData)(
                                                         (0x503000305030f030ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070129_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066370_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x47U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065566_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->mem_rdata[0U] 
                                                                                >> 4U))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->mem_rdata[1U] 
                                                                           >> 0x1bU)) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0xcU))))))))));
    vlSelf->wasmetal_core__DOT___070014_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065647_))));
    vlSelf->wasmetal_core__DOT___069997_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065572_))));
    vlSelf->wasmetal_core__DOT___070053_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065842_))));
    vlSelf->wasmetal_core__DOT___069392_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066020_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 5U))))));
    vlSelf->wasmetal_core__DOT___069585_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066020_))));
    vlSelf->wasmetal_core__DOT___070086_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066020_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 2U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 3U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76d711b0__0))))))));
    vlSelf->wasmetal_core__DOT___067360_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067359_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066020_))));
    vlSelf->wasmetal_core__DOT___036766_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9473bd37__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfd696a08__0))));
    vlSelf->wasmetal_core__DOT___066380_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066375_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xdU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 6U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___066947_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066943_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x14U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xdU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___066560_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066556_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x10U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 9U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___066728_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066724_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x12U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xbU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___066997_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 0xfU))))));
    vlSelf->wasmetal_core__DOT___069634_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066218_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xcU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xdU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069449_ = (1U & (0xbb0bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066218_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067560_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 5U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 6U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069260_)))))));
    vlSelf->wasmetal_core__DOT___070112_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066218_))));
    vlSelf->wasmetal_core__DOT___067504_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066218_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7e1b7882__0))));
    vlSelf->wasmetal_core__DOT___066179_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___069418_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066176_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 6U))))));
    vlSelf->wasmetal_core__DOT___070100_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066176_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 4U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76d711b0__0))))))));
    vlSelf->wasmetal_core__DOT___069608_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___067428_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067426_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___066809_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066808_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___069368_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065975_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069365_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 1U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___067560_)))))))));
    vlSelf->wasmetal_core__DOT___069569_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065975_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 9U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xaU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___070070_ = (1U & (IData)(
                                                         (0x2a3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065975_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 1U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76d711b0__0))))))));
    vlSelf->wasmetal_core__DOT___067264_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067262_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065975_))));
    vlSelf->wasmetal_core__DOT___066670_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066669_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065975_))));
    vlSelf->wasmetal_core__DOT___036765_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfd696a08__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb0a19382__0))));
    vlSelf->wasmetal_core__DOT___036764_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0a19382__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h959d8796__0))));
    vlSelf->wasmetal_core__DOT___069517_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065755_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069471_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 7U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 8U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069315_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065755_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069260_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___070036_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065755_))));
    vlSelf->wasmetal_core__DOT___067110_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067108_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065755_))));
    vlSelf->wasmetal_core__DOT___066480_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066479_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065755_))));
    vlSelf->wasmetal_core__DOT___036763_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h959d8796__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6d2d9567__0))));
    vlSelf->wasmetal_core__DOT___070249_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066375_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xdU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xeU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))))));
    vlSelf->wasmetal_core__DOT___070313_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066724_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x12U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x13U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))))));
    vlSelf->wasmetal_core__DOT___070350_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[1U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___036762_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6d2d9567__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h291433ac__0))));
    vlSelf->wasmetal_core__DOT___036761_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h291433ac__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd028268__0))));
    vlSelf->wasmetal_core__DOT___036760_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbd028268__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6265db41__0))));
    vlSelf->wasmetal_core__DOT___036759_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6265db41__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7b2f5a0d__0))));
    vlSelf->__VdfgTmp_h2df5fb6a__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h73f978ac__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & ((IData)(vlSelf->cmd_kind) 
                                                     >> 1U)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___048483_));
    vlSelf->wasmetal_core__DOT___051236_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->cmd_kind)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h73f978ac__0))))));
    vlSelf->wasmetal_core__DOT___050385_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h73f978ac__0)) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & (IData)(vlSelf->cmd_kind)))));
    vlSelf->wasmetal_core__DOT___036758_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7b2f5a0d__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h86617c98__0))));
    vlSelf->wasmetal_core__DOT___036757_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h86617c98__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h20c332a4__0))));
    vlSelf->wasmetal_core__DOT___036787_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h20c332a4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1c8d20fd__0))));
    vlSelf->wasmetal_core__DOT___036786_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1c8d20fd__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5736dc67__0))));
    vlSelf->wasmetal_core__DOT___053312_ = (1U & (IData)(
                                                         (0x4100004100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053310_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b89__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b86__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_y 
                                                                           >> 0x15U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b87__05d) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x17U)))))))))))));
    vlSelf->wasmetal_core__DOT___070490_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->cmd_kind) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0))))));
    vlSelf->wasmetal_core__DOT___070486_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->cmd_kind) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___053094_ = (1U & (0xfe0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->cmd_kind)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->cmd_kind) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->cmd_kind)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->cmd_kind) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___052861_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052858_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0))))));
    vlSelf->wasmetal_core__DOT___036785_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5736dc67__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h13987860__0))));
    vlSelf->wasmetal_core__DOT___036784_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h13987860__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_haa7ff968__0))));
    vlSelf->wasmetal_core__DOT___036783_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_haa7ff968__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h85ffa972__0))));
    vlSelf->wasmetal_core__DOT___036782_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h85ffa972__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h83e5aafb__0))));
    vlSelf->wasmetal_core__DOT___036781_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h83e5aafb__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcb9fc16c__0))));
    vlSelf->wasmetal_core__DOT___036778_ = (1U & (0x4bU 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcb9fc16c__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8befad22__0))));
    vlSelf->wasmetal_core__DOT___067568_ = (1U & (0x7fff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067565_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->mem_rdata[0U] 
                                                          >> 4U)) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065557_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065565_)))))));
    vlSelf->wasmetal_core__DOT___067623_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065647_))));
    vlSelf->wasmetal_core__DOT___067935_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066176_))));
    vlSelf->wasmetal_core__DOT___067772_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065842_))));
    vlSelf->wasmetal_core__DOT___067704_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065755_))));
    vlSelf->wasmetal_core__DOT___067569_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065572_))));
    vlSelf->wasmetal_core__DOT___067833_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065975_))));
    vlSelf->wasmetal_core__DOT___067986_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066218_))));
    vlSelf->wasmetal_core__DOT___067864_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066020_))));
    vlSelf->wasmetal_core__DOT___064711_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___064698_))))))))))));
    vlSelf->wasmetal_core__DOT___065144_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065026_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065143_))));
    vlSelf->wasmetal_core__DOT___064835_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064437_))));
    wasmetal_core__DOT___065223_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064431_))));
    vlSelf->wasmetal_core__DOT___064435_ = (1U & (0xf5f3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064431_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064430_)))));
    wasmetal_core__DOT___065380_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064430_))));
    vlSelf->wasmetal_core__DOT___064689_ = (1U & (0xf5f3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064430_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064433_)))));
    wasmetal_core__DOT___065485_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064433_))));
    vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032866_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___064434_ = (1U & (0xf5f3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064433_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064432_)))));
    wasmetal_core__DOT___065509_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064432_))));
    vlSelf->wasmetal_core__DOT___064688_ = (1U & (0xf3f5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064408_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064432_)))));
    wasmetal_core__DOT___065649_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064408_))));
    wasmetal_core__DOT___064410_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064409_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___065761_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064409_))));
    wasmetal_core__DOT___064414_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064413_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___065956_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064413_))));
    wasmetal_core__DOT___064415_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064412_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___065844_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064412_))));
    wasmetal_core__DOT___064421_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064418_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066027_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064418_))));
    wasmetal_core__DOT___064420_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064419_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066180_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064419_))));
    wasmetal_core__DOT___064425_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064422_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066225_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064422_))));
    wasmetal_core__DOT___064424_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064423_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066336_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064423_))));
    wasmetal_core__DOT___064365_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064362_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066434_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064362_))));
    wasmetal_core__DOT___064364_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064363_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066500_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064363_))));
    vlSelf->wasmetal_core__DOT___069265_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064351_))));
    vlSelf->wasmetal_core__DOT___064352_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064351_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___064369_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___064366_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    wasmetal_core__DOT___066581_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064366_))));
    vlSelf->wasmetal_core__DOT___064368_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064367_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066695_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064367_))));
    vlSelf->wasmetal_core__DOT___064375_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064372_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066748_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064372_))));
    vlSelf->wasmetal_core__DOT___064374_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064373_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066830_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064373_))));
    vlSelf->wasmetal_core__DOT___064379_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064376_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066914_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064376_))));
    vlSelf->wasmetal_core__DOT___064378_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064377_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___066998_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064377_))));
    vlSelf->wasmetal_core__DOT___064387_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064384_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067043_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064384_))));
    vlSelf->wasmetal_core__DOT___069216_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064350_))));
    vlSelf->wasmetal_core__DOT___064353_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064350_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064386_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064385_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067128_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064385_))));
    vlSelf->wasmetal_core__DOT___064391_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064388_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067239_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064388_))));
    vlSelf->wasmetal_core__DOT___069184_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064347_))));
    vlSelf->wasmetal_core__DOT___064348_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064347_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064390_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064389_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067278_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064389_))));
    vlSelf->wasmetal_core__DOT___064397_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064394_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067383_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064394_))));
    vlSelf->wasmetal_core__DOT___069117_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064346_))));
    vlSelf->wasmetal_core__DOT___064349_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064346_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064396_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064395_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067430_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064395_))));
    vlSelf->wasmetal_core__DOT___064401_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064398_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067527_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064398_))));
    vlSelf->wasmetal_core__DOT___069069_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064341_))));
    vlSelf->wasmetal_core__DOT___064342_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064341_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___069022_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064340_))));
    vlSelf->wasmetal_core__DOT___064343_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064340_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068991_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064337_))));
    vlSelf->wasmetal_core__DOT___064338_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064337_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064400_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064399_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067575_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064399_))));
    vlSelf->wasmetal_core__DOT___064271_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064268_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067641_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064268_))));
    vlSelf->wasmetal_core__DOT___068924_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064336_))));
    vlSelf->wasmetal_core__DOT___064339_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064336_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064270_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064269_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067709_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064269_))));
    vlSelf->wasmetal_core__DOT___064275_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064272_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067788_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064272_))));
    vlSelf->wasmetal_core__DOT___068875_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064329_))));
    vlSelf->wasmetal_core__DOT___064330_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064329_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068828_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064328_))));
    vlSelf->wasmetal_core__DOT___064331_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064328_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064274_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064273_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067837_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064273_))));
    vlSelf->wasmetal_core__DOT___068681_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064319_))));
    vlSelf->wasmetal_core__DOT___064320_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064319_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068778_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064325_))));
    vlSelf->wasmetal_core__DOT___064326_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064325_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068728_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064324_))));
    vlSelf->wasmetal_core__DOT___064327_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064324_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064281_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064278_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067880_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064278_))));
    vlSelf->wasmetal_core__DOT___064280_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064279_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___067940_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064279_))));
    vlSelf->wasmetal_core__DOT___064285_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064282_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068003_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064282_))));
    vlSelf->wasmetal_core__DOT___064284_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064283_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068056_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064283_))));
    vlSelf->wasmetal_core__DOT___064297_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064294_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068217_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064294_))));
    vlSelf->wasmetal_core__DOT___068631_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064318_))));
    vlSelf->wasmetal_core__DOT___064321_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064318_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064293_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064290_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068131_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064290_))));
    vlSelf->wasmetal_core__DOT___064296_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064295_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068270_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064295_))));
    vlSelf->wasmetal_core__DOT___064292_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064291_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068183_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064291_))));
    vlSelf->wasmetal_core__DOT___064303_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064300_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068323_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064300_))));
    vlSelf->wasmetal_core__DOT___068581_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064315_))));
    vlSelf->wasmetal_core__DOT___064316_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064315_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___064302_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064301_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068379_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064301_))));
    vlSelf->wasmetal_core__DOT___064317_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064314_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068517_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064314_))));
    vlSelf->wasmetal_core__DOT___064307_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064304_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068454_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064304_))));
    vlSelf->wasmetal_core__DOT___064306_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064305_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))));
    vlSelf->wasmetal_core__DOT___068499_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064305_))));
    vlSelf->wasmetal_core__DOT___053733_ = (1U & (IData)(
                                                         (0xffff3c3fffff23ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)))))))))));
    vlSelf->wasmetal_core__DOT___053007_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xaaaa02aaaaaa282aULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___052997_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053002_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)))))));
    vlSelf->wasmetal_core__DOT___053618_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053615_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)))))));
    vlSelf->wasmetal_core__DOT___053422_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0))))));
    vlSelf->wasmetal_core__DOT___053285_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0))))));
    vlSelf->wasmetal_core__DOT___052696_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)))))));
    vlSelf->wasmetal_core__DOT___064632_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___064589_))))))))))));
    vlSelf->wasmetal_core__DOT___064795_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064616_))));
    vlSelf->wasmetal_core__DOT___064128_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064127_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067547_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064127_))));
    vlSelf->wasmetal_core__DOT___064192_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064189_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___064938_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064189_))));
    vlSelf->wasmetal_core__DOT___064191_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064190_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065102_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064190_))));
    vlSelf->wasmetal_core__DOT___064129_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064126_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067514_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064126_))));
    vlSelf->wasmetal_core__DOT___064182_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064179_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065242_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064179_))));
    vlSelf->wasmetal_core__DOT___064124_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064123_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067412_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064123_))));
    vlSelf->wasmetal_core__DOT___064181_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064180_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065330_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064180_))));
    vlSelf->wasmetal_core__DOT___064186_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064183_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065441_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064183_))));
    vlSelf->wasmetal_core__DOT___064125_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064122_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067370_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064122_))));
    vlSelf->wasmetal_core__DOT___064185_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064184_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065525_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064184_))));
    vlSelf->wasmetal_core__DOT___064118_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064117_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067272_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064117_))));
    vlSelf->wasmetal_core__DOT___064114_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064113_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067116_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064113_))));
    vlSelf->wasmetal_core__DOT___064119_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064116_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067226_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064116_))));
    vlSelf->wasmetal_core__DOT___064160_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064157_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065665_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064157_))));
    vlSelf->wasmetal_core__DOT___064164_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064161_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065860_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064161_))));
    vlSelf->wasmetal_core__DOT___064115_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064112_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067055_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064112_))));
    vlSelf->wasmetal_core__DOT___064159_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064158_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    wasmetal_core__DOT___065743_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___064158_))));
    vlSelf->wasmetal_core__DOT___064163_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064162_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___065976_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064162_))));
    vlSelf->wasmetal_core__DOT___064150_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064149_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___067008_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064149_))));
    vlSelf->wasmetal_core__DOT___064170_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064167_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066039_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064167_))));
    vlSelf->wasmetal_core__DOT___064151_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064148_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066925_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064148_))));
    vlSelf->wasmetal_core__DOT___064173_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064172_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066346_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064172_))));
    vlSelf->wasmetal_core__DOT___064174_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064171_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066237_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064171_))));
    vlSelf->wasmetal_core__DOT___064169_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064168_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066168_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064168_))));
    vlSelf->wasmetal_core__DOT___064140_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064139_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066685_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064139_))));
    vlSelf->wasmetal_core__DOT___064146_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064145_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066820_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064145_))));
    vlSelf->wasmetal_core__DOT___064137_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064134_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066446_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064134_))));
    vlSelf->wasmetal_core__DOT___064141_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064138_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066568_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064138_))));
    vlSelf->wasmetal_core__DOT___064147_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064144_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066735_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064144_))));
    vlSelf->wasmetal_core__DOT___064136_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064135_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O)))));
    vlSelf->wasmetal_core__DOT___066492_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064135_))));
    vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___027801_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b0__05d));
    vlSelf->wasmetal_core__DOT___064554_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___064544_))))))))))));
    vlSelf->wasmetal_core__DOT___064051_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064050_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___066359_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064050_))));
    vlSelf->wasmetal_core__DOT___064052_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064049_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___066249_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064049_))));
    vlSelf->wasmetal_core__DOT___064074_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064071_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___064778_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064071_))));
    vlSelf->wasmetal_core__DOT___064070_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064067_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___064979_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064067_))));
    vlSelf->wasmetal_core__DOT___064047_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064046_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___066150_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064046_))));
    vlSelf->wasmetal_core__DOT___064069_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064068_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065089_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064068_))));
    vlSelf->wasmetal_core__DOT___064048_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064045_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___066053_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064045_))));
    vlSelf->wasmetal_core__DOT___064060_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064057_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065267_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064057_))));
    vlSelf->wasmetal_core__DOT___064041_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064040_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065987_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064040_))));
    vlSelf->wasmetal_core__DOT___064042_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064039_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065872_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064039_))));
    vlSelf->wasmetal_core__DOT___064059_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064058_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065354_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064058_))));
    vlSelf->wasmetal_core__DOT___064064_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064061_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065461_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064061_))));
    vlSelf->wasmetal_core__DOT___064037_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064036_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065774_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064036_))));
    vlSelf->wasmetal_core__DOT___064038_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064035_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065676_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064035_))));
    vlSelf->wasmetal_core__DOT___064063_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064062_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O)))));
    vlSelf->wasmetal_core__DOT___065535_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128577___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064062_))));
    vlSelf->wasmetal_core__DOT___064575_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064571_))))))))));
    vlSelf->wasmetal_core__DOT___064226_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064225_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___064821_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064225_))));
    vlSelf->wasmetal_core__DOT___064235_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064234_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___065546_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064234_))));
    vlSelf->wasmetal_core__DOT___064236_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064233_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___065452_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064233_))));
    vlSelf->wasmetal_core__DOT___064223_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064220_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___064950_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064220_))));
    vlSelf->wasmetal_core__DOT___064232_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064229_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___065255_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064229_))));
    vlSelf->wasmetal_core__DOT___064231_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064230_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___065343_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064230_))));
    vlSelf->wasmetal_core__DOT___064222_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064221_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O)))));
    vlSelf->wasmetal_core__DOT___065120_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128586___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064221_))));
    vlSelf->wasmetal_core__DOT___037208_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036716_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h08c26bfc__0))));
    vlSelf->wasmetal_core__DOT___044716_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032695_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032698_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032697_)))));
    vlSelf->wasmetal_core__DOT___061607_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061598_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x17U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 8U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x11U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 2U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x17U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 8U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x11U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 2U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x17U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 8U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x11U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 2U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061608_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061602_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x18U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 9U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x12U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 3U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x18U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 9U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x12U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 3U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x18U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 9U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x12U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 3U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061619_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061616_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x19U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0xaU)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x13U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 4U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x19U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xaU)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x13U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 4U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x19U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0xaU)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x13U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 4U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___037207_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h08c26bfc__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09206f3f__0))));
    vlSelf->wasmetal_core__DOT___128050___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_x >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128050___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045828_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x19U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h946ed16f__0))))))));
    vlSelf->wasmetal_core__DOT___045837_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x17U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x18U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h17df9f02__0))))))));
    vlSelf->wasmetal_core__DOT___045836_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x14U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x15U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd5d86514__0))))))));
    vlSelf->wasmetal_core__DOT___045835_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x10U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd7080d55__0))))))));
    vlSelf->wasmetal_core__DOT___045834_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xcU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xfU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfe93be6e__0))))))));
    vlSelf->wasmetal_core__DOT___045833_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xaU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8243d19d__0))))))));
    vlSelf->wasmetal_core__DOT___045832_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 8U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 9U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he8f67c93__0))))))));
    vlSelf->wasmetal_core__DOT___045831_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 6U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haf096c00__0))))))));
    vlSelf->wasmetal_core__DOT___045830_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfcd21fa2__0))))))));
    vlSelf->wasmetal_core__DOT___045829_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               << 1U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4104a354__0))))))));
    vlSelf->wasmetal_core__DOT___045827_ = (1U & (0x9009U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_y 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h521b28ea__0)))));
    vlSelf->wasmetal_core__DOT___044280_ = (1U & ((1U 
                                                   & (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_y 
                                                               >> 0x1aU))))
                                                   ? 
                                                  ((1U 
                                                    & (IData)(
                                                              (1ULL 
                                                               >> 
                                                               (0x3fU 
                                                                & (vlSelf->insn_y 
                                                                   >> 0x14U)))))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (0x3fU 
                                                                 & (vlSelf->insn_y 
                                                                    >> 0xeU)))))
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044291_) 
                                                     | (0xfffffffeU 
                                                        >> 
                                                        (0x1fU 
                                                         & (vlSelf->insn_y 
                                                            >> 9U))))
                                                     : 
                                                    (~ (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (0x3fU 
                                                                 & (vlSelf->insn_y 
                                                                    >> 0xeU))))))
                                                    : 
                                                   (~ (IData)(
                                                              (1ULL 
                                                               >> 
                                                               (0x3fU 
                                                                & (vlSelf->insn_y 
                                                                   >> 0x14U))))))
                                                   : 
                                                  (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_y 
                                                               >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___052867_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032694_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___032693_))));
    vlSelf->wasmetal_core__DOT___037205_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h09206f3f__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbc309d1b__0))));
    vlSelf->wasmetal_core__DOT___037204_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbc309d1b__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4312483e__0))));
    vlSelf->wasmetal_core__DOT___061593_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061588_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x15U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 6U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0xfU)) 
                                                                                | (1U 
                                                                                & vlSelf->insn_imm[2U])))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x15U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 6U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0xfU)) 
                                                                                | (1U 
                                                                                & vlSelf->insn_imm[1U])))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x15U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 6U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0xfU)) 
                                                                                | (1U 
                                                                                & vlSelf->insn_imm[0U])))))))))))))))));
    vlSelf->wasmetal_core__DOT___061594_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061592_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x16U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 7U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 0x10U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[2U] 
                                                                                >> 1U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x16U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 7U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 0x10U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[1U] 
                                                                                >> 1U))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x16U)) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 7U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 0x10U)) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_imm[0U] 
                                                                                >> 1U))))))))))))))))));
    vlSelf->__VdfgTmp_h42a8fe82__0 = (((IData)(vlSelf->wasmetal_core__DOT___032691_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032690_));
    vlSelf->wasmetal_core__DOT___037203_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4312483e__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4679be83__0))));
    vlSelf->wasmetal_core__DOT___037202_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4679be83__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h137eceb9__0))));
    vlSelf->wasmetal_core__DOT___044723_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032686_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032688_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032687_)))));
    vlSelf->wasmetal_core__DOT___128314___DOT__CO__BRA__2__KET__ 
        = ((~ (vlSelf->function_params >> 2U)) & (IData)(vlSelf->wasmetal_core__DOT___128314___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___037201_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h137eceb9__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h590821b5__0))));
    vlSelf->wasmetal_core__DOT___044722_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032682_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032684_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032683_)))));
    vlSelf->wasmetal_core__DOT___037200_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h590821b5__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5a255a66__0))));
    vlSelf->wasmetal_core__DOT___037199_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a255a66__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbc3091a9__0))));
    vlSelf->wasmetal_core__DOT___044721_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032679_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032680_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032681_)))));
    vlSelf->wasmetal_core__DOT___037198_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbc3091a9__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h092cd911__0))));
    vlSelf->__VdfgTmp_haf0d31b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___032678_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032677_));
    vlSelf->wasmetal_core__DOT___037197_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h092cd911__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0817f177__0))));
    vlSelf->wasmetal_core__DOT___037196_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0817f177__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1274aae9__0))));
    vlSelf->wasmetal_core__DOT___044719_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032704_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032675_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032705_)))));
    vlSelf->wasmetal_core__DOT___037194_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1274aae9__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h148285ae__0))));
    vlSelf->wasmetal_core__DOT___044718_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032701_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___032703_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___032702_)))));
    vlSelf->wasmetal_core__DOT___037193_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h148285ae__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0dd4dc97__0))));
    vlSelf->wasmetal_core__DOT___052868_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032700_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___032699_))));
    vlSelf->wasmetal_core__DOT___037192_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0dd4dc97__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5f5f5b59__0))));
    vlSelf->__VdfgTmp_h74a82ee2__0 = (((IData)(vlSelf->wasmetal_core__DOT___032685_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032674_));
    vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032674_) 
           | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d));
    vlSelf->wasmetal_core__DOT___037191_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5f5f5b59__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54e5e4c4__0))));
    vlSelf->wasmetal_core__DOT___037190_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h54e5e4c4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h558b9029__0))));
    vlSelf->wasmetal_core__DOT___037189_ = (1U & (0x87U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h558b9029__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h629179e3__0))));
    vlSelf->wasmetal_core__DOT___037188_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h629179e3__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h638a3747__0))));
    vlSelf->wasmetal_core__DOT___037187_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h638a3747__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h68654253__0))));
    vlSelf->wasmetal_core__DOT___037186_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h68654253__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6978beee__0))));
    vlSelf->wasmetal_core__DOT___037185_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6978beee__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h14007945__0))));
    vlSelf->wasmetal_core__DOT___037215_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h14007945__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h13ef8f89__0))));
    vlSelf->wasmetal_core__DOT___037214_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h13ef8f89__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e12a4a2__0))));
    vlSelf->wasmetal_core__DOT___037213_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0e12a4a2__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0d1b5516__0))));
    vlSelf->wasmetal_core__DOT___037212_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0d1b5516__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5afc8767__0))));
    vlSelf->wasmetal_core__DOT___037211_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5afc8767__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5b0f43f4__0))));
    vlSelf->wasmetal_core__DOT___037210_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5b0f43f4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h60140cd4__0))));
    vlSelf->wasmetal_core__DOT___037209_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h60140cd4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h61cb7e30__0))));
    vlSelf->wasmetal_core__DOT___037206_ = (1U & (0x87U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h61cb7e30__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2cd56cce__0))));
    vlSelf->wasmetal_core__DOT___037195_ = (1U & (0xe1U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2cd56cce__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2d9d1f69__0))));
    vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___026357_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fp__05b0__05d));
    vlSelf->wasmetal_core__DOT___044248_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048499_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (vlSelf->insn_x 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___048114_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6c590b04__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1a7964bb__0))));
    vlSelf->wasmetal_core__DOT___070577_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070576_))));
    vlSelf->wasmetal_core__DOT___070578_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070576_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 6U)))));
    vlSelf->wasmetal_core__DOT___044234_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 2U))))));
    vlSelf->__VdfgTmp_h6253e4f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___001241_) 
                                       << 1U) | (1U 
                                                 & (0x4000U 
                                                    >> 
                                                    (0xfU 
                                                     & (vlSelf->insn_op 
                                                        >> 4U)))));
    vlSelf->wasmetal_core__DOT___070626_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002988_))));
    vlSelf->wasmetal_core__DOT___048447_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000366_))));
    vlSelf->wasmetal_core__DOT___045654_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_op 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 7U))))));
    vlSelf->__VdfgTmp_h5f7c118b__0 = (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                       << 1U) | (1U 
                                                 & (0x1000U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h682c3842__0))));
    vlSelf->wasmetal_core__DOT___045676_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | (3U 
                                                      & (vlSelf->insn_op 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___070624_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002994_))));
    vlSelf->wasmetal_core__DOT___045673_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002994_))));
    vlSelf->__VdfgTmp_h71254871__0 = ((4U & (vlSelf->insn_op 
                                             >> 1U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h20102633__0));
    vlSelf->wasmetal_core__DOT___002984_ = (1U & (0x100U 
                                                  >> 
                                                  ((8U 
                                                    & vlSelf->insn_op) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h20102633__0)))));
    vlSelf->wasmetal_core__DOT___054680_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (1ULL 
                                                                        >> 
                                                                        (0x3fU 
                                                                         & (vlSelf->insn_x 
                                                                            >> 0x14U)))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & (vlSelf->insn_x 
                                                                       >> 6U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x17U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_x 
                                                                        >> 0x11U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0xdU)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___044243_)))))))));
    vlSelf->__VdfgTmp_h2d79cdd9__0 = ((2U & (vlSelf->insn_x 
                                             >> 7U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___044243_));
    vlSelf->wasmetal_core__DOT___048303_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x1000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0))))));
    vlSelf->__VdfgTmp_h87f36829__0 = ((2U & ((0x100U 
                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000366_));
    vlSelf->wasmetal_core__DOT___000368_ = (1U & (IData)(
                                                         ((0U 
                                                           == 
                                                           (0x3000U 
                                                            & vlSelf->insn_op)) 
                                                          & (1ULL 
                                                             >> (IData)(vlSelf->__VdfgTmp_h8e88a732__0)))));
    vlSelf->wasmetal_core__DOT___135236___DOT__CO__BRA__0__KET__ 
        = (1U & ((4U >> (IData)(vlSelf->__VdfgTmp_h2780d718__0)) 
                 | (vlSelf->insn_op >> 1U)));
    vlSelf->__VdfgTmp_ha8374813__0 = ((8U & (vlSelf->insn_op 
                                             << 1U)) 
                                      | ((4U & (vlSelf->insn_op 
                                                >> 1U)) 
                                         | (IData)(vlSelf->__VdfgTmp_h2780d718__0)));
    vlSelf->wasmetal_core__DOT___001230_ = (1U & (0x1000U 
                                                  >> 
                                                  ((0xcU 
                                                    & vlSelf->insn_op) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2780d718__0))));
    vlSelf->wasmetal_core__DOT___135390___DOT__CO__BRA__0__KET__ 
        = (1U & (5U >> (IData)(vlSelf->__VdfgTmp_h2780d718__0)));
    vlSelf->wasmetal_core__DOT___044066_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7a4c1007__0))))));
    vlSelf->wasmetal_core__DOT___044086_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7a4c1007__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048346_))));
    vlSelf->wasmetal_core__DOT___002985_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7a4c1007__0)))));
    vlSelf->wasmetal_core__DOT___044231_ = (1U & (0xffff80ffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 6U))) 
                                                          << 3U)) 
                                                      | ((6U 
                                                          & (vlSelf->insn_op 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000375_))))));
    vlSelf->wasmetal_core__DOT___048329_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (3U 
                                                          & (vlSelf->insn_op 
                                                             >> 6U)))))));
    vlSelf->wasmetal_core__DOT___048336_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 6U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0))))));
    vlSelf->wasmetal_core__DOT___007028_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 6U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0))))));
    vlSelf->wasmetal_core__DOT___001234_ = (1U & (0x100U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 3U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 5U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3ca161df__0)))));
    vlSelf->__VdfgTmp_h695ce273__0 = ((0xcU & (vlSelf->insn_op 
                                               >> 4U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h3ca161df__0));
    vlSelf->wasmetal_core__DOT___044162_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7a4c1007__0))))));
    vlSelf->wasmetal_core__DOT___070615_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000378_))));
    vlSelf->wasmetal_core__DOT___001233_ = (1U & (IData)(
                                                         ((0x100U 
                                                           == 
                                                           (0x1100U 
                                                            & vlSelf->insn_op)) 
                                                          & (1ULL 
                                                             >> 
                                                             ((0x20U 
                                                               & (vlSelf->insn_op 
                                                                  >> 8U)) 
                                                              | ((0x10U 
                                                                  & (vlSelf->insn_op 
                                                                     >> 0xaU)) 
                                                                 | ((8U 
                                                                     & (vlSelf->insn_op 
                                                                        >> 0xcU)) 
                                                                    | ((4U 
                                                                        & (vlSelf->insn_op 
                                                                           >> 7U)) 
                                                                       | (IData)(__VdfgTmp_h225c4799__0)))))))));
    vlSelf->wasmetal_core__DOT___054454_ = (1U & (1U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 9U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 0xbU)) 
                                                      | (IData)(__VdfgTmp_h225c4799__0)))));
    vlSelf->wasmetal_core__DOT___048515_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha3f5bbbb__0))));
    vlSelf->wasmetal_core__DOT___048276_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_op 
                                                               >> 0xeU)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (1ULL 
                                                                           >> 
                                                                           (vlSelf->insn_op 
                                                                            >> 0x1aU))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & (vlSelf->insn_op 
                                                                          >> 0x10U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x8000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_op 
                                                                           >> 0x11U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (3U 
                                                                              & (vlSelf->insn_op 
                                                                                >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___000354_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha3f5bbbb__0)))));
    vlSelf->wasmetal_core__DOT___000356_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (1ULL 
                                                                        >> 
                                                                        (vlSelf->insn_op 
                                                                         >> 0x1aU))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_op 
                                                                  >> 0xcU)) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & (vlSelf->insn_op 
                                                                          >> 0x12U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x8000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_op 
                                                                           >> 0x10U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (3U 
                                                                              & (vlSelf->insn_op 
                                                                                >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___044063_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xeU 
                                                         >> 
                                                         (3U 
                                                          & (vlSelf->insn_op 
                                                             >> 0x18U)))))));
    vlSelf->__VdfgTmp_hc705d0d5__0 = ((2U & ((0x8000U 
                                              >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                             << 1U)) 
                                      | (1U & (0xeU 
                                               >> (3U 
                                                   & (vlSelf->insn_op 
                                                      >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___047780_ = (1U & (0x1000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 4U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h752c22b4__0)))));
    vlSelf->__VdfgTmp_he33f1ed5__0 = ((2U & ((0x1000U 
                                              >> (0xfU 
                                                  & (vlSelf->insn_op 
                                                     >> 0x10U))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___054455_));
    vlSelf->wasmetal_core__DOT___070621_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 0x10U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054455_)))));
    vlSelf->wasmetal_core__DOT___044062_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054455_))));
    vlSelf->wasmetal_core__DOT___044170_ = (1U & (0xf400U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 0x12U))) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & (vlSelf->insn_op 
                                                          >> 0xfU)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054455_)))));
    vlSelf->wasmetal_core__DOT___044174_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054455_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 0xeU)) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & (vlSelf->insn_op 
                                                                  >> 0x12U))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 0x11U)))))));
    vlSelf->wasmetal_core__DOT___070338_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070337_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[3U] 
                                                                     >> 0x14U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x1dU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3313b173__0))))))));
    vlSelf->wasmetal_core__DOT___052985_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052984_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___052983_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___052982_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052970_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052969_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___052968_) 
                                                                                << 3U) 
                                                                                | ((6U 
                                                                                & (vlSelf->mem_rdata[2U] 
                                                                                >> 0x15U)) 
                                                                                | (1U 
                                                                                & (vlSelf->mem_rdata[2U] 
                                                                                >> 0x10U)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052978_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052977_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___052976_) 
                                                                                << 3U) 
                                                                                | ((6U 
                                                                                & (vlSelf->mem_rdata[1U] 
                                                                                >> 0x15U)) 
                                                                                | (1U 
                                                                                & (vlSelf->mem_rdata[1U] 
                                                                                >> 0x10U)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x100000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052960_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052959_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___052958_) 
                                                                                << 3U) 
                                                                                | ((6U 
                                                                                & (vlSelf->mem_rdata[3U] 
                                                                                >> 0x15U)) 
                                                                                | (1U 
                                                                                & (vlSelf->mem_rdata[3U] 
                                                                                >> 0x10U)))))))))))))))));
    vlSelf->wasmetal_core__DOT___051227_ = (1U & (0x1400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___038805_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & (IData)(vlSelf->cmd_kind)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->cmd_kind) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___053737_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xfaf0f0f3U 
                                                         >> 
                                                         ((0x18U 
                                                           & ((IData)(vlSelf->cmd_kind) 
                                                              << 2U)) 
                                                          | ((4U 
                                                              & ((IData)(vlSelf->cmd_kind) 
                                                                 >> 1U)) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->cmd_kind) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___038805_)))))))));
    vlSelf->wasmetal_core__DOT___070288_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070287_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[3U] 
                                                                     >> 0x10U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x19U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3313b173__0))))))));
    vlSelf->wasmetal_core__DOT___063392_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063391_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063389_) 
                                                                  << 3U) 
                                                                 | (vlSelf->function_locals 
                                                                    >> 0x1dU)))))));
    vlSelf->wasmetal_core__DOT___066197_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065590_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065584_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 0xeU))))));
    vlSelf->wasmetal_core__DOT___069726_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069721_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069720_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[1U] 
                                                                           >> 8U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[0U] 
                                                                              >> 0x11U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hede308eb__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x13U))))));
    vlSelf->wasmetal_core__DOT___069769_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069765_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069764_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[2U] 
                                                                     >> 0x12U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___069262_)))))))));
    vlSelf->wasmetal_core__DOT___069813_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069808_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069807_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[1U] 
                                                                           >> 0xcU)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[0U] 
                                                                              >> 0x15U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hede308eb__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x17U))))));
    vlSelf->wasmetal_core__DOT___069657_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___069655_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069654_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 5U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xeU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hede308eb__0))))))));
    vlSelf->wasmetal_core__DOT___070204_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070203_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070202_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066020_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066370_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1dU))))))))));
    vlSelf->wasmetal_core__DOT___070219_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070218_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070217_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066176_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066370_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1eU))))))))));
    vlSelf->wasmetal_core__DOT___066462_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066457_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xeU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 7U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___069681_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xd00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___066457_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069676_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069675_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___069653_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->mem_rdata[1U] 
                                                                                >> 9U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x11U))))));
    vlSelf->wasmetal_core__DOT___070263_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066457_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068537_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 0x11U))))))));
    vlSelf->wasmetal_core__DOT___069854_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067042_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x16U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x17U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___069891_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067216_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x18U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x19U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1bU))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128026___O 
        = (((0xeU & vlSelf->insn_z) | (1U & (~ vlSelf->insn_z))) 
           ^ (((IData)(wasmetal_core__DOT___128026___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128026___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & (vlSelf->insn_z 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___027954_ = ((vlSelf->insn_z 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128026___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128266___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 3U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 2U)) << 2U)) 
                              | ((2U & ((~ (vlSelf->mem_rdata[0U] 
                                            >> 1U)) 
                                        << 1U)) | (1U 
                                                   & vlSelf->mem_rdata[0U])))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128266___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128266___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & (vlSelf->mem_rdata[0U] 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT___030489_ = (1U & ((8U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 3U)
                                                   : (IData)(wasmetal_core__DOT___128266___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___069831_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066996_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x15U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x16U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))));
    vlSelf->wasmetal_core__DOT___070018_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070014_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067622_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0xeU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84a22723__0))))))));
    vlSelf->wasmetal_core__DOT___070147_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070014_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070144_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 6U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x17U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___070132_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070130_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 5U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x16U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___070001_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067567_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0xdU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84a22723__0))))))));
    vlSelf->wasmetal_core__DOT___070056_ = (1U & (0x77070000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070053_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___070174_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070053_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070171_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 8U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x19U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___069586_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069585_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069584_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xaU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xbU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069936_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067360_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x1aU)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x1bU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1dU))))));
    vlSelf->wasmetal_core__DOT___067364_ = (1U & (0x7000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067360_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 0x1dU)))))));
    vlSelf->wasmetal_core__DOT___067220_ = (1U & (0x7000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067216_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 0x1bU)))))));
    vlSelf->wasmetal_core__DOT___070115_ = (1U & (0x77070000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070112_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[0U] 
                                                             >> 5U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 6U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___069258_)))))));
    vlSelf->wasmetal_core__DOT___070235_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070112_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070232_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xcU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x1dU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___069974_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067504_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x1cU)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x1dU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[2U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___067508_ = (1U & (0x7000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066997_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067504_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066373_) 
                                                          << 1U) 
                                                         | (vlSelf->mem_rdata[0U] 
                                                            >> 0x1fU))))));
    vlSelf->wasmetal_core__DOT___069609_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069608_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069607_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xbU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0xcU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h753cf8b1__0))))))));
    vlSelf->wasmetal_core__DOT___069953_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067428_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x1bU)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x1cU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1eU))))));
    vlSelf->wasmetal_core__DOT___069790_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069786_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069653_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((2U 
                                                                           & (vlSelf->mem_rdata[0U] 
                                                                              >> 0x15U)) 
                                                                          | (1U 
                                                                             & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfed1012b__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x16U))))))))));
    vlSelf->wasmetal_core__DOT___070325_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066809_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068773_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 0x16U))))))));
    vlSelf->wasmetal_core__DOT___066812_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066809_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x13U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xcU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___069912_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067264_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x19U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x1aU)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1cU))))));
    vlSelf->wasmetal_core__DOT___070402_ = (1U & (0x700U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067264_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069059_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[1U] 
                                                               >> 0x1cU)))))));
    vlSelf->wasmetal_core__DOT___066674_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066670_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x11U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xaU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___069748_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066670_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069743_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069742_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069653_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0xcU))))))))));
    vlSelf->wasmetal_core__DOT___070299_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066670_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068675_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 0x14U))))))));
    vlSelf->wasmetal_core__DOT___069319_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069315_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->mem_rdata[2U]) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___067560_)))))));
    vlSelf->wasmetal_core__DOT___070040_ = (1U & (IData)(
                                                         (0x2a3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070036_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067703_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0xfU)) 
                                                                 | ((4U 
                                                                     & vlSelf->mem_rdata[1U]) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84a22723__0))))))));
    vlSelf->wasmetal_core__DOT___070161_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070036_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070158_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 7U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[1U] 
                                                                        >> 0x18U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___069871_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x8acf000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069828_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067110_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->mem_rdata[0U] 
                                                                           >> 0x17U)) 
                                                                       | ((4U 
                                                                           & (vlSelf->mem_rdata[1U] 
                                                                              >> 0x18U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haa81a95c__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___069704_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xd00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___066480_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069699_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069698_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___069653_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->mem_rdata[1U] 
                                                                                >> 0xaU))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[2U] 
                                                            >> 0x12U))))));
    vlSelf->wasmetal_core__DOT___070275_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066480_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068576_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 0x12U))))))));
    vlSelf->wasmetal_core__DOT___066483_ = (1U & (IData)(
                                                         (0x45cf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066374_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066480_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xfU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 8U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc8ebfb4__0))))))));
    vlSelf->wasmetal_core__DOT___070314_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070313_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0x13U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x1cU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___070351_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066996_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070349_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___068869_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x18U))))))))));
    vlSelf->wasmetal_core__DOT___070366_ = (1U & (0x70000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067042_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070365_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 0x19U))))))));
    vlSelf->wasmetal_core__DOT___070378_ = (1U & (0x70000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067110_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070377_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 0x1aU))))))));
    vlSelf->wasmetal_core__DOT___070390_ = (1U & (0x70000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067216_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070389_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 0x1bU))))))));
    vlSelf->wasmetal_core__DOT___070415_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067360_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070414_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069105_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1dU))))))))));
    vlSelf->wasmetal_core__DOT___070427_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070426_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069172_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069258_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1eU))))))))));
    vlSelf->wasmetal_core__DOT___070440_ = (1U & (0x70000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067504_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070439_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070350_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                             << 1U) 
                                                            | (vlSelf->mem_rdata[3U] 
                                                               >> 0x1fU)))))));
    vlSelf->wasmetal_core__DOT___019798_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___038805_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051236_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)))))));
    vlSelf->wasmetal_core__DOT___039415_ = (1U & (0xeaaa2aaaU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->cmd_kind) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051236_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___038805_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__query_table)))))));
    vlSelf->wasmetal_core__DOT___063418_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051236_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d))));
    vlSelf->wasmetal_core__DOT___063013_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050385_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___050467_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050385_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___044659_))));
    vlSelf->wasmetal_core__DOT___050389_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050385_))));
    vlSelf->wasmetal_core__DOT___050438_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___044659_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050385_))));
    vlSelf->wasmetal_core__DOT___053330_ = (1U & (IData)(
                                                         (0x9009000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053312_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053311_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b79__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_y 
                                                                        >> 0xdU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b78__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_y 
                                                                             >> 0xeU))))))))));
    vlSelf->wasmetal_core__DOT___068051_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->mem_rdata[0U] 
                                                            >> 0x17U))))));
    vlSelf->wasmetal_core__DOT___068492_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066372_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[0U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___067626_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067623_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067622_)))));
    vlSelf->wasmetal_core__DOT___067939_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067935_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x13U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 4U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf22e2068__0))))))));
    vlSelf->wasmetal_core__DOT___067775_ = (1U & (0xd000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067772_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___067708_ = (1U & (0xd000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067704_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067703_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067566_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0x12U))))))));
    vlSelf->wasmetal_core__DOT___067574_ = (1U & (0xd000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067569_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067567_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067566_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0x10U))))))));
    vlSelf->wasmetal_core__DOT___067836_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067833_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x11U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf22e2068__0))))))));
    vlSelf->wasmetal_core__DOT___069061_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067833_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069059_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067262_)))));
    vlSelf->wasmetal_core__DOT___067989_ = (1U & (0xd000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067986_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 7U)))))));
    vlSelf->wasmetal_core__DOT___067867_ = (1U & (0xd000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067864_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067568_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb1936621__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 5U)))))));
    vlSelf->wasmetal_core__DOT___065027_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064835_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065026_))));
    vlSelf->wasmetal_core__DOT___064836_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064698_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064835_))));
    vlSelf->wasmetal_core__DOT___065224_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065223_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065143_))));
    vlSelf->wasmetal_core__DOT___065381_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065223_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065380_))));
    vlSelf->wasmetal_core__DOT___065486_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065380_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065485_))));
    vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032877_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___064436_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064435_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064434_))));
    vlSelf->wasmetal_core__DOT___065510_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065485_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065509_))));
    vlSelf->wasmetal_core__DOT___064693_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064689_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064688_))));
    vlSelf->wasmetal_core__DOT___065650_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065509_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065649_))));
    vlSelf->wasmetal_core__DOT___064417_ = (1U & (0x53U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___064408_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___064410_))));
    vlSelf->wasmetal_core__DOT___065762_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065649_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065761_))));
    vlSelf->wasmetal_core__DOT___064683_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064410_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064415_))));
    vlSelf->wasmetal_core__DOT___064416_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064415_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064414_))));
    vlSelf->wasmetal_core__DOT___065845_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065761_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065844_))));
    vlSelf->wasmetal_core__DOT___065957_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065844_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065956_))));
    vlSelf->wasmetal_core__DOT___064682_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064414_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064421_))));
    vlSelf->wasmetal_core__DOT___066028_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065956_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066027_))));
    vlSelf->wasmetal_core__DOT___064427_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064421_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064420_))));
    vlSelf->wasmetal_core__DOT___066181_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066027_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066180_))));
    vlSelf->wasmetal_core__DOT___064685_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064420_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064425_))));
    vlSelf->wasmetal_core__DOT___066226_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066180_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066225_))));
    vlSelf->wasmetal_core__DOT___064426_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064425_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064424_))));
    vlSelf->wasmetal_core__DOT___066337_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066225_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066336_))));
    vlSelf->wasmetal_core__DOT___064684_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064365_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064424_))));
    vlSelf->wasmetal_core__DOT___066435_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066336_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066434_))));
    vlSelf->wasmetal_core__DOT___064371_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064365_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064364_))));
    vlSelf->wasmetal_core__DOT___066501_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066434_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066500_))));
    vlSelf->wasmetal_core__DOT___069979_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  (2U 
                                                                   & ((4U 
                                                                       >> 
                                                                       ((IData)(vlSelf->wasmetal_core__DOT___069265_) 
                                                                        << 1U)) 
                                                                      << 1U))) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___064669_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064364_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064369_))));
    vlSelf->wasmetal_core__DOT___066582_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066500_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066581_))));
    vlSelf->wasmetal_core__DOT___064370_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064369_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064368_))));
    vlSelf->wasmetal_core__DOT___066696_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066581_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066695_))));
    vlSelf->wasmetal_core__DOT___064668_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064368_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064375_))));
    vlSelf->wasmetal_core__DOT___066749_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066695_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066748_))));
    vlSelf->__VdfgTmp_hdbf4091d__0 = (((IData)(vlSelf->wasmetal_core__DOT___064375_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___064374_));
    vlSelf->wasmetal_core__DOT___066831_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066748_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066830_))));
    vlSelf->wasmetal_core__DOT___064671_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064374_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064379_))));
    vlSelf->wasmetal_core__DOT___066915_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066914_))));
    vlSelf->wasmetal_core__DOT___064380_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064379_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064378_))));
    vlSelf->wasmetal_core__DOT___066999_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066998_))));
    vlSelf->wasmetal_core__DOT___064670_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064378_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064387_))));
    vlSelf->wasmetal_core__DOT___067044_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066998_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067043_))));
    vlSelf->wasmetal_core__DOT___069266_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069216_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069265_))));
    vlSelf->wasmetal_core__DOT___064354_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064353_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064352_))));
    vlSelf->wasmetal_core__DOT___064393_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064387_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064386_))));
    vlSelf->wasmetal_core__DOT___067129_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067043_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067128_))));
    vlSelf->wasmetal_core__DOT___064675_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064386_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064391_))));
    vlSelf->wasmetal_core__DOT___067240_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067128_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067239_))));
    vlSelf->wasmetal_core__DOT___069217_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069184_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069216_))));
    vlSelf->wasmetal_core__DOT___064661_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064348_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064353_))));
    vlSelf->wasmetal_core__DOT___064392_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064391_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064390_))));
    vlSelf->wasmetal_core__DOT___067279_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067239_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067278_))));
    vlSelf->wasmetal_core__DOT___064674_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064390_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064397_))));
    vlSelf->wasmetal_core__DOT___067384_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067383_))));
    vlSelf->wasmetal_core__DOT___069185_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069184_))));
    vlSelf->wasmetal_core__DOT___064355_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064349_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064348_))));
    vlSelf->wasmetal_core__DOT___064403_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064397_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064396_))));
    vlSelf->wasmetal_core__DOT___067431_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067430_))));
    vlSelf->wasmetal_core__DOT___064677_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064396_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064401_))));
    vlSelf->wasmetal_core__DOT___067528_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067430_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067527_))));
    vlSelf->wasmetal_core__DOT___069118_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069069_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069117_))));
    vlSelf->wasmetal_core__DOT___064658_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064342_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064349_))));
    vlSelf->wasmetal_core__DOT___069070_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069022_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069069_))));
    vlSelf->wasmetal_core__DOT___064344_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064343_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064342_))));
    vlSelf->wasmetal_core__DOT___069023_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068991_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069022_))));
    vlSelf->wasmetal_core__DOT___064659_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064338_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064343_))));
    vlSelf->wasmetal_core__DOT___064402_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064401_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064400_))));
    vlSelf->wasmetal_core__DOT___067576_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067527_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067575_))));
    vlSelf->wasmetal_core__DOT___064676_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064271_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064400_))));
    vlSelf->wasmetal_core__DOT___067642_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067575_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067641_))));
    vlSelf->wasmetal_core__DOT___068992_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068991_))));
    vlSelf->wasmetal_core__DOT___064345_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064339_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064338_))));
    vlSelf->wasmetal_core__DOT___064277_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064271_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064270_))));
    vlSelf->wasmetal_core__DOT___067710_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067641_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067709_))));
    vlSelf->wasmetal_core__DOT___064639_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064270_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064275_))));
    vlSelf->wasmetal_core__DOT___067789_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067709_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067788_))));
    vlSelf->wasmetal_core__DOT___068925_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068875_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068924_))));
    vlSelf->wasmetal_core__DOT___064654_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064330_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064339_))));
    vlSelf->wasmetal_core__DOT___068876_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068828_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068875_))));
    vlSelf->wasmetal_core__DOT___064332_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064331_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064330_))));
    vlSelf->wasmetal_core__DOT___064276_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064275_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064274_))));
    vlSelf->wasmetal_core__DOT___067838_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067788_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067837_))));
    vlSelf->wasmetal_core__DOT___068829_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068778_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068828_))));
    vlSelf->wasmetal_core__DOT___064655_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064326_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064331_))));
    vlSelf->wasmetal_core__DOT___068729_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068681_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068728_))));
    vlSelf->wasmetal_core__DOT___068779_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068728_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068778_))));
    vlSelf->wasmetal_core__DOT___064652_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064320_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064327_))));
    vlSelf->wasmetal_core__DOT___064333_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064326_))));
    vlSelf->wasmetal_core__DOT___064638_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064274_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064281_))));
    vlSelf->wasmetal_core__DOT___067881_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067880_))));
    vlSelf->wasmetal_core__DOT___064287_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064281_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064280_))));
    vlSelf->wasmetal_core__DOT___067941_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067880_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067940_))));
    vlSelf->wasmetal_core__DOT___064641_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064280_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064285_))));
    vlSelf->wasmetal_core__DOT___068004_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067940_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068003_))));
    vlSelf->wasmetal_core__DOT___064286_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064285_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064284_))));
    vlSelf->wasmetal_core__DOT___068057_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068003_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068056_))));
    vlSelf->wasmetal_core__DOT___068682_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068681_))));
    vlSelf->wasmetal_core__DOT___064322_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064321_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064320_))));
    vlSelf->wasmetal_core__DOT___064640_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064284_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064293_))));
    vlSelf->wasmetal_core__DOT___068132_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068056_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068131_))));
    vlSelf->wasmetal_core__DOT___064298_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064297_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064296_))));
    vlSelf->wasmetal_core__DOT___068271_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068217_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068270_))));
    vlSelf->wasmetal_core__DOT___064645_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064292_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064297_))));
    vlSelf->wasmetal_core__DOT___064299_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064293_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064292_))));
    vlSelf->wasmetal_core__DOT___068218_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068183_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068217_))));
    vlSelf->wasmetal_core__DOT___068184_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068183_))));
    vlSelf->wasmetal_core__DOT___064644_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064296_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064303_))));
    vlSelf->wasmetal_core__DOT___068324_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068270_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068323_))));
    vlSelf->wasmetal_core__DOT___068632_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068581_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068631_))));
    vlSelf->wasmetal_core__DOT___064653_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064316_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064321_))));
    vlSelf->wasmetal_core__DOT___064309_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064303_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064302_))));
    vlSelf->wasmetal_core__DOT___068380_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068323_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068379_))));
    vlSelf->wasmetal_core__DOT___064323_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064317_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064316_))));
    vlSelf->wasmetal_core__DOT___068582_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068517_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068581_))));
    vlSelf->wasmetal_core__DOT___064647_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064307_))));
    vlSelf->wasmetal_core__DOT___068455_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068379_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068454_))));
    vlSelf->wasmetal_core__DOT___064646_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064306_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064317_))));
    vlSelf->wasmetal_core__DOT___064308_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064306_))));
    vlSelf->wasmetal_core__DOT___068518_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068499_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068517_))));
    vlSelf->wasmetal_core__DOT___068500_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068454_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068499_))));
    vlSelf->wasmetal_core__DOT___053752_ = (1U & (0xb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053618_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048487_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->mem_ready)))))));
    vlSelf->wasmetal_core__DOT___072274_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x44474444U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___072258_) 
                                                          << 4U) 
                                                         | ((8U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                                << 3U)) 
                                                            | ((4U 
                                                                & ((0xf38f2778U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->mem_write)))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x4000ffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___053285_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                                           << 4U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045785_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->cmd_kind) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h73f978ac__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->cmd_kind) 
                                                                                >> 1U))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053345_)))));
    vlSelf->wasmetal_core__DOT___064796_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064589_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064795_))));
    vlSelf->wasmetal_core__DOT___064939_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064795_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064938_))));
    vlSelf->wasmetal_core__DOT___064193_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064192_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064191_))));
    vlSelf->wasmetal_core__DOT___065103_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064938_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065102_))));
    vlSelf->wasmetal_core__DOT___064130_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064129_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064128_))));
    vlSelf->wasmetal_core__DOT___067548_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067514_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067547_))));
    vlSelf->wasmetal_core__DOT___064617_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064182_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064191_))));
    vlSelf->wasmetal_core__DOT___065243_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065102_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065242_))));
    vlSelf->wasmetal_core__DOT___064603_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064124_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064129_))));
    vlSelf->wasmetal_core__DOT___067515_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067412_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067514_))));
    vlSelf->wasmetal_core__DOT___064188_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064182_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064181_))));
    vlSelf->wasmetal_core__DOT___065331_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065242_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065330_))));
    vlSelf->wasmetal_core__DOT___064615_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064181_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064186_))));
    vlSelf->wasmetal_core__DOT___065442_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065330_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065441_))));
    vlSelf->wasmetal_core__DOT___064131_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064125_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064124_))));
    vlSelf->wasmetal_core__DOT___067413_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067370_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067412_))));
    vlSelf->wasmetal_core__DOT___064187_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064186_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064185_))));
    vlSelf->wasmetal_core__DOT___065526_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065441_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065525_))));
    vlSelf->wasmetal_core__DOT___064600_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064118_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064125_))));
    vlSelf->wasmetal_core__DOT___067371_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067272_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067370_))));
    vlSelf->wasmetal_core__DOT___064601_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064114_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064119_))));
    vlSelf->wasmetal_core__DOT___064120_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064119_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064118_))));
    vlSelf->wasmetal_core__DOT___067227_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067116_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067226_))));
    vlSelf->wasmetal_core__DOT___067273_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067272_))));
    vlSelf->wasmetal_core__DOT___064614_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064160_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064185_))));
    vlSelf->wasmetal_core__DOT___065666_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065525_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065665_))));
    vlSelf->wasmetal_core__DOT___064121_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064115_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064114_))));
    vlSelf->wasmetal_core__DOT___067117_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067055_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067116_))));
    vlSelf->wasmetal_core__DOT___064609_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064159_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064164_))));
    vlSelf->wasmetal_core__DOT___064166_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064160_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064159_))));
    vlSelf->wasmetal_core__DOT___065861_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065743_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065860_))));
    vlSelf->wasmetal_core__DOT___065744_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065665_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065743_))));
}
