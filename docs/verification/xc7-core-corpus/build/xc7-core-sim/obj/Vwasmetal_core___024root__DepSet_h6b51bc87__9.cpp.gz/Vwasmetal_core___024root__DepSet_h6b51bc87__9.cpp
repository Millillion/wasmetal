#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__45(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__45\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___009690_;
    wasmetal_core__DOT___009690_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012248_;
    wasmetal_core__DOT___012248_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012306_;
    wasmetal_core__DOT___012306_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013011_;
    wasmetal_core__DOT___013011_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013012_;
    wasmetal_core__DOT___013012_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013189_;
    wasmetal_core__DOT___013189_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024987_;
    wasmetal_core__DOT___024987_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024991_;
    wasmetal_core__DOT___024991_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024996_;
    wasmetal_core__DOT___024996_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025000_;
    wasmetal_core__DOT___025000_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025789_;
    wasmetal_core__DOT___025789_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025793_;
    wasmetal_core__DOT___025793_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025797_;
    wasmetal_core__DOT___025797_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025800_;
    wasmetal_core__DOT___025800_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025801_;
    wasmetal_core__DOT___025801_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025802_;
    wasmetal_core__DOT___025802_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025803_;
    wasmetal_core__DOT___025803_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025804_;
    wasmetal_core__DOT___025804_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025805_;
    wasmetal_core__DOT___025805_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025806_;
    wasmetal_core__DOT___025806_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025807_;
    wasmetal_core__DOT___025807_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025808_;
    wasmetal_core__DOT___025808_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025809_;
    wasmetal_core__DOT___025809_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025810_;
    wasmetal_core__DOT___025810_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025811_;
    wasmetal_core__DOT___025811_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025812_;
    wasmetal_core__DOT___025812_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025885_;
    wasmetal_core__DOT___025885_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025889_;
    wasmetal_core__DOT___025889_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025894_;
    wasmetal_core__DOT___025894_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025898_;
    wasmetal_core__DOT___025898_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025915_;
    wasmetal_core__DOT___025915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025916_;
    wasmetal_core__DOT___025916_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025917_;
    wasmetal_core__DOT___025917_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025918_;
    wasmetal_core__DOT___025918_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025919_;
    wasmetal_core__DOT___025919_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025921_;
    wasmetal_core__DOT___025921_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025922_;
    wasmetal_core__DOT___025922_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025923_;
    wasmetal_core__DOT___025923_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025924_;
    wasmetal_core__DOT___025924_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025925_;
    wasmetal_core__DOT___025925_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025926_;
    wasmetal_core__DOT___025926_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025927_;
    wasmetal_core__DOT___025927_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025928_;
    wasmetal_core__DOT___025928_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025929_;
    wasmetal_core__DOT___025929_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___025930_;
    wasmetal_core__DOT___025930_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026065_;
    wasmetal_core__DOT___026065_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026069_;
    wasmetal_core__DOT___026069_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026074_;
    wasmetal_core__DOT___026074_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026111_;
    wasmetal_core__DOT___026111_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026112_;
    wasmetal_core__DOT___026112_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026113_;
    wasmetal_core__DOT___026113_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026114_;
    wasmetal_core__DOT___026114_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026115_;
    wasmetal_core__DOT___026115_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026116_;
    wasmetal_core__DOT___026116_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026118_;
    wasmetal_core__DOT___026118_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026119_;
    wasmetal_core__DOT___026119_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026120_;
    wasmetal_core__DOT___026120_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026121_;
    wasmetal_core__DOT___026121_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026122_;
    wasmetal_core__DOT___026122_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026123_;
    wasmetal_core__DOT___026123_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___026124_;
    wasmetal_core__DOT___026124_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027560_;
    wasmetal_core__DOT___027560_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027567_;
    wasmetal_core__DOT___027567_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027568_;
    wasmetal_core__DOT___027568_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027569_;
    wasmetal_core__DOT___027569_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043538_;
    wasmetal_core__DOT___043538_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043543_;
    wasmetal_core__DOT___043543_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043544_;
    wasmetal_core__DOT___043544_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043563_;
    wasmetal_core__DOT___043563_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043570_;
    wasmetal_core__DOT___043570_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043571_;
    wasmetal_core__DOT___043571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043572_;
    wasmetal_core__DOT___043572_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043573_;
    wasmetal_core__DOT___043573_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043896_;
    wasmetal_core__DOT___043896_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043899_;
    wasmetal_core__DOT___043899_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043900_;
    wasmetal_core__DOT___043900_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043907_;
    wasmetal_core__DOT___043907_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043908_;
    wasmetal_core__DOT___043908_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043909_;
    wasmetal_core__DOT___043909_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043932_;
    wasmetal_core__DOT___043932_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043933_;
    wasmetal_core__DOT___043933_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043935_;
    wasmetal_core__DOT___043935_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043936_;
    wasmetal_core__DOT___043936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043937_;
    wasmetal_core__DOT___043937_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043938_;
    wasmetal_core__DOT___043938_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043939_;
    wasmetal_core__DOT___043939_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043944_;
    wasmetal_core__DOT___043944_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043946_;
    wasmetal_core__DOT___043946_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043947_;
    wasmetal_core__DOT___043947_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043948_;
    wasmetal_core__DOT___043948_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043949_;
    wasmetal_core__DOT___043949_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043950_;
    wasmetal_core__DOT___043950_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056871_;
    wasmetal_core__DOT___056871_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057006_;
    wasmetal_core__DOT___057006_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057075_;
    wasmetal_core__DOT___057075_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057121_;
    wasmetal_core__DOT___057121_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057277_;
    wasmetal_core__DOT___057277_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057478_;
    wasmetal_core__DOT___057478_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057518_;
    wasmetal_core__DOT___057518_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060657_;
    wasmetal_core__DOT___060657_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060658_;
    wasmetal_core__DOT___060658_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060663_;
    wasmetal_core__DOT___060663_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060671_;
    wasmetal_core__DOT___060671_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060683_;
    wasmetal_core__DOT___060683_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060684_;
    wasmetal_core__DOT___060684_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060698_;
    wasmetal_core__DOT___060698_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060699_;
    wasmetal_core__DOT___060699_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060700_;
    wasmetal_core__DOT___060700_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060702_;
    wasmetal_core__DOT___060702_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060703_;
    wasmetal_core__DOT___060703_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060781_;
    wasmetal_core__DOT___060781_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060784_;
    wasmetal_core__DOT___060784_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060787_;
    wasmetal_core__DOT___060787_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060788_;
    wasmetal_core__DOT___060788_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060817_;
    wasmetal_core__DOT___060817_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060823_;
    wasmetal_core__DOT___060823_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060868_;
    wasmetal_core__DOT___060868_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060871_;
    wasmetal_core__DOT___060871_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060874_;
    wasmetal_core__DOT___060874_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060875_;
    wasmetal_core__DOT___060875_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060900_;
    wasmetal_core__DOT___060900_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060944_;
    wasmetal_core__DOT___060944_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060947_;
    wasmetal_core__DOT___060947_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060950_;
    wasmetal_core__DOT___060950_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060951_;
    wasmetal_core__DOT___060951_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060970_;
    wasmetal_core__DOT___060970_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060976_;
    wasmetal_core__DOT___060976_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061033_;
    wasmetal_core__DOT___061033_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061036_;
    wasmetal_core__DOT___061036_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061040_;
    wasmetal_core__DOT___061040_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061042_;
    wasmetal_core__DOT___061042_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061059_;
    wasmetal_core__DOT___061059_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061065_;
    wasmetal_core__DOT___061065_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061114_;
    wasmetal_core__DOT___061114_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061117_;
    wasmetal_core__DOT___061117_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061121_;
    wasmetal_core__DOT___061121_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061123_;
    wasmetal_core__DOT___061123_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061138_;
    wasmetal_core__DOT___061138_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061144_;
    wasmetal_core__DOT___061144_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061195_;
    wasmetal_core__DOT___061195_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061196_;
    wasmetal_core__DOT___061196_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061199_;
    wasmetal_core__DOT___061199_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061203_;
    wasmetal_core__DOT___061203_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061205_;
    wasmetal_core__DOT___061205_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061228_;
    wasmetal_core__DOT___061228_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061231_;
    wasmetal_core__DOT___061231_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061237_;
    wasmetal_core__DOT___061237_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061289_;
    wasmetal_core__DOT___061289_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061292_;
    wasmetal_core__DOT___061292_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061298_;
    wasmetal_core__DOT___061298_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___061935_;
    wasmetal_core__DOT___061935_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___062159_;
    wasmetal_core__DOT___062159_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068409_;
    wasmetal_core__DOT___068409_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068433_;
    wasmetal_core__DOT___068433_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068439_;
    wasmetal_core__DOT___068439_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068488_;
    wasmetal_core__DOT___068488_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068489_;
    wasmetal_core__DOT___068489_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068976_;
    wasmetal_core__DOT___068976_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068977_;
    wasmetal_core__DOT___068977_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069096_;
    wasmetal_core__DOT___069096_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069100_;
    wasmetal_core__DOT___069100_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069145_;
    wasmetal_core__DOT___069145_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069148_;
    wasmetal_core__DOT___069148_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069168_;
    wasmetal_core__DOT___069168_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069170_;
    wasmetal_core__DOT___069170_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069247_;
    wasmetal_core__DOT___069247_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070677_;
    wasmetal_core__DOT___070677_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070678_;
    wasmetal_core__DOT___070678_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070679_;
    wasmetal_core__DOT___070679_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127804___O;
    wasmetal_core__DOT____Vcellout___127804___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127805___O;
    wasmetal_core__DOT____Vcellout___127805___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127811___O;
    wasmetal_core__DOT____Vcellout___127811___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127812___O;
    wasmetal_core__DOT____Vcellout___127812___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127813___O;
    wasmetal_core__DOT____Vcellout___127813___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127815___O;
    wasmetal_core__DOT____Vcellout___127815___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127816___O;
    wasmetal_core__DOT____Vcellout___127816___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127824___O;
    wasmetal_core__DOT____Vcellout___127824___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127825___O;
    wasmetal_core__DOT____Vcellout___127825___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127978___O;
    wasmetal_core__DOT____Vcellout___127978___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127737___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127737___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127737___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127737___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127737___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127737___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127738___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127738___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127738___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127738___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127738___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127738___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127739___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127739___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127747___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127747___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127747___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127747___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127747___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127747___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127748___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127748___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127748___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127748___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127748___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127748___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127802___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127802___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127802___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127802___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127802___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127802___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127803___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127803___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127803___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127803___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127803___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127803___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127804___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127804___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127804___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127804___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127804___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127804___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127810___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127810___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127810___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127810___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127810___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127810___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127811___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127811___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127811___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127811___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127811___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127811___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127812___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127812___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127812___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127812___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127812___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127812___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127813___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127813___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127815___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127815___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127815___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127815___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127815___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127815___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127816___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127816___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127816___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127816___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127824___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127824___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127825___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127825___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127825___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127825___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127825___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127825___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127978___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127978___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128609___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128609___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128609___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128609___DOT__CO__BRA__1__KET__ = 0;
    CData/*2:0*/ __VdfgTmp_h965ce7cb__0;
    __VdfgTmp_h965ce7cb__0 = 0;
    CData/*2:0*/ __VdfgTmp_h8648f195__0;
    __VdfgTmp_h8648f195__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2b50c012__0;
    __VdfgTmp_h2b50c012__0 = 0;
    CData/*1:0*/ __VdfgTmp_h38415c57__0;
    __VdfgTmp_h38415c57__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbda467d5__0;
    __VdfgTmp_hbda467d5__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf4482b2c__0;
    __VdfgTmp_hf4482b2c__0 = 0;
    CData/*5:0*/ __VdfgTmp_hbed24786__0;
    __VdfgTmp_hbed24786__0 = 0;
    CData/*1:0*/ __VdfgTmp_hfa1f27b8__0;
    __VdfgTmp_hfa1f27b8__0 = 0;
    CData/*1:0*/ __VdfgTmp_h94355ed4__0;
    __VdfgTmp_h94355ed4__0 = 0;
    // Body
    wasmetal_core__DOT___026124_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134227_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                               >> 0xcU))))));
    wasmetal_core__DOT___026123_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134227_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                               >> 0xbU))))));
    wasmetal_core__DOT___026122_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134227_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                               >> 0xaU))))));
    wasmetal_core__DOT___026121_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134227_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                               >> 9U))))));
    wasmetal_core__DOT___026120_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134227_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                               >> 8U))))));
    wasmetal_core__DOT___026119_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134227_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                               >> 7U))))));
    wasmetal_core__DOT___026118_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134227_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                               >> 6U))))));
    wasmetal_core__DOT___026116_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134227_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                               >> 5U))))));
    wasmetal_core__DOT___026115_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134227_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                               >> 4U))))));
    wasmetal_core__DOT___026114_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134227_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                               >> 3U))))));
    wasmetal_core__DOT___026113_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134227_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                               >> 2U))))));
    wasmetal_core__DOT___026112_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134227_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                               >> 1U))))));
    wasmetal_core__DOT___026111_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134227_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum)))));
    wasmetal_core__DOT___127824___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026111_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127824___DOT__CO__BRA__1__KET__)
                  : (IData)(vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum)));
    wasmetal_core__DOT____Vcellout___127824___O = (
                                                   (((IData)(wasmetal_core__DOT___026112_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___026111_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___026110_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026109_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127824___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127824___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127824___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026061_)))));
    wasmetal_core__DOT___026065_ = (1U & ((IData)(wasmetal_core__DOT___026112_)
                                           ? (IData)(wasmetal_core__DOT___127824___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                      >> 1U))));
    wasmetal_core__DOT___025918_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134229_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127824___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025917_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134229_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127824___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025916_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 0x10U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127824___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025915_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134228_.__PVT__alu_sum 
                                                              >> 0xfU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127824___O)))));
    wasmetal_core__DOT___127825___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026113_)
                  ? (IData)(wasmetal_core__DOT___026065_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                             >> 2U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127809___O 
        = ((((IData)(wasmetal_core__DOT___025915_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___025914_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___025913_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025912_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___025881_)))));
    wasmetal_core__DOT___025885_ = (1U & ((IData)(wasmetal_core__DOT___025915_)
                                           ? (IData)(vlSelf->wasmetal_core__DOT___127809___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127824___O)));
    wasmetal_core__DOT___127825___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026114_)
                  ? (IData)(wasmetal_core__DOT___127825___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                             >> 3U))));
    wasmetal_core__DOT___068409_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068406_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128241___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___068433_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068430_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128241___O)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___068488_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068483_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128242___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___060781_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
                                                        >> 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he7f579a2__0))))));
    wasmetal_core__DOT___060658_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h1b99479d__0))))));
    wasmetal_core__DOT___061195_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h8565eee7__0))))));
    wasmetal_core__DOT___057478_ = (1U & (IData)((0xccaaf0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xee22fa0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___012944_)))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O))))))))));
    wasmetal_core__DOT___060699_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h92b02c04__0))))));
    wasmetal_core__DOT___127747___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___024983_));
    wasmetal_core__DOT___127810___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025916_)
                  ? (IData)(wasmetal_core__DOT___025885_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127824___O) 
                     >> 1U)));
    wasmetal_core__DOT___127825___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026115_)
                  ? (IData)(wasmetal_core__DOT___127825___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                             >> 4U))));
    vlSelf->wasmetal_core__DOT___068415_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068409_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068408_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066141_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068399_)))))))))))));
    wasmetal_core__DOT___068439_ = (1U & (IData)((0x5f3f00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___068433_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068432_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___066288_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0xa3U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067499_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___068423_)))))))))))));
    wasmetal_core__DOT___068489_ = (1U & (IData)((0xf0fb00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___068488_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068487_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068486_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xb0U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066308_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___063837_)))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0x5533f0f000000000ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067595_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068075_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068475_)))))))))))))))));
    wasmetal_core__DOT___060784_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___060781_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___060780_)))));
    wasmetal_core__DOT___060683_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___060658_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___060660_)))));
    wasmetal_core__DOT___061228_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___061197_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061195_)))));
    vlSelf->wasmetal_core__DOT___057496_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff00ff00ff000eULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                           << 5U) 
                                                                          | (((IData)(wasmetal_core__DOT___057478_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057477_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x4f00U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                                                >> 2U))))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                                                & (IData)(
                                                                                (0xff00ffeeff00fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012942_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7a970221__0))))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xfff1ffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___057489_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057488_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x4f00U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                                                >> 2U))))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((~ 
                                                                                (0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127685___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0)))) 
                                                                                & ((1U 
                                                                                & (0x1000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057399_))))))
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___010376_))
                                                                                 : (IData)(
                                                                                (0xffff00fffffff1ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(
                                                                                (0xff00fff100000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha5e2ba13__0))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5c1422ca__0)))))))))))))))))))))));
    wasmetal_core__DOT___061289_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___060696_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___060699_)))));
    wasmetal_core__DOT___127747___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127747___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127810___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025917_)
                  ? (IData)(wasmetal_core__DOT___127810___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127824___O) 
                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127825___O = (
                                                   (((IData)(wasmetal_core__DOT___026116_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___026115_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___026114_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026113_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127825___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127825___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127825___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026065_)))));
    wasmetal_core__DOT___026069_ = (1U & ((IData)(wasmetal_core__DOT___026116_)
                                           ? (IData)(wasmetal_core__DOT___127825___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                      >> 5U))));
    vlSelf->wasmetal_core__DOT___068470_ = (1U & (IData)(
                                                         (0xf0f0f020f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___068439_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068438_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068437_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057577_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012559_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064017_)))))))));
    vlSelf->wasmetal_core__DOT___068514_ = (1U & (0xf7f00000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___068489_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056299_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___060759_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048505_)))))));
    wasmetal_core__DOT___127747___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127747___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127810___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025918_)
                  ? (IData)(wasmetal_core__DOT___127810___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127824___O) 
                     >> 3U)));
    wasmetal_core__DOT___025923_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134229_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127825___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025922_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134229_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127825___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025921_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134229_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127825___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025919_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134229_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127825___O)))));
    wasmetal_core__DOT___127815___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026118_)
                  ? (IData)(wasmetal_core__DOT___026069_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                             >> 6U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127747___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
           ^ (((IData)(wasmetal_core__DOT___127747___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127747___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127747___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024983_)))));
    wasmetal_core__DOT___024987_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127747___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127810___O 
        = ((((IData)(wasmetal_core__DOT___025919_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025918_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025917_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025916_)))) 
           ^ (((IData)(wasmetal_core__DOT___127810___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127810___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127810___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025885_)))));
    wasmetal_core__DOT___025889_ = (1U & ((IData)(wasmetal_core__DOT___025919_)
                                           ? (IData)(wasmetal_core__DOT___127810___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127825___O)));
    wasmetal_core__DOT___127815___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026119_)
                  ? (IData)(wasmetal_core__DOT___127815___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                             >> 7U))));
    wasmetal_core__DOT___013189_ = (1U & (IData)((0x7fff0000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127747___O) 
                                                          << 4U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h238f5c0e__0))))));
    vlSelf->wasmetal_core__DOT___068615_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068611_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128242___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127810___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___060868_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127810___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb1732b67__0))))));
    wasmetal_core__DOT___127748___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127810___O) 
           & (IData)(wasmetal_core__DOT___024987_));
    wasmetal_core__DOT___025805_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134220_.__PVT__alu_sum 
                                                              >> 2U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127810___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025804_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134220_.__PVT__alu_sum 
                                                              >> 1U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127810___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025800_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSymsp->TOP__wasmetal_core__DOT___134220_.__PVT__alu_sum) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127810___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___127811___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025921_)
                  ? (IData)(wasmetal_core__DOT___025889_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127825___O) 
                     >> 1U)));
    wasmetal_core__DOT___127815___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026120_)
                  ? (IData)(wasmetal_core__DOT___127815___DOT__CO__BRA__1__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                             >> 8U))));
    vlSelf->wasmetal_core__DOT___057676_ = (1U & (IData)(
                                                         (0x10ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057671_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057670_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___013191_)
                                                                          ? 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___011074_)
                                                                           ? (IData)(
                                                                                (0x8808aa0aaa0aULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013190_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___013189_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013188_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013187_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x7fff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127745___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h238f5c0e__0)))))))))))))
                                                                           : 
                                                                          (0x2fU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013190_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___013187_)))))
                                                                          : 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___011074_)
                                                                           ? 
                                                                          (0xdddU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013190_) 
                                                                                << 2U) 
                                                                               | (((IData)(wasmetal_core__DOT___013189_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013188_)))))
                                                                           : 
                                                                          (7U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___013190_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xa8a800fcfcfcfcULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012497_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013188_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013191_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012661_)))))))))))))))));
    wasmetal_core__DOT___060871_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___060868_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___060867_)))));
    wasmetal_core__DOT___127802___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(wasmetal_core__DOT___025800_)) 
                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127810___O) 
                    >> 1U)));
    wasmetal_core__DOT___127811___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025922_)
                  ? (IData)(wasmetal_core__DOT___127811___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127825___O) 
                     >> 2U)));
    wasmetal_core__DOT___026074_ = (1U & ((IData)(wasmetal_core__DOT___026121_)
                                           ? (IData)(wasmetal_core__DOT___127815___DOT__CO__BRA__2__KET__)
                                           : (IData)(
                                                     (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                      >> 9U))));
    wasmetal_core__DOT____Vcellout___127815___O = (
                                                   (((IData)(wasmetal_core__DOT___026121_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___026120_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___026119_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026118_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127815___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127815___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127815___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026069_)))));
    wasmetal_core__DOT___127802___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025804_)
                  ? (IData)(wasmetal_core__DOT___127802___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127810___O) 
                     >> 2U)));
    wasmetal_core__DOT___127811___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025923_)
                  ? (IData)(wasmetal_core__DOT___127811___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127825___O) 
                     >> 3U)));
    wasmetal_core__DOT___127816___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026122_)
                  ? (IData)(wasmetal_core__DOT___026074_)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                             >> 0xaU))));
    wasmetal_core__DOT___025927_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134229_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127815___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025926_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134229_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127815___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025925_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134229_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127815___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025924_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134229_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127815___O)))));
    wasmetal_core__DOT___127802___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025805_)
                  ? (IData)(wasmetal_core__DOT___127802___DOT__CO__BRA__1__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127810___O) 
                     >> 3U)));
    wasmetal_core__DOT___127816___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___026123_)
                  ? (IData)(wasmetal_core__DOT___127816___DOT__CO__BRA__0__KET__)
                  : (IData)((vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                             >> 0xbU))));
    wasmetal_core__DOT____Vcellout___127811___O = (
                                                   (((IData)(wasmetal_core__DOT___025924_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025923_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025922_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025921_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127811___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127811___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127811___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025889_)))));
    wasmetal_core__DOT___025894_ = (1U & ((IData)(wasmetal_core__DOT___025924_)
                                           ? (IData)(wasmetal_core__DOT___127811___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127815___O)));
    wasmetal_core__DOT____Vcellout___127816___O = (
                                                   (((IData)(wasmetal_core__DOT___026124_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___026123_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___026122_))) 
                                                   ^ 
                                                   ((8U 
                                                     & (((IData)(wasmetal_core__DOT___026124_)
                                                          ? (IData)(wasmetal_core__DOT___127816___DOT__CO__BRA__1__KET__)
                                                          : (IData)(
                                                                    (vlSymsp->TOP__wasmetal_core__DOT___134221_.__PVT__alu_sum 
                                                                     >> 0xcU))) 
                                                        << 3U)) 
                                                    | (((IData)(wasmetal_core__DOT___127816___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127816___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___026074_)))));
    wasmetal_core__DOT___025809_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134220_.__PVT__alu_sum 
                                                              >> 6U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127811___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025808_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134220_.__PVT__alu_sum 
                                                              >> 5U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127811___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025807_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134220_.__PVT__alu_sum 
                                                              >> 4U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127811___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025806_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134220_.__PVT__alu_sum 
                                                              >> 3U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127811___O)))));
    wasmetal_core__DOT___127812___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025925_)
                  ? (IData)(wasmetal_core__DOT___025894_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127815___O) 
                     >> 1U)));
    wasmetal_core__DOT___025930_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134229_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127816___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025929_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134229_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127816___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025928_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134229_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127816___O)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127802___O 
        = ((((IData)(wasmetal_core__DOT___025806_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025805_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025804_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025800_)))) 
           ^ (((IData)(wasmetal_core__DOT___127802___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127802___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___127802___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    wasmetal_core__DOT___025793_ = (1U & ((IData)(wasmetal_core__DOT___025806_)
                                           ? (IData)(wasmetal_core__DOT___127802___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127811___O)));
    wasmetal_core__DOT___127812___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025926_)
                  ? (IData)(wasmetal_core__DOT___127812___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127815___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT___068664_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068660_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128242___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    vlSelf->wasmetal_core__DOT___068712_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068708_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128243___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    vlSelf->wasmetal_core__DOT___068761_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068757_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128243___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___061033_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h91f4b3ba__0))))));
    wasmetal_core__DOT___060944_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h68f6955f__0))))));
    wasmetal_core__DOT___061114_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O)) 
                                                    | (IData)(vlSelf->__VdfgTmp_haaeadd36__0))))));
    wasmetal_core__DOT___061196_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
                                                        >> 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd96a7b90__0))))));
    vlSelf->wasmetal_core__DOT___057509_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xee22fa0aU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___010650_)))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127674___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
                                                                  >> 3U))))))));
    wasmetal_core__DOT___057121_ = (1U & (IData)((0xf3f5f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0x1d1d00000f55ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009904_)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127674___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
                                                                     >> 1U))))))))));
    wasmetal_core__DOT___127748___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
           & (IData)(wasmetal_core__DOT___127748___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127803___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025807_)
                  ? (IData)(wasmetal_core__DOT___025793_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127811___O) 
                     >> 1U)));
    wasmetal_core__DOT___127812___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025927_)
                  ? (IData)(wasmetal_core__DOT___127812___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127815___O) 
                     >> 3U)));
    wasmetal_core__DOT___061042_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061033_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___061032_)))));
    wasmetal_core__DOT___060947_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___060944_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___060943_)))));
    wasmetal_core__DOT___061123_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061114_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___061113_)))));
    wasmetal_core__DOT___061205_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061196_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061195_)))));
    wasmetal_core__DOT___127748___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127748___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127803___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025808_)
                  ? (IData)(wasmetal_core__DOT___127803___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127811___O) 
                     >> 2U)));
    wasmetal_core__DOT___025898_ = (1U & ((IData)(wasmetal_core__DOT___025928_)
                                           ? (IData)(wasmetal_core__DOT___127812___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127816___O)));
    wasmetal_core__DOT____Vcellout___127812___O = (
                                                   (((IData)(wasmetal_core__DOT___025928_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025927_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025926_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025925_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127812___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127812___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127812___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025894_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127748___O 
        = (((0xeU & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
                     << 1U)) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127810___O))) 
           ^ (((IData)(wasmetal_core__DOT___127748___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127748___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127748___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024987_)))));
    wasmetal_core__DOT___024991_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
                                     >> 2U) & (IData)(wasmetal_core__DOT___127748___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127803___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025809_)
                  ? (IData)(wasmetal_core__DOT___127803___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127811___O) 
                     >> 3U)));
    wasmetal_core__DOT___127813___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025929_)
                  ? (IData)(wasmetal_core__DOT___025898_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127816___O) 
                     >> 1U)));
    wasmetal_core__DOT___025801_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134220_.__PVT__alu_sum 
                                                              >> 0xaU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127812___O) 
                                                       >> 3U)))));
    wasmetal_core__DOT___025812_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134220_.__PVT__alu_sum 
                                                              >> 9U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127812___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___025811_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134220_.__PVT__alu_sum 
                                                              >> 8U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127812___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025810_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134220_.__PVT__alu_sum 
                                                              >> 7U)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127812___O)))));
    wasmetal_core__DOT___127737___DOT__CO__BRA__0__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
            >> 3U) & (IData)(wasmetal_core__DOT___024991_));
    wasmetal_core__DOT____Vcellout___127813___O = (
                                                   (((IData)(wasmetal_core__DOT___025930_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___025929_)) 
                                                   ^ 
                                                   (((4U 
                                                      & (((IData)(wasmetal_core__DOT___025930_)
                                                           ? (IData)(wasmetal_core__DOT___127813___DOT__CO__BRA__0__KET__)
                                                           : 
                                                          ((IData)(wasmetal_core__DOT____Vcellout___127816___O) 
                                                           >> 2U)) 
                                                         << 2U)) 
                                                     | ((IData)(wasmetal_core__DOT___127813___DOT__CO__BRA__0__KET__) 
                                                        << 1U)) 
                                                    | (IData)(wasmetal_core__DOT___025898_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127803___O 
        = ((((IData)(wasmetal_core__DOT___025810_) 
             << 3U) | (((IData)(wasmetal_core__DOT___025809_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___025808_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___025807_)))) 
           ^ (((IData)(wasmetal_core__DOT___127803___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127803___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127803___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___025793_)))));
    wasmetal_core__DOT___025797_ = (1U & ((IData)(wasmetal_core__DOT___025810_)
                                           ? (IData)(wasmetal_core__DOT___127803___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127812___O)));
    wasmetal_core__DOT___025803_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134220_.__PVT__alu_sum 
                                                              >> 0xcU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127813___O) 
                                                       >> 1U)))));
    wasmetal_core__DOT___025802_ = (1U & (6U >> ((2U 
                                                  & ((IData)(
                                                             (vlSymsp->TOP__wasmetal_core__DOT___134220_.__PVT__alu_sum 
                                                              >> 0xbU)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127813___O)))));
    vlSelf->wasmetal_core__DOT___068952_ = (1U & (0xe00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0x153f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___068947_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128244___O) 
                                                                           << 2U)) 
                                                                       | ((4U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xcfaf0f0f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068945_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068944_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b57__05d)))))))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hbd712dd8__0))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xafcfU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___068941_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067071_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0xeeee0f0fff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068101_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068549_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068747_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10281295__0)))))))))))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048287_))))));
    wasmetal_core__DOT___068976_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068973_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128244___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___060874_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
                                                        >> 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd69bf43a__0))))));
    wasmetal_core__DOT___060787_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he43dd87d__0))))));
    wasmetal_core__DOT___060657_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h4a046d69__0))))));
    wasmetal_core__DOT___056871_ = (1U & (IData)((0x33550f0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xee22fa0aU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___010034_)))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127675___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___060698_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h2225d234__0))))));
    wasmetal_core__DOT___013011_ = (1U & (IData)((0x55330f0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xccaaf0f0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((0xee22fa0aU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009907_)))))) 
                                                                            << 2U)) 
                                                                        | ((2U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127674___O) 
                                                                               >> 2U)) 
                                                                           | (1U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> 
                                                                    ((2U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                                         >> 2U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___127737___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
           & (IData)(wasmetal_core__DOT___127737___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127804___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025811_)
                  ? (IData)(wasmetal_core__DOT___025797_)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127812___O) 
                     >> 1U)));
    wasmetal_core__DOT___068977_ = (1U & (IData)((0x3f2a00000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___068976_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068975_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___060935_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0xafcfU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___068967_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___067149_) 
                                                                                << 1U) 
                                                                               | (1U 
                                                                                & (IData)(
                                                                                (0xeeee0f0fff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068152_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068601_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068791_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068963_))))))))))))))))))))))))));
    wasmetal_core__DOT___060900_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___060868_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___060874_)))));
    wasmetal_core__DOT___060875_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___060874_))));
    wasmetal_core__DOT___060817_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___060781_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___060787_)))));
    wasmetal_core__DOT___060788_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___060787_))));
    wasmetal_core__DOT___060663_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___060658_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___060657_)))));
    wasmetal_core__DOT___060684_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___060657_))));
    vlSelf->wasmetal_core__DOT___012019_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xdddd000f000fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056872_) 
                                                                           << 4U) 
                                                                          | (((IData)(wasmetal_core__DOT___056871_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & (((0xdf0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xccfe0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                                                >> 2U))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                                                >> 2U))))))) 
                                                                                & (IData)(
                                                                                (0xff00ff00fffafffcULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012024_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4364218e__0)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xee22fa0a00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010034_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf3faU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127724___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                                                >> 2U)))))))))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00f000ff00eeULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056881_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((0xccaaf0f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010647_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127810___O))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x4f00U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                                                >> 2U))))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                                                & (IData)(
                                                                                (0xff00ff00fffefff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012055_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012054_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012053_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012052_)))))))))))))))))))))));
    wasmetal_core__DOT___060703_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___060699_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___060698_)))));
    wasmetal_core__DOT___127737___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127737___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127804___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025812_)
                  ? (IData)(wasmetal_core__DOT___127804___DOT__CO__BRA__0__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127812___O) 
                     >> 2U)));
    vlSelf->wasmetal_core__DOT___068978_ = (1U & (0xfafc0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___068977_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4364218e__0))))));
    vlSelf->wasmetal_core__DOT___060916_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f0ccccff005555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___060900_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060899_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060897_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060904_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf5533ffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                 << 3U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h0f4209a4__0)))))))));
    vlSelf->wasmetal_core__DOT___060906_ = (1U & (IData)(
                                                         (0xccccaaaaf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060900_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060899_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((0xf0f5533U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 2U)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef814ba9__0))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060869_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___060897_)))))))));
    vlSelf->wasmetal_core__DOT___060884_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0f0cc55U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0xccaaf0f0U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                            << 3U) 
                                                                           | (((IData)(wasmetal_core__DOT___060871_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060870_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060869_)))))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___060876_) 
                                                                      << 1U) 
                                                                     | (IData)(wasmetal_core__DOT___060875_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f555500ff3333ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060881_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060880_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h805d75e1__0))))))))))));
    vlSelf->wasmetal_core__DOT___060924_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f03333ff005555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___060871_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060876_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___060875_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060880_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x55330fffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060881_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h805d75e1__0))))))))));
    vlSelf->wasmetal_core__DOT___060831_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f0ccccff005555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___060817_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060816_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060814_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060821_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf5533ffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                 << 3U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hc1ae2972__0)))))))));
    wasmetal_core__DOT___060823_ = (1U & (IData)((0xccccaaaaf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___060817_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___060816_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xacU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xf0f5533U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 1U)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha9869a20__0))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___060782_)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___060814_)))))))));
    vlSelf->wasmetal_core__DOT___060798_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0f0cc55U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0xccaaf0f0U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                            << 3U) 
                                                                           | (((IData)(wasmetal_core__DOT___060784_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060783_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060782_)))))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___060789_) 
                                                                      << 1U) 
                                                                     | (IData)(wasmetal_core__DOT___060788_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f555500ff3333ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060795_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060794_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h743eef07__0))))))))))));
    vlSelf->wasmetal_core__DOT___060843_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f03333ff005555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___060784_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060789_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___060788_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060794_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x55330fffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060795_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h743eef07__0))))))))));
    vlSelf->wasmetal_core__DOT___060738_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xaaaaccccf0f000ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((0xa0cU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h73281823__0)) 
                                                                              << 3U)) 
                                                                          | (((IData)(wasmetal_core__DOT___060663_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060662_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060670_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf5533ffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                 << 3U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h73a9d128__0)))))))));
    wasmetal_core__DOT___060671_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___060663_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___060662_)))));
    vlSelf->wasmetal_core__DOT___060692_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0f5533U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0x5533f0f0U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060682_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060665_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060667_)))))) 
                                                                      << 2U)) 
                                                                  | (((IData)(wasmetal_core__DOT___060684_) 
                                                                      << 1U) 
                                                                     | (IData)(wasmetal_core__DOT___060683_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f0aaaaff00ccccULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060689_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060688_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hfc1711e0__0))))))))))));
    vlSelf->wasmetal_core__DOT___060748_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xccccf0f0ff00aaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___060684_) 
                                                                           << 3U) 
                                                                          | (((IData)(wasmetal_core__DOT___060683_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060682_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060688_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf5533ffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060689_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hfc1711e0__0))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127737___O 
        = (((0xeU & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
                     << 1U)) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
                                      >> 3U))) ^ (((IData)(wasmetal_core__DOT___127737___DOT__CO__BRA__2__KET__) 
                                                   << 3U) 
                                                  | (((IData)(wasmetal_core__DOT___127737___DOT__CO__BRA__1__KET__) 
                                                      << 2U) 
                                                     | (((IData)(wasmetal_core__DOT___127737___DOT__CO__BRA__0__KET__) 
                                                         << 1U) 
                                                        | (IData)(wasmetal_core__DOT___024991_)))));
    wasmetal_core__DOT___024996_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
                                     >> 2U) & (IData)(wasmetal_core__DOT___127737___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127804___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT___025801_)
                  ? (IData)(wasmetal_core__DOT___127804___DOT__CO__BRA__1__KET__)
                  : ((IData)(wasmetal_core__DOT____Vcellout___127812___O) 
                     >> 3U)));
    vlSelf->wasmetal_core__DOT___060907_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060906_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff33330f0f5555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060904_) 
                                                                            << 3U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h0f4209a4__0)))))))))));
    vlSelf->wasmetal_core__DOT___027561_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___027479_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060884_))));
    vlSelf->wasmetal_core__DOT___061794_ = (1U & (IData)(
                                                         (0xff0faa0aff0fcc0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061638_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054745_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060823_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061773_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061790_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3e487a94__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he2d6a2af__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haf785b2f__0)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___060824_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___060823_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff33330f0f5555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060821_) 
                                                                            << 3U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hc1ae2972__0)))))))))));
    vlSelf->wasmetal_core__DOT___027575_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___027493_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060798_))));
    wasmetal_core__DOT___043936_ = (1U & (0xfeU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___060738_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060916_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___060831_))))));
    __VdfgTmp_h8648f195__0 = (((IData)(vlSelf->wasmetal_core__DOT___060916_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___060831_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___060738_)));
    vlSelf->__VdfgTmp_h02d5ce92__0 = (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                  << 4U) 
                                                 | (((IData)(wasmetal_core__DOT___060671_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060670_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0x44444444f0f0ff00ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007881_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h18f87701__0))))))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (4U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___060665_)))))))));
    __VdfgTmp_hfa1f27b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___060798_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___060692_));
    vlSelf->wasmetal_core__DOT___027574_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___027492_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060692_))));
    wasmetal_core__DOT___127738___DOT__CO__BRA__0__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
            >> 3U) & (IData)(wasmetal_core__DOT___024996_));
    wasmetal_core__DOT___025789_ = (1U & ((IData)(wasmetal_core__DOT___025802_)
                                           ? (IData)(wasmetal_core__DOT___127804___DOT__CO__BRA__2__KET__)
                                           : (IData)(wasmetal_core__DOT____Vcellout___127813___O)));
    wasmetal_core__DOT____Vcellout___127804___O = (
                                                   (((IData)(wasmetal_core__DOT___025802_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___025801_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___025812_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025811_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127804___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127804___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127804___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___025797_)))));
    wasmetal_core__DOT___027568_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___027486_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___060907_))));
    wasmetal_core__DOT___027567_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___027485_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___060824_))));
    wasmetal_core__DOT___043947_ = (1U & (0x8001U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                                            << 3U) 
                                           | (IData)(__VdfgTmp_h8648f195__0))));
    vlSelf->wasmetal_core__DOT___043901_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x1111f0f0ff00ff00ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h02d5ce92__0))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xf0f0f0fff55ff33ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h73281823__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbbe663c1__0))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xffff5533fffff0f0ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hebcfe313__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h284fdec6__0))))))))))))));
    wasmetal_core__DOT____Vcellout___127805___O = ((IData)(wasmetal_core__DOT___025803_) 
                                                   ^ 
                                                   ((2U 
                                                     & (((IData)(wasmetal_core__DOT___025803_)
                                                          ? (IData)(wasmetal_core__DOT___025789_)
                                                          : 
                                                         ((IData)(wasmetal_core__DOT____Vcellout___127813___O) 
                                                          >> 1U)) 
                                                        << 1U)) 
                                                    | (IData)(wasmetal_core__DOT___025789_)));
    vlSelf->wasmetal_core__DOT___069050_ = (1U & (0xe00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0x153f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___069045_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128244___O)) 
                                                                       | ((4U 
                                                                           & ((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xcfaf0f0f00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___069043_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069042_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b59__05d)))))))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_he56eea3a__0))))))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xafcfU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___069039_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067190_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0xeeee0f0fff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068237_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068651_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068846_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h280fcf30__0)))))))))))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048287_))))));
    wasmetal_core__DOT___069096_ = (1U & (IData)((0x777000007770777ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069095_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128245___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
                                                                     >> 1U))))))))));
    wasmetal_core__DOT___069145_ = (1U & (IData)((0x777000007770777ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069144_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128245___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019396_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
                                                                     >> 2U))))))))));
    wasmetal_core__DOT___069168_ = (1U & (IData)((0x153f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069163_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128245___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha02e1627__0))))))));
    wasmetal_core__DOT___061036_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
                                                        << 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h1c7a54d6__0))))));
    wasmetal_core__DOT___060950_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h2577a83c__0))))));
    wasmetal_core__DOT___061117_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (IData)(wasmetal_core__DOT____Vcellout___127804___O)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hdf1f98b8__0))))));
    wasmetal_core__DOT___061199_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
                                                        >> 1U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb79381c2__0))))));
    wasmetal_core__DOT___057518_ = (1U & (IData)((0x3f5fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057517_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___057277_ = (1U & (IData)((0xf0f0f0fd00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057263_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xfdd0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                                                >> 1U))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0x35U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O)) 
                                                                        | (1U 
                                                                           & ((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
                                                                              >> 2U))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___010378_)))))))));
    wasmetal_core__DOT___057075_ = (1U & (IData)((0xff00fff400000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057073_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0x33550f0f00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hab523f16__0)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127675___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___127804___O))))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                     ? 
                                                                    ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                      ? 
                                                                     (1U 
                                                                      >> (IData)(vlSelf->wasmetal_core__DOT___012331_))
                                                                      : 
                                                                     (0xbU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___012331_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127675___O) 
                                                                              >> 2U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))
                                                                     : 
                                                                    ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                                      ? 
                                                                     (1U 
                                                                      >> (IData)(vlSelf->wasmetal_core__DOT___012331_))
                                                                      : 
                                                                     (0xa0cU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012331_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012330_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___012329_))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___009691_)))))))));
    wasmetal_core__DOT___127738___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
           & (IData)(wasmetal_core__DOT___127738___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___027560_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___027478_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043901_))));
    wasmetal_core__DOT___069247_ = (1U & (IData)((0x7000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019400_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069240_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069239_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> 
                                                                 ((2U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128245___O) 
                                                                      >> 2U)) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___019396_))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___127805___O))))))))));
    wasmetal_core__DOT___060700_ = (1U & (0xf0f5533U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((IData)(wasmetal_core__DOT____Vcellout___127805___O) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb23bd85a__0))))));
    wasmetal_core__DOT___013012_ = (1U & (0x1f000000U 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                  << 4U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0xccaa00000f0fULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056134_)))))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___127805___O))))))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0xf0440000U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))))))));
    wasmetal_core__DOT___069100_ = (1U & (IData)((0x311f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069097_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___069096_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha5ccee3f__0))))))));
    wasmetal_core__DOT___069148_ = (1U & (IData)((0x311f000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069097_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___069145_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha5ccee3f__0))))))));
    wasmetal_core__DOT___069170_ = (1U & (IData)((0xaf2300000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___069168_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069167_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0xff0044440000f0f0ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048869_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048870_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0643d6d2__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___000169_)))))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0x1111f0f0ff00ff00ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067468_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068399_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xac00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068963_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8888f0f000ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069154_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069133_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063825_))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068792_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063832_))))))))))))))))))));
    wasmetal_core__DOT___061040_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___061036_))));
    wasmetal_core__DOT___061059_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061033_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061036_)))));
    wasmetal_core__DOT___060970_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___060944_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___060950_)))));
    wasmetal_core__DOT___060951_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___060950_))));
    wasmetal_core__DOT___061138_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061114_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061117_)))));
    wasmetal_core__DOT___061121_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___061117_))));
    wasmetal_core__DOT___061231_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___061196_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___061199_)))));
    wasmetal_core__DOT___061203_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___061199_))));
    vlSelf->wasmetal_core__DOT___057526_ = (1U & (IData)(
                                                         (0xf0f0007700000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057523_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0ff44ffULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___057518_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f033aaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056129_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127725___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc4dae929__0)))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))));
    vlSelf->wasmetal_core__DOT___057285_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___009693_)) 
                                                  | ((1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O))
                                                      ? 
                                                     (2U 
                                                      >> 
                                                      (1U 
                                                       & (IData)(
                                                                 (0xffff0000bb0bULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                    << 5U) 
                                                                   | (((IData)(wasmetal_core__DOT___057277_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057276_) 
                                                                          << 3U) 
                                                                         | ((4U 
                                                                             & ((0xdf0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                                                >> 1U))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                                                >> 1U))))))) 
                                                                                << 2U)) 
                                                                            | ((2U 
                                                                                & ((0xf3fa0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127725___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                                                >> 1U)))))))))))) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & (IData)(
                                                                                (0xee22fa0a00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2275929a__0))))))))))))))))))))
                                                      : 
                                                     (0xf0f0aa33U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & ((IData)(
                                                                         (0xaaaaccccff0fff00ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057282_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009808_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009905_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O) 
                                                                                >> 1U))))))))) 
                                                                 << 2U)) 
                                                             | ((2U 
                                                                 & ((0xdf0fU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___057260_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                          << 3U) 
                                                                         | ((4U 
                                                                             & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                                                >> 1U))))))))) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 1U) 
                                                                               | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                                                >> 1U))))))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (0xccaaf0f0U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010649_)))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127674___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O) 
                                                                                >> 2U))))))))))))))));
    wasmetal_core__DOT___127738___DOT__CO__BRA__2__KET__ 
        = (((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127738___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127978___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___027560_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___027478_));
    vlSelf->wasmetal_core__DOT___069250_ = (1U & (IData)(
                                                         (0xafcf00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___069247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069246_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067500_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xeeee0f0f00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068423_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068847_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xca00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2926b28a__0)))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f306e5e__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h280fcf30__0)))))))))))))))))));
    wasmetal_core__DOT___061292_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___060698_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___060700_)))));
    wasmetal_core__DOT___060702_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___060700_))));
    vlSelf->wasmetal_core__DOT___013001_ = (1U & ((1U 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O)))))
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___009691_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(wasmetal_core__DOT___013012_) 
                                                      << 1U) 
                                                     | (IData)(wasmetal_core__DOT___013011_)))
                                                    : (IData)(
                                                              (0xb0000000b0bULL 
                                                               >> 
                                                               (((IData)(wasmetal_core__DOT___013012_) 
                                                                 << 5U) 
                                                                | (((IData)(wasmetal_core__DOT___013011_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013010_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((IData)(
                                                                                (0xf3fa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057569_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127724___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                                                >> 3U)))))))))))))) 
                                                                             << 2U)) 
                                                                         | ((2U 
                                                                             & ((0xdf0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                                                >> 3U))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                                                >> 3U))))))) 
                                                                                << 1U)) 
                                                                            | (1U 
                                                                               & (IData)(
                                                                                (0x44440000000fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057554_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057553_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127674___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))))))))))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___009691_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(wasmetal_core__DOT___013012_))
                                                    : 
                                                   (0xbU 
                                                    >> 
                                                    (((IData)(wasmetal_core__DOT___013012_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___013010_))))));
    vlSelf->wasmetal_core__DOT___069101_ = (1U & (IData)(
                                                         (0x3f2a00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___069100_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069099_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056168_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xafcfU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___069089_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067305_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xeeee0f0fff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068290_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068699_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x33550f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068962_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8025ed93__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb27da868__0)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___069150_ = (1U & (IData)(
                                                         (0x3f2a00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___069148_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069147_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056124_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xafcfU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___069138_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067596_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067335_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xeeee0f0fff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068344_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068748_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x33550f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069034_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f306e5e__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10281295__0)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___069171_ = (1U & (0xf7f00000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___069170_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb6e1260e__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061264_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048505_)))))));
    vlSelf->wasmetal_core__DOT___061049_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xaaaaf0f0ff003333ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___061042_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061041_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___061040_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061038_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061037_)))))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f555500ff3333ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061046_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061045_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h87c0b1ab__0))))))))))));
    vlSelf->wasmetal_core__DOT___061096_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f03333ff005555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___061042_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061041_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___061040_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061045_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x55330fffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061046_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h87c0b1ab__0))))))))));
    vlSelf->wasmetal_core__DOT___061086_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f0ccccff005555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___061059_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061058_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061056_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061062_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf5533ffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061063_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hd173054d__0))))))))));
    wasmetal_core__DOT___061065_ = (1U & (IData)((0xccccaaaaf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___061059_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061058_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xacU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xf0f5533U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 4U)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc9c602ec__0))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___061037_)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061056_)))))))));
    vlSelf->wasmetal_core__DOT___060997_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f0ccccff005555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___060970_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060969_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060967_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060974_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf5533ffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                 << 3U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hc0fd2d13__0)))))))));
    wasmetal_core__DOT___060976_ = (1U & (IData)((0xccccaaaaf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___060970_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___060969_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xacU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xf0f5533U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 3U)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1327a702__0))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___060945_)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___060967_)))))))));
    vlSelf->wasmetal_core__DOT___060960_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xf0f0cc55U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((0xccaaf0f0U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                            << 3U) 
                                                                           | (((IData)(wasmetal_core__DOT___060947_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060946_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060945_)))))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___060952_) 
                                                                      << 1U) 
                                                                     | (IData)(wasmetal_core__DOT___060951_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f555500ff3333ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060957_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060956_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h85e16522__0))))))))))));
    vlSelf->wasmetal_core__DOT___061007_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f03333ff005555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___060947_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060952_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___060951_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060956_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x55330fffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060957_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h85e16522__0))))))))));
    vlSelf->wasmetal_core__DOT___061168_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f0ccccff005555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___061138_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061137_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061135_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061142_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf5533ffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                 << 3U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h02022f9b__0)))))))));
    wasmetal_core__DOT___061144_ = (1U & (IData)((0xccccaaaaf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___061138_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061137_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xacU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xf0f5533U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 5U)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h57efbd27__0))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___061118_)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___061135_)))))))));
    vlSelf->wasmetal_core__DOT___061176_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f03333ff005555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___061123_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061122_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___061121_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061126_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x55330fffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061127_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hb1a6f4d3__0))))))))));
    vlSelf->wasmetal_core__DOT___061130_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xaaaaf0f0ff003333ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___061123_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061122_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___061121_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061119_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061118_)))))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f555500ff3333ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061127_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061126_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hb1a6f4d3__0))))))))))));
    wasmetal_core__DOT___061237_ = (1U & (IData)((0xccccaaaaf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___061231_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061230_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xacU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xf0f5533U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 6U)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc326eb38__0))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___061200_)))) 
                                                                   << 1U)) 
                                                               | (IData)(wasmetal_core__DOT___061228_)))))))));
    vlSelf->wasmetal_core__DOT___061250_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f0ccccff005555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___061231_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061230_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___061228_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061235_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf5533ffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                 << 3U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h0fd3f1c4__0)))))))));
    vlSelf->wasmetal_core__DOT___061258_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f03333ff005555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___061205_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061204_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___061203_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061208_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x55330fffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061209_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hcf41fd11__0))))))))));
    vlSelf->wasmetal_core__DOT___061212_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xaaaaf0f0ff003333ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___061205_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061204_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___061203_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061201_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061200_)))))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f555500ff3333ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061209_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061208_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hcf41fd11__0))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127738___O 
        = (((0xeU & ((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
                     << 1U)) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127803___O) 
                                      >> 3U))) ^ (((IData)(wasmetal_core__DOT___127738___DOT__CO__BRA__2__KET__) 
                                                   << 3U) 
                                                  | (((IData)(wasmetal_core__DOT___127738___DOT__CO__BRA__1__KET__) 
                                                      << 2U) 
                                                     | (((IData)(wasmetal_core__DOT___127738___DOT__CO__BRA__0__KET__) 
                                                         << 1U) 
                                                        | (IData)(wasmetal_core__DOT___024996_)))));
    wasmetal_core__DOT___025000_ = (((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
                                     >> 2U) & (IData)(wasmetal_core__DOT___127738___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128609___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___027567_) ? (IData)(wasmetal_core__DOT___127978___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___027485_));
    wasmetal_core__DOT___061298_ = (1U & (IData)((0xccccaaaaf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___061292_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061291_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0xcaU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061280_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (0xf0f5533U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 7U)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h57d78adc__0))))))))) 
                                                                   << 1U)) 
                                                               | (IData)(wasmetal_core__DOT___061289_)))))))));
    vlSelf->wasmetal_core__DOT___061320_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f0ccccff005555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                        << 4U) 
                                                                       | (((IData)(wasmetal_core__DOT___061292_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061291_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___061289_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061296_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf5533ffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                 << 3U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h88cf509b__0)))))))));
    wasmetal_core__DOT___043563_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0xff003333f0f05555ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___060704_) 
                                                                 << 3U) 
                                                                | (((IData)(wasmetal_core__DOT___060703_) 
                                                                    << 2U) 
                                                                   | (((IData)(wasmetal_core__DOT___060702_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___060701_)))))))) 
                                                << 1U)) 
                                              | (1U 
                                                 & (0x33550fffU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                         << 3U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h415259f4__0)))))))));
    vlSelf->wasmetal_core__DOT___043541_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xaaaaf0f0ff003333ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060704_) 
                                                                           << 3U) 
                                                                          | (((IData)(wasmetal_core__DOT___060703_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___060702_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___060659_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061280_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061279_)))))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff555533330f0fULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060701_) 
                                                                            << 3U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h415259f4__0)))))))))));
    vlSelf->wasmetal_core__DOT___027563_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___027481_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061049_))));
    vlSelf->wasmetal_core__DOT___061986_ = (1U & (IData)(
                                                         (0xff0faa0aff0fcc0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061638_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054745_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___061065_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061971_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061969_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ffde934__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h64c25376__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ad5bd42__0)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061066_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___061065_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f333300ff5555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061063_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061062_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hd173054d__0))))))))))));
    wasmetal_core__DOT___061935_ = (1U & (IData)((0xff0faa0aff0fcc0cULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061638_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054745_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___060976_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___061907_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xf0f0aaaaff00ccccULL 
                                                                             >> 
                                                                             ((0x20U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 3U)) 
                                                                              | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061933_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha87b9f86__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h782ee59f__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed924a08__0)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___060977_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___060976_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff33330f0f5555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___060974_) 
                                                                            << 3U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hc0fd2d13__0)))))))))));
    __VdfgTmp_h2b50c012__0 = (((IData)(vlSelf->wasmetal_core__DOT___061049_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___060960_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___060884_)));
    vlSelf->wasmetal_core__DOT___027562_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___027480_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060960_))));
    wasmetal_core__DOT___070678_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061007_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___060924_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___060843_)))));
    wasmetal_core__DOT___043939_ = (1U & (0xfeU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___060843_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061007_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___060924_))))));
    wasmetal_core__DOT___043571_ = (1U & (IData)((0x8000000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061168_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061086_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060997_) 
                                                          << 3U) 
                                                         | (IData)(__VdfgTmp_h8648f195__0)))))));
    wasmetal_core__DOT___043948_ = (1U & (0x8001U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___061168_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061086_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___060997_))))));
    wasmetal_core__DOT___043937_ = (1U & (0xfeU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___060997_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061168_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061086_))))));
    vlSelf->wasmetal_core__DOT___062047_ = (1U & (IData)(
                                                         (0xff0faa0aff0fcc0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061638_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054745_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___061144_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___062031_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062029_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hee831718__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c0fb6b2__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfa295b2__0)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061145_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___061144_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff33330f0f5555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061142_) 
                                                                            << 3U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h02022f9b__0)))))))))));
    vlSelf->wasmetal_core__DOT___027564_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___027482_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061130_))));
    vlSelf->wasmetal_core__DOT___062105_ = (1U & (IData)(
                                                         (0xff0faa0aff0fcc0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061638_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054745_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___061237_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___062090_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062088_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1f51ea8e__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb0afff05__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128811___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf366d942__0)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061238_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___061237_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff33330f0f5555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061235_) 
                                                                            << 3U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h0fd3f1c4__0)))))))))));
    wasmetal_core__DOT___043932_ = (1U & (0xfeU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___061096_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061258_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061176_))))));
    wasmetal_core__DOT___043944_ = (1U & (0x8001U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___061258_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061176_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061096_))))));
    __VdfgTmp_h94355ed4__0 = (((IData)(vlSelf->wasmetal_core__DOT___061212_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___061130_));
    vlSelf->wasmetal_core__DOT___027565_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___027483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061212_))));
    wasmetal_core__DOT___057006_ = (1U & (0xf3f5U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127738___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127748___O)))))));
    wasmetal_core__DOT___127739___DOT__CO__BRA__0__KET__ 
        = (((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
            >> 3U) & (IData)(wasmetal_core__DOT___025000_));
    wasmetal_core__DOT___128609___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___027568_) ? (IData)(wasmetal_core__DOT___128609___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___027486_));
    wasmetal_core__DOT___062159_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___061298_))));
    vlSelf->wasmetal_core__DOT___061299_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060678_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___061298_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff55550f0f3333ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___060664_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060672_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061296_) 
                                                                            << 3U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h88cf509b__0)))))))))));
    wasmetal_core__DOT___070679_ = (1U & (0x40U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061320_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___061250_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___060748_)))));
    wasmetal_core__DOT___043938_ = (1U & (0xefU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___060748_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061320_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061250_))))));
    wasmetal_core__DOT___043573_ = (1U & (0x8000U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___061258_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___061176_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061096_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___043563_))))));
    wasmetal_core__DOT___043933_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___043563_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048322_))));
    __VdfgTmp_hf4482b2c__0 = (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                               << 1U) | (IData)(wasmetal_core__DOT___043563_));
    wasmetal_core__DOT___043896_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___043541_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___062175_))));
    __VdfgTmp_hbda467d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___062175_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___043541_));
    wasmetal_core__DOT___043935_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___043541_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048322_))));
    __VdfgTmp_h38415c57__0 = (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___043541_));
    vlSelf->wasmetal_core__DOT___027566_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___027484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___043541_))));
    vlSelf->wasmetal_core__DOT___027570_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___027488_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061066_))));
    vlSelf->wasmetal_core__DOT___061937_ = (1U & (IData)(
                                                         (0xcc00effe00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___061935_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048270_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048367_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061907_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048443_)))))))));
    wasmetal_core__DOT___027569_ = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___027487_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___060977_))));
    wasmetal_core__DOT___043899_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___062175_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (1U 
                                                       >> (IData)(__VdfgTmp_h2b50c012__0))))));
    wasmetal_core__DOT___043908_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062175_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0x80U 
                                                 >> (IData)(__VdfgTmp_h2b50c012__0)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (1U 
                                                    >> (IData)(__VdfgTmp_h2b50c012__0)))))));
    wasmetal_core__DOT___043950_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___043939_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___070678_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048322_)))));
    vlSelf->wasmetal_core__DOT___027571_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___027489_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061145_))));
    vlSelf->wasmetal_core__DOT___027572_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___027490_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061238_))));
    wasmetal_core__DOT___070677_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___043541_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(__VdfgTmp_h94355ed4__0))))));
    wasmetal_core__DOT___043900_ = (1U & (0xbU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___062175_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(__VdfgTmp_h94355ed4__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___043541_)))));
    wasmetal_core__DOT___012248_ = (1U & (IData)((0xffff8000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___057006_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h22919fe9__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127739___O 
        = (((2U & ((IData)(wasmetal_core__DOT____Vcellout___127805___O) 
                   << 1U)) | (1U & ((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
                                    >> 3U))) ^ (((((IData)(wasmetal_core__DOT____Vcellout___127805___O) 
                                                   & (IData)(wasmetal_core__DOT___127739___DOT__CO__BRA__0__KET__)) 
                                                  << 2U) 
                                                 | ((IData)(wasmetal_core__DOT___127739___DOT__CO__BRA__0__KET__) 
                                                    << 1U)) 
                                                | (IData)(wasmetal_core__DOT___025000_)));
    vlSelf->wasmetal_core__DOT___062174_ = (1U & (IData)(
                                                         (0xeffe00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062160_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___062159_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048367_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061706_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___062157_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048443_)))))))));
    wasmetal_core__DOT___043543_ = (1U & (0x1400U >> 
                                          ((8U & ((8U 
                                                   >> (IData)(__VdfgTmp_hfa1f27b8__0)) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___062175_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___061299_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061238_))))));
    vlSelf->__VdfgTmp_h2edb9803__0 = (((IData)(vlSelf->wasmetal_core__DOT___062175_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___061299_));
    __VdfgTmp_h965ce7cb__0 = (((IData)(vlSelf->wasmetal_core__DOT___061299_) 
                               << 2U) | (IData)(__VdfgTmp_hfa1f27b8__0));
    vlSelf->wasmetal_core__DOT___027573_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___027491_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061299_))));
    wasmetal_core__DOT___043572_ = (1U & (8U >> (((IData)(wasmetal_core__DOT___070679_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___070678_))));
    wasmetal_core__DOT___043949_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___043938_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___070679_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048322_)))));
    wasmetal_core__DOT___043570_ = (1U & (4U >> ((2U 
                                                  & ((1U 
                                                      >> (IData)(__VdfgTmp_h94355ed4__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (9U 
                                                       >> (IData)(__VdfgTmp_h38415c57__0))))));
    wasmetal_core__DOT___043946_ = (1U & (8U >> ((2U 
                                                  & ((9U 
                                                      >> (IData)(__VdfgTmp_h38415c57__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(__VdfgTmp_h94355ed4__0))))));
    wasmetal_core__DOT____Vcellout___127978___O = (
                                                   (((IData)(wasmetal_core__DOT___027569_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___027568_) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___027567_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___027560_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128609___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128609___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | ((IData)(wasmetal_core__DOT___127978___DOT__CO__BRA__0__KET__) 
                                                          << 1U))));
    vlSelf->wasmetal_core__DOT___027529_ = ((IData)(wasmetal_core__DOT___027569_)
                                             ? (IData)(wasmetal_core__DOT___128609___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___027487_));
    wasmetal_core__DOT___043544_ = (1U & (8U >> (((IData)(wasmetal_core__DOT___070677_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x80U 
                                                       >> (IData)(__VdfgTmp_h2b50c012__0))))));
    wasmetal_core__DOT___043909_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___043900_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___070677_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___062175_)))));
    __VdfgTmp_hbed24786__0 = (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                          << 4U) | 
                                         (((IData)(wasmetal_core__DOT___012248_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0xacffU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                   << 3U) 
                                                  | ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                         << 2U)) 
                                                     | ((2U 
                                                         & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                              ? 
                                                             (0xfcfaU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_he65514a2__0)))))
                                                              : 
                                                             (2U 
                                                              >> 
                                                              (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___011101_)
                                                                   ? 
                                                                  (7U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___012262_)))
                                                                   : 
                                                                  (0x3050f0fU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((0x40U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___056968_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd6365363__0))))))))) 
                                                            << 1U)) 
                                                        | (1U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                               ? 
                                                              ((~ (IData)(vlSelf->wasmetal_core__DOT___011743_)) 
                                                               & (0xf0fdU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___012214_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h3659b78c__0)))))
                                                               : 
                                                              (1U 
                                                               >> 
                                                               ((2U 
                                                                 & (((~ (IData)(vlSelf->wasmetal_core__DOT___011101_)) 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                                         ? (IData)(
                                                                                (0xff00ff55fff0ffccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012275_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012180_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x110fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012185_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc338337f__0)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012179_))))))))
                                                                         : 
                                                                        (2U 
                                                                         >> (IData)(vlSelf->wasmetal_core__DOT___012275_)))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (0x80U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___056983_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0)))))))))))) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___010077_))))));
    wasmetal_core__DOT___009690_ = (1U & (4U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127739___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010077_))));
    wasmetal_core__DOT___043538_ = (1U & (0x1fU >> 
                                          ((4U & ((8U 
                                                   >> (IData)(__VdfgTmp_hfa1f27b8__0)) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_h2edb9803__0))));
    wasmetal_core__DOT___043907_ = (1U & (0x8001U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___062175_) 
                                            << 3U) 
                                           | (IData)(__VdfgTmp_h965ce7cb__0))));
    vlSelf->wasmetal_core__DOT___043549_ = ((IData)(wasmetal_core__DOT___043563_) 
                                            & ((IData)(wasmetal_core__DOT___043563_)
                                                ? ((IData)(wasmetal_core__DOT___043563_)
                                                    ? 
                                                   ((IData)(wasmetal_core__DOT___043563_)
                                                     ? 
                                                    ((IData)(wasmetal_core__DOT___043563_)
                                                      ? 
                                                     ((IData)(wasmetal_core__DOT___043573_)
                                                       ? 
                                                      ((IData)(wasmetal_core__DOT___043572_)
                                                        ? 
                                                       ((IData)(wasmetal_core__DOT___043571_)
                                                         ? 
                                                        ((~ (IData)(wasmetal_core__DOT___043570_)) 
                                                         & (1U 
                                                            >> (IData)(__VdfgTmp_h38415c57__0)))
                                                         : 
                                                        (~ (IData)(wasmetal_core__DOT___043571_)))
                                                        : 
                                                       (~ (IData)(wasmetal_core__DOT___043572_)))
                                                       : 
                                                      (~ (IData)(wasmetal_core__DOT___043573_)))
                                                      : 
                                                     (~ (IData)(wasmetal_core__DOT___043563_)))
                                                     : 
                                                    (~ (IData)(wasmetal_core__DOT___043563_)))
                                                    : 
                                                   (~ (IData)(wasmetal_core__DOT___043563_)))
                                                : (~ (IData)(wasmetal_core__DOT___043563_))));
    vlSelf->wasmetal_core__DOT___043923_ = (1U & ((1U 
                                                   & (9U 
                                                      >> (IData)(__VdfgTmp_hf4482b2c__0)))
                                                   ? 
                                                  ((1U 
                                                    & (9U 
                                                       >> (IData)(__VdfgTmp_hf4482b2c__0)))
                                                    ? 
                                                   ((1U 
                                                     & (9U 
                                                        >> (IData)(__VdfgTmp_hf4482b2c__0)))
                                                     ? 
                                                    ((1U 
                                                      & (9U 
                                                         >> (IData)(__VdfgTmp_hf4482b2c__0)))
                                                      ? 
                                                     ((1U 
                                                       & (9U 
                                                          >> (IData)(__VdfgTmp_hf4482b2c__0)))
                                                       ? 
                                                      ((1U 
                                                        & (9U 
                                                           >> (IData)(__VdfgTmp_hf4482b2c__0)))
                                                        ? 
                                                       ((1U 
                                                         & (9U 
                                                            >> (IData)(__VdfgTmp_hf4482b2c__0)))
                                                         ? 
                                                        ((1U 
                                                          & (9U 
                                                             >> (IData)(__VdfgTmp_hf4482b2c__0)))
                                                          ? 
                                                         ((1U 
                                                           & (9U 
                                                              >> (IData)(__VdfgTmp_hf4482b2c__0)))
                                                           ? 
                                                          ((1U 
                                                            & (9U 
                                                               >> (IData)(__VdfgTmp_hf4482b2c__0)))
                                                            ? 
                                                           ((1U 
                                                             & (9U 
                                                                >> (IData)(__VdfgTmp_hf4482b2c__0)))
                                                             ? 
                                                            ((IData)(wasmetal_core__DOT___043944_)
                                                              ? 
                                                             ((IData)(wasmetal_core__DOT___043950_)
                                                               ? 
                                                              ((IData)(wasmetal_core__DOT___043949_)
                                                                ? 
                                                               ((IData)(wasmetal_core__DOT___043948_)
                                                                 ? 
                                                                ((IData)(wasmetal_core__DOT___043947_)
                                                                  ? 
                                                                 ((~ (IData)(wasmetal_core__DOT___043946_)) 
                                                                  & (IData)(wasmetal_core__DOT___043935_))
                                                                  : (IData)(wasmetal_core__DOT___043936_))
                                                                 : (IData)(wasmetal_core__DOT___043937_))
                                                                : (IData)(wasmetal_core__DOT___043938_))
                                                               : (IData)(wasmetal_core__DOT___043939_))
                                                              : (IData)(wasmetal_core__DOT___043932_))
                                                             : (IData)(wasmetal_core__DOT___043933_))
                                                            : (IData)(wasmetal_core__DOT___043933_))
                                                           : (IData)(wasmetal_core__DOT___043933_))
                                                          : (IData)(wasmetal_core__DOT___043933_))
                                                         : (IData)(wasmetal_core__DOT___043933_))
                                                        : (IData)(wasmetal_core__DOT___043933_))
                                                       : (IData)(wasmetal_core__DOT___043933_))
                                                      : (IData)(wasmetal_core__DOT___043933_))
                                                     : (IData)(wasmetal_core__DOT___043933_))
                                                    : (IData)(wasmetal_core__DOT___043933_))
                                                   : 
                                                  (4U 
                                                   >> (IData)(__VdfgTmp_hf4482b2c__0))));
    vlSelf->wasmetal_core__DOT___060978_ = (1U & (IData)(
                                                         (0x55cc0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060718_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                           << 2U) 
                                                                          | (3U 
                                                                             & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127978___O) 
                                                                                >> 3U))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055510_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h1327a702__0))))))))))));
    vlSelf->wasmetal_core__DOT___060908_ = (1U & (IData)(
                                                         (0x55cc0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060718_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                           << 2U) 
                                                                          | (3U 
                                                                             & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127978___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055467_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hef814ba9__0))))))))))));
    vlSelf->wasmetal_core__DOT___060825_ = (1U & (IData)(
                                                         (0x55cc0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060718_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                           << 2U) 
                                                                          | (3U 
                                                                             & (- (IData)(
                                                                                (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127978___O) 
                                                                                >> 1U))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055411_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_ha9869a20__0))))))))))));
    vlSelf->wasmetal_core__DOT___060727_ = (1U & (IData)(
                                                         (0xff440f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060726_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                                           << 2U) 
                                                                          | (3U 
                                                                             & (- (IData)(
                                                                                (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___127978___O))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055364_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___060718_)))))))));
    vlSelf->wasmetal_core__DOT___128610___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027570_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027529_)
            : (IData)(vlSelf->wasmetal_core__DOT___027488_));
    wasmetal_core__DOT___012306_ = (1U & (0xf4U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                               << 2U) 
                                              | (((IData)(wasmetal_core__DOT___009690_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012496_))))));
    vlSelf->wasmetal_core__DOT___012016_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___009693_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___009692_)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009691_))
                                                      : (IData)(
                                                                (0xffffffff8000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                   << 5U) 
                                                                  | (((IData)(wasmetal_core__DOT___009690_) 
                                                                      << 4U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h83b9759e__0))))))));
    vlSelf->wasmetal_core__DOT___043528_ = ((IData)(vlSelf->wasmetal_core__DOT___043541_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___043541_)
                                                ? ((IData)(vlSelf->wasmetal_core__DOT___043541_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___043541_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043541_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043541_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043541_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043541_)
                                                         ? 
                                                        ((IData)(wasmetal_core__DOT___043544_)
                                                          ? 
                                                         ((~ (IData)(wasmetal_core__DOT___043543_)) 
                                                          & (IData)(wasmetal_core__DOT___043538_))
                                                          : 
                                                         (~ (IData)(wasmetal_core__DOT___043544_)))
                                                         : 
                                                        (~ (IData)(vlSelf->wasmetal_core__DOT___043541_)))
                                                        : 
                                                       (~ (IData)(vlSelf->wasmetal_core__DOT___043541_)))
                                                       : 
                                                      (~ (IData)(vlSelf->wasmetal_core__DOT___043541_)))
                                                      : 
                                                     (~ (IData)(vlSelf->wasmetal_core__DOT___043541_)))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___043541_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___043541_)))
                                                : (~ (IData)(vlSelf->wasmetal_core__DOT___043541_))));
    vlSelf->wasmetal_core__DOT___043887_ = (1U & ((1U 
                                                   & (9U 
                                                      >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                   ? 
                                                  ((1U 
                                                    & (9U 
                                                       >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                    ? 
                                                   ((1U 
                                                     & (9U 
                                                        >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                     ? 
                                                    ((1U 
                                                      & (9U 
                                                         >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                      ? 
                                                     ((1U 
                                                       & (9U 
                                                          >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                       ? 
                                                      ((1U 
                                                        & (9U 
                                                           >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                        ? 
                                                       ((1U 
                                                         & (9U 
                                                            >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                         ? 
                                                        ((1U 
                                                          & (9U 
                                                             >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                          ? 
                                                         ((1U 
                                                           & (9U 
                                                              >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                           ? 
                                                          ((1U 
                                                            & (9U 
                                                               >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                            ? 
                                                           ((1U 
                                                             & (9U 
                                                                >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                             ? 
                                                            ((1U 
                                                              & (9U 
                                                                 >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                              ? 
                                                             ((1U 
                                                               & (9U 
                                                                  >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                               ? 
                                                              ((1U 
                                                                & (9U 
                                                                   >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                                ? 
                                                               ((1U 
                                                                 & (9U 
                                                                    >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                                 ? 
                                                                ((1U 
                                                                  & (9U 
                                                                     >> (IData)(__VdfgTmp_hbda467d5__0)))
                                                                  ? 
                                                                 ((IData)(wasmetal_core__DOT___043909_)
                                                                   ? 
                                                                  ((IData)(wasmetal_core__DOT___043908_)
                                                                    ? 
                                                                   ((~ (IData)(wasmetal_core__DOT___043907_)) 
                                                                    & (1U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___062175_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (1U 
                                                                              >> (IData)(__VdfgTmp_h965ce7cb__0))))))
                                                                    : (IData)(wasmetal_core__DOT___043899_))
                                                                   : (IData)(wasmetal_core__DOT___043900_))
                                                                  : (IData)(wasmetal_core__DOT___043896_))
                                                                 : (IData)(wasmetal_core__DOT___043896_))
                                                                : (IData)(wasmetal_core__DOT___043896_))
                                                               : (IData)(wasmetal_core__DOT___043896_))
                                                              : (IData)(wasmetal_core__DOT___043896_))
                                                             : (IData)(wasmetal_core__DOT___043896_))
                                                            : (IData)(wasmetal_core__DOT___043896_))
                                                           : (IData)(wasmetal_core__DOT___043896_))
                                                          : (IData)(wasmetal_core__DOT___043896_))
                                                         : (IData)(wasmetal_core__DOT___043896_))
                                                        : (IData)(wasmetal_core__DOT___043896_))
                                                       : (IData)(wasmetal_core__DOT___043896_))
                                                      : (IData)(wasmetal_core__DOT___043896_))
                                                     : (IData)(wasmetal_core__DOT___043896_))
                                                    : (IData)(wasmetal_core__DOT___043896_))
                                                   : 
                                                  (4U 
                                                   >> (IData)(__VdfgTmp_hbda467d5__0))));
    vlSelf->wasmetal_core__DOT___060693_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043923_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019246_))));
    vlSelf->wasmetal_core__DOT___060737_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043549_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___043923_))));
    vlSelf->wasmetal_core__DOT___060739_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048364_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___043923_)))));
    vlSelf->wasmetal_core__DOT___060710_ = (1U & (0xf0011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043923_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019246_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___043549_) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___043563_)))))));
    vlSelf->wasmetal_core__DOT___128610___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027571_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128610___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___027489_));
    vlSelf->wasmetal_core__DOT___057159_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                   & (IData)(
                                                             (0xf000f55553333ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012354_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((IData)(
                                                                                (0xf5f3f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x3f5fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057109_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127804___O) 
                                                                                >> 1U))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128547___O))))))))) 
                                                                            << 2U)) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0xffffffffff000e00ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___057121_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057120_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127674___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057118_)))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0x5555333300f000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057125_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009904_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O))))))))))))))))))
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012343_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012343_))
                                                    : (IData)(
                                                              (0xff000000700000ULL 
                                                               >> 
                                                               (((IData)(wasmetal_core__DOT___012306_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012343_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012015_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & (IData)(
                                                                                (0xc0ccf0ff00aa00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012929_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057100_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057099_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057098_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x330f0f0fff55ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057096_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057095_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057094_)))))))))))))))))))))))))));
    vlSelf->__VdfgTmp_h2a75aa71__0 = ((4U & ((IData)(
                                                     (0xfcfaf0f0ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056541_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0xca00U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___056543_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hf4e23b72__0)))) 
                                                                    << 2U)) 
                                                                | (IData)(vlSelf->__VdfgTmp_h28d1a2cd__0))))))) 
                                             << 2U)) 
                                      | ((2U & ((IData)(
                                                        (0xfff4ff00000000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___011156_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057083_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & (((1U 
                                                                         & (0xff1fU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                              << 4U) 
                                                                             | (((IData)(wasmetal_core__DOT___057075_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x55553333f0f000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057060_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xccaaf0f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010648_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127802___O))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127723___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                                                >> 3U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xee22fa0a00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010648_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xfbbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128544___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))))))))))))))
                                                                         ? 
                                                                        ((IData)(wasmetal_core__DOT___012306_)
                                                                          ? 
                                                                         (4U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___012305_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___009693_)))
                                                                          : (IData)(
                                                                                (0xef0000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012305_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012015_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x3a00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057046_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x30303000aa0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012261_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057044_))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012929_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x30303000aa0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056901_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057077_)))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he11b9fc4__0))))))))))))))))
                                                                         : 
                                                                        (2U 
                                                                         >> (IData)(vlSelf->wasmetal_core__DOT___012305_))) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((0xd0U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0ccccff00aaaaULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128555___O) 
                                                                                >> 3U))))))))) 
                                                                                << 1U)) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___010092_)))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0x55330000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___012018_)
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? (IData)(
                                                                                (0x8880000088808880ULL 
                                                                                >> (IData)(__VdfgTmp_hbed24786__0)))
                                                                                 : (IData)(
                                                                                (0x8880888088800000ULL 
                                                                                >> (IData)(__VdfgTmp_hbed24786__0))))
                                                                                 : 
                                                                                (0xeU 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___012248_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009691_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf00ee00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057022_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xfbbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128555___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xee22fa0a00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbf1fbd0a__0)))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127735___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O) 
                                                                                >> 3U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x55553333f0f000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057040_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xccaaf0f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056052_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127671___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                                                >> 1U))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056052_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127721___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                                                >> 3U)))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xfbbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))))))))))))))))))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0xfff4ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057005_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057004_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf400U 
                                                                         >> 
                                                                         ((8U 
                                                                           & (((~ (IData)(vlSelf->wasmetal_core__DOT___009681_)) 
                                                                               & ((1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O))
                                                                                 ? 
                                                                                (0x5f3fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xfff4ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056941_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056940_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127682___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056938_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaacccc0f0fff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056957_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127682___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127818___O) 
                                                                                >> 2U))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128553___O) 
                                                                                >> 3U))))))))))))))
                                                                                 : 
                                                                                (0xcfdfU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x55330f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xccaaf0f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010053_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127680___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127814___O) 
                                                                                >> 2U))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128551___O) 
                                                                                >> 3U))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfff4ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056954_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056953_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127680___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056951_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))))))))) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & (((1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O))
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___009691_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___012063_))
                                                                                 : 
                                                                                (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012063_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x7fff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127746___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h238f5c0e__0))))))))))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___009691_)
                                                                                 ? 
                                                                                (0xbU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf0788fad__0))
                                                                                 : 
                                                                                (0xbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x7fff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127744___O) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h238f5c0e__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf0788fad__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011163_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((~ 
                                                                              ((0xcfaf0000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x55553333fff0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056991_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127678___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 0xbU)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O) 
                                                                                >> 3U))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff5503030303ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056997_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056996_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x33aa0f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                                                >> 3U)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                                                >> 3U))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((~ (IData)(vlSelf->wasmetal_core__DOT___010378_)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010084_)
                                                                                 ? (IData)(
                                                                                (0xff00fff4ff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012242_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012241_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012240_))))))))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___012242_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_)))))))))))))) 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT___012207_)
                                                                                 ? (IData)(
                                                                                (0x3f3f3f3fbfffffbfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012206_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012205_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h648a31a7__0)))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___012205_))))) 
                                                                             & (IData)(
                                                                                (0xff00fff0fffeffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012162_) 
                                                                                << 3U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                                & (IData)(
                                                                                (0x3f3f5f5fff0f0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012166_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012165_))))))))) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127740___O))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009692_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___025138_ = (1U & ((1U 
                                                   & (IData)(
                                                             (0xfcfaf0f0ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056543_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((0xca00U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___056541_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5d11eb70__0)))) 
                                                                            << 2U)) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hfb017232__0))))))))
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011157_))
                                                   : (IData)(
                                                             (0xb0bb0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___011157_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011156_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012768_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & (((0xd0U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011740_)))) 
                                                                             & (IData)(
                                                                                (0xff00fff0fffdffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012774_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x1111000f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057417_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010077_)
                                                                                 ? 
                                                                                (0x110fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xff00f4f4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127727___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043735_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ff00e0e0ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009728_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h83e89eb3__0)))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x50cU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055661_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___033416_)))))))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ff00ffff4040ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057401_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057400_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x11110000000fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057413_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x44440000f000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012941_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127679___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057409_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                                                >> 2U))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xee22fa0a00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055839_)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0faa3300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf044U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055839_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127679___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 0xeU)))))))))))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011163_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0feU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057397_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x7fff0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057395_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h22919fe9__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010077_))))))))))))))) 
                                                                            << 2U)) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0x4fff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057532_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057531_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00b000ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057526_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x5f3fU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009906_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127723___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                                                >> 2U)))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xfbbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128545___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff0000f1f1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057510_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057509_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xee000fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h90d51bf1__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127674___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012016_) 
                                                                                << 1U) 
                                                                                | ((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                & ((1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O))
                                                                                 ? 
                                                                                (1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0xaaccf0f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                                                 ? 
                                                                                (0xffefefU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012965_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012804_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011102_))))))
                                                                                 : 
                                                                                (0xdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012964_)))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4fe8c7bc__0)))))))
                                                                                 : 
                                                                                (0xff1fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012959_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012957_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011026_)))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011163_)))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xfe000000ffff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057498_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057497_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057496_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x7f77777f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xdU 
                                                                                >> 
                                                                                ((((IData)(vlSelf->wasmetal_core__DOT___012929_) 
                                                                                & (IData)(
                                                                                (0xffff1111fff0fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012928_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057384_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012926_))))))))) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___012559_))
                                                                                 : (IData)(vlSelf->wasmetal_core__DOT___012818_))
                                                                                 : 
                                                                                (1U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0xee0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012828_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057391_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010092_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012826_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011102_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057390_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056504_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00fff8ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127738___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h46d848cb__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127748___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h46d848cb__0))))))))))))))))))))))))))));
    vlSelf->__VdfgTmp_he998c60f__0 = ((4U & ((IData)(
                                                     (0xfcfaf0f0ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056541_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0xca00U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___056543_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hf89db412__0)))) 
                                                                    << 2U)) 
                                                                | (IData)(vlSelf->__VdfgTmp_hae784e62__0))))))) 
                                             << 2U)) 
                                      | ((2U & ((IData)(
                                                        (0xfe000000ffff0000ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___057377_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011156_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057376_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((0xf0fdU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((0x11f00000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xeeeeeeeeff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057339_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ff00ffff4040ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057334_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057333_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0ccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134165___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                                >> 1U))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x2e2e0faaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___033411_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009726_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 5U)))))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x101ff01ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057349_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057348_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x44440000f000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057343_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127679___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x33aa0f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                                                >> 1U)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                                                >> 1U))))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0faa3300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf044U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055826_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127679___O)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 0xdU)))))))))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011163_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0feU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057330_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x7fff0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057328_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h22919fe9__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))))))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0xf0f0cc5500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___033411_)))))))))))))))) 
                                                << 1U)) 
                                         | (1U & ((IData)(vlSelf->wasmetal_core__DOT___009681_)
                                                   ? 
                                                  (0xdcU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xf0f0fef00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___057319_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___057318_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & (((~ (IData)(vlSelf->wasmetal_core__DOT___010092_)) 
                                                                                & (IData)(
                                                                                (0xfffff1111ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012594_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf8f80000ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057299_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x1d1d00000f55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056062_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O) 
                                                                                >> 3U))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((0xff8fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057308_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127685___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O) 
                                                                                >> 3U))))))))))) 
                                                                                & (IData)(
                                                                                (0xff00ff00fff0fffeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012604_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012603_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012602_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056196_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056238_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127735___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                                                >> 1U)))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O) 
                                                                                >> 1U)))))))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0f030f0f0f05ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127738___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127748___O) 
                                                                                >> 2U))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009691_)))))))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007364_)))))
                                                   : 
                                                  (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xff00ff00efef0000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___057285_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057284_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012016_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056601_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xfef0f0fULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00fff800000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057247_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012644_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011102_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011103_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011026_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf000ee00ff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057246_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xfffefffe0000ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057244_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0xffaaccf0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h15546f37__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011101_)))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011163_)))))))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007366_)))))))));
    vlSelf->wasmetal_core__DOT___019300_ = ((IData)(vlSelf->wasmetal_core__DOT___011156_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___011740_)
                                                ? (0xfcfaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h05777dd7__0))))
                                                : (0xfcfaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                ? 
                                                               (2U 
                                                                >> 
                                                                (1U 
                                                                 & (IData)(
                                                                           (0xf0f0ccccff00aaaaULL 
                                                                            >> 
                                                                            ((0x20U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056191_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128555___O) 
                                                                                >> 2U)))))))))))
                                                                : 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___009693_)
                                                                 ? 
                                                                (0xeU 
                                                                 >> 
                                                                 ((2U 
                                                                   & ((IData)(
                                                                              (0xf0f00000aa33ULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ff0f0f1111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056853_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056240_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xcc0035U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O) 
                                                                                >> 2U))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127734___O) 
                                                                                >> 3U)))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((~ 
                                                                                (0x4f00U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                                                >> 2U))))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))) 
                                                                                & (IData)(
                                                                                (0xff00ff00fffcfff5ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012003_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012002_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012001_))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xccaaf0f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056240_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127684___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127806___O))))))))))))))) 
                                                                      << 1U)) 
                                                                  | (1U 
                                                                     & (IData)(
                                                                               (0xf0f0aa3300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff0fff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056841_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056191_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056250_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O) 
                                                                                >> 2U))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00bb00ff00f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056836_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056835_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127671___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xccaaf0f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xee22fa0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056191_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056250_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127671___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127808___O))))))))))))))))))
                                                                 : 
                                                                (0xf1U 
                                                                 >> 
                                                                 ((4U 
                                                                   & ((IData)(
                                                                              (0xdfdddddf00000000ULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xbb0b0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056860_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O)) 
                                                                                & (IData)(
                                                                                (0xff00ff00fff0fff7ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012008_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012007_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2ddf0adc__0))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                & (IData)(
                                                                                (0xff00ff00fff0fffdULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012012_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012011_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xfafcU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4aad360c__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011103_))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00fff400000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdf888c66__0)))))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & ((IData)(
                                                                                (0xf0f0f030f0f0f05ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127737___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127747___O) 
                                                                                >> 3U))))))))) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___009691_)))))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                 ? 
                                                                (2U 
                                                                 >> 
                                                                 (1U 
                                                                  & (IData)(
                                                                            (0xff00aaaaf0f0ccccULL 
                                                                             >> 
                                                                             ((0x20U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O) 
                                                                                << 1U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128544___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d))))))))))
                                                                 : 
                                                                (0x7f0fU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___012019_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___012016_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012015_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xafcf0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056887_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012929_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaf0fbbffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056775_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056778_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d))))))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha6c246b8__0)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___009679_ = (1U & (0xbe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012016_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf38792bb__0))));
    vlSelf->__VdfgTmp_h72854726__0 = (((IData)(vlSelf->wasmetal_core__DOT___012016_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012018_));
    vlSelf->__VdfgTmp_h7c6e85dc__0 = ((4U & ((IData)(
                                                     (0xfcfaf0f0ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056543_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0xca00U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___056541_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hde31b2d5__0)))) 
                                                                    << 2U)) 
                                                                | (IData)(vlSelf->__VdfgTmp_h13e1c0a0__0))))))) 
                                             << 2U)) 
                                      | ((2U & ((IData)(
                                                        (0x11110000000fULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057602_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & (((~ (IData)(vlSelf->wasmetal_core__DOT___011740_)) 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                            ? 
                                                                           (2U 
                                                                            >> (IData)(vlSelf->wasmetal_core__DOT___013002_))
                                                                            : (IData)(
                                                                                (0xffff8fffffff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012016_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013002_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013001_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf000ee00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012929_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057542_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012559_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0ff7777U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057540_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057539_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010092_)))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xbeU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf38792bb__0)))))))))))) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((4U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___007417_))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & ((1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0ccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d))))))))))) 
                                                                            & (IData)(
                                                                                (0xff0fff0fff00ffeeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013031_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (((1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O))
                                                                                 ? 
                                                                                (0x1fU 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056247_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127722___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                                                >> 3U)))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                                >> 3U))))))))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x1d1d00000f55ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056070_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xcfaf0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127809___O) 
                                                                                >> 1U))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((~ 
                                                                                (0x4f00U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(
                                                                                (0xcfcffcee00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                                                >> 3U))))))))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))) 
                                                                                & (IData)(
                                                                                (0xff00ff00fff0fffdULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013078_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013076_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010084_))))))))))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (((0xff8fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057589_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127685___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127807___O) 
                                                                                >> 1U))))))))))) 
                                                                                & (IData)(
                                                                                (0xff00ff00fff0fffeULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013083_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013082_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013081_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f033aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056239_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127720___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                                                >> 3U)))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O) 
                                                                                >> 3U))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f0f030f0f0f05ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012496_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009692_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127739___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127737___O))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009691_))))))))))))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0xffff0000fe000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057676_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057675_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0fdU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf111100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057626_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0faf0f300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xfdd0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                                                >> 3U))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0x888b8888U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h69066ba7__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d))))))
                                                                                 : 
                                                                                (0x888b8888U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h69066ba7__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127679___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 0xfU)))))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00bb00ff000f00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057618_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057617_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf5fc0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb920cb05__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127728___O))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x2e2e0faa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010043_))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0faa3300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf044U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x2e2e0faaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010043_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___134222_.__PVT__alu_sum 
                                                                                >> 7U)))))))))))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011163_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xeU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xfc550000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xfff1f100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf218f314__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057635_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((~ (IData)(vlSelf->wasmetal_core__DOT___011101_)) 
                                                                                & (IData)(
                                                                                (0xff00ffaaff0fff33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013104_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013103_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013047_))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057633_))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                                                 ? (IData)(vlSelf->wasmetal_core__DOT___013114_)
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8088f5ad__0)))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___013108_))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((~ (IData)(vlSelf->wasmetal_core__DOT___009692_)) 
                                                                                & ((1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127743___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h46d848cb__0))))))
                                                                                 ? 
                                                                                (0x40000000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1cb679e9__0))
                                                                                 : (IData)(
                                                                                (0x555555557fffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127741___O) 
                                                                                << 5U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1cb679e9__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009691_)))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0cc5500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010044_)))))))))))))))))));
}
