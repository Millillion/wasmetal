#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__4(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__4\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___065371_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065370_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___064354_)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___065134_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065130_))));
    vlSelf->wasmetal_core__DOT___067841_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067281_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067840_))));
    vlSelf->wasmetal_core__DOT___069394_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069120_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___069287_))))));
    vlSelf->wasmetal_core__DOT___065216_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065215_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064662_))))));
    vlSelf->wasmetal_core__DOT___069345_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069025_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069344_))));
    vlSelf->wasmetal_core__DOT___069370_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069072_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___069267_))))));
    vlSelf->wasmetal_core__DOT___065009_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065008_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065007_))));
    vlSelf->wasmetal_core__DOT___065139_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065138_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064356_))))));
    vlSelf->wasmetal_core__DOT___065221_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065219_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065218_))));
    vlSelf->wasmetal_core__DOT___067884_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067386_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067883_))));
    vlSelf->wasmetal_core__DOT___065377_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065376_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065375_))));
    vlSelf->wasmetal_core__DOT___067944_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067433_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067943_))));
    vlSelf->wasmetal_core__DOT___065483_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065481_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065480_))));
    vlSelf->wasmetal_core__DOT___068007_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067530_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068006_))));
    vlSelf->wasmetal_core__DOT___065519_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064313_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064406_))));
    vlSelf->wasmetal_core__DOT___068060_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067578_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068059_))));
    vlSelf->wasmetal_core__DOT___069322_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068994_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069321_))));
    vlSelf->wasmetal_core__DOT___064853_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064852_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064851_))));
    vlSelf->wasmetal_core__DOT___065659_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064651_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064680_))));
    vlSelf->wasmetal_core__DOT___068135_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068134_))));
    vlSelf->wasmetal_core__DOT___065854_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065002_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065015_))));
    vlSelf->wasmetal_core__DOT___065758_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064859_))));
    vlSelf->wasmetal_core__DOT___065965_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065130_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065136_))));
    vlSelf->wasmetal_core__DOT___068221_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067791_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068220_))));
    vlSelf->wasmetal_core__DOT___068187_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067712_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068186_))));
    vlSelf->wasmetal_core__DOT___068274_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067840_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068273_))));
    vlSelf->wasmetal_core__DOT___066024_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065218_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065213_))));
    vlSelf->wasmetal_core__DOT___068327_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067883_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068326_))));
    vlSelf->wasmetal_core__DOT___069289_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068927_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069288_))));
    vlSelf->wasmetal_core__DOT___064666_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064665_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064664_))));
    vlSelf->wasmetal_core__DOT___066190_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065375_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065368_))));
    vlSelf->wasmetal_core__DOT___068383_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067943_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068382_))));
    vlSelf->wasmetal_core__DOT___064360_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064359_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064358_))));
    vlSelf->wasmetal_core__DOT___069269_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068878_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069268_))));
    vlSelf->wasmetal_core__DOT___066222_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065480_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065475_))));
    vlSelf->wasmetal_core__DOT___068458_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068006_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068457_))));
    vlSelf->__VdfgTmp_hbca1334b__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065212_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065215_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___064662_)) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___064667_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064651_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064650_))));
    vlSelf->__VdfgTmp_h61c930cb__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064650_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064665_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064664_))));
    vlSelf->__VdfgTmp_hde8128eb__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065001_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065008_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___065007_))));
    vlSelf->wasmetal_core__DOT___065010_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065002_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065001_))));
    vlSelf->__VdfgTmp_h227fe25d__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065474_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065477_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064352_) 
                                                               << 1U)) 
                                                             << 1U))) 
                                                        << 1U))) 
                                                   << 1U)))));
    vlSelf->__VdfgTmp_he8d6e4f5__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065367_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065370_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064354_)) 
                                                        << 1U))) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___064854_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064845_))));
    vlSelf->__VdfgTmp_h09fbb425__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064845_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064852_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064851_))));
    vlSelf->__VdfgTmp_ha81b0ca8__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065135_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065138_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___064356_)) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___064361_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064313_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064312_))));
    vlSelf->__VdfgTmp_h82ca1536__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064312_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064359_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064358_))));
    vlSelf->wasmetal_core__DOT___069220_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068831_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069219_))));
    vlSelf->wasmetal_core__DOT___068832_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068457_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068831_))));
    vlSelf->wasmetal_core__DOT___069026_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068634_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069025_))));
    vlSelf->wasmetal_core__DOT___068635_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068220_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068634_))));
    vlSelf->wasmetal_core__DOT___068732_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068326_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068731_))));
    vlSelf->wasmetal_core__DOT___069121_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068731_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069120_))));
    vlSelf->wasmetal_core__DOT___068928_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068520_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068927_))));
    vlSelf->wasmetal_core__DOT___068521_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068134_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068520_))));
    vlSelf->wasmetal_core__DOT___069188_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068781_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069187_))));
    vlSelf->wasmetal_core__DOT___068782_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068382_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068781_))));
    vlSelf->wasmetal_core__DOT___068995_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068994_))));
    vlSelf->wasmetal_core__DOT___068585_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068186_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068584_))));
    vlSelf->wasmetal_core__DOT___068685_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068273_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068684_))));
    vlSelf->wasmetal_core__DOT___069073_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068684_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069072_))));
    vlSelf->wasmetal_core__DOT___068879_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068502_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068878_))));
    vlSelf->wasmetal_core__DOT___068503_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068059_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068502_))));
    vlSelf->wasmetal_core__DOT___064977_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064949_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064948_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064947_)))))))));
    vlSelf->wasmetal_core__DOT___065252_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065245_))))));
    vlSelf->wasmetal_core__DOT___065340_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065333_))))));
    vlSelf->wasmetal_core__DOT___065449_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065444_))))));
    vlSelf->wasmetal_core__DOT___065532_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065528_))))));
    vlSelf->__VdfgTmp_h11c2cb19__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064961_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064960_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064964_));
    vlSelf->wasmetal_core__DOT___067125_ = (1U & (IData)(
                                                         (0xffcf0040ffcfffcfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067123_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064812_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (1U 
                                                                          >> 
                                                                          (3U 
                                                                           & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U)))))))))))))));
    vlSelf->__VdfgTmp_ha9e0ea4b__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064809_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064808_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064812_));
    vlSelf->wasmetal_core__DOT___065669_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064589_)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065668_))));
    vlSelf->__VdfgTmp_hcce0135b__0 = (((IData)(vlSelf->wasmetal_core__DOT___064156_) 
                                       << 1U) | (1U 
                                                 & (0x55330f0fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___064154_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_he8a45048__0)))));
    vlSelf->wasmetal_core__DOT___065864_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064940_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065863_))));
    vlSelf->wasmetal_core__DOT___065747_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064796_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065746_))));
    vlSelf->wasmetal_core__DOT___065980_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065104_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065979_))));
    vlSelf->wasmetal_core__DOT___067996_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067517_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___067547_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___066043_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065245_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066042_))));
    vlSelf->wasmetal_core__DOT___067928_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067415_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___067548_)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___066241_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066240_))));
    vlSelf->wasmetal_core__DOT___066172_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065333_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066171_))));
    vlSelf->wasmetal_core__DOT___066350_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065528_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066349_))));
    vlSelf->wasmetal_core__DOT___067874_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067373_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___067633_))))));
    vlSelf->wasmetal_core__DOT___066450_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065668_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066449_))));
    vlSelf->wasmetal_core__DOT___066694_ = (1U & (IData)(
                                                         (0xf7770000f333f333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x5cU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h0f450401__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066692_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b20__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (3U 
                                                                              & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U))))))))))))))));
    vlSelf->wasmetal_core__DOT___067781_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067229_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067780_))));
    vlSelf->wasmetal_core__DOT___067693_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067119_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067692_))));
    vlSelf->wasmetal_core__DOT___067847_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067275_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___067549_))))));
    vlSelf->wasmetal_core__DOT___065674_ = (1U & (IData)(
                                                         (0x330f5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064607_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064606_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___064621_))))))));
    vlSelf->wasmetal_core__DOT___064622_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064607_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064606_))));
    vlSelf->wasmetal_core__DOT___065254_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha0b0298a__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064613_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___064619_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___065239_))))))));
    vlSelf->wasmetal_core__DOT___066048_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065239_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha0b0298a__0)))));
    vlSelf->wasmetal_core__DOT___065451_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hf24dfeba__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xf0f0ccaaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064967_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064609_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___064614_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___065438_))))))));
    vlSelf->wasmetal_core__DOT___066246_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065438_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf24dfeba__0)))))));
    vlSelf->wasmetal_core__DOT___066177_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065327_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hedd7926b__0)))))));
    vlSelf->wasmetal_core__DOT___065342_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hedd7926b__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xf0f0ccaaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064815_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064166_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___064187_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___065327_))))))));
    vlSelf->wasmetal_core__DOT___065128_ = (1U & (IData)(
                                                         (0x5f3f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3fff20003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b4__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065113_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065112_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065111_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f0ccaaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___065114_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064178_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064196_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x5cU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h0f450401__0)))))))))));
    vlSelf->wasmetal_core__DOT___065986_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065114_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0f450401__0)))))));
    vlSelf->wasmetal_core__DOT___067059_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066449_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067058_))));
    vlSelf->wasmetal_core__DOT___067635_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067058_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067634_))));
    vlSelf->wasmetal_core__DOT___067374_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067373_))));
    vlSelf->wasmetal_core__DOT___066739_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066042_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066738_))));
    vlSelf->wasmetal_core__DOT___067230_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066571_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067229_))));
    vlSelf->wasmetal_core__DOT___066572_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065863_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066571_))));
    vlSelf->wasmetal_core__DOT___066929_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066928_))));
    vlSelf->wasmetal_core__DOT___067518_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067517_))));
    vlSelf->wasmetal_core__DOT___067416_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066823_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067415_))));
    vlSelf->wasmetal_core__DOT___066824_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066823_))));
    vlSelf->wasmetal_core__DOT___067120_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066495_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067119_))));
    vlSelf->wasmetal_core__DOT___066496_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065746_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066495_))));
    vlSelf->wasmetal_core__DOT___066689_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065979_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066688_))));
    vlSelf->wasmetal_core__DOT___067276_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066688_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067275_))));
    vlSelf->wasmetal_core__DOT___067012_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066349_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067011_))));
    vlSelf->wasmetal_core__DOT___067551_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067011_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067550_))));
    vlSelf->wasmetal_core__DOT___128011___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027827_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027794_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b4__05d));
    vlSelf->wasmetal_core__DOT___064995_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064986_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064985_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064984_)))))))));
    vlSelf->wasmetal_core__DOT___065276_ = (1U & (IData)(
                                                         (0x55330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064566_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2cdbdda9__0))))));
    vlSelf->wasmetal_core__DOT___064636_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x3fff20003fff3fffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b1__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064556_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                              << 2U)) 
                                                                          | ((4U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064554_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064553_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f335500000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                                      << 5U) 
                                                                     | ((4U 
                                                                         & ((0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2cdbdda9__0)) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___064566_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0x55550f0f00ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064070_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064069_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064074_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064060_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___065129_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x3fff20003fff3fffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b4__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065098_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                              << 2U)) 
                                                                          | ((4U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___065097_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065096_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x330f5500000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___064056_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___064055_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___064077_)))))))))));
    vlSelf->wasmetal_core__DOT___065274_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065270_))))));
    vlSelf->wasmetal_core__DOT___065361_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065357_))))));
    vlSelf->wasmetal_core__DOT___065468_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065464_))))));
    vlSelf->wasmetal_core__DOT___064250_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xcc0f550fU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___064082_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b0__05d) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064081_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & (0xf0f3355U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___064077_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064076_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0x47U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064074_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                                << 1U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & vlSelf->mem_rdata[0U])))))))))))))))));
    vlSelf->wasmetal_core__DOT___066429_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065679_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066428_))));
    vlSelf->wasmetal_core__DOT___065680_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064544_)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065679_))));
    vlSelf->wasmetal_core__DOT___066057_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065270_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066056_))));
    vlSelf->wasmetal_core__DOT___066730_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066056_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___066427_))))));
    vlSelf->wasmetal_core__DOT___066563_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065875_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066562_))));
    vlSelf->wasmetal_core__DOT___065876_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064981_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065875_))));
    vlSelf->wasmetal_core__DOT___066936_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066252_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___066359_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___066253_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065464_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066252_))));
    vlSelf->wasmetal_core__DOT___066676_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065990_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___066361_))))));
    vlSelf->wasmetal_core__DOT___065991_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065091_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065990_))));
    vlSelf->wasmetal_core__DOT___066994_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065538_)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___066362_)))))));
    vlSelf->wasmetal_core__DOT___065543_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065538_))))));
    vlSelf->wasmetal_core__DOT___066363_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065538_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066362_))));
    vlSelf->wasmetal_core__DOT___066154_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065357_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066153_))));
    vlSelf->wasmetal_core__DOT___066814_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066153_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___066360_)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___065778_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064779_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065777_))));
    vlSelf->wasmetal_core__DOT___066486_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065777_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066485_))));
    vlSelf->wasmetal_core__DOT___064957_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064954_))));
    vlSelf->wasmetal_core__DOT___066421_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065640_))));
    vlSelf->__VdfgTmp_hd880fa11__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (8U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___064571_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065640_))))));
    vlSelf->wasmetal_core__DOT___065259_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065258_))));
    vlSelf->__VdfgTmp_hf93a855f__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065258_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___065639_))))))));
    vlSelf->wasmetal_core__DOT___066554_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065835_))));
    vlSelf->__VdfgTmp_hf64104f4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___064952_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065835_))))));
    vlSelf->wasmetal_core__DOT___065456_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065455_))));
    vlSelf->__VdfgTmp_h5d3bfbfd__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065455_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___065546_) 
                                                                       << 1U)) 
                                                                     << 1U))) 
                                                                << 1U)))))))));
    vlSelf->__VdfgTmp_he75eceef__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065124_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066667_))))));
    vlSelf->wasmetal_core__DOT___065125_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065124_))));
    vlSelf->__VdfgTmp_hd4e6b48d__0 = (((IData)(vlSelf->wasmetal_core__DOT___065973_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___065972_)));
    vlSelf->__VdfgTmp_hadcb4246__0 = (((IData)(vlSelf->wasmetal_core__DOT___065973_) 
                                       << 2U) | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___065972_)));
    vlSelf->__VdfgTmp_h90496874__0 = (((IData)(vlSelf->wasmetal_core__DOT___065973_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___065972_));
    vlSelf->__VdfgTmp_hd4192dd5__0 = (((IData)(vlSelf->wasmetal_core__DOT___065973_) 
                                       << 3U) | ((6U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___065972_)));
    vlSelf->__VdfgTmp_hfdfb8f5f__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h20cdb85c__0)) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___064570_)))));
    vlSelf->__VdfgTmp_h737b874d__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h20cdb85c__0)) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)))));
    vlSelf->__VdfgTmp_h1f2f6132__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065346_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___065547_)) 
                                                                << 1U)))))))));
    vlSelf->wasmetal_core__DOT___065347_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065346_))));
    vlSelf->wasmetal_core__DOT___066475_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065735_))));
    vlSelf->__VdfgTmp_h0b08a7c5__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064822_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065735_))))));
    vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_x >> 6U) & (IData)(vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028102_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 1U)));
    vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__2__KET__ 
        = ((~ (vlSelf->function_params >> 6U)) & (IData)(vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___052873_ = (1U & (IData)(
                                                         (0x8000ffff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052871_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052870_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044716_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___044720_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___044719_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___044718_))))))))))));
    vlSelf->wasmetal_core__DOT___070633_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b1__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___070634_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b3__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128466___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___128467___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032700_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032667_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    vlSelf->wasmetal_core__DOT___134209___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037210_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___037178_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h5b0f43f4__0))));
    vlSelf->wasmetal_core__DOT___127843___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026383_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026350_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b4__05d));
    vlSelf->wasmetal_core__DOT___054480_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127834___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054483_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127834___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___052580_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->result_index 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127826___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___051018_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->result_index 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127842___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127826___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___053773_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043673_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___043283_))));
    vlSelf->wasmetal_core__DOT___053771_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043576_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___043129_))));
    vlSelf->wasmetal_core__DOT___070619_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003013_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053264_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003039_)))));
    vlSelf->wasmetal_core__DOT___061665_ = (1U & (IData)(
                                                         (0xfeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052731_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048412_)))))))));
    vlSelf->wasmetal_core__DOT___052732_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052731_))));
    vlSelf->wasmetal_core__DOT___007057_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048432_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019203_))));
    vlSelf->wasmetal_core__DOT___019242_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019203_))));
    vlSelf->wasmetal_core__DOT___048356_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4ab35b3e__0))));
    vlSelf->wasmetal_core__DOT___048345_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4ab35b3e__0))));
    vlSelf->wasmetal_core__DOT___048349_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4ab35b3e__0))));
    vlSelf->wasmetal_core__DOT___048505_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048323_))));
    vlSelf->wasmetal_core__DOT___048330_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048323_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048322_)))));
    vlSelf->wasmetal_core__DOT___048410_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048404_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048323_))));
    vlSelf->wasmetal_core__DOT___039792_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b32__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039763_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b33__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039764_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b34__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039765_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b35__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039762_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b36__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039410_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b37__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039767_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b38__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039768_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b39__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039769_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b40__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039770_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b41__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039771_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b42__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039772_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b43__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___039773_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b44__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039774_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b45__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039796_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b46__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___039785_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b47__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___039784_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b48__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039783_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b49__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039782_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b50__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039766_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b51__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___039412_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b52__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039781_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b53__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039779_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b54__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039778_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b55__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___039777_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b56__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039776_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b57__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039786_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b58__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039787_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b59__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT___039788_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b60__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039805_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b61__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___039800_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b62__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039799_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045979_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__catch_values__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___063410_ = (1U & (IData)(
                                                         (0xccf05500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053332_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0ff1168c__0))))))));
    vlSelf->wasmetal_core__DOT___053334_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053332_))));
    vlSelf->wasmetal_core__DOT___045206_ = (1U & (IData)(
                                                         (0xff555500ff3f3f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070681_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h387d079a__0)))))));
    vlSelf->wasmetal_core__DOT___045230_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071867_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h387d079a__0)))))));
    vlSelf->wasmetal_core__DOT___044934_ = (1U & (IData)(
                                                         (0xff555500ff3f3f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054322_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070784_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hee073a4e__0)))))));
    vlSelf->wasmetal_core__DOT___044958_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054322_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hee073a4e__0)))))));
    vlSelf->wasmetal_core__DOT___070684_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054327_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070682_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 3U)))))))))));
    vlSelf->wasmetal_core__DOT___070683_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070682_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054327_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 3U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___070689_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054333_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070687_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 6U)))))))))));
    vlSelf->wasmetal_core__DOT___070688_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070687_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054333_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 6U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___070699_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054350_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070697_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xbU)))))))))));
    vlSelf->wasmetal_core__DOT___070698_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054350_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xbU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___070704_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070702_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xeU)))))))))));
    vlSelf->wasmetal_core__DOT___070703_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070702_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xeU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___070714_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070712_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b21__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x13U)))))))))));
    vlSelf->wasmetal_core__DOT___070713_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070712_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054368_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x13U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___070719_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054374_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070717_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b24__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x16U)))))))))));
    vlSelf->wasmetal_core__DOT___070718_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070717_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054374_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x16U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___070729_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054386_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070727_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1bU)))))))))));
    vlSelf->wasmetal_core__DOT___070728_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070727_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054386_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1bU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___070734_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054392_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070732_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1eU)))))))))));
    vlSelf->wasmetal_core__DOT___070733_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070732_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054392_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1eU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT___070744_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054404_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070742_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x23U)))))))))));
    vlSelf->wasmetal_core__DOT___070743_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070742_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054404_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x23U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___070749_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054410_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070747_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x26U)))))))))));
    vlSelf->wasmetal_core__DOT___070748_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070747_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054410_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x26U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___070759_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054422_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070757_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b48__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2bU)))))))))));
    vlSelf->wasmetal_core__DOT___070758_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070757_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054422_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2bU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___070764_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054428_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070762_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b51__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2eU)))))))))));
    vlSelf->wasmetal_core__DOT___070763_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070762_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054428_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2eU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT___070774_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054440_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070772_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b57__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x33U)))))))))));
    vlSelf->wasmetal_core__DOT___070773_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070772_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054440_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x33U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b57__05d)))))))));
    vlSelf->wasmetal_core__DOT___070779_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054446_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070777_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x36U)))))))))));
    vlSelf->wasmetal_core__DOT___070778_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054446_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x36U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___070694_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054344_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070692_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 8U)))))))))));
    vlSelf->wasmetal_core__DOT___070693_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070692_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054344_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 8U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___070709_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054362_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070707_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x10U)))))))))));
    vlSelf->wasmetal_core__DOT___070708_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070707_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054362_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x10U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___070724_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054380_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070722_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x18U)))))))))));
    vlSelf->wasmetal_core__DOT___070723_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070722_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054380_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x18U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___070739_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054398_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x20U)))))))))));
    vlSelf->wasmetal_core__DOT___070738_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070737_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054398_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x20U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT___070754_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054416_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070752_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x28U)))))))))));
    vlSelf->wasmetal_core__DOT___070753_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070752_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054416_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x28U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___070769_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054434_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070767_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b54__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x30U)))))))))));
    vlSelf->wasmetal_core__DOT___070768_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070767_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054434_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x30U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b54__05d)))))))));
    vlSelf->wasmetal_core__DOT___070787_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054326_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070785_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 3U)))))))))));
    vlSelf->wasmetal_core__DOT___070786_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070785_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054326_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 3U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___070792_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054332_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070790_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 6U)))))))))));
    vlSelf->wasmetal_core__DOT___070791_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070790_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054332_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 6U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___070802_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054349_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070800_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xbU)))))))))));
    vlSelf->wasmetal_core__DOT___070801_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070800_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054349_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xbU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___070807_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054355_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070805_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xeU)))))))))));
    vlSelf->wasmetal_core__DOT___070806_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070805_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054355_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xeU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___070817_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054367_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070815_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b21__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x13U)))))))))));
    vlSelf->wasmetal_core__DOT___070816_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070815_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054367_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x13U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___070822_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054373_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070820_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b24__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x16U)))))))))));
    vlSelf->wasmetal_core__DOT___070821_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070820_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054373_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x16U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___070832_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054385_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070830_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1bU)))))))))));
    vlSelf->wasmetal_core__DOT___070831_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070830_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1bU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___070837_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054391_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070835_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1eU)))))))))));
    vlSelf->wasmetal_core__DOT___070836_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070835_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054391_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1eU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT___070847_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054403_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070845_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x23U)))))))))));
    vlSelf->wasmetal_core__DOT___070846_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070845_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054403_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x23U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___070852_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054409_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070850_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x26U)))))))))));
    vlSelf->wasmetal_core__DOT___070851_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070850_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054409_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x26U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___070862_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054421_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070860_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b48__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2bU)))))))))));
    vlSelf->wasmetal_core__DOT___070861_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070860_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054421_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2bU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___070867_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054427_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070865_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b51__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2eU)))))))))));
    vlSelf->wasmetal_core__DOT___070866_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070865_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054427_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2eU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT___070877_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054439_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070875_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b57__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x33U)))))))))));
    vlSelf->wasmetal_core__DOT___070876_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070875_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054439_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x33U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b57__05d)))))))));
    vlSelf->wasmetal_core__DOT___070882_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054445_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070880_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x36U)))))))))));
    vlSelf->wasmetal_core__DOT___070881_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070880_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054445_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x36U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___070797_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054343_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070795_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 8U)))))))))));
    vlSelf->wasmetal_core__DOT___070796_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070795_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054343_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 8U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___070812_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070810_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x10U)))))))))));
    vlSelf->wasmetal_core__DOT___070811_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070810_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054361_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x10U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___070827_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054379_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070825_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x18U)))))))))));
    vlSelf->wasmetal_core__DOT___070826_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070825_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054379_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x18U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___070842_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054397_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070840_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x20U)))))))))));
    vlSelf->wasmetal_core__DOT___070841_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070840_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054397_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x20U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT___070857_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054415_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070855_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x28U)))))))))));
    vlSelf->wasmetal_core__DOT___070856_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070855_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054415_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x28U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___070872_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054433_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070870_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b54__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x30U)))))))))));
    vlSelf->wasmetal_core__DOT___070871_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054433_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x30U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b54__05d)))))))));
    vlSelf->wasmetal_core__DOT___052705_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045321_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h568bee24__0))));
    vlSelf->wasmetal_core__DOT___045491_ = (1U & (IData)(
                                                         (0xfffefeeefeeefeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071405_) 
                                                            << 4U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071404_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___045515_ = (1U & (IData)(
                                                         (0x1010000101000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071405_) 
                                                            << 3U) 
                                                           | ((IData)(vlSelf->wasmetal_core__DOT___071404_) 
                                                              << 2U)))));
    vlSelf->wasmetal_core__DOT___045483_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071385_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071384_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071383_))))));
    vlSelf->wasmetal_core__DOT___045507_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071385_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071384_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071383_))))));
    vlSelf->wasmetal_core__DOT___045484_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071388_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071387_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071386_))))));
    vlSelf->wasmetal_core__DOT___045508_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071388_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071387_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071386_))))));
    vlSelf->wasmetal_core__DOT___045485_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071391_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071390_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071389_))))));
    vlSelf->wasmetal_core__DOT___045509_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071391_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071390_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071389_))))));
    vlSelf->wasmetal_core__DOT___045486_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071394_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071393_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071392_))))));
    vlSelf->wasmetal_core__DOT___045510_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071394_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071393_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071392_))))));
    vlSelf->wasmetal_core__DOT___045487_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071397_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071396_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071395_))))));
    vlSelf->wasmetal_core__DOT___045511_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071397_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071396_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071395_))))));
    vlSelf->wasmetal_core__DOT___045488_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071400_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071399_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071398_))))));
    vlSelf->wasmetal_core__DOT___045512_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071400_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071399_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071398_))))));
    vlSelf->wasmetal_core__DOT___045490_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071403_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071402_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071401_))))));
    vlSelf->wasmetal_core__DOT___045514_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071403_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071402_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___071401_))))));
    vlSelf->wasmetal_core__DOT___070026_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053071_))));
    vlSelf->wasmetal_core__DOT___062617_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062629_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128255___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062640_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128255___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062651_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128255___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062662_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128255___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062673_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128256___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062684_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128256___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062695_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128256___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062706_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128256___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062717_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128257___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062728_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128257___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062739_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128257___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062750_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128257___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062761_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128258___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062772_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128258___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062783_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128258___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062794_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128258___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062805_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128259___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062816_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128259___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062827_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128259___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062838_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128259___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062849_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128260___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062860_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128260___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062871_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128260___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062882_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128260___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062893_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128261___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062904_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128261___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062915_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128261___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062926_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128261___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062937_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128262___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___062948_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128262___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053989_))));
    vlSelf->wasmetal_core__DOT___007207_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007194_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007190_))));
    vlSelf->wasmetal_core__DOT___052853_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xff01ffffffffffffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((0xfffeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                           << 3U)) 
                                                                       | ((4U 
                                                                           & ((0x1000U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___000366_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052851_))));
    vlSelf->wasmetal_core__DOT___063095_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb2eda61f__0))));
    vlSelf->wasmetal_core__DOT___063293_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0))));
    vlSelf->wasmetal_core__DOT___063295_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))));
    vlSelf->wasmetal_core__DOT___063297_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))));
    vlSelf->wasmetal_core__DOT___063299_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))));
    vlSelf->wasmetal_core__DOT___063301_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))));
    vlSelf->wasmetal_core__DOT___063303_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))));
    vlSelf->wasmetal_core__DOT___063305_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))));
    vlSelf->wasmetal_core__DOT___063307_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc231438f__0))));
    vlSelf->wasmetal_core__DOT___063309_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))));
    vlSelf->wasmetal_core__DOT___063311_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))));
    vlSelf->wasmetal_core__DOT___063313_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))));
    vlSelf->wasmetal_core__DOT___063315_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))));
    vlSelf->wasmetal_core__DOT___063317_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))));
    vlSelf->wasmetal_core__DOT___063319_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h132c3402__0))));
    vlSelf->wasmetal_core__DOT___063321_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hac359f24__0))));
    vlSelf->wasmetal_core__DOT___063323_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))));
    vlSelf->wasmetal_core__DOT___063325_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))));
    vlSelf->wasmetal_core__DOT___063327_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))));
    vlSelf->wasmetal_core__DOT___063329_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0))));
    vlSelf->wasmetal_core__DOT___063331_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0))));
    vlSelf->wasmetal_core__DOT___063333_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0))));
    vlSelf->wasmetal_core__DOT___063335_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8df5578a__0))));
    vlSelf->wasmetal_core__DOT___063337_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3378cabf__0))));
    vlSelf->wasmetal_core__DOT___063339_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h139d3776__0))));
    vlSelf->wasmetal_core__DOT___063341_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0))));
    vlSelf->wasmetal_core__DOT___063343_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h56116db4__0))));
    vlSelf->wasmetal_core__DOT___063345_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0))));
    vlSelf->wasmetal_core__DOT___063347_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0))));
    vlSelf->wasmetal_core__DOT___063349_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0))));
    vlSelf->wasmetal_core__DOT___063351_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h46733dea__0))));
    vlSelf->wasmetal_core__DOT___063353_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8696f73b__0))));
    vlSelf->wasmetal_core__DOT___063101_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h47317805__0))));
    vlSelf->wasmetal_core__DOT___063107_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h989e4977__0))));
    vlSelf->wasmetal_core__DOT___063113_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf0092dd5__0))));
    vlSelf->wasmetal_core__DOT___063119_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8b5bebff__0))));
    vlSelf->wasmetal_core__DOT___063125_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1656da2e__0))));
    vlSelf->wasmetal_core__DOT___063131_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1048f6d3__0))));
    vlSelf->wasmetal_core__DOT___063137_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1ea91d16__0))));
    vlSelf->wasmetal_core__DOT___063143_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6a7f974d__0))));
    vlSelf->wasmetal_core__DOT___063149_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcc9d97e7__0))));
    vlSelf->wasmetal_core__DOT___063155_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4172973d__0))));
    vlSelf->wasmetal_core__DOT___063161_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0585c3f4__0))));
    vlSelf->wasmetal_core__DOT___063167_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h840c74b0__0))));
    vlSelf->wasmetal_core__DOT___063173_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5bc17448__0))));
    vlSelf->wasmetal_core__DOT___063179_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h88a0d3a9__0))));
    vlSelf->wasmetal_core__DOT___063185_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5e46481a__0))));
    vlSelf->wasmetal_core__DOT___063191_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h652edcf1__0))));
    vlSelf->wasmetal_core__DOT___063197_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha8cefda7__0))));
    vlSelf->wasmetal_core__DOT___063203_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h95830544__0))));
    vlSelf->wasmetal_core__DOT___063209_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4d6951f5__0))));
    vlSelf->wasmetal_core__DOT___063215_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8476215a__0))));
    vlSelf->wasmetal_core__DOT___063221_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf1e329c9__0))));
    vlSelf->wasmetal_core__DOT___063227_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h434b0db3__0))));
    vlSelf->wasmetal_core__DOT___063233_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3e1a5258__0))));
    vlSelf->wasmetal_core__DOT___063239_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8670d2e8__0))));
    vlSelf->wasmetal_core__DOT___063245_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h975aebd1__0))));
    vlSelf->wasmetal_core__DOT___063251_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6e881f1b__0))));
    vlSelf->wasmetal_core__DOT___063257_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbaf6c8a7__0))));
    vlSelf->wasmetal_core__DOT___063263_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbf5b2f76__0))));
    vlSelf->wasmetal_core__DOT___063269_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9206c0aa__0))));
    vlSelf->wasmetal_core__DOT___063275_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hec1752e3__0))));
    vlSelf->wasmetal_core__DOT___063281_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))));
    vlSelf->wasmetal_core__DOT___063287_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))));
    vlSelf->__VdfgTmp_h4abf7b91__0 = (((IData)(vlSelf->wasmetal_core__DOT___048367_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___048443_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048270_)));
    vlSelf->wasmetal_core__DOT___064514_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___069095_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048339_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007031_)))));
    vlSelf->wasmetal_core__DOT___069144_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048339_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007031_)))));
    vlSelf->__VdfgTmp_h3eb9c9bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___052905_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050435_));
    vlSelf->wasmetal_core__DOT___007196_ = (1U & (IData)(
                                                         (0x1f00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053755_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053754_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048446_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010007_)))))))));
    vlSelf->wasmetal_core__DOT___072270_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052902_))));
    vlSelf->wasmetal_core__DOT___007193_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053781_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053780_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053779_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053778_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053777_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053776_)))))))));
    vlSelf->wasmetal_core__DOT___052907_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052906_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052905_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d 
        = (1U & (0x8000U >> (((IData)(vlSelf->wasmetal_core__DOT___007058_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___048475_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___048467_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048464_))))));
    vlSelf->wasmetal_core__DOT__divider__02eremainder_op 
        = (1U & (IData)((0xf888ffff00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052746_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048343_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048365_)))))))));
    vlSelf->wasmetal_core__DOT___052903_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052901_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052900_))));
    vlSelf->wasmetal_core__DOT___063857_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048312_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007031_))));
    vlSelf->wasmetal_core__DOT___048332_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048313_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048312_)))));
    vlSelf->wasmetal_core__DOT___054541_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052584_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))))));
    vlSelf->wasmetal_core__DOT___054187_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054036_))));
    vlSelf->wasmetal_core__DOT___053095_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052681_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052645_))));
    vlSelf->wasmetal_core__DOT___052683_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052681_))));
    vlSelf->wasmetal_core__DOT___052706_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052678_))));
    vlSelf->wasmetal_core__DOT___052680_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fifth_ready))));
    vlSelf->wasmetal_core__DOT___048518_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048514_))));
    vlSelf->wasmetal_core__DOT___007055_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048401_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048400_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048316_)))));
    vlSelf->wasmetal_core__DOT___052847_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052845_))));
    vlSelf->wasmetal_core__DOT___062496_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052896_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052893_))));
    vlSelf->wasmetal_core__DOT___052913_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052893_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052892_))));
    vlSelf->wasmetal_core__DOT___054746_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054744_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048448_))));
    vlSelf->wasmetal_core__DOT___060719_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019246_))));
    vlSelf->wasmetal_core__DOT___019323_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_x 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054677_))));
    vlSelf->wasmetal_core__DOT___009643_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->insn_x 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & (vlSelf->insn_op 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___009642_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & vlSelf->insn_x) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8cb32961__0))))));
    vlSelf->wasmetal_core__DOT___054696_ = (1U & (IData)(
                                                         (0xf0fbbbb00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048453_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_x 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbec427aa__0))))))));
    vlSelf->wasmetal_core__DOT___054685_ = (1U & (IData)(
                                                         (0xefffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054677_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (0xfU 
                                                                    & (vlSelf->insn_x 
                                                                       >> 0xfU))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054680_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054679_) 
                                                                     << 2U) 
                                                                    | (3U 
                                                                       & (vlSelf->insn_x 
                                                                          >> 0x1bU)))))))));
    vlSelf->wasmetal_core__DOT___009543_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053367_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053009_)))));
    vlSelf->wasmetal_core__DOT___060664_ = (1U & (0x5ff01fbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007060_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048448_)))))));
    vlSelf->wasmetal_core__DOT___060655_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007060_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019246_))));
    vlSelf->wasmetal_core__DOT___050451_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050397_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050449_))));
    vlSelf->wasmetal_core__DOT___053350_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052889_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052892_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052886_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052884_))))));
    vlSelf->wasmetal_core__DOT___063446_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052884_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052897_))));
    vlSelf->wasmetal_core__DOT___061645_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061644_))));
    vlSelf->wasmetal_core__DOT___061653_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048401_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061644_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048513_)))));
    vlSelf->wasmetal_core__DOT___061646_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061644_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048514_)))));
    vlSelf->wasmetal_core__DOT___062618_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062630_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062641_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128593___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128018___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062652_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O))))))))));
    vlSelf->wasmetal_core__DOT___062663_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062674_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062685_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128594___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128019___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062696_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O))))))))));
    vlSelf->wasmetal_core__DOT___062707_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062718_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062729_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128595___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128020___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062740_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O))))))))));
    vlSelf->wasmetal_core__DOT___062751_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062762_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062773_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128596___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128021___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062784_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O))))))))));
    vlSelf->wasmetal_core__DOT___062795_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062806_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062817_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062828_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O))))))))));
    vlSelf->wasmetal_core__DOT___062839_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062850_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062861_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062872_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O))))))))));
    vlSelf->wasmetal_core__DOT___062883_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062894_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062905_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___062916_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O))))))))));
    vlSelf->wasmetal_core__DOT___062927_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___062938_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___062949_ = (1U & (IData)(
                                                         (0xfff07770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052879_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052645_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___052915_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048279_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052879_))));
    vlSelf->wasmetal_core__DOT___053351_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052900_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052882_))));
    vlSelf->wasmetal_core__DOT___064476_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048372_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007033_))));
    vlSelf->__VdfgTmp_ha5ccee3f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007032_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048369_));
    vlSelf->__VdfgTmp_h42143724__0 = (((IData)(vlSelf->wasmetal_core__DOT___007032_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___048339_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048369_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007031_))));
    vlSelf->wasmetal_core__DOT___063855_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048319_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007032_))));
    vlSelf->wasmetal_core__DOT___007191_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x1515153fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052904_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010007_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___000375_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053762_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053761_)))));
    vlSelf->wasmetal_core__DOT___019204_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048441_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048360_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048323_)))));
    vlSelf->wasmetal_core__DOT___007043_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048443_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048442_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048441_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048306_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048304_)))))));
    vlSelf->wasmetal_core__DOT___063999_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007036_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007035_))));
    vlSelf->wasmetal_core__DOT___048355_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048342_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048341_))));
    vlSelf->wasmetal_core__DOT___007192_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053770_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053769_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053768_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053767_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053766_)))))));
    vlSelf->wasmetal_core__DOT___064466_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053012_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052895_))));
    vlSelf->wasmetal_core__DOT___052910_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052896_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052895_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052894_)))));
    vlSelf->wasmetal_core__DOT___054745_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048442_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007054_))));
    vlSelf->__VdfgTmp_h27b70ff4__0 = (((IData)(vlSelf->wasmetal_core__DOT___048357_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007034_));
    vlSelf->wasmetal_core__DOT___066281_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048348_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065609_))));
    vlSelf->wasmetal_core__DOT___033032_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048446_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054146_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054145_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054144_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048407_)))))));
    vlSelf->__VdfgTmp_h058312bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___048334_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019396_));
    vlSelf->__VdfgTmp_ha02e1627__0 = (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019396_));
    vlSelf->wasmetal_core__DOT___019293_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019336_))));
    vlSelf->wasmetal_core__DOT___019291_ = (1U & (0xfff80000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048416_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055311_)))))));
    vlSelf->wasmetal_core__DOT___019278_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048448_))));
    vlSelf->wasmetal_core__DOT___007195_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x1515153fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053757_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048365_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002984_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___000375_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053758_))));
    vlSelf->wasmetal_core__DOT___063856_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048352_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048333_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063854_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048348_))))));
    vlSelf->wasmetal_core__DOT___065612_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063854_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048339_))));
    vlSelf->wasmetal_core__DOT___019385_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048370_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064017_))));
    vlSelf->wasmetal_core__DOT___048471_ = (1U & (IData)(
                                                         (0x1f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048470_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048407_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048383_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048284_)))))))));
    vlSelf->wasmetal_core__DOT___051252_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048476_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048455_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048466_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048454_))))));
    vlSelf->wasmetal_core__DOT___048271_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045652_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044072_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___045662_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___044082_))))));
    vlSelf->wasmetal_core__DOT___048280_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045734_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044220_))));
    vlSelf->wasmetal_core__DOT___030686_ = (1U & (0x78U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003147_)))));
    vlSelf->wasmetal_core__DOT___048022_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7e49e6e6__0))))));
    vlSelf->wasmetal_core__DOT___048021_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc5249891__0))))));
    vlSelf->wasmetal_core__DOT___048136_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h5bb31d88__0))))));
    vlSelf->wasmetal_core__DOT___048138_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h37d1cc77__0))))));
    vlSelf->wasmetal_core__DOT___048039_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_heecb7e70__0))))));
    vlSelf->wasmetal_core__DOT___048035_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb773d3a6__0)))));
    vlSelf->wasmetal_core__DOT___048152_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd9d86825__0))))));
    vlSelf->wasmetal_core__DOT___048151_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h99694808__0)))));
    vlSelf->wasmetal_core__DOT___005496_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3fce9550__0))))));
    vlSelf->wasmetal_core__DOT___005436_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_he61be2d5__0))))));
    vlSelf->wasmetal_core__DOT___048030_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hfb5e3b7e__0))))));
    vlSelf->wasmetal_core__DOT___048029_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4a4b1d7e__0)))));
    vlSelf->wasmetal_core__DOT___005446_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h630336df__0))))));
    vlSelf->wasmetal_core__DOT___005389_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6b4c794b__0))))));
    vlSelf->wasmetal_core__DOT___005387_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h82a219c8__0)))));
    vlSelf->wasmetal_core__DOT___005399_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3d9b9896__0))))));
    vlSelf->wasmetal_core__DOT___005409_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h79077a59__0))))));
    vlSelf->wasmetal_core__DOT___005407_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h15e8b450__0)))));
    vlSelf->wasmetal_core__DOT___005419_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h13f17749__0))))));
    vlSelf->wasmetal_core__DOT___005417_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hffec0e42__0)))));
    vlSelf->wasmetal_core__DOT___047989_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd2cb6624__0))))));
    vlSelf->wasmetal_core__DOT___048156_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1d47507a__0))))));
    vlSelf->wasmetal_core__DOT___048155_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcab9d929__0)))));
    vlSelf->wasmetal_core__DOT___005456_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h8b941ffe__0))))));
    vlSelf->wasmetal_core__DOT___005454_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h39540d35__0)))));
    vlSelf->wasmetal_core__DOT___048013_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h9b6447c0__0))))));
    vlSelf->wasmetal_core__DOT___048015_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2996e40e__0)))));
    vlSelf->wasmetal_core__DOT___048066_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h41785ae8__0))))));
    vlSelf->wasmetal_core__DOT___048065_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hae88697a__0)))));
    vlSelf->wasmetal_core__DOT___048195_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h88d138aa__0))))));
    vlSelf->wasmetal_core__DOT___048194_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd822ef23__0)))));
    vlSelf->wasmetal_core__DOT___005466_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha2c9478b__0))))));
    vlSelf->wasmetal_core__DOT___005464_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3ff94b24__0)))));
    vlSelf->wasmetal_core__DOT___048070_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h29fb25ab__0))))));
    vlSelf->wasmetal_core__DOT___048069_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h62980089__0)))));
    vlSelf->wasmetal_core__DOT___005476_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1bb342d2__0))))));
    vlSelf->wasmetal_core__DOT___005474_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7c65fb3__0)))));
    vlSelf->wasmetal_core__DOT___005486_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h90194312__0))))));
    vlSelf->wasmetal_core__DOT___005484_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h426f01c6__0)))));
    vlSelf->wasmetal_core__DOT___048175_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h15796065__0))))));
    vlSelf->wasmetal_core__DOT___048174_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h93789414__0)))));
    vlSelf->wasmetal_core__DOT___048244_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hec648199__0))))));
    vlSelf->wasmetal_core__DOT___048243_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0989e186__0)))));
    vlSelf->wasmetal_core__DOT___048231_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2b63e99d__0))))));
    vlSelf->wasmetal_core__DOT___048233_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h35d7421d__0)))));
    vlSelf->wasmetal_core__DOT___048177_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h45f8df98__0))))));
    vlSelf->wasmetal_core__DOT___048180_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1d8dd092__0)))));
    vlSelf->wasmetal_core__DOT___048258_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hfaaa855f__0))))));
    vlSelf->wasmetal_core__DOT___048257_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h81d9a883__0)))));
    vlSelf->wasmetal_core__DOT___048183_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h331e01c9__0))))));
    vlSelf->wasmetal_core__DOT___048182_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h69cbf44b__0)))));
    vlSelf->wasmetal_core__DOT___048198_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2cf790ef__0))))));
    vlSelf->wasmetal_core__DOT___048200_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7b1a2166__0)))));
    vlSelf->wasmetal_core__DOT___048238_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h62281c26__0))))));
    vlSelf->wasmetal_core__DOT___048241_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3063303a__0)))));
    vlSelf->wasmetal_core__DOT___048003_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf772eecc__0))))));
    vlSelf->wasmetal_core__DOT___048007_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbfbeb842__0))))));
    vlSelf->wasmetal_core__DOT___048171_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h22e3dba7__0))))));
    vlSelf->wasmetal_core__DOT___048170_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb653ab3a__0)))));
    vlSelf->wasmetal_core__DOT___048262_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7482f819__0))))));
    vlSelf->wasmetal_core__DOT___048261_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h38c61391__0)))));
    vlSelf->wasmetal_core__DOT___048186_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf7e0ef4b__0))))));
    vlSelf->wasmetal_core__DOT___048188_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc1bc9aa3__0)))));
    vlSelf->wasmetal_core__DOT___048235_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h31491600__0))))));
    vlSelf->wasmetal_core__DOT___048237_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h60633cb7__0)))));
    vlSelf->wasmetal_core__DOT___048190_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h19aa2548__0))))));
    vlSelf->wasmetal_core__DOT___048192_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haaaaa9f9__0)))));
    vlSelf->wasmetal_core__DOT___048695_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_he8484823__0))))));
    vlSelf->wasmetal_core__DOT___048694_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h808c51bd__0)))));
    vlSelf->wasmetal_core__DOT___048010_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf123ec52__0))))));
    vlSelf->wasmetal_core__DOT___048009_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4781af3e__0)))));
    vlSelf->wasmetal_core__DOT___048074_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h29035176__0))))));
    vlSelf->wasmetal_core__DOT___048073_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf275be9a__0)))));
    vlSelf->wasmetal_core__DOT___048017_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6332189a__0))))));
    vlSelf->wasmetal_core__DOT___048019_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h58ec7cd3__0)))));
    vlSelf->wasmetal_core__DOT___048140_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd87a9123__0))))));
    vlSelf->wasmetal_core__DOT___048142_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h76eadb80__0)))));
    vlSelf->wasmetal_core__DOT___048042_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h98759836__0))))));
    vlSelf->wasmetal_core__DOT___048041_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5a48cd94__0)))));
    vlSelf->wasmetal_core__DOT___048059_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_he8c28620__0))))));
    vlSelf->wasmetal_core__DOT___048058_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hba3bfb32__0)))));
    vlSelf->wasmetal_core__DOT___048046_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2b07b055__0))))));
    vlSelf->wasmetal_core__DOT___048045_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb2af30db__0)))));
    vlSelf->wasmetal_core__DOT___003031_ = (1U & (IData)(
                                                         (0x40ff000000ff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047988_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (vlSelf->insn_op 
                                                                                >> 0x1aU))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (3U 
                                                                              & (vlSelf->insn_op 
                                                                                >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___042542_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042590_))));
    vlSelf->wasmetal_core__DOT___053014_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053012_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053011_))));
    vlSelf->__VdfgTmp_h44c20413__0 = (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___044240_));
    vlSelf->wasmetal_core__DOT___051199_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050366_))));
    vlSelf->wasmetal_core__DOT___062497_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050381_))));
    vlSelf->wasmetal_core__DOT___051220_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050381_))));
    vlSelf->__VdfgTmp_h8a2b49a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050381_));
    vlSelf->wasmetal_core__DOT___047785_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002967_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002966_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002965_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002964_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002963_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002968_)))))))));
    vlSelf->wasmetal_core__DOT___003146_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002967_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047795_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___047792_)))))));
    vlSelf->wasmetal_core__DOT___009501_ = ((IData)(vlSelf->wasmetal_core__DOT___002969_) 
                                            & (IData)(
                                                      (0x8000000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___002968_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002967_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002966_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002965_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002964_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___002963_)))))))));
    vlSelf->__VdfgTmp_h50379cea__0 = ((2U & ((0x80000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___047966_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___047985_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047953_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003009_) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (0x777ffffU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                   << 4U) 
                                                                  | ((8U 
                                                                      & ((0x4000U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                                                         << 3U)) 
                                                                     | ((4U 
                                                                         & ((0x8000U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___001234_)))))))))))) 
                                             << 1U)) 
                                      | (1U & (0x80000000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___047983_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047982_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x1ffffffU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0x1000U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___002984_)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___047975_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x1110fffffffffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0))))))))))))))))));
    vlSelf->wasmetal_core__DOT___070599_ = (1U & (0xf88U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_op 
                                                          >> 5U)) 
                                                      | ((2U 
                                                          & ((0x8000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___047790_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___047953_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___047789_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___002965_))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x4000000000000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___070596_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___070595_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047975_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002977_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x777ffffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x4000U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_phase))))))))))))));
    vlSelf->wasmetal_core__DOT___047978_ = (1U & (IData)(
                                                         (0x80000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047977_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047976_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___047975_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047789_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002977_)))))))));
    vlSelf->wasmetal_core__DOT___051570_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051568_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051567_))));
    vlSelf->wasmetal_core__DOT___134151___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036767_) 
                 | (6U >> (IData)(vlSelf->__VdfgTmp_h8befad22__0))));
    vlSelf->wasmetal_core__DOT___063369_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053010_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050435_))));
    vlSelf->wasmetal_core__DOT___053016_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053010_))));
    vlSelf->wasmetal_core__DOT___028244_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))));
    vlSelf->__VdfgTmp_h7e6b8024__0 = (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052833_));
    vlSelf->wasmetal_core__DOT___028243_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hec1752e3__0))));
    vlSelf->wasmetal_core__DOT___063094_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052839_))));
    vlSelf->wasmetal_core__DOT___028241_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9206c0aa__0))));
    vlSelf->wasmetal_core__DOT___028240_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbf5b2f76__0))));
    vlSelf->wasmetal_core__DOT___028239_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbaf6c8a7__0))));
    vlSelf->wasmetal_core__DOT___028238_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6e881f1b__0))));
    vlSelf->wasmetal_core__DOT___028237_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h975aebd1__0))));
    vlSelf->wasmetal_core__DOT___062601_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052894_)))));
    vlSelf->wasmetal_core__DOT___028236_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8670d2e8__0))));
    vlSelf->wasmetal_core__DOT___028235_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3e1a5258__0))));
    vlSelf->wasmetal_core__DOT___028234_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h434b0db3__0))));
    vlSelf->wasmetal_core__DOT___028233_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf1e329c9__0))));
    vlSelf->wasmetal_core__DOT___028232_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8476215a__0))));
    vlSelf->wasmetal_core__DOT___028230_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4d6951f5__0))));
    vlSelf->wasmetal_core__DOT___028229_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h95830544__0))));
    vlSelf->wasmetal_core__DOT___028228_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha8cefda7__0))));
    vlSelf->wasmetal_core__DOT___028227_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h652edcf1__0))));
    vlSelf->wasmetal_core__DOT___028226_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5e46481a__0))));
    vlSelf->wasmetal_core__DOT___028225_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h88a0d3a9__0))));
    vlSelf->wasmetal_core__DOT___028224_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5bc17448__0))));
    vlSelf->wasmetal_core__DOT___028223_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h840c74b0__0))));
    vlSelf->wasmetal_core__DOT___028222_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0585c3f4__0))));
    vlSelf->wasmetal_core__DOT___028221_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4172973d__0))));
    vlSelf->wasmetal_core__DOT___028251_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcc9d97e7__0))));
    vlSelf->wasmetal_core__DOT___028250_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6a7f974d__0))));
    vlSelf->wasmetal_core__DOT___028249_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1ea91d16__0))));
    vlSelf->wasmetal_core__DOT___028248_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1048f6d3__0))));
    vlSelf->wasmetal_core__DOT___028247_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1656da2e__0))));
    vlSelf->wasmetal_core__DOT___028246_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8b5bebff__0))));
    vlSelf->wasmetal_core__DOT___028245_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf0092dd5__0))));
    vlSelf->wasmetal_core__DOT___028242_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h989e4977__0))));
    vlSelf->wasmetal_core__DOT___028231_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h47317805__0))));
    vlSelf->wasmetal_core__DOT___028220_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb2eda61f__0))));
    vlSelf->__VdfgTmp_h9c6bfb0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052880_));
    vlSelf->wasmetal_core__DOT___053568_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052880_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050430_))));
    vlSelf->wasmetal_core__DOT___053511_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052677_))));
    vlSelf->wasmetal_core__DOT___063363_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052836_))));
    vlSelf->__VdfgTmp_h5c8f7b91__0 = (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052839_));
    vlSelf->wasmetal_core__DOT___052885_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052881_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052880_))));
    vlSelf->wasmetal_core__DOT___053567_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052888_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052881_))));
    vlSelf->wasmetal_core__DOT___052911_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052899_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052898_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052897_)))));
    vlSelf->wasmetal_core__DOT___053089_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051200_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050366_))));
    vlSelf->wasmetal_core__DOT___063787_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053367_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hced715c6__0))));
    vlSelf->wasmetal_core__DOT___052644_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hced715c6__0))));
    vlSelf->wasmetal_core__DOT___071467_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_heb46fbcb__0))));
    vlSelf->wasmetal_core__DOT___071468_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h48de7988__0))));
    vlSelf->wasmetal_core__DOT___071446_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2535fff2__0))));
    vlSelf->wasmetal_core__DOT___071447_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hed7c6d19__0))));
    vlSelf->wasmetal_core__DOT___071448_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha300b05f__0))));
    vlSelf->wasmetal_core__DOT___071449_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h17228d9d__0))));
    vlSelf->wasmetal_core__DOT___071450_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7ee7d44c__0))));
    vlSelf->wasmetal_core__DOT___071451_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha431143d__0))));
    vlSelf->wasmetal_core__DOT___071452_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd266b697__0))));
    vlSelf->wasmetal_core__DOT___071453_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h123a295b__0))));
    vlSelf->wasmetal_core__DOT___071454_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h73075b94__0))));
    vlSelf->wasmetal_core__DOT___071455_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he372c179__0))));
    vlSelf->wasmetal_core__DOT___071456_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8fd79857__0))));
    vlSelf->wasmetal_core__DOT___071457_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb3e6303e__0))));
    vlSelf->wasmetal_core__DOT___071458_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1bbfb27a__0))));
    vlSelf->wasmetal_core__DOT___071459_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8d7f942c__0))));
    vlSelf->wasmetal_core__DOT___071460_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8a6dc29d__0))));
    vlSelf->wasmetal_core__DOT___071461_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h86abd4f4__0))));
    vlSelf->wasmetal_core__DOT___071462_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h966a07d3__0))));
    vlSelf->wasmetal_core__DOT___071463_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbceb8814__0))));
    vlSelf->wasmetal_core__DOT___071464_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8a64daef__0))));
    vlSelf->wasmetal_core__DOT___071465_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h966312d4__0))));
    vlSelf->wasmetal_core__DOT___071466_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5dc57786__0))));
    vlSelf->wasmetal_core__DOT___071410_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd8bdfcc6__0))));
    vlSelf->wasmetal_core__DOT___071411_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0bf68f44__0))));
    vlSelf->wasmetal_core__DOT___071412_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7e0b807__0))));
    vlSelf->wasmetal_core__DOT___071413_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8649aac__0))));
    vlSelf->wasmetal_core__DOT___071414_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd389bfd2__0))));
    vlSelf->wasmetal_core__DOT___071415_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he127cdd2__0))));
    vlSelf->wasmetal_core__DOT___071422_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h65437cee__0))));
    vlSelf->wasmetal_core__DOT___071423_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4c7f02d9__0))));
    vlSelf->wasmetal_core__DOT___071424_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h83bd92c8__0))));
    vlSelf->wasmetal_core__DOT___071425_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1915a5ff__0))));
    vlSelf->wasmetal_core__DOT___071426_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h70b63d5e__0))));
    vlSelf->wasmetal_core__DOT___071427_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf6358f59__0))));
    vlSelf->wasmetal_core__DOT___071434_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdf9c0a20__0))));
    vlSelf->wasmetal_core__DOT___071435_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he08c96ba__0))));
    vlSelf->wasmetal_core__DOT___071436_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h370a9404__0))));
    vlSelf->wasmetal_core__DOT___071437_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1473a3fc__0))));
    vlSelf->wasmetal_core__DOT___071438_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbbedaddf__0))));
    vlSelf->wasmetal_core__DOT___071439_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h098d62f8__0))));
    vlSelf->wasmetal_core__DOT___071443_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc1d04e55__0))));
    vlSelf->wasmetal_core__DOT___071444_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha31457b4__0))));
    vlSelf->wasmetal_core__DOT___071445_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3006d0f0__0))));
    vlSelf->wasmetal_core__DOT___071406_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5dfde09f__0))));
    vlSelf->wasmetal_core__DOT___071407_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h31b47573__0))));
    vlSelf->wasmetal_core__DOT___071408_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedf8c8b5__0))));
    vlSelf->wasmetal_core__DOT___071409_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbba81ae3__0))));
    vlSelf->wasmetal_core__DOT___071416_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0201c3e9__0))));
    vlSelf->wasmetal_core__DOT___071417_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbc582c17__0))));
    vlSelf->wasmetal_core__DOT___071418_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h670f6b42__0))));
    vlSelf->wasmetal_core__DOT___071419_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4dc6a706__0))));
    vlSelf->wasmetal_core__DOT___071420_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h978cb234__0))));
    vlSelf->wasmetal_core__DOT___071421_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfb8717f5__0))));
    vlSelf->wasmetal_core__DOT___071428_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9685a33e__0))));
    vlSelf->wasmetal_core__DOT___071429_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hee7ba675__0))));
    vlSelf->wasmetal_core__DOT___071430_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5b1f350b__0))));
    vlSelf->wasmetal_core__DOT___071431_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2c74d244__0))));
    vlSelf->wasmetal_core__DOT___071432_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf5aac232__0))));
    vlSelf->wasmetal_core__DOT___071433_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h852d6a23__0))));
    vlSelf->wasmetal_core__DOT___071440_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0919c673__0))));
    vlSelf->wasmetal_core__DOT___071441_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc7238523__0))));
    vlSelf->wasmetal_core__DOT___071442_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0ba16cdb__0))));
    vlSelf->__VdfgTmp_h2157de83__0 = (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___062976_));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b1__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hc52368c6__0))));
    vlSelf->wasmetal_core__DOT___053973_ = (1U & (0xdd0db0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_x 
                                                          >> 8U)) 
                                                      | ((6U 
                                                          & (vlSelf->insn_y 
                                                             >> 9U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_x 
                                                               >> 0xaU)))))));
    vlSelf->wasmetal_core__DOT___053966_ = (1U & (0xdd0db0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x11U)) 
                                                      | ((4U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x12U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h94eb0193__0))))));
    vlSelf->wasmetal_core__DOT___053980_ = (1U & (0xdd0db0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_x 
                                                          >> 0x1cU)) 
                                                      | ((4U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1dU)) 
                                                         | ((2U 
                                                             & (vlSelf->insn_y 
                                                                >> 0x19U)) 
                                                            | (1U 
                                                               & (vlSelf->insn_x 
                                                                  >> 0x1aU))))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b7__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hd0f5eb35__0))));
    vlSelf->wasmetal_core__DOT___050764_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 6U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 7U))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b5__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hd6f0d46f__0))));
    vlSelf->wasmetal_core__DOT___049400_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 4U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 5U))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b2__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hefae6eba__0))));
    vlSelf->wasmetal_core__DOT___048524_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b3__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hec90fad7__0))));
    vlSelf->wasmetal_core__DOT___048526_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b0__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hc3828814__0))));
    vlSelf->wasmetal_core__DOT___048522_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          << 1U)) 
                                                      | (1U 
                                                         & vlSelf->insn_x)))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b6__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hd3ff3db1__0))));
    vlSelf->wasmetal_core__DOT___050766_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 5U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 6U))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b4__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he98db662__0))));
    vlSelf->wasmetal_core__DOT___049402_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 3U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 4U))))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b14__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1a8ff62f__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b15__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h19a3d105__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b16__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h134dac5a__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b18__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h3c4e434c__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b19__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h3d708201__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b20__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h2660b6cc__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b21__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h273da3c5__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b24__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he4692376__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b26__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h3a2be217__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b27__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he16c95bc__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b31__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h26a9e557__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b10__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h16f85c0c__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b8__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hedbed4ea__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b22__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he08305af__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b29__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h272aca04__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b25__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_heb8306fa__0))));
    vlSelf->__VdfgTmp_he7cea807__0 = (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h265c757d__0));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b23__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he580b887__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b17__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he366744c__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b28__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he081d797__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b9__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_heb713746__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b12__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h10bdd4bc__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b13__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1fc2f2ef__0))));
    vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b1__05d__02eindex__05b11__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1585cf87__0))));
    vlSelf->wasmetal_core__DOT___050924_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1eU)) 
                                                      | (vlSelf->insn_x 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___050945_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h94eb0193__0))));
    vlSelf->wasmetal_core__DOT___050947_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0xfU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x10U))))));
    vlSelf->wasmetal_core__DOT___050959_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 7U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 8U))))));
    vlSelf->wasmetal_core__DOT___050952_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x15U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x16U))))));
    vlSelf->wasmetal_core__DOT___050937_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1cU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x1dU))))));
    vlSelf->wasmetal_core__DOT___050927_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x18U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x19U))))));
    vlSelf->wasmetal_core__DOT___050919_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x1bU)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x1cU))))));
    vlSelf->wasmetal_core__DOT___050950_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x16U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x17U))))));
    vlSelf->wasmetal_core__DOT___050943_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x10U)) 
                                                      | (1U 
                                                         & (vlSelf->insn_x 
                                                            >> 0x11U))))));
}
